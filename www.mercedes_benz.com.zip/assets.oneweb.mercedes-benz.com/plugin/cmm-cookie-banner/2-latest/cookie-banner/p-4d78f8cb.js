/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import {
  b as r,
  _ as n,
  C as t,
  V as e,
  U as i,
  v as s,
  a as u,
  x as a,
  D as o,
  N as c,
  c as f,
  d as h,
  P as v,
  f as p,
  I as l,
  w as d,
} from "./p-6c6818e1.js";
import "./p-a7d21f71.js";
import "./p-54a36ea4.js";
import "https://assets.oneweb.mercedes-benz.com/plugin/workbench/core/7.32.0/loader/index.js";
import "./p-c1686f45.js";
var w = (function (n) {
    function t(r, w, m) {
      var b = n.call(this, m) || this;
      return (
        (b.categorySlug = r.categorySlug),
        (b.consent = s(r, w)),
        (b.id = r.templateId),
        (b.isEssential = w.isEssential),
        (b.isHidden = !!w.isHidden || r.isHidden),
        (b.processorId = "".concat(u(a()))),
        (b.subServices = []),
        (b.subServicesLength = r.subConsents ? r.subConsents.length : 0),
        (b.usesThirdCountry = r.usesThirdCountry),
        (b.version = r.version),
        (b.fetchSubServices = function () {
          return o(b, void 0, void 0, function () {
            var n,
              s,
              u,
              a,
              o,
              m,
              b,
              j,
              x = this;
            return c(this, function (c) {
              switch (c.label) {
                case 0:
                  if (
                    ((n = h.getInstance()),
                    (s = v.getInstance()),
                    !(a = p((u = r.subConsents))).length)
                  )
                    return [2, []];
                  (m = null), (c.label = 1);
                case 1:
                  return (
                    c.trys.push([1, 4, , 5]),
                    [4, n.fetchAggregatedServices(a, !1)]
                  );
                case 2:
                  return (o = c.sent()), [4, n.fetchTranslations()];
                case 3:
                  return (m = c.sent()), [3, 5];
                case 4:
                  throw (c.sent(), new Error(f.FETCH_DATA_PROCESSING_SERVICES));
                case 5:
                  return o && u
                    ? ((b = s.getServicesBaseInfo()),
                      (j = b.filter(function (r) {
                        return r.id === x.id;
                      })),
                      (this.subServices = u.reduce(function (r, n) {
                        var s =
                          null == o
                            ? void 0
                            : o.find(function (r) {
                                return (
                                  n.templateId === r.templateId &&
                                  n.version === r.version
                                );
                              });
                        if (!s) return e([], i(r), !1);
                        var u = new t(n, w, s);
                        return e(e([], i(r), !1), [u], !1);
                      }, [])),
                      [
                        2,
                        this.subServices.reduce(function (r, n) {
                          var t = u.find(function (r) {
                            return (
                              n.id === r.templateId && n.version === r.version
                            );
                          });
                          if (!t) return e([], i(r), !1);
                          var s = new l(t, m, o),
                            a =
                              1 === j.length
                                ? { legalBasis: j[0].legalBasis }
                                : {},
                            c = d(d(d(d({}, s), n), { subServices: [] }), a);
                          return e(e([], i(r), !1), [c], !1);
                        }, []),
                      ])
                    : [2, []];
              }
            });
          });
        }),
        b
      );
    }
    return r(t, n), t;
  })(n),
  m = function (r, n, t) {
    (this.isEssential = r.isEssential),
      (this.isHidden = r.isHidden),
      (this.services = b(r, n, t)),
      (this.slug = r.categorySlug);
  },
  b = function (r, n, t) {
    return n.reduce(function (n, s) {
      if (s.categorySlug === r.categorySlug) {
        var u =
            null == t
              ? void 0
              : t.find(function (r) {
                  return (
                    s.templateId === r.templateId && s.version === r.version
                  );
                }),
          a = new w(s, r, u);
        return e(e([], i(n), !1), [a], !1);
      }
      return e([], i(n), !1);
    }, []);
  };
export default function (r, n, s) {
  (this.categories = r.categories.reduce(function (n, u) {
    var a = new m(u, r.consentTemplates, s);
    return t(a.services) ? e(e([], i(n), !1), [a], !1) : e([], i(n), !1);
  }, [])),
    (this.controllerId = n);
}
