/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { r as t, c as e, h as n, H as i, g as r } from "./p-a7d21f71.js";
import { I as o, s, r as a, a as l, b as c, c as u } from "./p-54a36ea4.js";
import { defineCustomElements as d } from "https://assets.oneweb.mercedes-benz.com/plugin/workbench/core/7.32.0/loader/index.js";
import { g as h, a as f } from "./p-c1686f45.js";
var m;
!(function (t) {
  (t.ThreeButtons = "A"),
    (t.TwoButtonsSimple = "B"),
    (t.Categories = "C"),
    (t.Information = "D"),
    (t.SettingsPage = "SettingsPage");
})(m || (m = {}));
const b = m.ThreeButtons,
  g = class {
    constructor(n) {
      t(this, n),
        (this.trackEvent = e(this, "trackEvent", 7)),
        (this.handlerAcceptAll = void 0),
        (this.handlerDeny = void 0),
        (this.handlerToggleDetails = void 0),
        (this.handlerSaveSelection = void 0),
        (this.labels = void 0),
        (this.variant = void 0);
    }
    handleClick() {
      this.handlerToggleDetails(), this.trackEvent.emit(13);
    }
    render() {
      return (
        !(!this.labels && !this.variant) &&
        n(
          i,
          null,
          n(
            "div",
            { class: "buttons-wrapper" },
            n(
              "div",
              { class: "button-group" },
              this.variant === m.ThreeButtons &&
                n(
                  "wb7-button",
                  {
                    class: "button button--only-technically-necessary",
                    "data-test": "handle-deny-button",
                    variant: "secondary",
                    size: "s",
                    onClick: () => this.handlerDeny(),
                  },
                  this.labels?.deny
                ),
              this.variant !== m.Categories &&
                n(
                  "wb7-button",
                  {
                    class: "button button--toggle-cookie-details",
                    "data-test": "toggle-cookie-details",
                    variant: "secondary",
                    size: "s",
                    onClick: () => this.handleClick(),
                  },
                  this.labels?.toggle
                ),
              this.variant === m.Categories &&
                n(
                  "wb7-button",
                  {
                    class: "button button--confirm-selection",
                    "data-test": "handle-confirm-selection-button",
                    variant: "secondary",
                    size: "s",
                    onClick: () => this.handlerSaveSelection(),
                  },
                  this.labels?.save
                ),
              n(
                "wb7-button",
                {
                  class: "button button--accept-all",
                  "data-test": "handle-accept-all-button",
                  variant: "secondary",
                  size: "s",
                  onClick: () => this.handlerAcceptAll(),
                },
                this.variant === m.Information
                  ? this.labels?.close
                  : this.labels?.acceptAll
              )
            ),
            this.variant === m.Categories &&
              n(
                "wb7-button",
                {
                  class: "toggle-button",
                  "data-test": "toggle-cookie-details",
                  variant: "tertiary",
                  size: "s",
                  onClick: () => this.handleClick(),
                },
                n("cmm-icon", { name: o.ARROW_UP, "aria-hidden": "true" }),
                this.labels?.showDetails
              )
          )
        )
      );
    }
  };
var w;
(g.style =
  ".buttons-wrapper{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}@media screen and (min-width: 768px){.buttons-wrapper .button-group{-ms-flex-order:1;order:1}}"),
  (function (t) {
    (t.Partial = "selected-partial"),
      (t.All = "selected-all"),
      (t.None = "selected-none");
  })(w || (w = {}));
class p {
  static acceptAllConsents(t) {
    return t?.acceptAllServices();
  }
  static saveConsentSelection(t, e) {
    return t?.updateServices(e);
  }
  static denyConsentsExceptRequired(t) {
    return t?.denyAllServices();
  }
  static trackEvent(t, e) {
    return t?.setTrackingPixel({ eventType: e, abTestVariant: "" });
  }
  static getConsentsByCategory(t, e) {
    let n = [];
    return (
      t?.forEach((t) => {
        const i = t?.services?.every((t) => t?.consent?.status),
          r = {
            isEssential: t.isEssential,
            name: t.label,
            slug: t.slug,
            userAccepted: !e && i,
          };
        n = [...n, r];
      }),
      n
    );
  }
  static consentsArrayToObjectConverter(t) {
    return t?.reduce((t, e) => ({ ...t, [e?.name]: e?.enabled }), {}) || {};
  }
  static getAllConsents(t) {
    let e = [];
    return (
      t?.forEach((t) => {
        const n = t?.services?.map((t) => {
          const e = t?.name
            .match(/^[\w\d\s{}}}\\\\{{{}"/-]+/g)[0]
            .trim()
            .replace(/\s/g, "_");
          return { name: e, enabled: t?.consent?.status, id: t?.id };
        });
        e = [...e, ...n];
      }),
      e
    );
  }
  static getUserDecision(t) {
    let e = [];
    return (
      t?.forEach((t) => {
        const n = t?.services?.map((t) => ({
          serviceId: t?.id,
          status: t?.consent?.status,
        }));
        e = [...e, ...n];
      }),
      e
    );
  }
  static getCheckboxClass(t) {
    const e = t?.services?.filter((t) => t.consent.status);
    let n = w.Partial;
    return (
      e?.length === t?.services?.length
        ? (n = w.All)
        : e.length || (n = w.None),
      n
    );
  }
  static getCheckboxAllClass(t) {
    const e = t?.filter((t) => t.status);
    let n = w.Partial;
    return t?.length === e?.length ? (n = w.All) : e?.length || (n = w.None), n;
  }
  static getCategoryChecked(t) {
    const e = t?.services?.filter((t) => t.consent.status);
    return e?.length === t?.services?.length;
  }
}
const v = class {
  constructor(e) {
    t(this, e),
      (this.handleCategoryChange = void 0),
      (this.scrollToDetails = void 0),
      (this.categories = null);
  }
  render() {
    return (
      !!this.categories &&
      n(
        i,
        null,
        n(
          "ul",
          { class: "category-overview" },
          this.categories.map((t) =>
            n(
              "li",
              {
                class: "category-overview-item",
                "data-category-wrapper": t.label,
              },
              n(
                "label",
                { class: "category-label cmm-checkbox" },
                n("input", {
                  type: "checkbox",
                  checked: p.getCategoryChecked(t) || t.isEssential,
                  class: `cmm-checkbox-input cmm-checkbox-input--category ${p.getCheckboxClass(
                    t
                  )}`,
                  disabled: t.isEssential,
                  "data-category": t.label,
                  "data-test": "handle-category-change",
                  onClick: (t) => this.handleCategoryChange(t),
                }),
                n("div", { class: "cmm-checkbox-fake" }),
                n(
                  "div",
                  { class: "consent-item__information" },
                  n("span", { class: "consent-item__name" }, t.label),
                  n(
                    "button",
                    {
                      type: "button",
                      class: "consent-item__icon",
                      "data-test": "scroll-to-details",
                      "aria-label": t.label,
                      onClick: () => this.scrollToDetails(t.label),
                    },
                    n("cmm-icon", { name: o.INFO })
                  )
                )
              )
            )
          )
        )
      )
    );
  }
};
function y() {
  y = function () {
    return t;
  };
  var t = {},
    e = Object.prototype,
    n = e.hasOwnProperty,
    i =
      Object.defineProperty ||
      function (t, e, n) {
        t[e] = n.value;
      },
    r = "function" == typeof Symbol ? Symbol : {},
    o = r.iterator || "@@iterator",
    s = r.asyncIterator || "@@asyncIterator",
    a = r.toStringTag || "@@toStringTag";
  function l(t, e, n) {
    return (
      Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0,
      }),
      t[e]
    );
  }
  try {
    l({}, "");
  } catch (ct) {
    l = function (t, e, n) {
      return (t[e] = n);
    };
  }
  function c(t, e, n, r) {
    var o = Object.create((e && e.prototype instanceof h ? e : h).prototype),
      s = new _(r || []);
    return i(o, "_invoke", { value: k(t, n, s) }), o;
  }
  function u(t, e, n) {
    try {
      return { type: "normal", arg: t.call(e, n) };
    } catch (ct) {
      return { type: "throw", arg: ct };
    }
  }
  t.wrap = c;
  var d = {};
  function h() {}
  function f() {}
  function m() {}
  var b = {};
  l(b, o, function () {
    return this;
  });
  var g = Object.getPrototypeOf,
    w = g && g(g(T([])));
  w && w !== e && n.call(w, o) && (b = w);
  var p = (m.prototype = h.prototype = Object.create(b));
  function v(t) {
    ["next", "throw", "return"].forEach(function (e) {
      l(t, e, function (t) {
        return this._invoke(e, t);
      });
    });
  }
  function x(t, e) {
    function r(i, o, s, a) {
      var l = u(t[i], t, o);
      if ("throw" !== l.type) {
        var c = l.arg,
          d = c.value;
        return d && "object" == typeof d && n.call(d, "__await")
          ? e.resolve(d.__await).then(
              function (t) {
                r("next", t, s, a);
              },
              function (t) {
                r("throw", t, s, a);
              }
            )
          : e.resolve(d).then(
              function (t) {
                (c.value = t), s(c);
              },
              function (t) {
                return r("throw", t, s, a);
              }
            );
      }
      a(l.arg);
    }
    var o;
    i(this, "_invoke", {
      value: function (t, n) {
        function i() {
          return new e(function (e, i) {
            r(t, n, e, i);
          });
        }
        return (o = o ? o.then(i, i) : i());
      },
    });
  }
  function k(t, e, n) {
    var i = "suspendedStart";
    return function (r, o) {
      if ("executing" === i) throw new Error("Generator is already running");
      if ("completed" === i) {
        if ("throw" === r) throw o;
        return { value: void 0, done: !0 };
      }
      for (n.method = r, n.arg = o; ; ) {
        var s = n.delegate;
        if (s) {
          var a = q(s, n);
          if (a) {
            if (a === d) continue;
            return a;
          }
        }
        if ("next" === n.method) n.sent = n._sent = n.arg;
        else if ("throw" === n.method) {
          if ("suspendedStart" === i) throw ((i = "completed"), n.arg);
          n.dispatchException(n.arg);
        } else "return" === n.method && n.abrupt("return", n.arg);
        i = "executing";
        var l = u(t, e, n);
        if ("normal" === l.type) {
          if (((i = n.done ? "completed" : "suspendedYield"), l.arg === d))
            continue;
          return { value: l.arg, done: n.done };
        }
        "throw" === l.type &&
          ((i = "completed"), (n.method = "throw"), (n.arg = l.arg));
      }
    };
  }
  function q(t, e) {
    var n = e.method,
      i = t.iterator[n];
    if (void 0 === i)
      return (
        (e.delegate = null),
        ("throw" === n &&
          t.iterator.return &&
          ((e.method = "return"),
          (e.arg = void 0),
          q(t, e),
          "throw" === e.method)) ||
          ("return" !== n &&
            ((e.method = "throw"),
            (e.arg = new TypeError(
              "The iterator does not provide a '" + n + "' method"
            )))),
        d
      );
    var r = u(i, t.iterator, e.arg);
    if ("throw" === r.type)
      return (e.method = "throw"), (e.arg = r.arg), (e.delegate = null), d;
    var o = r.arg;
    return o
      ? o.done
        ? ((e[t.resultName] = o.value),
          (e.next = t.nextLoc),
          "return" !== e.method && ((e.method = "next"), (e.arg = void 0)),
          (e.delegate = null),
          d)
        : o
      : ((e.method = "throw"),
        (e.arg = new TypeError("iterator result is not an object")),
        (e.delegate = null),
        d);
  }
  function S(t) {
    var e = { tryLoc: t[0] };
    1 in t && (e.catchLoc = t[1]),
      2 in t && ((e.finallyLoc = t[2]), (e.afterLoc = t[3])),
      this.tryEntries.push(e);
  }
  function C(t) {
    var e = t.completion || {};
    (e.type = "normal"), delete e.arg, (t.completion = e);
  }
  function _(t) {
    (this.tryEntries = [{ tryLoc: "root" }]),
      t.forEach(S, this),
      this.reset(!0);
  }
  function T(t) {
    if (t) {
      var e = t[o];
      if (e) return e.call(t);
      if ("function" == typeof t.next) return t;
      if (!isNaN(t.length)) {
        var i = -1,
          r = function e() {
            for (; ++i < t.length; )
              if (n.call(t, i)) return (e.value = t[i]), (e.done = !1), e;
            return (e.value = void 0), (e.done = !0), e;
          };
        return (r.next = r);
      }
    }
    return { next: A };
  }
  function A() {
    return { value: void 0, done: !0 };
  }
  return (
    (f.prototype = m),
    i(p, "constructor", { value: m, configurable: !0 }),
    i(m, "constructor", { value: f, configurable: !0 }),
    (f.displayName = l(m, a, "GeneratorFunction")),
    (t.isGeneratorFunction = function (t) {
      var e = "function" == typeof t && t.constructor;
      return (
        !!e && (e === f || "GeneratorFunction" === (e.displayName || e.name))
      );
    }),
    (t.mark = function (t) {
      return (
        Object.setPrototypeOf
          ? Object.setPrototypeOf(t, m)
          : ((t.__proto__ = m), l(t, a, "GeneratorFunction")),
        (t.prototype = Object.create(p)),
        t
      );
    }),
    (t.awrap = function (t) {
      return { __await: t };
    }),
    v(x.prototype),
    l(x.prototype, s, function () {
      return this;
    }),
    (t.AsyncIterator = x),
    (t.async = function (e, n, i, r, o) {
      void 0 === o && (o = Promise);
      var s = new x(c(e, n, i, r), o);
      return t.isGeneratorFunction(n)
        ? s
        : s.next().then(function (t) {
            return t.done ? t.value : s.next();
          });
    }),
    v(p),
    l(p, a, "Generator"),
    l(p, o, function () {
      return this;
    }),
    l(p, "toString", function () {
      return "[object Generator]";
    }),
    (t.keys = function (t) {
      var e = Object(t),
        n = [];
      for (var i in e) n.push(i);
      return (
        n.reverse(),
        function t() {
          for (; n.length; ) {
            var i = n.pop();
            if (i in e) return (t.value = i), (t.done = !1), t;
          }
          return (t.done = !0), t;
        }
      );
    }),
    (t.values = T),
    (_.prototype = {
      constructor: _,
      reset: function (t) {
        if (
          ((this.prev = 0),
          (this.next = 0),
          (this.sent = this._sent = void 0),
          (this.done = !1),
          (this.delegate = null),
          (this.method = "next"),
          (this.arg = void 0),
          this.tryEntries.forEach(C),
          !t)
        )
          for (var e in this)
            "t" === e.charAt(0) &&
              n.call(this, e) &&
              !isNaN(+e.slice(1)) &&
              (this[e] = void 0);
      },
      stop: function () {
        this.done = !0;
        var t = this.tryEntries[0].completion;
        if ("throw" === t.type) throw t.arg;
        return this.rval;
      },
      dispatchException: function (t) {
        if (this.done) throw t;
        var e = this;
        function i(n, i) {
          return (
            (s.type = "throw"),
            (s.arg = t),
            (e.next = n),
            i && ((e.method = "next"), (e.arg = void 0)),
            !!i
          );
        }
        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
          var o = this.tryEntries[r],
            s = o.completion;
          if ("root" === o.tryLoc) return i("end");
          if (o.tryLoc <= this.prev) {
            var a = n.call(o, "catchLoc"),
              l = n.call(o, "finallyLoc");
            if (a && l) {
              if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
              if (this.prev < o.finallyLoc) return i(o.finallyLoc);
            } else if (a) {
              if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
            } else {
              if (!l) throw new Error("try statement without catch or finally");
              if (this.prev < o.finallyLoc) return i(o.finallyLoc);
            }
          }
        }
      },
      abrupt: function (t, e) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var r = this.tryEntries[i];
          if (
            r.tryLoc <= this.prev &&
            n.call(r, "finallyLoc") &&
            this.prev < r.finallyLoc
          ) {
            var o = r;
            break;
          }
        }
        o &&
          ("break" === t || "continue" === t) &&
          o.tryLoc <= e &&
          e <= o.finallyLoc &&
          (o = null);
        var s = o ? o.completion : {};
        return (
          (s.type = t),
          (s.arg = e),
          o
            ? ((this.method = "next"), (this.next = o.finallyLoc), d)
            : this.complete(s)
        );
      },
      complete: function (t, e) {
        if ("throw" === t.type) throw t.arg;
        return (
          "break" === t.type || "continue" === t.type
            ? (this.next = t.arg)
            : "return" === t.type
            ? ((this.rval = this.arg = t.arg),
              (this.method = "return"),
              (this.next = "end"))
            : "normal" === t.type && e && (this.next = e),
          d
        );
      },
      finish: function (t) {
        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
          var n = this.tryEntries[e];
          if (n.finallyLoc === t)
            return this.complete(n.completion, n.afterLoc), C(n), d;
        }
      },
      catch: function (t) {
        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
          var n = this.tryEntries[e];
          if (n.tryLoc === t) {
            var i = n.completion;
            if ("throw" === i.type) {
              var r = i.arg;
              C(n);
            }
            return r;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function (t, e, n) {
        return (
          (this.delegate = { iterator: T(t), resultName: e, nextLoc: n }),
          "next" === this.method && (this.arg = void 0),
          d
        );
      },
    }),
    t
  );
}
function x(t) {
  return (
    (x =
      "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
        ? function (t) {
            return typeof t;
          }
        : function (t) {
            return t &&
              "function" == typeof Symbol &&
              t.constructor === Symbol &&
              t !== Symbol.prototype
              ? "symbol"
              : typeof t;
          }),
    x(t)
  );
}
function k(t, e, n, i, r, o, s) {
  try {
    var a = t[o](s),
      l = a.value;
  } catch (E) {
    return void n(E);
  }
  a.done ? e(l) : Promise.resolve(l).then(i, r);
}
function q(t) {
  return function () {
    var e = this,
      n = arguments;
    return new Promise(function (i, r) {
      var o = t.apply(e, n);
      function s(t) {
        k(o, i, r, s, a, "next", t);
      }
      function a(t) {
        k(o, i, r, s, a, "throw", t);
      }
      s(void 0);
    });
  };
}
function S(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function C(t, e) {
  for (var n = 0; n < e.length; n++) {
    var i = e[n];
    (i.enumerable = i.enumerable || !1),
      (i.configurable = !0),
      "value" in i && (i.writable = !0),
      Object.defineProperty(t, B(i.key), i);
  }
}
function _(t, e, n) {
  return (
    e && C(t.prototype, e),
    n && C(t, n),
    Object.defineProperty(t, "prototype", { writable: !1 }),
    t
  );
}
function T(t, e, n) {
  return (
    (e = B(e)) in t
      ? Object.defineProperty(t, e, {
          value: n,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (t[e] = n),
    t
  );
}
function A(t, e) {
  if ("function" != typeof e && null !== e)
    throw new TypeError("Super expression must either be null or a function");
  (t.prototype = Object.create(e && e.prototype, {
    constructor: { value: t, writable: !0, configurable: !0 },
  })),
    Object.defineProperty(t, "prototype", { writable: !1 }),
    e && z(t, e);
}
function E(t) {
  return (
    (E = Object.setPrototypeOf
      ? Object.getPrototypeOf.bind()
      : function (t) {
          return t.__proto__ || Object.getPrototypeOf(t);
        }),
    E(t)
  );
}
function z(t, e) {
  return (
    (z = Object.setPrototypeOf
      ? Object.setPrototypeOf.bind()
      : function (t, e) {
          return (t.__proto__ = e), t;
        }),
    z(t, e)
  );
}
function O() {
  if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
  if (Reflect.construct.sham) return !1;
  if ("function" == typeof Proxy) return !0;
  try {
    return (
      Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      ),
      !0
    );
  } catch (y) {
    return !1;
  }
}
function I(t, e, n) {
  return (
    (I = O()
      ? Reflect.construct.bind()
      : function (t, e, n) {
          var i = [null];
          i.push.apply(i, e);
          var r = new (Function.bind.apply(t, i))();
          return n && z(r, n.prototype), r;
        }),
    I.apply(null, arguments)
  );
}
function D(t) {
  var e = "function" == typeof Map ? new Map() : void 0;
  return (
    (D = function (t) {
      if (
        null === t ||
        -1 === Function.toString.call(t).indexOf("[native code]")
      )
        return t;
      if ("function" != typeof t)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      if (void 0 !== e) {
        if (e.has(t)) return e.get(t);
        e.set(t, n);
      }
      function n() {
        return I(t, arguments, E(this).constructor);
      }
      return (
        (n.prototype = Object.create(t.prototype, {
          constructor: {
            value: n,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
        z(n, t)
      );
    }),
    D(t)
  );
}
function L(t) {
  if (void 0 === t)
    throw new ReferenceError(
      "this hasn't been initialised - super() hasn't been called"
    );
  return t;
}
function N(t, e) {
  if (e && ("object" == typeof e || "function" == typeof e)) return e;
  if (void 0 !== e)
    throw new TypeError(
      "Derived constructors may only return object or undefined"
    );
  return L(t);
}
function R(t) {
  var e = O();
  return function () {
    var n,
      i = E(t);
    if (e) {
      var r = E(this).constructor;
      n = Reflect.construct(i, arguments, r);
    } else n = i.apply(this, arguments);
    return N(this, n);
  };
}
function F(t, e) {
  for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = E(t)); );
  return t;
}
function P() {
  return (
    (P =
      "undefined" != typeof Reflect && Reflect.get
        ? Reflect.get.bind()
        : function (t, e, n) {
            var i = F(t, e);
            if (i) {
              var r = Object.getOwnPropertyDescriptor(i, e);
              return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value;
            }
          }),
    P.apply(this, arguments)
  );
}
function U(t) {
  return (
    (function (t) {
      if (Array.isArray(t)) return M(t);
    })(t) ||
    (function (t) {
      if (
        ("undefined" != typeof Symbol && null != t[Symbol.iterator]) ||
        null != t["@@iterator"]
      )
        return Array.from(t);
    })(t) ||
    j(t) ||
    (function () {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    })()
  );
}
function j(t, e) {
  if (t) {
    if ("string" == typeof t) return M(t, e);
    var n = Object.prototype.toString.call(t).slice(8, -1);
    return (
      "Object" === n && t.constructor && (n = t.constructor.name),
      "Map" === n || "Set" === n
        ? Array.from(t)
        : "Arguments" === n ||
          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
        ? M(t, e)
        : void 0
    );
  }
}
function M(t, e) {
  (null == e || e > t.length) && (e = t.length);
  for (var n = 0, i = new Array(e); n < e; n++) i[n] = t[n];
  return i;
}
function V(t, e) {
  var n =
    ("undefined" != typeof Symbol && t[Symbol.iterator]) || t["@@iterator"];
  if (!n) {
    if (
      Array.isArray(t) ||
      (n = j(t)) ||
      (e && t && "number" == typeof t.length)
    ) {
      n && (t = n);
      var i = 0,
        r = function () {};
      return {
        s: r,
        n: function () {
          return i >= t.length ? { done: !0 } : { done: !1, value: t[i++] };
        },
        e: function (t) {
          throw t;
        },
        f: r,
      };
    }
    throw new TypeError(
      "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
    );
  }
  var o,
    s = !0,
    a = !1;
  return {
    s: function () {
      n = n.call(t);
    },
    n: function () {
      var t = n.next();
      return (s = t.done), t;
    },
    e: function (t) {
      (a = !0), (o = t);
    },
    f: function () {
      try {
        s || null == n.return || n.return();
      } finally {
        if (a) throw o;
      }
    },
  };
}
function B(t) {
  var e = (function (t) {
    if ("object" != typeof t || null === t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var n = e.call(t, "string");
      if ("object" != typeof n) return n;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return String(t);
  })(t);
  return "symbol" == typeof e ? e : String(e);
}
var H = function (t, e) {
  return (
    (H =
      Object.setPrototypeOf ||
      ({ __proto__: [] } instanceof Array &&
        function (t, e) {
          t.__proto__ = e;
        }) ||
      function (t, e) {
        for (var n in e)
          Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
      }),
    H(t, e)
  );
};
function G(t, e) {
  if ("function" != typeof e && null !== e)
    throw new TypeError(
      "Class extends value " + String(e) + " is not a constructor or null"
    );
  function n() {
    this.constructor = t;
  }
  H(t, e),
    (t.prototype =
      null === e ? Object.create(e) : ((n.prototype = e.prototype), new n()));
}
var J,
  W,
  $,
  Y,
  K,
  Q,
  X,
  Z,
  tt,
  et,
  nt,
  it,
  rt,
  ot,
  st,
  at,
  lt,
  ct = function () {
    return (
      (ct =
        Object.assign ||
        function (t) {
          for (var e, n = 1, i = arguments.length; n < i; n++)
            for (var r in (e = arguments[n]))
              Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
          return t;
        }),
      ct.apply(this, arguments)
    );
  };
function ut(t, e, n, i) {
  return new (n || (n = Promise))(function (r, o) {
    function s(t) {
      try {
        l(i.next(t));
      } catch (e) {
        o(e);
      }
    }
    function a(t) {
      try {
        l(i.throw(t));
      } catch (e) {
        o(e);
      }
    }
    function l(t) {
      var e;
      t.done
        ? r(t.value)
        : ((e = t.value),
          e instanceof n
            ? e
            : new n(function (t) {
                t(e);
              })).then(s, a);
    }
    l((i = i.apply(t, e || [])).next());
  });
}
function dt(t, e) {
  var n,
    i,
    r,
    o,
    s = {
      label: 0,
      sent: function () {
        if (1 & r[0]) throw r[1];
        return r[1];
      },
      trys: [],
      ops: [],
    };
  return (
    (o = { next: a(0), throw: a(1), return: a(2) }),
    "function" == typeof Symbol &&
      (o[Symbol.iterator] = function () {
        return this;
      }),
    o
  );
  function a(a) {
    return function (l) {
      return (function (a) {
        if (n) throw new TypeError("Generator is already executing.");
        for (; o && ((o = 0), a[0] && (s = 0)), s; )
          try {
            if (
              ((n = 1),
              i &&
                (r =
                  2 & a[0]
                    ? i.return
                    : a[0]
                    ? i.throw || ((r = i.return) && r.call(i), 0)
                    : i.next) &&
                !(r = r.call(i, a[1])).done)
            )
              return r;
            switch (((i = 0), r && (a = [2 & a[0], r.value]), a[0])) {
              case 0:
              case 1:
                r = a;
                break;
              case 4:
                return s.label++, { value: a[1], done: !1 };
              case 5:
                s.label++, (i = a[1]), (a = [0]);
                continue;
              case 7:
                (a = s.ops.pop()), s.trys.pop();
                continue;
              default:
                if (
                  !(
                    (r = (r = s.trys).length > 0 && r[r.length - 1]) ||
                    (6 !== a[0] && 2 !== a[0])
                  )
                ) {
                  s = 0;
                  continue;
                }
                if (3 === a[0] && (!r || (a[1] > r[0] && a[1] < r[3]))) {
                  s.label = a[1];
                  break;
                }
                if (6 === a[0] && s.label < r[1]) {
                  (s.label = r[1]), (r = a);
                  break;
                }
                if (r && s.label < r[2]) {
                  (s.label = r[2]), s.ops.push(a);
                  break;
                }
                r[2] && s.ops.pop(), s.trys.pop();
                continue;
            }
            a = e.call(t, s);
          } catch (l) {
            (a = [6, l]), (i = 0);
          } finally {
            n = r = 0;
          }
        if (5 & a[0]) throw a[1];
        return { value: a[0] ? a[1] : void 0, done: !0 };
      })([a, l]);
    };
  }
}
function ht(t, e) {
  var n = "function" == typeof Symbol && t[Symbol.iterator];
  if (!n) return t;
  var i,
    r,
    o = n.call(t),
    s = [];
  try {
    for (; (void 0 === e || e-- > 0) && !(i = o.next()).done; ) s.push(i.value);
  } catch (T) {
    r = { error: T };
  } finally {
    try {
      i && !i.done && (n = o.return) && n.call(o);
    } finally {
      if (r) throw r.error;
    }
  }
  return s;
}
function ft(t, e, n) {
  if (n || 2 === arguments.length)
    for (var i, r = 0, o = e.length; r < o; r++)
      (!i && r in e) ||
        (i || (i = Array.prototype.slice.call(e, 0, r)), (i[r] = e[r]));
  return t.concat(i || Array.prototype.slice.call(e));
}
function mt(t) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var e,
    n = t[Symbol.asyncIterator];
  return n
    ? n.call(t)
    : ((t = (function (t) {
        var e = "function" == typeof Symbol && Symbol.iterator,
          n = e && t[e],
          i = 0;
        if (n) return n.call(t);
        if (t && "number" == typeof t.length)
          return {
            next: function () {
              return (
                t && i >= t.length && (t = void 0),
                { value: t && t[i++], done: !t }
              );
            },
          };
        throw new TypeError(
          e ? "Object is not iterable." : "Symbol.iterator is not defined."
        );
      })(t)),
      (e = {}),
      i("next"),
      i("throw"),
      i("return"),
      (e[Symbol.asyncIterator] = function () {
        return this;
      }),
      e);
  function i(n) {
    e[n] =
      t[n] &&
      function (e) {
        return new Promise(function (i, r) {
          !(function (t, e, n, i) {
            Promise.resolve(i).then(function (e) {
              t({ value: e, done: n });
            }, e);
          })(i, r, (e = t[n](e)).done, e.value);
        });
      };
  }
}
!(function (t) {
  (t.CONSENT_RESPONSE = "consent-response"), (t.CONSENT_UI = "consent-ui");
})(J || (J = {})),
  (function (t) {
    (t.ACCEPT = "accept"),
      (t.REJECT = "reject"),
      (t.DISMISS = "dismiss"),
      (t.FULLSCREEN = "enter-fullscreen"),
      (t.READY = "ready");
  })(W || (W = {})),
  (function (t) {
    (t[(t.TCF_V2 = 2)] = "TCF_V2"), (t[(t.CCPA = 3)] = "CCPA");
  })($ || ($ = {})),
  (function (t) {
    (t[(t.FALSE = 0)] = "FALSE"), (t[(t.TRUE = 1)] = "TRUE");
  })(Y || (Y = {})),
  (function (t) {
    (t[(t.DATA_LAYER = 0)] = "DATA_LAYER"),
      (t[(t.WINDOW_EVENT = 1)] = "WINDOW_EVENT");
  })(K || (K = {})),
  (function (t) {
    (t[(t.MAJOR = 0)] = "MAJOR"),
      (t[(t.MINOR = 1)] = "MINOR"),
      (t[(t.PATCH = 2)] = "PATCH");
  })(Q || (Q = {})),
  (function (t) {
    (t.CALL_INIT = "Usercentrics: You have to call the init method before!"),
      (t.DATA_LOCAL =
        "Usercentrics: disableServerConsents and controllerId should not be present at the same time in the InitOptions!"),
      (t.UNKNOWN_VARIANT = "Usercentrics: Unknown variant"),
      (t.NOT_CCPA = "Usercentrics: CCPA was not initialized"),
      (t.NOT_DEFAULT = "Usercentrics: GDPR was not initialized"),
      (t.NOT_TCF = "Usercentrics: TCF was not initialized");
  })(X || (X = {})),
  (function (t) {
    (t.BANNER = "BANNER"), (t.WALL = "WALL");
  })(Z || (Z = {})),
  (function (t) {
    (t.CENTER = "CENTER"), (t.SIDE = "SIDE");
  })(tt || (tt = {})),
  (function (t) {
    (t[(t.DARK = 0)] = "DARK"), (t[(t.LIGHT = 1)] = "LIGHT");
  })(et || (et = {})),
  (function (t) {
    (t.LINK = "LINK"),
      (t.BUTTON = "BUTTON"),
      (t.MORE_LINK_BUTTON = "MORE_LINK_BUTTON");
  })(nt || (nt = {})),
  (function (t) {
    (t.LEFT = "LEFT"), (t.RIGHT = "RIGHT");
  })(it || (it = {})),
  (function (t) {
    (t.HORIZONTAL = "HORIZONTAL"), (t.VERTICAL = "VERTICAL");
  })(rt || (rt = {})),
  (function (t) {
    (t.ALL = "ALL"), (t.SHORT = "SHORT");
  })(ot || (ot = {})),
  (function (t) {
    (t.CROSS_DEVICE_DATA_NOT_AVAILABLE =
      "Usercentrics: Cross Device Consents data is not available"),
      (t.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE =
        "Usercentrics: Cross Device TCF data is not available"),
      (t.CROSS_DEVICE_FEATURE_DISABLED =
        "Usercentrics: The `Cross-Device Consent Sharing` feature is not enabled. Please contact the support team in order to enable this feature for your configuration");
  })(st || (st = {})),
  (function (t) {
    (t.CROSS_DOMAIN_DATA_NOT_AVAILABLE =
      "Usercentrics: Cross Domain Consents data is not available"),
      (t.CROSS_DOMAIN_TCF_DATA_NOT_AVAILABLE =
        "Usercentrics: Cross Domain TCF data is not available"),
      (t.CROSS_DOMAIN_FEATURE_NOT_AVAILABLE =
        "Usercentrics: Cross Domain Consent Sharing is not available."),
      (t.CROSS_DOMAIN_LANGUAGE_NOT_AVAILABLE =
        "Usercentrics: Cross Domain Consent language is not available"),
      (t.CROSS_DOMAIN_SET_DATA_FAILURE =
        "Usercentrics: Unable to set Cross Domain data"),
      (t.CROSS_DOMAIN_SET_TCF_DATA_FAILURE =
        "Usercentrics: Unable to set Cross Domain TCF data"),
      (t.CROSS_DOMAIN_IFRAME_ERROR = "Usercentrics: Iframe error"),
      (t.CROSS_DOMAIN_IFRAME_NOT_FOUND =
        "Usercentrics: Cross Domain iFrame not found"),
      (t.CROSS_DOMAIN_IFRAME_LOAD_ERROR = "Usercentrics: IFrame did not load");
  })(at || (at = {})),
  (function (t) {
    (t.CLEAR = "clear"),
      (t.GET_CROSS_DOMAIN_LANGUAGE = "getCrossDomainLanguage"),
      (t.GET_CROSS_DOMAIN_SESSION_DATA = "getCrossDomainSessionData"),
      (t.GET_CROSS_DOMAIN_TCF_DATA = "getCrossDomainTcfData"),
      (t.GET_CROSS_DOMAIN_CCPA_DATA = "getCrossDomainCcpaData"),
      (t.GET_TC_STRING = "getTCString"),
      (t.PING = "ping"),
      (t.SET_CROSS_DOMAIN_DATA = "setCrossDomainData"),
      (t.SET_CROSS_DOMAIN_TCF_DATA = "setCrossDomainTcfData"),
      (t.SET_CROSS_DOMAIN_CCPA_DATA = "setCrossDomainCcpaData"),
      (t.SET_TC_STRING = "setTCString");
  })(lt || (lt = {}));
var bt,
  gt,
  wt = "ucMobileSdk",
  pt = "4.21.0",
  vt = 1,
  yt = "1---",
  xt = "__uspapiLocator",
  kt = /^[1][nNyY-][nNyY-][nNyY-]$/,
  qt = "__uspapi";
!(function (t) {
  (t.CCPA = "uc_usprivacy"),
    (t.CCPA_DATA = "uc_ccpa"),
    (t.CONSENTS_BUFFER = "uc_consents_buffer"),
    (t.CONSENTS_V2_BUFFER = "uc_consents_v2_buffer"),
    (t.GCM_DATA = "uc_gcm"),
    (t.LEGACY_SETTINGS = "ucSettings"),
    (t.SERVICES = "uc_services"),
    (t.SETTINGS = "uc_settings"),
    (t.TCF = "uc_tcf"),
    (t.USER_INTERACTION = "uc_user_interaction"),
    (t.AB_TEST_VARIANT = "uc_ab_variant");
})(bt || (bt = {})),
  ((gt || (gt = {})).USER_COUNTRY = "uc_user_country");
var St,
  Ct,
  _t,
  Tt,
  At = "uc-cross-domain-bridge",
  Et = ""
    .concat("https://app.usercentrics.eu", "/browser-sdk/")
    .concat(pt, "/cross-domain-bridge.html"),
  zt = ""
    .concat("https://app.eu.usercentrics.eu", "/browser-sdk/")
    .concat(pt, "/cross-domain-bridge.html"),
  Ot = (function () {
    function t() {}
    return (
      (t.setDomainBridgeUri = function (e) {
        var n = "";
        e &&
          (e.crossDomainConsentSharingIFrame
            ? (n = e.crossDomainConsentSharingIFrame)
            : e.app &&
              (n = ""
                .concat(e.app, "/browser-sdk/")
                .concat(pt, "/cross-domain-bridge.html"))),
          (t.domainBridgeUri = t.useEuCdn ? zt : "" !== n ? n : Et);
      }),
      (t.getDomainBridgeUri = function () {
        return t.domainBridgeUri;
      }),
      (t.init = function (e, n) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return (
              t.setDomainBridgeUri(n),
              t.setUseEuCdn((null == e ? void 0 : e.useEuCdn) || !1),
              t.setDomainBridgeUri(n),
              [2, this.initIFrame(t.getDomainBridgeUri(), At)]
            );
          });
        });
      }),
      (t.initIFrame = function (e, n) {
        return ut(this, void 0, void 0, function () {
          var i = this;
          return dt(this, function () {
            return [
              2,
              new Promise(function (r, o) {
                var s = t.createIFrame(e, n);
                (s.onload = function () {
                  return ut(i, void 0, void 0, function () {
                    var i;
                    return dt(this, function () {
                      return (
                        (i = setTimeout(function () {
                          (s = {}),
                            o(new Error(at.CROSS_DOMAIN_IFRAME_LOAD_ERROR));
                        }, 1e3)),
                        t
                          .queryIFrame(e, n, lt.PING)
                          .then(function () {
                            clearTimeout(i), r(!0);
                          })
                          .catch(function (t) {
                            clearTimeout(i), o(t);
                          }),
                        [2]
                      );
                    });
                  });
                }),
                  (s.onerror = function () {
                    return ut(i, void 0, void 0, function () {
                      return dt(this, function () {
                        return o(new Error(at.CROSS_DOMAIN_IFRAME_ERROR)), [2];
                      });
                    });
                  }),
                  t.appendIFrame(s);
              }),
            ];
          });
        });
      }),
      (t.setIsCrossDomainAvailable = function (e) {
        t.crossDomainAvailable = e;
      }),
      (t.isCookieBridgeAvailable = function () {
        return t.cookieBridgeAvailable;
      }),
      (t.setIsCookieBridgeAvailable = function (e) {
        t.cookieBridgeAvailable = e;
      }),
      (t.isCrossDomainAvailable = function () {
        return t.crossDomainAvailable;
      }),
      (t.getCrossDomainId = function () {
        return t.crossDomainId;
      }),
      (t.setCrossDomainId = function (e) {
        t.crossDomainId = "".concat("uc_cross_domain_data", "_").concat(e);
      }),
      (t.setCookieBridgeDomain = function (t, e) {
        this.cookieBridgeDomain = "".concat(t).concat(e);
      }),
      (t.setUseEuCdn = function (e) {
        t.useEuCdn = e;
      }),
      (t.createIFrame = function (e, n) {
        t.removeIFrame(n);
        var i = document.createElement("iframe");
        return (i.style.display = "none"), (i.id = n), (i.src = e), i;
      }),
      (t.removeIFrame = function (t) {
        var e = document.getElementById(t);
        e && e.parentNode && e.parentNode.removeChild(e);
      }),
      (t.queryIFrame = function (t, e, n, i, r) {
        return ut(this, void 0, void 0, function () {
          var o;
          return dt(this, function () {
            if (!(o = document.getElementById(e)) || !o.id)
              throw new Error(at.CROSS_DOMAIN_IFRAME_NOT_FOUND);
            return [
              2,
              new Promise(function (e, s) {
                var a = JSON.stringify({
                    crossDomainId: r,
                    method: n,
                    payload: i,
                  }),
                  l = new MessageChannel();
                (l.port1.onmessage = function (t) {
                  var n = JSON.parse(t.data);
                  n.success ? e(n.data) : s(t);
                }),
                  o &&
                    o.contentWindow &&
                    o.contentWindow.postMessage(a, t, [l.port2]);
              }),
            ];
          });
        });
      }),
      (t.appendIFrame = function (t) {
        try {
          document.body
            ? document.body.appendChild(t)
            : document.addEventListener("DOMContentLoaded", function () {
                document.body.appendChild(t);
              });
        } catch (x) {
          return new Error(at.CROSS_DOMAIN_IFRAME_ERROR);
        }
        return null;
      }),
      (t.query = function (e, n) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [
              2,
              t.queryIFrame(t.getDomainBridgeUri(), At, e, n, t.crossDomainId),
            ];
          });
        });
      }),
      (t.getCrossDomainLanguage = function () {
        return t.query(lt.GET_CROSS_DOMAIN_LANGUAGE);
      }),
      (t.setCrossDomainData = function (e) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [
              2,
              t.query(
                lt.SET_CROSS_DOMAIN_DATA,
                ((n = e),
                {
                  consents: n.services
                    .map(function (t) {
                      return t.history.map(function (e) {
                        return {
                          action: e.action,
                          consentId: "",
                          settingsVersion: e.versions.settings,
                          status: e.status,
                          templateId: t.id,
                          timestamp: "".concat(e.timestamp),
                          updatedBy: e.type,
                        };
                      });
                    })
                    .reduce(function (t, e) {
                      return t.concat(e);
                    }, [])
                    .sort(function (t, e) {
                      return (
                        parseInt(t.timestamp, 10) - parseInt(e.timestamp, 10)
                      );
                    }),
                  controllerId: n.controllerId,
                  language: n.language,
                })
              ),
            ];
            var n;
          });
        });
      }),
      (t.setCrossDomainCcpaData = function (e) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.SET_CROSS_DOMAIN_CCPA_DATA, e)];
          });
        });
      }),
      (t.getCrossDomainCcpaData = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.GET_CROSS_DOMAIN_CCPA_DATA)];
          });
        });
      }),
      (t.getCrossDomainSessionData = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.GET_CROSS_DOMAIN_SESSION_DATA)];
          });
        });
      }),
      (t.getCrossDomainTcfData = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.GET_CROSS_DOMAIN_TCF_DATA)];
          });
        });
      }),
      (t.setCrossDomainTcfData = function (e) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.SET_CROSS_DOMAIN_TCF_DATA, e)];
          });
        });
      }),
      (t.clearCrossDomainStorage = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, t.query(lt.CLEAR)];
          });
        });
      }),
      (t.crossDomainId = ""),
      (t.cookieBridgeDomain = ""),
      (t.domainBridgeUri = Et),
      (t.useEuCdn = !1),
      (t.cookieBridgeAvailable = !1),
      (t.crossDomainAvailable = !1),
      t
    );
  })(),
  It = (function () {
    function t() {
      (this.length = 0), (this.data = {});
    }
    return (
      (t.prototype.updateLength = function () {
        this.length = Object.keys(this.data).length;
      }),
      (t.prototype.key = function (t) {
        var e = Object.keys(this.data)[t];
        return void 0 === x(e) ? null : e;
      }),
      (t.prototype.getItem = function (t) {
        return void 0 !== this.data[t] ? this.data[t] : null;
      }),
      (t.prototype.setItem = function (t, e) {
        (this.data[t] = String(e)), this.updateLength();
      }),
      (t.prototype.removeItem = function (t) {
        delete this.data[t], this.updateLength();
      }),
      (t.prototype.clear = function () {
        (this.data = {}), this.updateLength();
      }),
      t
    );
  })();
!(function (t) {
  (t.COOKIE_BRIDGE_NOT_AVAILABLE =
    "Usercentrics: Cookie bridge is not available."),
    (t.COOKIE_BRIDGE_OPTIONS_NOT_SET =
      "Usercentrics: Cookie bridge options are not set"),
    (t.GET_GLOBAL_TC_STRING_FAILURE =
      "Usercentrics: Unable to get the Global TC string"),
    (t.INIT_TCF_ERROR = "Usercentrics: Unable to init TCF"),
    (t.RESET_GVL_FAILURE = "Usercentrics: Unable to reset Global Vendor List"),
    (t.SET_GLOBAL_TC_STRING_FAILURE =
      "Usercentrics: Unable to set the Global TC string"),
    (t.VENDOR_REMOVED =
      "Usercentrics: The following vendor is not part of the official vendors list anymore: "),
    (t.TC_MODEL_UNDEFINED = "Usercentrics: tcModel can not be null."),
    (t.SELECTED_LANGUAGE_UNDEFINED =
      "Usercentrics: Selected language can not be undefined");
})(St || (St = {})),
  (function (t) {
    (t.LEGITIMATE_INTEREST = "legIntPurposes"), (t.PURPOSES = "purposes");
  })(Ct || (Ct = {})),
  (function (t) {
    (t[(t.ID = 0)] = "ID"),
      (t[(t.LEGITIMATE_INTEREST = 1)] = "LEGITIMATE_INTEREST"),
      (t[(t.PURPOSES = 2)] = "PURPOSES"),
      (t[(t.SPECIAL_PURPOSES = 3)] = "SPECIAL_PURPOSES");
  })(_t || (_t = {})),
  (function (t) {
    (t[(t.FIRST_LAYER = 1)] = "FIRST_LAYER"),
      (t[(t.SECOND_LAYER = 2)] = "SECOND_LAYER");
  })(Tt || (Tt = {}));
var Dt = function (t) {
    switch (t) {
      case "onAcceptAllBtnClick":
      case "onSpecialFunctionAcceptAllConsentTrigger":
        return "onAcceptAllServices";
      case "onDenyAllAnchorClick":
      case "onDenyAllBtnClick":
        return "onDenyAllServices";
      case "onNonEURegion":
        return "onNonEURegion";
      case "onInitialPageLoad":
      case "onCountdownFinished":
      default:
        return "onInitialPageLoad";
      case "onToggleCategory":
      case "onToggleConsent":
      case "onToggleSelectAll":
        return "onEssentialChange";
      case "onWindowFunctionUpdateConsent":
      case "bySettingsUpdate":
      case "onSaveBtnClick":
        return "onUpdateServices";
    }
  },
  Lt = function (t) {
    switch (t) {
      case "update":
      case "implicit":
      default:
        return "implicit";
      case "explicit":
        return "explicit";
    }
  },
  Nt = "RAMDOM_KEY_LOCAL_STORAGE",
  Rt = (function () {
    function t() {
      (this.localStorage = null),
        (this.sessionStorage = null),
        (this.storeServiceIdToNameMapping = !1);
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        (t.instance.localStorage = null), (t.instance.sessionStorage = null);
      }),
      (t.prototype.setStoreServiceIdToNameMapping = function (t) {
        this.storeServiceIdToNameMapping = t;
      }),
      (t.prototype.getStoreServiceIdToNameMapping = function () {
        return this.storeServiceIdToNameMapping;
      }),
      (t.prototype.init = function () {
        try {
          localStorage.setItem(Nt, Nt),
            localStorage.removeItem(Nt),
            (this.localStorage = localStorage);
        } catch (t) {
          this.localStorage = new It();
        }
        try {
          sessionStorage.setItem(Nt, Nt),
            sessionStorage.removeItem(Nt),
            (this.sessionStorage = sessionStorage);
        } catch (t) {
          this.sessionStorage = new It();
        }
      }),
      (t.appendToConsentsBuffer = function (e) {
        var n,
          i = t.fetchConsentsBuffer(),
          r = new Date().valueOf();
        i.push({ consents: e, timestamp: r }),
          null === (n = t.getInstance().localStorage) ||
            void 0 === n ||
            n.setItem(bt.CONSENTS_BUFFER, JSON.stringify(i));
      }),
      (t.appendToConsentsV2Buffer = function (e) {
        var n,
          i = t.fetchConsentsV2Buffer(),
          r = new Date().valueOf();
        i.push({ consents: e, timestamp: r }),
          null === (n = t.getInstance().localStorage) ||
            void 0 === n ||
            n.setItem(bt.CONSENTS_V2_BUFFER, JSON.stringify(i));
      }),
      (t.clearOnNewSettingsId = function (e) {
        e !== t.fetchSettingsId() && t.clear();
      }),
      (t.findBufferItem = function (e) {
        return t
          .fetchConsentsBuffer()
          .slice()
          .find(function (t) {
            return JSON.stringify(t.consents) === JSON.stringify(e);
          });
      }),
      (t.findV2BufferItem = function (e) {
        return t
          .fetchConsentsV2Buffer()
          .slice()
          .find(function (t) {
            return JSON.stringify(t.consents) === JSON.stringify(e);
          });
      }),
      (t.removeConsentsBufferItem = function (e) {
        var n,
          i,
          r = t.fetchConsentsBuffer(),
          o = r.length + 0;
        (r = r.filter(function (t) {
          return JSON.stringify(t) !== JSON.stringify(e);
        })).length && r.length !== o
          ? null === (n = t.getInstance().localStorage) ||
            void 0 === n ||
            n.setItem(bt.CONSENTS_BUFFER, JSON.stringify(r))
          : null === (i = t.getInstance().localStorage) ||
            void 0 === i ||
            i.removeItem(bt.CONSENTS_BUFFER);
      }),
      (t.removeConsentsV2BufferItem = function (e) {
        var n,
          i,
          r = t.fetchConsentsV2Buffer(),
          o = r.length + 0;
        (r = r.filter(function (t) {
          return JSON.stringify(t) !== JSON.stringify(e);
        })).length && r.length !== o
          ? null === (n = t.getInstance().localStorage) ||
            void 0 === n ||
            n.setItem(bt.CONSENTS_V2_BUFFER, JSON.stringify(r))
          : null === (i = t.getInstance().localStorage) ||
            void 0 === i ||
            i.removeItem(bt.CONSENTS_V2_BUFFER);
      }),
      (t.getCcpaString = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.CCPA);
        return n && kt.test(n) ? n : yt;
      }),
      (t.getCcpaData = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.CCPA_DATA);
        return n ? JSON.parse(n) : null;
      }),
      (t.fetchConsentsBuffer = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.CONSENTS_BUFFER);
        return n ? JSON.parse(n) : [];
      }),
      (t.fetchConsentsV2Buffer = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.CONSENTS_V2_BUFFER);
        return n ? JSON.parse(n) : [];
      }),
      (t.fetchControllerId = function () {
        var e = t.fetchSettings();
        return e ? e.controllerId : "";
      }),
      (t.fetchLanguage = function () {
        var e = t.fetchSettings();
        return e ? e.language : "";
      }),
      (t.fetchServices = function () {
        var e = t.fetchSettings();
        return e ? e.services : [];
      }),
      (t.fetchLegacySettings = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.LEGACY_SETTINGS);
        return n ? JSON.parse(n) : null;
      }),
      (t.fetchSettings = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.SETTINGS);
        return n ? JSON.parse(n) : {};
      }),
      (t.fetchSettingsId = function () {
        var e = t.fetchSettings();
        return e ? e.id : "";
      }),
      (t.fetchSettingsVersion = function () {
        var e = t.fetchSettings();
        return e ? e.version : "";
      }),
      (t.fetchTCFData = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.TCF),
          i = n
            ? JSON.parse(n)
            : { tcString: "", timestamp: Date.now(), vendors: [] };
        return i.vendors || (i.vendors = []), i;
      }),
      (t.fetchTCFVendorsDisclosedObject = function (e) {
        var n,
          i = t.fetchTCFData(),
          r = i.tcString,
          o = i.vendors,
          s = i.vendorsDisclosed;
        if (!o && !s) return {};
        if ((s || (!s && !o.length && r)) && e) {
          var a = Object.keys(e).map(Number);
          (n = (s || a)
            .filter(function (t) {
              return e[t];
            })
            .map(function (t) {
              var n = e[t];
              return [n.id, n.legIntPurposes, n.purposes, n.specialPurposes];
            })),
            t.saveTCFData({ tcString: r, timestamp: Date.now(), vendors: n });
        } else n = o;
        return n.reduce(function (t, e) {
          var n;
          return ct(ct({}, t), (((n = {})[e[_t.ID]] = !0), n));
        }, {});
      }),
      (t.fetchTCString = function () {
        return t.fetchTCFData().tcString || "";
      }),
      (t.fetchUserActionPerformed = function () {
        var e;
        return (
          "true" ===
          (null === (e = t.getInstance().localStorage) || void 0 === e
            ? void 0
            : e.getItem(bt.USER_INTERACTION))
        );
      }),
      (t.fetchUserCountryResponse = function () {
        var e;
        try {
          return JSON.parse(
            (null === (e = t.getInstance().sessionStorage) || void 0 === e
              ? void 0
              : e.getItem(gt.USER_COUNTRY)) || "null"
          );
        } catch (k) {
          return null;
        }
      }),
      (t.setUserCountryResponse = function (e) {
        var n;
        null === (n = t.getInstance().sessionStorage) ||
          void 0 === n ||
          n.setItem(gt.USER_COUNTRY, JSON.stringify(e));
      }),
      (t.mapServices = function (t) {
        return t.map(function (t) {
          return {
            history: t.consent.history,
            id: t.id,
            processorId: t.processorId,
            status: t.consent.status,
          };
        });
      }),
      (t.mapSettings = function (e, n) {
        return {
          controllerId: e.controllerId,
          id: e.id,
          language: e.selectedLanguage,
          services: t.mapServices(n),
          version: e.version,
        };
      }),
      (t.migrateLegacySettings = function (e) {
        if (!t.settingsExist()) {
          var n,
            i,
            r = t.fetchLegacySettings();
          if ((t.clearLegacySettings(), null == r ? void 0 : r[e])) {
            var o =
              (n = r[e]) && jt(n.ucConsents.consents)
                ? (((i = {})[bt.SETTINGS] = {
                    controllerId: n.ucConsents.consents[0].controllerId,
                    id: n.usercentrics.settings.settingsId,
                    language: n.usercentrics.settings.language,
                    services: n.ucConsents.consents.map(function (t) {
                      return {
                        history: t.history.map(function (t) {
                          return {
                            action: Dt(t.action),
                            language: t.language,
                            status: t.consentStatus,
                            timestamp: t.updatedAt,
                            type: Lt(t.updatedBy),
                            versions: {
                              application: t.appVersion,
                              service: t.consentTemplateVersion,
                              settings: t.settingsVersion,
                            },
                          };
                        }),
                        id: t.templateId,
                        processorId: t.processorId,
                        status: t.consentStatus,
                      };
                    }),
                    version: n.usercentrics.settings.version,
                  }),
                  (i[bt.USER_INTERACTION] =
                    n.usercentrics.firstUserInteraction.stateSaved),
                  i)
                : null;
            o &&
              (t.saveSettings(o[bt.SETTINGS]),
              o[bt.USER_INTERACTION] && t.setUserActionPerformed(!0));
          }
        }
      }),
      (t.saveSettings = function (e, n) {
        var i, r;
        if (
          (null === (i = t.getInstance().localStorage) ||
            void 0 === i ||
            i.setItem(bt.SETTINGS, JSON.stringify(e)),
          t.getInstance().getStoreServiceIdToNameMapping() && n && n.length)
        ) {
          var o = n.reduce(function (t, e) {
            return (t[e.id] = e.name), t;
          }, {});
          null === (r = t.getInstance().localStorage) ||
            void 0 === r ||
            r.setItem(bt.SERVICES, JSON.stringify(o));
        }
        Ot.isCrossDomainAvailable() &&
          Ot.setCrossDomainData(e).catch(function () {
            console.warn(at.CROSS_DOMAIN_SET_DATA_FAILURE);
          });
      }),
      (t.saveTCFData = function (e) {
        var n;
        null === (n = t.getInstance().localStorage) ||
          void 0 === n ||
          n.setItem(bt.TCF, JSON.stringify(e)),
          Ot.isCrossDomainAvailable() &&
            Ot.setCrossDomainTcfData(e).catch(function () {
              console.warn(at.CROSS_DOMAIN_SET_TCF_DATA_FAILURE);
            });
      }),
      (t.fetchGcmData = function () {
        var e,
          n =
            null === (e = t.getInstance().localStorage) || void 0 === e
              ? void 0
              : e.getItem(bt.GCM_DATA);
        return n ? JSON.parse(n) : null;
      }),
      (t.saveGcmData = function (e) {
        var n;
        null === (n = t.getInstance().localStorage) ||
          void 0 === n ||
          n.setItem(bt.GCM_DATA, JSON.stringify(e));
      }),
      (t.saveTCString = function (e) {
        var n = t.fetchTCFData();
        this.saveTCFData(ct(ct({}, n), { tcString: e }));
      }),
      (t.setCcpaTimeStamp = function (e) {
        var n,
          i = e || {
            ccpaString: this.getCcpaString() || "",
            timestamp: new Date().getTime(),
          };
        null === (n = t.getInstance().localStorage) ||
          void 0 === n ||
          n.setItem(bt.CCPA_DATA, JSON.stringify(i));
      }),
      (t.getCcpaTimeStamp = function () {
        var t = this.getCcpaData();
        return t && t.timestamp ? t.timestamp : new Date().getTime();
      }),
      (t.setCcpaString = function (e) {
        var n;
        null === (n = t.getInstance().localStorage) ||
          void 0 === n ||
          n.setItem(bt.CCPA, e);
      }),
      (t.settingsExist = function () {
        return Mt(t.fetchSettings());
      }),
      (t.setUserActionPerformed = function (e) {
        var n;
        null === (n = t.getInstance().localStorage) ||
          void 0 === n ||
          n.setItem(bt.USER_INTERACTION, JSON.stringify(e));
      }),
      (t.clearCcpa = function () {
        var e;
        this.clearCcpaData(),
          null === (e = t.getInstance().localStorage) ||
            void 0 === e ||
            e.removeItem(bt.CCPA);
      }),
      (t.clearCcpaData = function () {
        var e;
        null === (e = t.getInstance().localStorage) ||
          void 0 === e ||
          e.removeItem(bt.CCPA_DATA);
      }),
      (t.clearTcf = function () {
        var e;
        null === (e = t.getInstance().localStorage) ||
          void 0 === e ||
          e.removeItem(bt.TCF);
      }),
      (t.clearGcm = function () {
        var e;
        null === (e = t.getInstance().localStorage) ||
          void 0 === e ||
          e.removeItem(bt.GCM_DATA);
      }),
      (t.clear = function () {
        var e, n;
        t.clearCcpa(),
          t.clearTcf(),
          t.clearGcm(),
          null === (e = t.getInstance().localStorage) ||
            void 0 === e ||
            e.removeItem(bt.SETTINGS),
          null === (n = t.getInstance().localStorage) ||
            void 0 === n ||
            n.removeItem(bt.USER_INTERACTION);
      }),
      (t.clearAll = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (t) {
            switch (t.label) {
              case 0:
                return (
                  this.clear(),
                  Ot.isCrossDomainAvailable()
                    ? [4, Ot.clearCrossDomainStorage()]
                    : [3, 2]
                );
              case 1:
                t.sent(), (t.label = 2);
              case 2:
                return [2];
            }
          });
        });
      }),
      (t.fetchAbTestVariant = function (e) {
        var n,
          i,
          r =
            (null === (n = t.getInstance().localStorage) || void 0 === n
              ? void 0
              : n.getItem(bt.AB_TEST_VARIANT)) || "";
        if (e.includes(r)) return r;
        var o = e[Math.floor(Math.random() * e.length)];
        return (
          null === (i = t.getInstance().localStorage) ||
            void 0 === i ||
            i.setItem(bt.AB_TEST_VARIANT, o),
          o
        );
      }),
      (t.clearLegacySettings = function () {
        var e;
        null === (e = t.getInstance().localStorage) ||
          void 0 === e ||
          e.removeItem(bt.LEGACY_SETTINGS);
      }),
      t
    );
  })(),
  Ft = function (t, e) {
    return -1 !== t.indexOf(e);
  },
  Pt = function () {
    return "SDK-".concat(pt);
  },
  Ut = function () {
    return parseInt("3", 10);
  },
  jt = function (t) {
    return Array.isArray(t) && t.length > 0;
  },
  Mt = function (t) {
    return "object" === x(t) && null !== t && Object.keys(t).length > 0;
  },
  Vt = function (t, e) {
    if (void 0 === e)
      throw new Error("altElement of nullishOperation can not be undefined");
    return null != t ? t : e;
  },
  Bt = function (t, e, n, i, r, o) {
    return {
      applicationVersion: Pt(),
      consent: { action: n, status: e.consent.status, type: i },
      service: {
        categorySlug: r || "",
        id: e.id,
        name: e.name,
        processorId: e.processorId,
        version: e.version,
      },
      settings: {
        controllerId: t.controllerId,
        id: t.id,
        language: t.selectedLanguage,
        referrerControllerId: Vt(
          null == o ? void 0 : o.referrerControllerId,
          ""
        ),
        version: t.version,
      },
      timestamp: Vt(null == o ? void 0 : o.timestamp, new Date().valueOf()),
    };
  },
  Ht = function (t) {
    var e = t.dataTransferSettings,
      n = t.services,
      i = t.consentAction,
      r = t.consentString,
      o = t.isCcpa,
      s = t.isTcf,
      a = t.isAnalyticsEnabled,
      l = t.isConsentXDeviceEnabled,
      c = (void 0 === n ? [] : n).map(function (t) {
        return {
          consentStatus: t.consent.status,
          consentTemplateId: t.id,
          consentTemplateVersion: t.version,
        };
      }),
      u = "",
      d = "";
    if (s) {
      var h = Rt.fetchTCFData(),
        f = h.timestamp,
        m = h.vendors,
        b = h.vendorsDisclosed;
      (u = Vt(u ? (null == r ? void 0 : r.TCF2) : h.tcString, "")),
        (d = JSON.stringify({ timestamp: f, vendors: m, vendorsDisclosed: b }));
    } else o && (u = Vt(null == r ? void 0 : r.CCPA, ""));
    return ct(
      ct(
        ct(
          ct(
            {
              action: i,
              analytics: Vt(a, !1),
              appVersion: Pt().replace("SDK-", ""),
            },
            d && { consentMeta: d }
          ),
          { consents: c }
        ),
        u && { consentString: u }
      ),
      {
        controllerId: e.controllerId,
        language: e.selectedLanguage,
        settingsId: e.id,
        settingsVersion: e.version,
        xdevice: Vt(l, !1),
      }
    );
  },
  Gt = function (t, e) {
    return t.reduce(function (t, n) {
      var i = e[n];
      if (!(null == i ? void 0 : i.name)) return t;
      var r = i.name;
      return ft(ft([], ht(t), !1), [{ id: n, name: r }], !1);
    }, []);
  };
function Jt(t) {
  return ft([], ht(new Set(t)), !1);
}
var Wt,
  $t,
  Yt,
  Kt,
  Qt,
  Xt,
  Zt,
  te,
  ee,
  ne,
  ie = function (t) {
    return t && "object" === x(t);
  },
  re = function t(e, n, i) {
    void 0 === i && (i = !1);
    var r = ct({}, n);
    if (!ie(r)) throw new Error("Source param should be an object");
    return ie(e)
      ? (Object.keys(e).forEach(function (n) {
          var o,
            s,
            a,
            l,
            c,
            u = e[n],
            d = r[n];
          void 0 !== d &&
            (r =
              Array.isArray(u) && Array.isArray(d)
                ? ct(
                    ct({}, r),
                    i
                      ? (((o = {})[n] = (c = u.concat(d)).filter(function (
                          t,
                          e
                        ) {
                          return c.indexOf(t) === e;
                        })),
                        o)
                      : (((s = {})[n] = u), s)
                  )
                : ie(u) && ie(d)
                ? ct(ct({}, r), (((a = {})[n] = t(ct({}, u), d)), a))
                : ct(ct({}, r), (((l = {})[n] = u), l)));
        }),
        r)
      : r;
  },
  oe = function (t, e, n, i) {
    return (
      void 0 === n && (n = 2e4),
      void 0 === i && (i = 5),
      new Promise(function (r, o) {
        var s = setInterval(function () {
            t() && (clearTimeout(a), clearInterval(s), r());
          }, i),
          a = setTimeout(function () {
            clearTimeout(a), clearInterval(s), o(new Error(e));
          }, n);
      })
    );
  },
  se = function (t, e) {
    for (
      var n = t.split("."),
        i = e.split("."),
        r = Math.min(n.length, i.length),
        o = 0;
      o < r;
      o += 1
    ) {
      var s = Number(n[o]) || 0,
        a = Number(i[o]) || 0;
      if (s !== a) return s > a ? 1 : -1;
    }
    return i.length - n.length;
  };
!(function (t) {
  (t[(t.COOKIE = 0)] = "COOKIE"),
    (t[(t.WEB = 1)] = "WEB"),
    (t[(t.APP = 2)] = "APP");
})(Wt || (Wt = {})),
  (function (t) {
    (t.LEFT = "LEFT"), (t.CENTER = "CENTER"), (t.RIGHT = "RIGHT");
  })($t || ($t = {})),
  (function (t) {
    (t.CAT = "CAT"), (t.SRV = "SRV");
  })(Yt || (Yt = {})),
  (function (t) {
    (t.AVAILABLE_LANGUAGES_NOT_FOUND =
      "Unable to find available languages using given settingsId and version."),
      (t.FETCH_AVAILABLE_LANGUAGES =
        "Something went wrong while fetching the available languages."),
      (t.FETCH_DATA_PROCESSING_SERVICES =
        "Something went wrong while fetching the data processing services."),
      (t.FETCH_LEGAL_BASIS =
        "Something went wrong while fetching the legal data translations."),
      (t.FETCH_SETTINGS = "Something went wrong while fetching the settings."),
      (t.FETCH_USER_CONSENTS =
        "Something went wrong while fetching the user's consents."),
      (t.FETCH_USER_COUNTRY =
        "Something went wrong while fetching the user's country."),
      (t.FETCH_USER_TCF_DATA =
        "Something went wrong while fetching the user's tcf data."),
      (t.GENERATE_DATA_PROCESSING_SERVICES =
        "Something went wrong while generating the data processing services."),
      (t.RULESET_NOT_FOUND = "Config Map not found!"),
      (t.TAGLOGGER =
        "Tag logger API is being called just before browser unload, some browsers like firefox cancel the api call and throw the error."),
      (t.SAVE_CONSENTS = "Something went wrong while saving user consents."),
      (t.SAVE_CONSENTS_RETRY =
        "Number of retries exceeded for saving user consents."),
      (t.SETTINGS_NOT_FOUND =
        "Unable to find settings using given settingsId and version.");
  })(Kt || (Kt = {})),
  (function (t) {
    (t.US_CA_ONLY = "US_CA_ONLY"), (t.US = "US");
  })(Qt || (Qt = {})),
  (function (t) {
    (t[(t.FIRST_LAYER = 1)] = "FIRST_LAYER"),
      (t[(t.SECOND_LAYER = 3)] = "SECOND_LAYER");
  })(Xt || (Xt = {})),
  (function (t) {
    (t[(t.DATA_LAYER = 1)] = "DATA_LAYER"),
      (t[(t.WINDOW_EVENT = 4)] = "WINDOW_EVENT");
  })(Zt || (Zt = {})),
  (function (t) {
    (t.DATA_COLLECTED_LIST = "dataCollectedList"),
      (t.DATA_PURPOSES_LIST = "dataPurposesList"),
      (t.DATA_RECIPIENTS_LIST = "dataRecipientsList"),
      (t.TECHNOLOGY_USED = "technologyUsed");
  })(te || (te = {})),
  (function (t) {
    (t.MAJOR = "major"), (t.MINOR = "minor"), (t.PATCH = "patch");
  })(ee || (ee = {})),
  (function (t) {
    (t.ICON = "ICON"), (t.LINK = "LINK");
  })(ne || (ne = {}));
var ae,
  le = function (t, e) {
    return "boolean" == typeof t ? t : e;
  },
  ce = function (t) {
    if (!t) return null;
    var e = t.startsWith("#") ? t : "#".concat(t);
    return ue(e) ? e : "#0045A5";
  },
  ue = function (t) {
    return !("" === t || !t) && /^#(?:[0-9a-fA-F]{3}){1,2}$/.test(t);
  },
  de = function (t) {
    if (null != t.firstLayer.isOverlayEnabled)
      return t.firstLayer.isOverlayEnabled;
    var e = t.backgroundOverlay.find(function (t) {
      var e;
      return (
        (null === (e = t.target) || void 0 === e ? void 0 : e[0]) ===
        Xt.FIRST_LAYER
      );
    });
    return !!e && (null == e ? void 0 : e.darken) > 0;
  },
  he = function (t) {
    if (null != t.secondLayer.isOverlayEnabled)
      return t.secondLayer.isOverlayEnabled;
    var e = t.backgroundOverlay.find(function (t) {
      var e;
      return (
        (null === (e = t.target) || void 0 === e ? void 0 : e[0]) ===
        Xt.SECOND_LAYER
      );
    });
    return !!e && (null == e ? void 0 : e.darken) > 0;
  },
  fe = function (t) {
    return "number" == typeof t || ("string" == typeof t && !t.includes("px"))
      ? "".concat(t, "px")
      : t;
  },
  me = function (t) {
    switch (t) {
      case $t.CENTER:
        return "center";
      case $t.RIGHT:
        return "right";
      default:
        return "left";
    }
  },
  be = { description: "", id: "", legalBasis: [], name: "" },
  ge = function (t, e) {
    return t.reduce(function (t, n) {
      var i = e.find(function (t) {
        return t.id === n.id;
      });
      return i
        ? ft(
            ft([], ht(t), !1),
            [
              {
                categorySlug: n.categorySlug,
                consent: n.consent,
                id: n.id,
                language: n.language,
                name: i.name,
                processorId: n.processorId,
                version: n.version,
              },
            ],
            !1
          )
        : ft([], ht(t), !1);
    }, []);
  },
  we = function t(e, n) {
    return e.map(function (e) {
      var i = n.find(function (t) {
        return t.id === e.id;
      });
      return ct(ct(ct({}, e), i || be), {
        description:
          e.description ||
          (null == i ? void 0 : i.description) ||
          be.description,
        id: e.id,
        subServices: t(e.subServices, n),
      });
    });
  },
  pe = function (t) {
    return null != t && null != t.region;
  },
  ve = function (t) {
    return null != t && null != t.changedPurposes;
  },
  ye = function (t) {
    var e;
    return (
      null != t &&
      null !=
        (null === (e = t.buttons) || void 0 === e ? void 0 : e.optOutNotice)
    );
  },
  xe = function (t) {
    return null != t && null != t.vendor;
  },
  ke = function (t) {
    var e;
    return (
      null != t &&
      null !=
        (null === (e = t.buttons) || void 0 === e ? void 0 : e.showSecondLayer)
    );
  },
  qe = function (t) {
    return null != t && (ye(t) || ke(t) || xe(t));
  },
  Se = {
    acceptAllButton: "Accept All",
    ccpaButton: "Agree to CCPA",
    ccpaMoreInformation: "More Information",
    closeButton: "Close Second Layer",
    collapse: "Collapse",
    cookiePolicyButton: "Open Cookie Policy",
    copyControllerId: "Copy Controller ID",
    denyAllButton: "Deny all",
    expand: "Expand",
    fullscreenButton: "Enter full screen",
    imprintButton: "Open Imprint",
    languageSelector: "Select language",
    privacyButton: "Open",
    privacyPolicyButton: "Open Privacy Policy",
    saveButton: "Save",
    serviceInCategoryDetails: "View Service details",
    servicesInCategory: "List of Services in this category",
    tabButton: "Tab",
    usercentricsCard: "Card",
    usercentricsCMPButtons: "Footer including buttons",
    usercentricsCMPContent: "Content",
    usercentricsCMPHeader:
      "Header including language selection and external links",
    usercentricsCMPUI: "Consent Management Platform Interface",
    usercentricsList: "List",
    vendorConsentToggle: "Consent",
    vendorDetailedStorageInformation: "Detailed Storage Information",
    vendorLegIntToggle: "Legitimate Interest",
  },
  Ce = "https://www.usercentrics.com/",
  _e = (function () {
    function t() {
      this.ampEnabled = !1;
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        t.instance.ampEnabled = !1;
      }),
      (t.prototype.isAmpEnabled = function () {
        return this.ampEnabled;
      }),
      (t.prototype.setIsAmpEnabled = function (t) {
        this.ampEnabled = t;
      }),
      t
    );
  })(),
  Te = "latest",
  Ae = {
    EU_URI: {
      AGGREGATOR: "https://aggregator.eu.usercentrics.eu/aggregate/",
      CDN: "https://config.eu.usercentrics.eu",
      FETCH_CONSENTS: "https://consents.eu.usercentrics.eu/consentsHistory",
      FETCH_CONSENTS_V2:
        "https://consent-rt-ret.service.consent.eu1.usercentrics.eu",
      FETCH_TCF_DATA: "https://consents.eu.usercentrics.eu/consentsHistoryTCF",
      FETCH_TCF_DATA_V2: "https://consents.eu.usercentrics.eu/consentState",
      GRAPHQL: "https://api.eu.usercentrics.eu/graphql",
      SAVE_CONSENTS_V2:
        "https://consent-api.service.consent.eu1.usercentrics.eu/consent",
      TRACK_EVENT: "https://uct.eu.usercentrics.eu/uct",
      TRACK_SESSION: "https://app.eu.usercentrics.eu/session/1px.png",
    },
    FOLDER: {
      RULESET: "ruleSet",
      SETTINGS: "settings",
      TEMPLATES: "consent-templates",
      TRANSLATIONS: "translations",
    },
    URI: {
      AGGREGATOR: "https://aggregator.service.usercentrics.eu/aggregate/",
      CDN: "https://api.usercentrics.eu",
      FETCH_CONSENTS: "https://consents.usercentrics.eu/consentsHistory",
      FETCH_CONSENTS_V2:
        "https://consent-rt-ret.service.consent.usercentrics.eu",
      FETCH_TCF_DATA: "https://consents.usercentrics.eu/consentsHistoryTCF",
      FETCH_TCF_DATA_V2: "https://consents.usercentrics.eu/consentState",
      GRAPHQL: "https://graphql.usercentrics.eu/graphql",
      RULESET: "https://api.usercentrics.eu",
      SAVE_CONSENTS_V2:
        "https://consent-api.service.consent.usercentrics.eu/consent",
      TRACK_EVENT: "https://uct.service.usercentrics.eu/uct",
      TRACK_SESSION: "https://app.usercentrics.eu/session/1px.png",
    },
  },
  Ee = {
    EU_URI: {
      AGGREGATOR:
        "https://aggregator.service.usercentrics-sandbox.eu/aggregate/",
      CDN: "https://api.usercentrics-sandbox.eu",
      FETCH_CONSENTS:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistory",
      FETCH_CONSENTS_V2:
        "https://consent-rt-ret.service.consent.eu1.usercentrics-staging.eu",
      FETCH_TCF_DATA:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistoryTCF",
      FETCH_TCF_DATA_V2:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentState",
      GRAPHQL:
        "https://api-v2-sandbox-consent-dot-usercentrics-playground.nw.r.appspot.com/",
      SAVE_CONSENTS_V2:
        "https://consent-api.service.consent.eu1.usercentrics-staging.eu/consent",
      TRACK_EVENT: "https://uct.eu.usercentrics.eu/uct",
      TRACK_SESSION: "https://app.usercentrics-sandbox.eu/session/1px.png",
    },
    FOLDER: {
      RULESET: "ruleSet",
      SETTINGS: "settings",
      TEMPLATES: "consent-templates",
      TRANSLATIONS: "translations",
    },
    URI: {
      AGGREGATOR:
        "https://aggregator.service.usercentrics-sandbox.eu/aggregate/",
      CDN: "https://api.usercentrics-sandbox.eu",
      FETCH_CONSENTS:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistory",
      FETCH_CONSENTS_V2:
        "https://consent-rt-ret.service.consent.usercentrics-staging.eu",
      FETCH_TCF_DATA:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistoryTCF",
      FETCH_TCF_DATA_V2:
        "https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentState",
      GRAPHQL:
        "https://api-v2-sandbox-consent-dot-usercentrics-playground.nw.r.appspot.com/",
      RULESET: "https://api.usercentrics-sandbox.eu",
      SAVE_CONSENTS_V2:
        "https://consent-api.service.consent.usercentrics-staging.eu/consent",
      TRACK_EVENT: "https://uct.service.usercentrics.eu/uct",
      TRACK_SESSION: "https://app.usercentrics-sandbox.eu/session/1px.png",
    },
  },
  ze = ["onEssentialChange", "onInitialPageLoad", "onNonEURegion"],
  Oe = ["onSessionRestored", "onMobileSessionRestore"],
  Ie = function (t, e, n) {
    return ut(void 0, void 0, void 0, function () {
      return dt(this, function () {
        return [2, Le(t, e, null, n)];
      });
    });
  },
  De = function (t, e, n, i) {
    return ut(void 0, void 0, void 0, function () {
      return dt(this, function () {
        return [2, Le(t, n, e, i)];
      });
    });
  },
  Le = function (t, e, n, i) {
    return ut(void 0, void 0, void 0, function () {
      var r, o;
      return dt(this, function () {
        return (
          (r = { "content-type": "application/json" }),
          (o = ct(ct({}, i), { headers: r, method: n ? "POST" : "GET" })),
          n && (o.body = JSON.stringify(n)),
          (null == i ? void 0 : i.headers) &&
            (o.headers = ct(ct({}, r), i.headers)),
          [
            2,
            fetch(t, o).then(function (t) {
              return ut(void 0, void 0, void 0, function () {
                return dt(this, function () {
                  if (t.ok) return [2, Re(t)];
                  throw Ne(e, t.status);
                });
              });
            }),
          ]
        );
      });
    });
  },
  Ne = function (t, e) {
    return { errorMessage: t, statusCode: e };
  },
  Re = function (t) {
    return ut(void 0, void 0, void 0, function () {
      return dt(this, function (e) {
        switch (e.label) {
          case 0:
            return [4, Fe(t)];
          case 1:
            return [
              2,
              {
                data: e.sent(),
                location: t.headers.get("x-client-geo-location"),
                statusCode: t.status,
              },
            ];
        }
      });
    });
  },
  Fe = function (t) {
    return ut(void 0, void 0, void 0, function () {
      var e, n;
      return dt(this, function (i) {
        switch (i.label) {
          case 0:
            return [4, t.text()];
          case 1:
            return (
              (e = i.sent()), [2, (n = "" === e ? {} : JSON.parse(e)).data || n]
            );
        }
      });
    });
  };
!(function (t) {
  t[(t.RESOURCE_NOT_FOUND = 403)] = "RESOURCE_NOT_FOUND";
})(ae || (ae = {}));
var Pe,
  Ue =
    "undefined" != typeof globalThis
      ? globalThis
      : "undefined" != typeof window
      ? window
      : "undefined" != typeof global
      ? global
      : "undefined" != typeof self
      ? self
      : {},
  je = { exports: {} },
  Me = { exports: {} };
(Me.exports =
  ((Pe =
    Pe ||
    (function (t) {
      var e;
      if (
        ("undefined" != typeof window && window.crypto && (e = window.crypto),
        "undefined" != typeof self && self.crypto && (e = self.crypto),
        "undefined" != typeof globalThis &&
          globalThis.crypto &&
          (e = globalThis.crypto),
        !e &&
          "undefined" != typeof window &&
          window.msCrypto &&
          (e = window.msCrypto),
        !e && void 0 !== Ue && Ue.crypto && (e = Ue.crypto),
        !e)
      )
        try {
          e = require("crypto");
        } catch (N) {}
      var n = function () {
          if (e) {
            if ("function" == typeof e.getRandomValues)
              try {
                return e.getRandomValues(new Uint32Array(1))[0];
              } catch (N) {}
            if ("function" == typeof e.randomBytes)
              try {
                return e.randomBytes(4).readInt32LE();
              } catch (N) {}
          }
          throw new Error(
            "Native crypto module could not be used to get secure random number."
          );
        },
        i =
          Object.create ||
          (function () {
            function t() {}
            return function (e) {
              var n;
              return (t.prototype = e), (n = new t()), (t.prototype = null), n;
            };
          })(),
        r = {},
        o = (r.lib = {}),
        s = (o.Base = {
          extend: function (t) {
            var e = i(this);
            return (
              t && e.mixIn(t),
              (e.hasOwnProperty("init") && this.init !== e.init) ||
                (e.init = function () {
                  e.$super.init.apply(this, arguments);
                }),
              (e.init.prototype = e),
              (e.$super = this),
              e
            );
          },
          create: function () {
            var t = this.extend();
            return t.init.apply(t, arguments), t;
          },
          init: function () {},
          mixIn: function (t) {
            for (var e in t) t.hasOwnProperty(e) && (this[e] = t[e]);
            t.hasOwnProperty("toString") && (this.toString = t.toString);
          },
          clone: function () {
            return this.init.prototype.extend(this);
          },
        }),
        a = (o.WordArray = s.extend({
          init: function (t, e) {
            (t = this.words = t || []),
              (this.sigBytes = null != e ? e : 4 * t.length);
          },
          toString: function (t) {
            return (t || c).stringify(this);
          },
          concat: function (t) {
            var e = this.words,
              n = t.words,
              i = this.sigBytes,
              r = t.sigBytes;
            if ((this.clamp(), i % 4))
              for (var o = 0; o < r; o++)
                e[(i + o) >>> 2] |=
                  ((n[o >>> 2] >>> (24 - (o % 4) * 8)) & 255) <<
                  (24 - ((i + o) % 4) * 8);
            else for (var s = 0; s < r; s += 4) e[(i + s) >>> 2] = n[s >>> 2];
            return (this.sigBytes += r), this;
          },
          clamp: function () {
            var e = this.words,
              n = this.sigBytes;
            (e[n >>> 2] &= 4294967295 << (32 - (n % 4) * 8)),
              (e.length = t.ceil(n / 4));
          },
          clone: function () {
            var t = s.clone.call(this);
            return (t.words = this.words.slice(0)), t;
          },
          random: function (t) {
            for (var e = [], i = 0; i < t; i += 4) e.push(n());
            return new a.init(e, t);
          },
        })),
        l = (r.enc = {}),
        c = (l.Hex = {
          stringify: function (t) {
            for (var e = t.words, n = t.sigBytes, i = [], r = 0; r < n; r++) {
              var o = (e[r >>> 2] >>> (24 - (r % 4) * 8)) & 255;
              i.push((o >>> 4).toString(16)), i.push((15 & o).toString(16));
            }
            return i.join("");
          },
          parse: function (t) {
            for (var e = t.length, n = [], i = 0; i < e; i += 2)
              n[i >>> 3] |= parseInt(t.substr(i, 2), 16) << (24 - (i % 8) * 4);
            return new a.init(n, e / 2);
          },
        }),
        u = (l.Latin1 = {
          stringify: function (t) {
            for (var e = t.words, n = t.sigBytes, i = [], r = 0; r < n; r++)
              i.push(
                String.fromCharCode((e[r >>> 2] >>> (24 - (r % 4) * 8)) & 255)
              );
            return i.join("");
          },
          parse: function (t) {
            for (var e = t.length, n = [], i = 0; i < e; i++)
              n[i >>> 2] |= (255 & t.charCodeAt(i)) << (24 - (i % 4) * 8);
            return new a.init(n, e);
          },
        }),
        d = (l.Utf8 = {
          stringify: function (t) {
            try {
              return decodeURIComponent(escape(u.stringify(t)));
            } catch (x) {
              throw new Error("Malformed UTF-8 data");
            }
          },
          parse: function (t) {
            return u.parse(unescape(encodeURIComponent(t)));
          },
        }),
        h = (o.BufferedBlockAlgorithm = s.extend({
          reset: function () {
            (this._data = new a.init()), (this._nDataBytes = 0);
          },
          _append: function (t) {
            "string" == typeof t && (t = d.parse(t)),
              this._data.concat(t),
              (this._nDataBytes += t.sigBytes);
          },
          _process: function (e) {
            var n,
              i = this._data,
              r = i.words,
              o = i.sigBytes,
              s = this.blockSize,
              l = o / (4 * s),
              c =
                (l = e ? t.ceil(l) : t.max((0 | l) - this._minBufferSize, 0)) *
                s,
              u = t.min(4 * c, o);
            if (c) {
              for (var d = 0; d < c; d += s) this._doProcessBlock(r, d);
              (n = r.splice(0, c)), (i.sigBytes -= u);
            }
            return new a.init(n, u);
          },
          clone: function () {
            var t = s.clone.call(this);
            return (t._data = this._data.clone()), t;
          },
          _minBufferSize: 0,
        }));
      o.Hasher = h.extend({
        cfg: s.extend(),
        init: function (t) {
          (this.cfg = this.cfg.extend(t)), this.reset();
        },
        reset: function () {
          h.reset.call(this), this._doReset();
        },
        update: function (t) {
          return this._append(t), this._process(), this;
        },
        finalize: function (t) {
          return t && this._append(t), this._doFinalize();
        },
        blockSize: 16,
        _createHelper: function (t) {
          return function (e, n) {
            return new t.init(n).finalize(e);
          };
        },
        _createHmacHelper: function (t) {
          return function (e, n) {
            return new f.HMAC.init(t, n).finalize(e);
          };
        },
      });
      var f = (r.algo = {});
      return r;
    })(Math)),
  Pe)),
  (je.exports = (function (t) {
    return (
      (function (e) {
        var n = t,
          i = n.lib,
          r = i.WordArray,
          o = i.Hasher,
          s = n.algo,
          a = [],
          l = [];
        !(function () {
          function t(t) {
            for (var n = e.sqrt(t), i = 2; i <= n; i++) if (!(t % i)) return !1;
            return !0;
          }
          function n(t) {
            return (4294967296 * (t - (0 | t))) | 0;
          }
          for (var i = 2, r = 0; r < 64; )
            t(i) &&
              (r < 8 && (a[r] = n(e.pow(i, 0.5))),
              (l[r] = n(e.pow(i, 1 / 3))),
              r++),
              i++;
        })();
        var c = [],
          u = (s.SHA256 = o.extend({
            _doReset: function () {
              this._hash = new r.init(a.slice(0));
            },
            _doProcessBlock: function (t, e) {
              for (
                var n = this._hash.words,
                  i = n[0],
                  r = n[1],
                  o = n[2],
                  s = n[3],
                  a = n[4],
                  u = n[5],
                  d = n[6],
                  h = n[7],
                  f = 0;
                f < 64;
                f++
              ) {
                if (f < 16) c[f] = 0 | t[e + f];
                else {
                  var m = c[f - 15],
                    b = c[f - 2];
                  c[f] =
                    (((m << 25) | (m >>> 7)) ^
                      ((m << 14) | (m >>> 18)) ^
                      (m >>> 3)) +
                    c[f - 7] +
                    (((b << 15) | (b >>> 17)) ^
                      ((b << 13) | (b >>> 19)) ^
                      (b >>> 10)) +
                    c[f - 16];
                }
                var g = (i & r) ^ (i & o) ^ (r & o),
                  w =
                    h +
                    (((a << 26) | (a >>> 6)) ^
                      ((a << 21) | (a >>> 11)) ^
                      ((a << 7) | (a >>> 25))) +
                    ((a & u) ^ (~a & d)) +
                    l[f] +
                    c[f];
                (h = d),
                  (d = u),
                  (u = a),
                  (a = (s + w) | 0),
                  (s = o),
                  (o = r),
                  (r = i),
                  (i =
                    (w +
                      ((((i << 30) | (i >>> 2)) ^
                        ((i << 19) | (i >>> 13)) ^
                        ((i << 10) | (i >>> 22))) +
                        g)) |
                    0);
              }
              (n[0] = (n[0] + i) | 0),
                (n[1] = (n[1] + r) | 0),
                (n[2] = (n[2] + o) | 0),
                (n[3] = (n[3] + s) | 0),
                (n[4] = (n[4] + a) | 0),
                (n[5] = (n[5] + u) | 0),
                (n[6] = (n[6] + d) | 0),
                (n[7] = (n[7] + h) | 0);
            },
            _doFinalize: function () {
              var t = this._data,
                n = t.words,
                i = 8 * this._nDataBytes,
                r = 8 * t.sigBytes;
              return (
                (n[r >>> 5] |= 128 << (24 - (r % 32))),
                (n[14 + (((r + 64) >>> 9) << 4)] = e.floor(i / 4294967296)),
                (n[15 + (((r + 64) >>> 9) << 4)] = i),
                (t.sigBytes = 4 * n.length),
                this._process(),
                this._hash
              );
            },
            clone: function () {
              var t = o.clone.call(this);
              return (t._hash = this._hash.clone()), t;
            },
          }));
        (n.SHA256 = o._createHelper(u)),
          (n.HmacSHA256 = o._createHmacHelper(u));
      })(Math),
      t.SHA256
    );
  })(Me.exports));
var Ve,
  Be = je.exports,
  He = new Uint8Array(16);
function Ge() {
  if (
    !Ve &&
    !(Ve =
      "undefined" != typeof crypto &&
      crypto.getRandomValues &&
      crypto.getRandomValues.bind(crypto))
  )
    throw new Error(
      "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
    );
  return Ve(He);
}
for (var Je = [], We = 0; We < 256; ++We)
  Je.push((We + 256).toString(16).slice(1));
var $e = {
  randomUUID:
    "undefined" != typeof crypto &&
    crypto.randomUUID &&
    crypto.randomUUID.bind(crypto),
};
function Ye(t, e, n) {
  if ($e.randomUUID && !e && !t) return $e.randomUUID();
  var i = (t = t || {}).random || (t.rng || Ge)();
  if (((i[6] = (15 & i[6]) | 64), (i[8] = (63 & i[8]) | 128), e)) {
    n = n || 0;
    for (var r = 0; r < 16; ++r) e[n + r] = i[r];
    return e;
  }
  return (function (t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    return (
      Je[t[e + 0]] +
      Je[t[e + 1]] +
      Je[t[e + 2]] +
      Je[t[e + 3]] +
      "-" +
      Je[t[e + 4]] +
      Je[t[e + 5]] +
      "-" +
      Je[t[e + 6]] +
      Je[t[e + 7]] +
      "-" +
      Je[t[e + 8]] +
      Je[t[e + 9]] +
      "-" +
      Je[t[e + 10]] +
      Je[t[e + 11]] +
      Je[t[e + 12]] +
      Je[t[e + 13]] +
      Je[t[e + 14]] +
      Je[t[e + 15]]
    ).toLowerCase();
  })(i);
}
var Ke = (function () {
    function t() {
      (this.needsSessionRestore = !1), (this.controllerId = "");
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        t.instance.controllerId = "";
      }),
      Object.defineProperty(t.prototype, "value", {
        get: function () {
          return this.controllerId;
        },
        set: function (t) {
          this.controllerId = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      (t.prototype.setControllerIdByResolvedSettingsId = function (t, e) {
        var n = e.find(function (e) {
          return t === e.settingsId;
        });
        n && (this.value = n.controllerId);
      }),
      (t.prototype.setNeedSessionRestore = function () {
        this.needsSessionRestore = "" !== this.controllerId;
      }),
      (t.prototype.init = function () {
        if ("" === this.controllerId) {
          var t = this.getStorageControllerId();
          this.controllerId = t || this.generateControllerId();
        }
      }),
      (t.prototype.generateControllerId = function () {
        return "".concat(Be(Ye()));
      }),
      (t.prototype.getStorageControllerId = function () {
        return Rt.fetchControllerId();
      }),
      t
    );
  })(),
  Qe = [
    "AT",
    "BE",
    "BG",
    "CY",
    "CZ",
    "DE",
    "DK",
    "EE",
    "ES",
    "FI",
    "FR",
    "GR",
    "HR",
    "HU",
    "IE",
    "IT",
    "LT",
    "LU",
    "LV",
    "MT",
    "NL",
    "PL",
    "PT",
    "RO",
    "SE",
    "SI",
    "SK",
  ],
  Xe = (function () {
    function t() {
      (this.userCountryData = {}),
        (this.convertUserCountryString = function (t) {
          var e = null == t ? void 0 : t.split(","),
            n = e && e[0] ? e[0] : "DE";
          return {
            countryCode: n,
            countryName: n || "Germany (default)",
            regionCode: e && e[1] && e[1].length >= 3 ? e[1].substring(2) : "",
          };
        });
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        t.instance.userCountryData = {};
      }),
      (t.prototype.setUserCountryData = function (t) {
        this.userCountryData = t;
      }),
      (t.prototype.getUserCountryData = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, this.userCountryData];
          });
        });
      }),
      (t.prototype.getIsUserInCalifornia = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return [2, this.getIsUserInUS("CA")];
          });
        });
      }),
      (t.prototype.getIsUserInEU = function () {
        return ut(this, void 0, void 0, function () {
          var t;
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return [4, this.getUserCountryData()];
              case 1:
                return (t = e.sent()), [2, Ft(Qe, t.code.toUpperCase())];
            }
          });
        });
      }),
      (t.prototype.getIsUserInUS = function (t) {
        return ut(this, void 0, void 0, function () {
          var e;
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return [4, this.getUserCountryData()];
              case 1:
                return [
                  2,
                  "US" === (e = n.sent()).code && (!t || e.regionCode === t),
                ];
            }
          });
        });
      }),
      (t.prototype.resolveLocation = function (e) {
        return ut(this, void 0, void 0, function () {
          var n, i;
          return dt(this, function (r) {
            switch (r.label) {
              case 0:
                return (
                  (n = this.convertUserCountryString(e)),
                  [4, t.getInstance().getUserCountryData()]
                );
              case 1:
                return (
                  (i = r.sent()),
                  Mt(i) ||
                    (Rt.setUserCountryResponse(n),
                    this.setUserCountryData({
                      code: n.countryCode,
                      name: n.countryName,
                      regionCode: n.regionCode,
                    })),
                  [2]
                );
            }
          });
        });
      }),
      (t.mapUserCountryData = function (t) {
        return {
          countryCode: t.code,
          countryName: t.name,
          regionCode: t.regionCode,
        };
      }),
      t
    );
  })(),
  Ze = {
    numOfAttempts: 7,
    onFirstFail: function () {},
    onFirstRetriedSuccess: function () {},
    startingDelay: 100,
    timeMultiple: 2,
  };
function tn(t, e) {
  return (
    void 0 === e && (e = {}),
    ut(this, void 0, void 0, function () {
      var n;
      return dt(this, function (i) {
        switch (i.label) {
          case 0:
            return (
              (n = (function (t) {
                var e = ct(ct({}, Ze), t);
                return e.numOfAttempts < 1 && (e.numOfAttempts = 1), e;
              })(e)),
              [4, new nn(t, n).execute()]
            );
          case 1:
            return [2, i.sent()];
        }
      });
    })
  );
}
var en,
  nn = (function () {
    function t(t, e) {
      (this.request = t), (this.options = e), (this.attemptNumber = 0);
    }
    return (
      (t.prototype.execute = function () {
        return ut(this, void 0, void 0, function () {
          var t, e;
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                if (this.attemptLimitReached) return [3, 7];
                n.label = 1;
              case 1:
                return (
                  n.trys.push([1, 5, , 6]),
                  this.attemptNumber ? [4, this.wait(this.delay)] : [3, 3]
                );
              case 2:
                n.sent(), (n.label = 3);
              case 3:
                return [4, this.request()];
              case 4:
                return (
                  (t = n.sent()),
                  this.attemptNumber && this.options.onFirstRetriedSuccess(),
                  [2, t]
                );
              case 5:
                if (
                  ((e = n.sent()),
                  this.attemptNumber || this.options.onFirstFail(),
                  (this.attemptNumber += 1),
                  this.attemptLimitReached)
                )
                  throw e;
                return [3, 6];
              case 6:
                return [3, 0];
              case 7:
                throw new Error("Something went wrong.");
            }
          });
        });
      }),
      Object.defineProperty(t.prototype, "attemptLimitReached", {
        get: function () {
          return this.attemptNumber >= this.options.numOfAttempts;
        },
        enumerable: !1,
        configurable: !0,
      }),
      (t.prototype.wait = function (t) {
        return new Promise(function (e) {
          return setTimeout(e, t);
        });
      }),
      Object.defineProperty(t.prototype, "delay", {
        get: function () {
          return (
            this.options.startingDelay *
            Math.pow(this.options.timeMultiple, this.attemptNumber)
          );
        },
        enumerable: !1,
        configurable: !0,
      }),
      t
    );
  })(),
  rn = function (t, e) {
    return { id: t, version: e };
  },
  on = function (t) {
    if (!t) return [];
    var e,
      n,
      i = t.reduce(function (t, e) {
        return ft(ft([], ht(t), !1), [rn(e.templateId, e.version)], !1);
      }, []);
    return (function (t) {
      return t.sort(function (t, e) {
        return t.id > e.id ? 1 : -1;
      });
    })(
      ((e = function (t, e) {
        return t.id === e.id && t.version === e.version;
      }),
      (n = []),
      i.forEach(function (t) {
        -1 ===
          n.findIndex(function (n) {
            return e(t, n);
          }) && n.push(t);
      }),
      n)
    );
  },
  sn = (function () {
    function t() {
      (this.API = Ae),
        (this.abTestVariant = ""),
        (this.controllerIdInstance = Ke.getInstance()),
        (this.jsonCacheBustingString = ""),
        (this.jsonFileLanguage = ""),
        (this.jsonFileVersion = Te),
        (this.settingsId = ""),
        (this.rulesetId = ""),
        (this.useEuCdn = !1),
        (this.disableServerConsents = !1),
        (this.aggregatedServicesCache = null),
        (this.translationsCache = null);
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        (t.instance.jsonCacheBustingString = ""),
          (t.instance.jsonFileLanguage = ""),
          (t.instance.jsonFileVersion = Te),
          (t.instance.settingsId = ""),
          (t.instance.disableServerConsents = !1);
      }),
      (t.prototype.resetAggregatedServicesCache = function () {
        this.aggregatedServicesCache = null;
      }),
      (t.prototype.resetTranslationsCache = function () {
        this.translationsCache = null;
      }),
      (t.prototype.getAbTestVariant = function () {
        return this.abTestVariant;
      }),
      (t.prototype.getJsonFileLanguage = function () {
        return this.jsonFileLanguage;
      }),
      (t.prototype.getJsonFileVersion = function () {
        return this.jsonFileVersion;
      }),
      (t.prototype.getSettingsId = function () {
        return this.settingsId;
      }),
      (t.prototype.getRulesetId = function () {
        return this.rulesetId;
      }),
      (t.prototype.getDisableServerConsents = function () {
        return this.disableServerConsents;
      }),
      (t.prototype.setJsonCacheBustingString = function (t) {
        this.jsonCacheBustingString = t;
      }),
      (t.prototype.setJsonFileLanguage = function (t) {
        this.jsonFileLanguage = t;
      }),
      (t.prototype.setJsonFileVersion = function (t) {
        this.jsonFileVersion = t;
      }),
      (t.prototype.setDisableServerConsents = function (t) {
        this.disableServerConsents = t;
      }),
      (t.prototype.setDomains = function (t, e) {
        this.API = t
          ? Ee
          : e
          ? {
              EU_URI: {
                AGGREGATOR: Ae.EU_URI.AGGREGATOR,
                CDN: Ae.EU_URI.CDN,
                FETCH_CONSENTS: Ae.EU_URI.FETCH_CONSENTS,
                FETCH_CONSENTS_V2: Ae.EU_URI.FETCH_CONSENTS_V2,
                FETCH_TCF_DATA: Ae.EU_URI.FETCH_TCF_DATA,
                FETCH_TCF_DATA_V2: Ae.EU_URI.FETCH_TCF_DATA_V2,
                GRAPHQL: Ae.EU_URI.GRAPHQL,
                SAVE_CONSENTS_V2: Ae.EU_URI.SAVE_CONSENTS_V2,
                TRACK_EVENT: Ae.EU_URI.TRACK_EVENT,
                TRACK_SESSION: Ae.EU_URI.TRACK_SESSION,
              },
              FOLDER: {
                RULESET: "configMap",
                SETTINGS: "settings",
                TEMPLATES: "consent-templates",
                TRANSLATIONS: "translations",
              },
              URI: ct(
                ct(
                  {
                    AGGREGATOR:
                      "" !== e.aggregator
                        ? "".concat(e.aggregator, "/aggregate/")
                        : Ae.URI.AGGREGATOR,
                    CDN: "" !== e.cdn ? e.cdn : Ae.URI.CDN,
                    RULESET: Ae.URI.RULESET,
                  },
                  "" !== e.consents
                    ? {
                        FETCH_CONSENTS: "".concat(
                          e.consents,
                          "/consentsHistory"
                        ),
                        FETCH_CONSENTS_V2: "".concat(e.consents),
                        FETCH_TCF_DATA: "".concat(
                          e.consents,
                          "/consentsHistoryTCF"
                        ),
                        FETCH_TCF_DATA_V2: "".concat(
                          e.consents,
                          "/consentState"
                        ),
                      }
                    : {
                        FETCH_CONSENTS: Ae.URI.FETCH_CONSENTS,
                        FETCH_CONSENTS_V2: Ae.URI.FETCH_CONSENTS_V2,
                        FETCH_TCF_DATA: Ae.URI.FETCH_TCF_DATA,
                        FETCH_TCF_DATA_V2: Ae.URI.FETCH_TCF_DATA_V2,
                      }
                ),
                {
                  GRAPHQL:
                    "" !== e.graphql
                      ? "".concat(e.graphql, "/graphql")
                      : Ae.URI.GRAPHQL,
                  SAVE_CONSENTS_V2:
                    "" !== e.consentsV2
                      ? "".concat(e.consentsV2, "/consent")
                      : Ae.URI.SAVE_CONSENTS_V2,
                  TRACK_EVENT:
                    "" !== e.trackingEvent
                      ? "".concat(e.trackingEvent, "/uct")
                      : Ae.URI.TRACK_EVENT,
                  TRACK_SESSION:
                    "" !== e.app
                      ? "".concat(e.app, "/session/1px.png")
                      : Ae.URI.TRACK_SESSION,
                }
              ),
            }
          : Ae;
      }),
      (t.prototype.setSettingsId = function (t) {
        this.settingsId = t;
      }),
      (t.prototype.setRulesetId = function (t) {
        this.rulesetId = t;
      }),
      (t.prototype.setEuMode = function (t) {
        this.useEuCdn = t;
      }),
      (t.prototype.isEuMode = function () {
        return this.useEuCdn;
      }),
      (t.prototype.getAggregatorUri = function () {
        return this.isEuMode()
          ? this.API.EU_URI.AGGREGATOR
          : this.API.URI.AGGREGATOR;
      }),
      (t.prototype.getCdnUri = function () {
        return this.isEuMode() ? this.API.EU_URI.CDN : this.API.URI.CDN;
      }),
      (t.prototype.getGraphQLUri = function () {
        return this.isEuMode() ? this.API.EU_URI.GRAPHQL : this.API.URI.GRAPHQL;
      }),
      (t.prototype.getTcfDataV2Uri = function () {
        return this.isEuMode()
          ? this.API.EU_URI.FETCH_TCF_DATA_V2
          : this.API.URI.FETCH_TCF_DATA_V2;
      }),
      (t.prototype.fetchAggregatedServices = function (t, e) {
        return (
          void 0 === e && (e = !0),
          ut(this, void 0, void 0, function () {
            var n, i;
            return dt(this, function (r) {
              switch (r.label) {
                case 0:
                  return this.aggregatedServicesCache && e
                    ? [2, this.aggregatedServicesCache]
                    : ((n = ""
                        .concat(this.getAggregatorUri())
                        .concat(this.jsonFileLanguage, "?templates=")
                        .concat(
                          t
                            .map(function (t) {
                              return "".concat(t.id, "@").concat(t.version);
                            })
                            .join(",")
                        )),
                      [4, Ie(n, Kt.GENERATE_DATA_PROCESSING_SERVICES)]);
                case 1:
                  return (
                    (i = r.sent()),
                    e && (this.aggregatedServicesCache = i.data.templates),
                    [2, i.data.templates]
                  );
              }
            });
          })
        );
      }),
      (t.prototype.fetchRuleset = function () {
        var t;
        return ut(this, void 0, void 0, function () {
          var e, n, i, r;
          return dt(this, function (o) {
            switch (o.label) {
              case 0:
                return (
                  o.trys.push([0, 2, , 3]),
                  (e = this.createRulesetUrl()),
                  [4, Ie(e, Kt.RULESET_NOT_FOUND)]
                );
              case 1:
                return (
                  (n = o.sent()),
                  (i =
                    null === (t = n.location) || void 0 === t
                      ? void 0
                      : t.split(",")),
                  [
                    2,
                    {
                      defaultRule: n.data.defaultRule,
                      description: n.data.description,
                      location: {
                        code: i ? i[0] : "",
                        name: n.location || "",
                        regionCode: i && i[1] ? i[1] : "",
                      },
                      rules: n.data.rules,
                    },
                  ]
                );
              case 2:
                throw (
                  ((r = o.sent()).statusCode &&
                    r.statusCode === ae.RESOURCE_NOT_FOUND &&
                    (r.errorMessage = Kt.RULESET_NOT_FOUND),
                  r)
                );
              case 3:
                return [2];
            }
          });
        });
      }),
      (t.prototype.fetchAvailableLanguages = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n;
          return dt(this, function (i) {
            switch (i.label) {
              case 0:
                return (
                  i.trys.push([0, 3, , 4]),
                  (t = this.createAvailableLanguagesUrl()),
                  [4, Ie(t, Kt.FETCH_AVAILABLE_LANGUAGES)]
                );
              case 1:
                return (
                  (e = i.sent()),
                  [4, Xe.getInstance().resolveLocation(e.location)]
                );
              case 2:
                return i.sent(), [2, e.data.languagesAvailable];
              case 3:
                throw (
                  ((n = i.sent()).statusCode &&
                    n.statusCode === ae.RESOURCE_NOT_FOUND &&
                    (n.errorMessage = Kt.AVAILABLE_LANGUAGES_NOT_FOUND),
                  n)
                );
              case 4:
                return [2];
            }
          });
        });
      }),
      (t.prototype.fetchTranslations = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n;
          return dt(this, function (i) {
            switch (i.label) {
              case 0:
                if (this.translationsCache) return [2, this.translationsCache];
                i.label = 1;
              case 1:
                return (
                  i.trys.push([1, 3, , 4]),
                  (t = this.createLanguagesUrl()),
                  [4, Ie(t, Kt.FETCH_LEGAL_BASIS)]
                );
              case 2:
                return (
                  (e = i.sent()), (this.translationsCache = e.data), [2, e.data]
                );
              case 3:
                return (
                  (n = i.sent()).statusCode &&
                    n.statusCode === ae.RESOURCE_NOT_FOUND &&
                    (n.errorMessage = Kt.FETCH_LEGAL_BASIS),
                  [2, null]
                );
              case 4:
                return [2];
            }
          });
        });
      }),
      (t.prototype.mergeAbVariant = function (t) {
        return ut(this, void 0, void 0, function () {
          var e, n, i;
          return dt(this, function (r) {
            switch (r.label) {
              case 0:
                if (
                  ((e = JSON.parse(t.data.variants.experiments)),
                  "UC" === t.data.variants.activateWith)
                )
                  return (
                    (n = Object.keys(e)),
                    (this.abTestVariant = Rt.fetchAbTestVariant(n)),
                    [2, re(e[this.abTestVariant], t.data)]
                  );
                r.label = 1;
              case 1:
                return (
                  r.trys.push([1, 3, , 4]),
                  [
                    4,
                    oe(
                      function () {
                        return !!window.UC_AB_VARIANT;
                      },
                      "window.UC_AB_VARIANT is not defined",
                      2e3
                    ),
                  ]
                );
              case 2:
                return r.sent(), [3, 4];
              case 3:
                return (i = r.sent()), console.warn(i), [3, 4];
              case 4:
                return window.UC_AB_VARIANT && e && e[window.UC_AB_VARIANT]
                  ? ((this.abTestVariant = window.UC_AB_VARIANT),
                    [2, re(e[window.UC_AB_VARIANT], t.data)])
                  : [2, t.data];
            }
          });
        });
      }),
      (t.prototype.fetchSettingsJson = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n;
          return dt(this, function (i) {
            switch (i.label) {
              case 0:
                return (
                  i.trys.push([0, 4, , 5]),
                  (t = this.createSettingsJsonUrl()),
                  [4, Ie(t, Kt.FETCH_SETTINGS)]
                );
              case 1:
                return (
                  (e = i.sent()),
                  ["ccpa", "firstLayer", "secondLayer"].forEach(function (t) {
                    e.data[t] || (e.data[t] = {});
                  }),
                  e.data.tcf2 &&
                    (e.data.tcf2.selectedVendorIds = (
                      e.data.tcf2.selectedVendorIds || []
                    ).sort(function (t, e) {
                      return t - e;
                    })),
                  e.data.consentTemplates &&
                    (e.data.consentTemplates = e.data.consentTemplates.reduce(
                      function (t, e) {
                        return e.isDeactivated || t.push(e), t;
                      },
                      []
                    )),
                  e.data.variants &&
                  e.data.variants.enabled &&
                  (function (t) {
                    try {
                      JSON.parse(t);
                    } catch (n) {
                      return (
                        console.warn(
                          "Invalid JSON string from "
                            .concat("A/B Testing", ': "')
                            .concat(t, '"')
                        ),
                        !1
                      );
                    }
                    return !0;
                  })(e.data.variants.experiments)
                    ? [4, this.mergeAbVariant(e)]
                    : [3, 3]
                );
              case 2:
                return [2, i.sent()];
              case 3:
                return [2, e.data];
              case 4:
                throw (
                  ((n = i.sent()).statusCode &&
                    n.statusCode === ae.RESOURCE_NOT_FOUND &&
                    (n.errorMessage = Kt.SETTINGS_NOT_FOUND),
                  n)
                );
              case 5:
                return [2];
            }
          });
        });
      }),
      (t.prototype.fetchUserConsents = function () {
        return ut(this, void 0, void 0, function () {
          var t;
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return this.getDisableServerConsents()
                  ? [3, 2]
                  : ((t = this.createFetchUserConsentsUrl()),
                    [4, Ie(t, Kt.FETCH_USER_CONSENTS)]);
              case 1:
                return [2, e.sent().data.reverse()];
              case 2:
                return [2, []];
            }
          });
        });
      }),
      (t.prototype.fetchUserConsentsV2 = function (t, e) {
        return ut(this, void 0, void 0, function () {
          var n, i, r, o, s, a, l, c;
          return dt(this, function (u) {
            switch (u.label) {
              case 0:
                return (
                  (n = function (t) {
                    return ft(ft([], ht(ze), !1), ht(Oe), !1).includes(t)
                      ? "implicit"
                      : "explicit";
                  }),
                  this.getDisableServerConsents()
                    ? [3, 2]
                    : ((i = this.createFetchUserConsentsV2Url()),
                      [4, Ie(i, Kt.FETCH_USER_CONSENTS)])
                );
              case 1:
                return (
                  (r = u.sent()),
                  (o = r.data),
                  (s = null),
                  (a = null),
                  t &&
                    ((l = JSON.parse(o.consentMeta)),
                    (s = {
                      tcString: o.consentString,
                      timestamp: l.timestamp,
                      vendors: l.vendors,
                      vendorsDisclosed: l.vendorsDisclosed,
                    })),
                  e &&
                    (a = {
                      ccpaString: o.consentString,
                      timestamp: o.timestamp || Date.now(),
                    }),
                  (c = o.consents.reduce(function (t, e) {
                    return ft(
                      ft([], ht(t), !1),
                      [
                        {
                          action: o.action,
                          consentId: "",
                          settingsVersion: o.settingsVersion,
                          status: e.consentStatus,
                          templateId: e.consentTemplateId,
                          timestamp: o.timestamp || Date.now(),
                          updatedBy: n(o.action),
                        },
                      ],
                      !1
                    );
                  }, [])),
                  [
                    2,
                    ct(ct({ consents: c }, a && { ccpa: a }), s && { tcf: s }),
                  ]
                );
              case 2:
                return [2, null];
            }
          });
        });
      }),
      (t.prototype.fetchUserTcfData = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n;
          return dt(this, function (i) {
            switch (i.label) {
              case 0:
                return this.getDisableServerConsents()
                  ? [3, 2]
                  : ((t = this.createFetchUserTcfDataUrl()),
                    [4, Ie(t, Kt.FETCH_USER_TCF_DATA)]);
              case 1:
                return (
                  (e = i.sent()),
                  [
                    2,
                    ct(
                      { tcString: (n = e.data).tcString },
                      JSON.parse(n.meta) || {}
                    ),
                  ]
                );
              case 2:
                return [2, null];
            }
          });
        });
      }),
      (t.prototype.fetchUserTcfDataV2 = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n;
          return dt(this, function (i) {
            switch (i.label) {
              case 0:
                return (
                  (t = this.createFetchUserTcfDataV2Url()),
                  [4, Ie(t, Kt.FETCH_USER_TCF_DATA)]
                );
              case 1:
                if ((e = i.sent()).data && e.data.tcf2)
                  return [
                    2,
                    ct(
                      { tcString: (n = e.data.tcf2).tcString },
                      JSON.parse(n.meta) || {}
                    ),
                  ];
                throw new Error(Kt.FETCH_USER_TCF_DATA);
            }
          });
        });
      }),
      (t.prototype.saveTCFConsents = function (t, e, n, i, r) {
        return ut(this, void 0, void 0, function () {
          var o, s, a, l, c, u;
          return dt(this, function () {
            return (
              (o = {
                consent: { status: !0 },
                id: "tcf2",
                name: "tcf2",
                processorId: "abcd",
                version: "1.0.0",
              }),
              (s = e.tcString),
              (a = (function (t, e) {
                var n = {};
                for (var i in t)
                  Object.prototype.hasOwnProperty.call(t, i) &&
                    e.indexOf(i) < 0 &&
                    (n[i] = t[i]);
                if (
                  null != t &&
                  "function" == typeof Object.getOwnPropertySymbols
                ) {
                  var r = 0;
                  for (i = Object.getOwnPropertySymbols(t); r < i.length; r++)
                    e.indexOf(i[r]) < 0 &&
                      Object.prototype.propertyIsEnumerable.call(t, i[r]) &&
                      (n[i[r]] = t[i[r]]);
                }
                return n;
              })(e, ["tcString"])),
              (l = Bt(t, o, n, i)),
              (c = {
                consentMeta: { TCF2: JSON.stringify(a) },
                consentString: { TCF2: s },
                dataTransferObjects: [l],
              }),
              r &&
                ((u = Ht({
                  consentAction: n,
                  consentString: { TCF2: s },
                  dataTransferSettings: t,
                  isAnalyticsEnabled: !0 === r.isAnalyticsEnabled,
                  isCcpa: !1,
                  isConsentXDeviceEnabled: !0 === r.isConsentAPIv2Enabled,
                  isTcf: !0,
                })),
                this.saveConsentsV2(u)),
              [2, this.saveConsents(c)]
            );
          });
        });
      }),
      (t.prototype.saveConsents = function (t) {
        return ut(this, void 0, void 0, function () {
          var e,
            n,
            i,
            r = this;
          return dt(this, function (o) {
            switch (o.label) {
              case 0:
                if (this.getDisableServerConsents()) return [3, 4];
                (e = an()), (n = ln(t)), (o.label = 1);
              case 1:
                return (
                  o.trys.push([1, 3, , 4]),
                  [
                    4,
                    tn(
                      function () {
                        return De(r.getGraphQLUri(), n, Kt.SAVE_CONSENTS, e);
                      },
                      {
                        onFirstFail: function () {
                          return Rt.appendToConsentsBuffer(t);
                        },
                        onFirstRetriedSuccess: function () {
                          var e = Rt.findBufferItem(t);
                          e && Rt.removeConsentsBufferItem(e);
                        },
                      }
                    ),
                  ]
                );
              case 2:
                return o.sent(), [3, 4];
              case 3:
                return (
                  (i = o.sent()) instanceof Error &&
                    console.error(
                      "".concat(Kt.SAVE_CONSENTS_RETRY, ": ").concat(i.message)
                    ),
                  console.error(Kt.SAVE_CONSENTS_RETRY),
                  [3, 4]
                );
              case 4:
                return [2];
            }
          });
        });
      }),
      (t.prototype.saveConsentsV2 = function (t) {
        return ut(this, void 0, void 0, function () {
          var e, n, i, r;
          return dt(this, function (o) {
            switch (o.label) {
              case 0:
                if (this.getDisableServerConsents()) return [3, 4];
                (e = this.createSaveConsentsV2Url()),
                  (n = t),
                  (i = an()),
                  (o.label = 1);
              case 1:
                return (
                  o.trys.push([1, 3, , 4]),
                  [
                    4,
                    tn(
                      function () {
                        return De(e, n, Kt.SAVE_CONSENTS, i);
                      },
                      {
                        onFirstFail: function () {
                          return Rt.appendToConsentsV2Buffer(t);
                        },
                        onFirstRetriedSuccess: function () {
                          var e = Rt.findV2BufferItem(t);
                          e && Rt.removeConsentsV2BufferItem(e);
                        },
                      }
                    ),
                  ]
                );
              case 2:
                return o.sent(), [3, 4];
              case 3:
                return (
                  (r = o.sent()) instanceof Error &&
                    console.error(
                      "".concat(Kt.SAVE_CONSENTS_RETRY, ": ").concat(r.message)
                    ),
                  console.error(Kt.SAVE_CONSENTS_RETRY),
                  [3, 4]
                );
              case 4:
                return [2];
            }
          });
        });
      }),
      (t.prototype.sendConsents = function (t, e) {
        return De(this.getGraphQLUri(), t, Kt.SAVE_CONSENTS, e);
      }),
      (t.prototype.sendConsentsV2 = function (t, e) {
        return De(this.createSaveConsentsV2Url(), t, Kt.SAVE_CONSENTS, e);
      }),
      (t.prototype.saveConsentsFromBuffer = function () {
        var t, e, n, i;
        return ut(this, void 0, void 0, function () {
          var r,
            o,
            s,
            a,
            l,
            c,
            u = this;
          return dt(this, function (d) {
            switch (d.label) {
              case 0:
                if (this.getDisableServerConsents()) return [3, 13];
                if (
                  ((r = Rt.fetchConsentsBuffer()),
                  !Array.isArray(r) || !r.length)
                )
                  return [3, 13];
                d.label = 1;
              case 1:
                d.trys.push([1, 7, 8, 13]),
                  (o = function () {
                    var t, e, n, r;
                    return dt(this, function (o) {
                      switch (o.label) {
                        case 0:
                          (i = l.value), (s = !1), (o.label = 1);
                        case 1:
                          o.trys.push([1, , 6, 7]),
                            (t = i),
                            (e = an()),
                            (n = ln(t.consents)),
                            (o.label = 2);
                        case 2:
                          return (
                            o.trys.push([2, 4, , 5]),
                            [
                              4,
                              tn(function () {
                                return u.sendConsents(n, e);
                              }),
                            ]
                          );
                        case 3:
                          return (
                            o.sent(), Rt.removeConsentsBufferItem(t), [3, 5]
                          );
                        case 4:
                          return (
                            (r = o.sent()) instanceof Error &&
                              console.error(
                                ""
                                  .concat(Kt.SAVE_CONSENTS_RETRY, ": ")
                                  .concat(r.message)
                              ),
                            console.error(Kt.SAVE_CONSENTS_RETRY),
                            [3, 5]
                          );
                        case 5:
                          return [3, 7];
                        case 6:
                          return (s = !0), [7];
                        case 7:
                          return [2];
                      }
                    });
                  }),
                  (s = !0),
                  (a = mt(r)),
                  (d.label = 2);
              case 2:
                return [4, a.next()];
              case 3:
                return (l = d.sent()), (t = l.done) ? [3, 6] : [5, o()];
              case 4:
                d.sent(), (d.label = 5);
              case 5:
                return [3, 2];
              case 6:
                return [3, 13];
              case 7:
                return (c = d.sent()), (e = { error: c }), [3, 13];
              case 8:
                return (
                  d.trys.push([8, , 11, 12]),
                  s || t || !(n = a.return) ? [3, 10] : [4, n.call(a)]
                );
              case 9:
                d.sent(), (d.label = 10);
              case 10:
                return [3, 12];
              case 11:
                if (e) throw e.error;
                return [7];
              case 12:
                return [7];
              case 13:
                return [2];
            }
          });
        });
      }),
      (t.prototype.saveConsentsV2FromBuffer = function () {
        var t, e, n, i;
        return ut(this, void 0, void 0, function () {
          var r,
            o,
            s,
            a,
            l,
            c,
            u = this;
          return dt(this, function (d) {
            switch (d.label) {
              case 0:
                if (this.getDisableServerConsents()) return [3, 13];
                if (
                  ((r = Rt.fetchConsentsV2Buffer()),
                  !Array.isArray(r) || !r.length)
                )
                  return [3, 13];
                d.label = 1;
              case 1:
                d.trys.push([1, 7, 8, 13]),
                  (o = function () {
                    var t, e, n, r;
                    return dt(this, function (o) {
                      switch (o.label) {
                        case 0:
                          (i = l.value), (s = !1), (o.label = 1);
                        case 1:
                          o.trys.push([1, , 6, 7]),
                            (t = i),
                            (e = an()),
                            (n = t.consents),
                            (o.label = 2);
                        case 2:
                          return (
                            o.trys.push([2, 4, , 5]),
                            [
                              4,
                              tn(function () {
                                return u.sendConsentsV2(n, e);
                              }),
                            ]
                          );
                        case 3:
                          return (
                            o.sent(), Rt.removeConsentsV2BufferItem(t), [3, 5]
                          );
                        case 4:
                          return (
                            (r = o.sent()) instanceof Error &&
                              console.error(
                                ""
                                  .concat(Kt.SAVE_CONSENTS_RETRY, ": ")
                                  .concat(r.message)
                              ),
                            console.error(Kt.SAVE_CONSENTS_RETRY),
                            [3, 5]
                          );
                        case 5:
                          return [3, 7];
                        case 6:
                          return (s = !0), [7];
                        case 7:
                          return [2];
                      }
                    });
                  }),
                  (s = !0),
                  (a = mt(r)),
                  (d.label = 2);
              case 2:
                return [4, a.next()];
              case 3:
                return (l = d.sent()), (t = l.done) ? [3, 6] : [5, o()];
              case 4:
                d.sent(), (d.label = 5);
              case 5:
                return [3, 2];
              case 6:
                return [3, 13];
              case 7:
                return (c = d.sent()), (e = { error: c }), [3, 13];
              case 8:
                return (
                  d.trys.push([8, , 11, 12]),
                  s || t || !(n = a.return) ? [3, 10] : [4, n.call(a)]
                );
              case 9:
                d.sent(), (d.label = 10);
              case 10:
                return [3, 12];
              case 11:
                if (e) throw e.error;
                return [7];
              case 12:
                return [7];
              case 13:
                return [2];
            }
          });
        });
      }),
      (t.prototype.setTrackingPixel = function (t) {
        var e = new Date().getTime(),
          n = encodeURIComponent(document.location.href),
          i = ""
            .concat(
              this.isEuMode()
                ? this.API.EU_URI.TRACK_EVENT
                : this.API.URI.TRACK_EVENT,
              "?v="
            )
            .concat(1, "&sid=")
            .concat(this.settingsId, "&t=")
            .concat(t.eventType, "&abv=")
            .concat(t.abTestVariant, "&r=")
            .concat(n, "&cb=")
            .concat(e);
        new Image().src = i;
      }),
      (t.prototype.updateTagLoggerData = function (t) {
        var e = window.location.href,
          n = cn({ settingsId: this.settingsId, source: e, targets: t });
        this.saveTagLoggerData(n);
      }),
      (t.prototype.addJsonCacheBustingString = function (t) {
        return this.jsonCacheBustingString
          ? "".concat(t, "?c=").concat(this.jsonCacheBustingString)
          : t;
      }),
      (t.prototype.createAvailableLanguagesUrl = function () {
        return this.addJsonCacheBustingString(
          ""
            .concat(this.getCdnUri(), "/")
            .concat(this.API.FOLDER.SETTINGS, "/")
            .concat(this.settingsId, "/")
            .concat(this.jsonFileVersion, "/languages.json")
        );
      }),
      (t.prototype.createLanguagesUrl = function () {
        return this.addJsonCacheBustingString(
          ""
            .concat(this.getCdnUri(), "/")
            .concat(this.API.FOLDER.TRANSLATIONS, "/translations-")
            .concat(this.jsonFileLanguage, ".json")
        );
      }),
      (t.prototype.getSettingsUrl = function () {
        return ""
          .concat(this.getCdnUri(), "/")
          .concat(this.API.FOLDER.SETTINGS, "/")
          .concat(this.settingsId, "/")
          .concat(this.jsonFileVersion);
      }),
      (t.prototype.createSettingsJsonUrl = function () {
        return this.addJsonCacheBustingString(
          ""
            .concat(this.getSettingsUrl(), "/")
            .concat(this.jsonFileLanguage, ".json")
        );
      }),
      (t.prototype.createSessionTrackingUrl = function () {
        return ""
          .concat(
            this.isEuMode()
              ? this.API.EU_URI.TRACK_SESSION
              : this.API.URI.TRACK_SESSION,
            "?settingsId="
          )
          .concat(this.settingsId);
      }),
      (t.prototype.createFetchUserConsentsUrl = function () {
        return ""
          .concat(
            this.isEuMode()
              ? this.API.EU_URI.FETCH_CONSENTS
              : this.API.URI.FETCH_CONSENTS,
            "?controllerId="
          )
          .concat(this.controllerIdInstance.value);
      }),
      (t.prototype.createFetchUserConsentsV2Url = function () {
        return ""
          .concat(
            this.isEuMode()
              ? this.API.EU_URI.FETCH_CONSENTS_V2
              : this.API.URI.FETCH_CONSENTS_V2,
            "?settingsId="
          )
          .concat(this.getSettingsId(), "&controllerId=")
          .concat(this.controllerIdInstance.value);
      }),
      (t.prototype.createFetchUserTcfDataUrl = function () {
        return ""
          .concat(this.API.URI.FETCH_TCF_DATA, "?controllerId=")
          .concat(this.controllerIdInstance.value);
      }),
      (t.prototype.createFetchUserTcfDataV2Url = function () {
        return ""
          .concat(this.getTcfDataV2Uri(), "?controllerId=")
          .concat(this.controllerIdInstance.value, "&tcf2=true&settingsId=")
          .concat(this.settingsId);
      }),
      (t.prototype.createRulesetUrl = function () {
        return ""
          .concat(this.API.URI.RULESET, "/")
          .concat(this.API.FOLDER.RULESET, "/")
          .concat(this.rulesetId, ".json");
      }),
      (t.prototype.createSaveConsentsV2Url = function () {
        return ""
          .concat(
            this.isEuMode()
              ? this.API.EU_URI.SAVE_CONSENTS_V2
              : this.API.URI.SAVE_CONSENTS_V2,
            "/uw/"
          )
          .concat(1);
      }),
      (t.prototype.saveTagLoggerData = function (t) {
        try {
          De(this.getGraphQLUri(), t, "", ct(ct({}, an()), { keepalive: !0 }));
        } catch (x) {
          console.warn(Kt.TAGLOGGER, x);
        }
      }),
      t
    );
  })(),
  an = function () {
    return {
      credentials: "omit",
      headers: {
        Accept: "application/json",
        "Access-Control-Allow-Origin": "*",
        "X-Request-ID": Ye(),
      },
      mode: "cors",
    };
  },
  ln = function (t) {
    var e = t.consentString;
    return {
      query:
        "mutation saveConsents($consents: [NewCreateConsentInput], $consentMeta: ConsentMeta, $consentString: ConsentString)\n      {\n        saveConsents(consents: $consents, consentMeta: $consentMeta, consentString: $consentString) { data { consentId } }\n      }",
      variables: {
        consentMeta: t.consentMeta,
        consents: un(t.dataTransferObjects),
        consentString: e,
      },
    };
  },
  cn = function (t) {
    return {
      operationName: "saveTagLoggerData",
      query:
        "mutation saveTagLoggerData($settingsId: String, $source: String, $targets: [String])\n        {\n          saveTagLoggerData(settingsId: $settingsId, source: $source, targets: $targets)\n        }",
      variables: {
        settingsId: t.settingsId,
        source: t.source,
        targets: t.targets,
      },
    };
  },
  un = function (t) {
    return t.map(function (t) {
      return {
        action: t.consent.action,
        appVersion: t.applicationVersion,
        consentStatus: t.consent.status ? "1" : "0",
        consentTemplateId: t.service.id,
        consentTemplateVersion: t.service.version,
        controllerId: t.settings.controllerId,
        language: t.settings.language,
        processorId: t.service.processorId,
        referrerControllerId: t.settings.referrerControllerId,
        settingsId: t.settings.id,
        settingsVersion: t.settings.version,
        updatedBy: t.consent.type,
      };
    });
  };
!(function (t) {
  (t[(t.NO = 0)] = "NO"),
    (t[(t.YES = 1)] = "YES"),
    (t[(t.NOT_SET = 2)] = "NOT_SET");
})(en || (en = {}));
var dn,
  hn = (function () {
    function t() {
      (this.isBotEnabled = !1), (this.isBot = en.NOT_SET);
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        t.instance.isBot = en.NOT_SET;
      }),
      (t.prototype.isRobot = function () {
        if (this.isBot === en.NOT_SET)
          if (this.isBotEnabled) {
            var t = window.navigator.userAgent,
              e = new RegExp(
                "bingbot/|BingPreview/|DuckDuckBot/|Google Page Speed Insights|Google PP|Google Search Console|Google Web Preview|Googlebot/|Googlebot-Image/|Googlebot-Mobile/|Googlebot-News|Googlebot-Video/|Google-SearchByImage|Google-Structured-Data-Testing-Tool|Chrome-Lighthouse|YahooSeeker|YahooCacheSystem|Yahoo! Site Explorer Feed Validator|Yahoo! Slurp|Slurp/",
                "i"
              );
            this.isBot = e.test(t) ? en.YES : en.NO;
          } else this.isBot = en.NO;
        return this.isBot === en.YES;
      }),
      t
    );
  })(),
  fn = [
    "LykAT-gy",
    "UekC8ye4S",
    "9V8bg4D63",
    "ByzZ5EsOsZX",
    "S1_9Vsuj-Q",
    "dqFgQeZH",
    "twMyStLkn",
    "B1Hk_zoTX",
    "pxiRY9112",
    "dyHOCwp5Y",
    "DHS2sEi4b",
  ],
  mn = ["HkocEodjb7", "87JYasXPF"],
  bn = (function () {
    function t() {
      (this.dataLayerNames = []),
        (this.windowEventNames = []),
        (this.dataLayer = new Map()),
        (this.blockDataLayerPush = !1);
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.prototype.setBlockDataLayerPush = function (t) {
        this.blockDataLayerPush = t;
      }),
      (t.prototype.shouldBlockDataLayerPush = function () {
        return this.blockDataLayerPush;
      }),
      (t.resetInstance = function () {
        (t.instance.dataLayerNames = []),
          (t.instance.windowEventNames = []),
          (t.instance.dataLayer = new Map());
      }),
      (t.prototype.init = function (t) {
        var e = this;
        t.forEach(function (t) {
          t.type === K.DATA_LAYER
            ? (e.dataLayerNames = Vt(t.names, []))
            : t.type === K.WINDOW_EVENT &&
              (e.windowEventNames = Vt(t.names, []));
        }),
          this.windowEventNames.includes("UC_SDK_EVENT") ||
            this.windowEventNames.push("UC_SDK_EVENT");
      }),
      (t.prototype.setDataLayer = function (t, e) {
        this.dataLayer.set(e, t);
      }),
      (t.prototype.getDataLayer = function () {
        return this.dataLayer;
      }),
      (t.prototype.dispatch = function (t, e, n) {
        jt(t) &&
          (this.pushEventsToDataLayer(t, e, n),
          this.dispatchWindowEvents(t, n));
      }),
      (t.prototype.isValidDataLayer = function (t) {
        return (
          window[t] &&
          (Array.isArray(window[t]) ||
            Object.prototype.hasOwnProperty.call(window[t], "push"))
        );
      }),
      (t.prototype.pushEventsToDataLayer = function (t, e, n) {
        var i = this;
        jt(this.dataLayerNames) &&
          this.dataLayerNames.forEach(function (r) {
            if (((window[r] = Vt(window[r], [])), !i.isValidDataLayer(r)))
              throw Error("DataLayer: ".concat(r, " is not of a valid type!"));
            if (e && "dataLayer" === r) {
              var o = !1,
                s = !1,
                a = !1,
                l = !1,
                c = !1;
              wn("set", "developer_id.dOThhZD", !0),
                t.forEach(function (t) {
                  var e = t.service.id,
                    n = t.consent,
                    i = n.status,
                    r = n.type,
                    s = n.action;
                  mn.includes(e) &&
                    ("explicit" === r ||
                      ("implicit" === r && "onNonEURegion" === s)) &&
                    ((o = o || i), (c = !0)),
                    fn.includes(e) &&
                      ("explicit" === r ||
                        ("implicit" === r && "onNonEURegion" === s)) &&
                      ((l = !0), (c = !0), i || (a = !0));
                }),
                l && !a && (s = !0);
              var u = { adsDataRedaction: !s };
              if (c) {
                (u = ct(ct({}, u), {
                  adStorage: s ? "granted" : "denied",
                  analyticsStorage: o ? "granted" : "denied",
                })),
                  wn("consent", "update", {
                    ad_storage: u.adStorage,
                    analytics_storage: u.analyticsStorage,
                  }),
                  Rt.saveGcmData(u);
                var d = new window.CustomEvent("UC_GCM_UPDATE", { detail: u });
                window.dispatchEvent(d);
              }
              wn("set", "ads_data_redaction", u.adsDataRedaction);
            }
            window[r].push(gn(t, n)),
              i.setDataLayer(window[r], r),
              i.shouldBlockDataLayerPush() ||
                ("explicit" === t[0].consent.type &&
                  t.forEach(function (t) {
                    t.consent.status ||
                      window[r].push({
                        event: "".concat(t.service.name, " EXPLICIT_DENY"),
                      });
                  }));
          });
      }),
      (t.prototype.dispatchWindowEvents = function (t, e) {
        if (jt(this.windowEventNames)) {
          var n = gn(t, e);
          this.windowEventNames.forEach(function (t) {
            var e = new window.CustomEvent(t, { detail: n });
            window.dispatchEvent(e);
          });
        }
      }),
      t
    );
  })(),
  gn = function (t, e) {
    var n = {
      action: null != e ? e : t[0].consent.action,
      event: "consent_status",
      type: t[0].consent.type,
      ucCategory: {},
    };
    return (
      t.forEach(function (t) {
        var e,
          i,
          r,
          o =
            (null === (i = t.service.categorySlug) || void 0 === i
              ? void 0
              : i.length) &&
            Object.prototype.hasOwnProperty.call(
              n.ucCategory,
              t.service.categorySlug
            );
        (n = ct(ct({}, n), (((e = {})[t.service.name] = t.consent.status), e))),
          (null === (r = t.service.categorySlug) || void 0 === r
            ? void 0
            : r.length) &&
            (n.ucCategory[t.service.categorySlug] =
              o && n.ucCategory[t.service.categorySlug] !== t.consent.status
                ? null
                : t.consent.status);
      }),
      n
    );
  },
  wn = function () {
    window.dataLayer.push(arguments);
  },
  pn = "en",
  vn = "https://api.usercentrics.eu/tcf2/",
  yn = "https://config.eu.usercentrics.eu/tcf2/",
  xn = "[LANG].json",
  kn = "en-v2.json";
!(function (t) {
  (t.TEXT_JAVASCRIPT = "text/javascript"), (t.TEXT_PLAIN = "text/plain");
})(dn || (dn = {}));
var qn = "data-usercentrics",
  Sn = (function () {
    function t() {}
    return (
      (t.enableScriptsForServicesWithConsent = function (e) {
        var n = t.getDisabledScripts();
        Array.prototype.forEach.call(n, function (n) {
          t.disabledScriptHasConsent(e, n) && t.enableScript(n);
        });
      }),
      (t.getDisabledScripts = function () {
        return document.querySelectorAll(
          "script[".concat(qn, '][type="').concat(dn.TEXT_PLAIN, '"]')
        );
      }),
      (t.disabledScriptHasConsent = function (t, e) {
        return t.some(function (t) {
          return t.name === e.getAttribute(qn);
        });
      }),
      (t.enableScript = function (e) {
        var n,
          i,
          r = e.src ? t.createSrcScriptTag(e) : t.createInlineScriptTag(e);
        (i = (n = e).parentNode) && i.replaceChild(r, n);
      }),
      (t.createSrcScriptTag = function (e) {
        var n = t.cloneScriptTag(e);
        return n.removeAttribute(qn), (n.type = dn.TEXT_JAVASCRIPT), n;
      }),
      (t.createInlineScriptTag = function (e) {
        var n = t.cloneScriptTag(e);
        n.removeAttribute(qn);
        var i = document.createTextNode(e.text);
        return n.appendChild(i), (n.type = dn.TEXT_JAVASCRIPT), n;
      }),
      (t.cloneScriptTag = function (t) {
        var e = document.createElement("script");
        return (
          Array.from(t.attributes).forEach(function (t) {
            e.setAttribute(t.name, t.value);
          }),
          e
        );
      }),
      t
    );
  })(),
  Cn = function (t, e, n) {
    var i, r;
    (this.anyDomain = t.anyDomain || "any domain (ex. first party cookie)"),
      (this.cookieRefresh =
        (null == e ? void 0 : e.COOKIE_REFRESH) ||
        (null === (i = null == n ? void 0 : n.labels) || void 0 === i
          ? void 0
          : i.COOKIE_REFRESH) ||
        "Cookie Refresh"),
      (this.cookieStorage =
        (null == e ? void 0 : e.COOKIE_STORAGE) ||
        (null === (r = null == n ? void 0 : n.labels) || void 0 === r
          ? void 0
          : r.COOKIE_STORAGE) ||
        "Cookie Storage"),
      (this.day = t.day),
      (this.days = t.days),
      (this.description =
        t.storageInformationDescription ||
        "Below you can see the longest potential duration for storage on a device, as set when using the cookie method of storage and if there are any other methods used."),
      (this.domain = t.domain || "Domain"),
      (this.duration = t.duration || "Duration"),
      (this.error =
        t.informationLoadingNotPossible ||
        "Sorry; we could not load the required information."),
      (this.hour = t.hour),
      (this.hours = t.hours),
      (this.identifier = t.identifier || "Identifier"),
      (this.loading =
        t.loadingStorageInformation || "Loading storage information"),
      (this.maximumAge =
        t.maximumAgeCookieStorage || "Maximum age of cookie storage"),
      (this.minute = t.minute),
      (this.minutes = t.minutes),
      (this.month = t.month),
      (this.months = t.months),
      (this.multipleDomains =
        t.multipleDomains || "multiple subdomains may exist"),
      (this.name = t.name || "Name"),
      (this.no = t.no || "no"),
      (this.nonCookieStorage = t.nonCookieStorage || "Non-cookie storage"),
      (this.purposes = t.purposes || "Purposes"),
      (this.second = t.second || "second"),
      (this.seconds = t.seconds || "seconds"),
      (this.session = t.session || "Session"),
      (this.storedInformation = t.storedInformation || "Stored Information"),
      (this.storedInformationDescription =
        t.storedInformationDescription ||
        "This service uses different means of storing information on a user’s device as listed below."),
      (this.title = t.storageInformation || "Storage Information"),
      (this.titleDetailed =
        t.detailedStorageInformation || "Detailed Storage Information"),
      (this.tryAgain = t.tryAgain || "Try again?"),
      (this.type = t.type || "Type"),
      (this.year = t.year),
      (this.years = t.years),
      (this.yes = t.yes || "yes");
  },
  _n = function (t, e) {
    return {
      history: [],
      status: !!(null == e ? void 0 : e.isEssential) || t.defaultConsentStatus,
    };
  },
  Tn = function (t, e) {
    return (
      (null == t ? void 0 : t.description) ||
      (null == e ? void 0 : e.descriptionOfService) ||
      (null == e ? void 0 : e.description) ||
      ""
    );
  },
  An = function (t, e, n) {
    var i,
      r =
        null == n
          ? void 0
          : n.find(function (e) {
              return t.templateId === e.templateId && t.version === e.version;
            }),
      o =
        (null == e ? void 0 : e.legalBasis) && t.legalBasisList
          ? t.legalBasisList.reduce(function (t, n) {
              return (null == e ? void 0 : e.legalBasis[n])
                ? ft(
                    ft([], ht(t), !1),
                    [null == e ? void 0 : e.legalBasis[n]],
                    !1
                  )
                : t;
            }, [])
          : [];
    (this.description = Tn(t, r)),
      (this.id = t.templateId),
      (this.legalBasis =
        r && !t.disableLegalBasis
          ? (function (t, e) {
              return e.length > 0
                ? e
                : (function (t, e) {
                    return jt(t) ? t : [e];
                  })(t.legalBasisList, t.legalGround);
            })(r, o)
          : []),
      (this.name =
        (null === (i = t._meta) || void 0 === i ? void 0 : i.name) ||
        (null == r ? void 0 : r.dataProcessor) ||
        (null == r ? void 0 : r.dataProcessors[0]) ||
        "");
  },
  En = (function (t) {
    function e(e, n, i, r) {
      var o,
        s,
        a,
        l,
        c,
        u,
        d,
        h = this;
      h = t.call(this) || this;
      var f = e.labels;
      return (
        (h.ariaLabels = (null == i ? void 0 : i.labelsAria) || Se),
        (h.categories = n.categories.map(function (t) {
          return {
            description: t.description,
            label: t.label,
            slug: t.categorySlug,
          };
        })),
        (h.cookieInformation = new Cn(f, null, i)),
        (h.general = {
          back:
            (null === (o = null == i ? void 0 : i.labels) || void 0 === o
              ? void 0
              : o.BACK) || "Back",
          consentGiven: f.accepted,
          consentNotGiven: f.denied,
          consentType: f.consentType,
          controllerId:
            (null === (s = null == i ? void 0 : i.labels) || void 0 === s
              ? void 0
              : s.CID_TITLE) || "Controller ID",
          copied: f.copied,
          copy: f.copy,
          date: f.date,
          decision: f.decision,
          details:
            (null === (a = null == i ? void 0 : i.labels) || void 0 === a
              ? void 0
              : a.DETAILS) || "Details",
          explicit: f.explicit,
          gpcSignalHonored:
            (null === (l = null == i ? void 0 : i.labels) || void 0 === l
              ? void 0
              : l.GPC_SIGNAL_HONORED) ||
            f.gpcSignalHonored ||
            "The GPC signal is honored",
          implicit: f.implicit,
          implicitNo: f.noImplicit,
          implicitYes: f.yesImplicit,
          privacyButton: f.btnChipName,
          showLess: f.readLess,
          showMore: f.btnBannerReadMore || f.showMore,
          subservice:
            (null === (c = null == i ? void 0 : i.labels) || void 0 === c
              ? void 0
              : c.SUB_SERVICE) || "Subservice",
          subservices:
            (null === (u = null == i ? void 0 : i.labels) || void 0 === u
              ? void 0
              : u.SUB_SERVICES) || "Subservices",
          subservicesDescription:
            (null === (d = null == i ? void 0 : i.labels) || void 0 === d
              ? void 0
              : d.SUB_SERVICES_DESCRIPTION) ||
            "Below you can find all the services that are subordinate to this service. The current consent status of this service applies to all subservices.",
        }),
        (h.links = {
          cookiePolicy: {
            ariaLabel: Se.cookiePolicyButton,
            label: Vt(f.cookiePolicyLinkText, ""),
            url: e.cookiePolicyUrl,
          },
          imprint: {
            ariaLabel: Se.imprintButton,
            label: f.imprintLinkText || null,
            url: e.imprintUrl,
          },
          privacyPolicy: {
            ariaLabel: Se.privacyPolicyButton,
            label: f.privacyPolicyLinkText,
            url: e.privacyPolicyUrl,
          },
        }),
        (h.poweredBy = {
          label: "Powered by",
          partnerUrlLabel: Vt(f.partnerPoweredByLinkText, null),
          urlLabel: "Usercentrics Consent Management",
        }),
        (h.service = {
          dataCollected: {
            description: f.dataCollectedInfo,
            title: f.dataCollectedList,
          },
          dataDistribution: {
            processingLocationDescription: f.locationofProcessingInfo,
            processingLocationTitle: f.locationOfProcessing,
            thirdPartyCountriesDescription: f.transferToThirdCountriesInfo,
            thirdPartyCountriesTitle: f.transferToThirdCountries,
          },
          dataProtectionOfficer: {
            description: f.dataProtectionOfficerInfo,
            title: f.dataProtectionOfficer,
          },
          dataPurposes: {
            description: f.dataPurposesInfo,
            title: f.dataPurposes,
          },
          dataRecipients: {
            description: f.dataRecipientsListInfo,
            title: f.dataRecipientsList,
          },
          descriptionTitle: f.descriptionOfService,
          history: { description: null, title: f.history },
          legalBasis: {
            description: f.legalBasisInfo,
            title: f.legalBasisList,
          },
          processingCompanyTitle: f.processingCompany,
          retentionPeriod: {
            description: f.retentionPeriodInfo,
            title: f.retentionPeriod,
          },
          technologiesUsed: {
            description: f.technologiesUsedInfo,
            title: f.technologiesUsed,
          },
          urls: {
            cookiePolicyTitle: f.cookiePolicyInfo,
            optOutTitle: f.optOut,
            privacyPolicyTitle: f.policyOf,
          },
        }),
        (h.services = n.consentTemplates.reduce(function (t, e) {
          var n = new An(e, i, r);
          return ft(ft([], ht(t), !1), [n], !1);
        }, [])),
        h
      );
    }
    return G(e, t), e;
  })(function () {
    this.ariaLabels = Se;
  }),
  zn = (function (t) {
    function e(e, n, i, r) {
      var o = t.call(this, e, n, i, r) || this;
      return (
        (o.buttons = {
          optOutNotice:
            e.ccpa.optOutNoticeLabel || "Do not sell my personal information",
          save: e.ccpa.btnSave || "okay",
          showSecondLayer: e.ccpa.btnMoreInfo || e.labels.btnMore,
        }),
        (o.firstLayer = {
          description: {
            default: e.ccpa.firstLayerDescription || "",
            short: e.ccpa.firstLayerMobileDescription || "",
            shortDesktop: e.ccpa.firstLayerShortMessage || "",
            shortMobile: e.ccpa.firstLayerMobileDescription || "",
          },
          title: e.ccpa.firstLayerTitle || "",
        }),
        (o.secondLayer = {
          categoryTab: e.secondLayer.tabsCategoriesLabel,
          description: e.ccpa.secondLayerDescription || "",
          serviceTab: e.secondLayer.tabsServicesLabel,
          title: e.ccpa.secondLayerTitle || "",
        }),
        o
      );
    }
    return G(e, t), e;
  })(En),
  On = function (t, e) {
    var n;
    (this.acceptAllImplicitlyOutsideEU = t.displayOnlyForEU),
      (this.consentAnalytics = Vt(t.consentAnalytics, !1)),
      (this.consentAPIv2 = Vt(t.consentAPIv2, !1)),
      (this.consentXDevice = Vt(t.consentXDevice, !1)),
      (this.consentSharingIFrameIsActive = t.consentSharingIFrameIsActive),
      (this.dataExchangeSettings = t.dataExchangeOnPage.reduce(function (t, e) {
        return (
          e.type === Zt.DATA_LAYER
            ? t.push({ names: e.names, type: K.DATA_LAYER })
            : e.type === Zt.WINDOW_EVENT &&
              t.push({ names: e.names, type: K.WINDOW_EVENT }),
          t
        );
      }, [])),
      (this.googleConsentMode = t.googleConsentMode),
      (this.id = t.settingsId),
      (this.isCcpaEnabled =
        (null === (n = t.ccpa) || void 0 === n ? void 0 : n.isActive) || !1),
      (this.isEmbeddingsEnabled = !0),
      (this.isTagLoggerActive = t.tagLoggerIsActive),
      (this.isTcfEnabled = t.tcf2Enabled || !1),
      (this.language = { available: t.languagesAvailable, selected: e }),
      (this.reshowBanner = Vt(t.reshowBanner, -1)),
      (this.showFirstLayerOnVersionChange =
        t.showInitialViewForVersionChange.map(function (t) {
          switch (t) {
            case ee.MAJOR:
              return Q.MAJOR;
            case ee.MINOR:
              return Q.MINOR;
            default:
              return Q.PATCH;
          }
        })),
      (this.version = t.version);
  },
  In = (function (t) {
    function e(e, n, i, r) {
      var o,
        s,
        a,
        l = this;
      return (
        ((l = t.call(this, e, n, i, r) || this).buttons = {
          acceptAll: e.labels.btnAcceptAll,
          cnilDeny:
            (null === (o = null == i ? void 0 : i.labels) || void 0 === o
              ? void 0
              : o.CNIL_DENY_LINK_TEXT) || "Continuer sans accepter",
          denyAll: e.labels.btnDeny,
          save: e.labels.btnSave,
          showSecondLayer: e.labels.btnMore,
        }),
        (l.firstLayer = {
          description: {
            default: e.bannerMessage || "",
            short: e.bannerMobileDescription || "",
            shortDesktop: e.firstLayer.shortMessage || "",
            shortMobile: e.bannerMobileDescription || "",
          },
          title: Vt(e.labels.firstLayerTitle, "Privacy Settings"),
        }),
        (l.secondLayer = {
          acceptButtonLabel: e.secondLayer.acceptButtonText,
          categoryTab: e.secondLayer.tabsCategoriesLabel,
          dataTransferFilter: {
            all:
              (null === (s = null == i ? void 0 : i.labels) || void 0 === s
                ? void 0
                : s.ALL) || "All",
            thirdCountry:
              (null === (a = null == i ? void 0 : i.labels) || void 0 === a
                ? void 0
                : a.THIRD_COUNTRY_TRANSFER) ||
              "Data Transfer to Third Countries",
          },
          denyButtonLabel: e.secondLayer.denyButtonText,
          description: e.labels.titleCorner,
          serviceTab: e.secondLayer.tabsServicesLabel,
          title: e.labels.headerCorner,
        }),
        l
      );
    }
    return G(e, t), e;
  })(En),
  Dn = function (t, e, n) {
    (this.privacyButton = Vt(
      null == n ? void 0 : n.labelsAria.privacyButton,
      ""
    )),
      (this.services = t.consentTemplates.reduce(function (t, i) {
        var r = new An(i, n, e);
        return ft(ft([], ht(t), !1), [r], !1);
      }, []));
  },
  Ln = (function () {
    function t() {
      (this.needsSessionRestore = !1),
        (this.apiInstance = sn.getInstance()),
        (this.locationInstance = Xe.getInstance());
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        delete t.instance.noShow;
      }),
      (t.prototype.unsetNoShow = function () {
        delete this.noShow;
      }),
      (t.prototype.getIsUsingNoShow = function () {
        return void 0 !== this.noShow;
      }),
      (t.prototype.getNoShow = function () {
        return !0 === this.noShow;
      }),
      (t.prototype.setNoShow = function (t) {
        this.noShow = t;
      }),
      (t.prototype.resolveSettingsId = function () {
        return ut(this, void 0, void 0, function () {
          var t, e, n, i, r, o, s, a;
          return dt(this, function (l) {
            switch (l.label) {
              case 0:
                return [4, this.apiInstance.fetchRuleset()];
              case 1:
                return (
                  (t = l.sent()),
                  (n = ""),
                  (r = t.rules),
                  (s = (o = t.defaultRule).settingsId),
                  (a = o.noShow),
                  (i = t.location) &&
                    i.code &&
                    ((e =
                      (i.regionCode &&
                        r.find(function (t) {
                          var e;
                          return null === (e = t.locations) || void 0 === e
                            ? void 0
                            : e.includes(i.regionCode);
                        })) ||
                      r.find(function (t) {
                        var e;
                        return null === (e = t.locations) || void 0 === e
                          ? void 0
                          : e.includes(i.code);
                      })),
                    this.locationInstance.setUserCountryData(i),
                    Rt.setUserCountryResponse(Xe.mapUserCountryData(i))),
                  this.unsetNoShow(),
                  e
                    ? ((n = e.settingsId),
                      void 0 !== e.noShow && this.setNoShow(!0 === e.noShow))
                    : ((n = s), this.setNoShow(!0 === a)),
                  [
                    2,
                    {
                      name: "Resolved Settings Id",
                      noShow: this.getNoShow(),
                      settingsId: n,
                    },
                  ]
                );
            }
          });
        });
      }),
      t
    );
  })(),
  Nn = function (t) {
    (this.cookieMaxAgeSeconds = null),
      (this.cookieRefresh = null),
      (this.dataCollected = []),
      (this.dataDistribution = null),
      (this.dataProtectionOfficer = null),
      (this.dataPurposes = []),
      (this.dataRecipients = []),
      (this.deviceStorage = null),
      (this.deviceStorageDisclosureUrl = null),
      (this.language = null),
      (this.processingCompany = null),
      (this.retentionPeriodDescription = null),
      (this.technologiesUsed = []),
      (this.urls = null),
      (this.usesCookies = null),
      (this.usesNonCookieAccess = null),
      (this.cookieMaxAgeSeconds = Vt(
        null == t ? void 0 : t.cookieMaxAgeSeconds,
        null
      )),
      (this.cookieRefresh = Vt(null == t ? void 0 : t.cookieRefresh, null)),
      (this.dataCollected = t ? Rn(t, te.DATA_COLLECTED_LIST) : []),
      (this.dataDistribution = t ? Pn(t) : null),
      (this.dataProtectionOfficer = Vt(
        null == t ? void 0 : t.dataProtectionOfficer,
        null
      )),
      (this.dataPurposes = t ? Fn(t) : []),
      (this.dataRecipients = t ? Rn(t, te.DATA_RECIPIENTS_LIST) : []),
      (this.description = Tn(null, t)),
      (this.deviceStorage = Vt(null == t ? void 0 : t.deviceStorage, null)),
      (this.deviceStorageDisclosureUrl = Vt(
        null == t ? void 0 : t.deviceStorageDisclosureUrl,
        null
      )),
      (this.language = t ? Un(t) : null),
      (this.processingCompany = t ? jn(t) : null),
      (this.retentionPeriodDescription = t ? Mn(t) : null),
      (this.technologiesUsed = t ? Rn(t, te.TECHNOLOGY_USED) : []),
      (this.usesCookies = Vt(null == t ? void 0 : t.usesCookies, null)),
      (this.usesNonCookieAccess = Vt(
        null == t ? void 0 : t.usesNonCookieAccess,
        null
      )),
      (this.urls = t ? Vn(t) : null);
  },
  Rn = function (t, e) {
    var n;
    return jt(t[e])
      ? t[e]
      : (null === (n = t[e]) || void 0 === n ? void 0 : n.length) > 0
      ? [t[e]]
      : [];
  },
  Fn = function (t) {
    var e = Rn(t, te.DATA_PURPOSES_LIST);
    return jt(e) ? e : t.dataPurposes;
  },
  Pn = function (t) {
    return {
      processingLocation: t.locationOfProcessing,
      thirdPartyCountries: t.thirdCountryTransfer
        ? t.thirdCountryTransfer.split(",")
        : [],
    };
  },
  Un = function (t) {
    return { available: t.languagesAvailable, selected: t.language };
  },
  jn = function (t) {
    return {
      address: t.addressOfProcessingCompany,
      dataProtectionOfficer: t.dataProtectionOfficer,
      name: t.nameOfProcessingCompany || t.processingCompany,
    };
  },
  Mn = function (t) {
    var e;
    return (
      t.retentionPeriodDescription ||
      (null === (e = t.retentionPeriodList) || void 0 === e ? void 0 : e[0]) ||
      ""
    );
  },
  Vn = function (t) {
    return {
      cookiePolicy: t.cookiePolicyURL,
      dataProcessingAgreement: t.linkToDpa,
      optOut: t.optOutUrl,
      privacyPolicy: t.privacyPolicyURL || t.policyOfProcessorUrl,
    };
  },
  Bn = (function (t) {
    function e(e, n, i, r) {
      var o,
        s,
        a,
        l = this;
      l = t.call(this, e, n, i, r) || this;
      var c = e.labels,
        u = e.tcf2;
      return (
        (l.cookieInformation.purposes = u.labelsPurposes),
        (l.buttons = {
          acceptAll: u.buttonsAcceptAllLabel,
          denyAll: u.buttonsDenyAllLabel,
          manageSettings: u.linksManageSettingsLabel,
          save: u.buttonsSaveLabel,
          showVendorTab: u.linksVendorListLinkLabel,
        }),
        (l.firstLayer = {
          description: {
            additionalInfo: u.firstLayerAdditionalInfo || null,
            dataSharedOutsideEUText:
              u.showDataSharedOutsideEUText && u.dataSharedOutsideEUText
                ? u.dataSharedOutsideEUText
                : null,
            default: u.firstLayerDescription,
            resurfaceNote: u.firstLayerNoteResurface || null,
          },
          disclaimer: { serviceScope: u.firstLayerNoteService },
          title: u.firstLayerTitle,
        }),
        (l.secondLayer = {
          dataSharedOutsideEU: {
            text:
              (null === (o = null == i ? void 0 : i.labels) || void 0 === o
                ? void 0
                : o.VENDORS_OUTSIDE_EU) || null,
            title: c.transferToThirdCountries,
          },
          dataTransferFilter: {
            all:
              (null === (s = null == i ? void 0 : i.labels) || void 0 === s
                ? void 0
                : s.ALL) || "All",
            thirdCountry:
              (null === (a = null == i ? void 0 : i.labels) || void 0 === a
                ? void 0
                : a.THIRD_COUNTRY_TRANSFER) ||
              "Data Transfer to Third Countries",
          },
          description: u.secondLayerDescription,
          purposesTab: u.tabsPurposeLabel,
          title: u.secondLayerTitle,
          vendorsTab: u.tabsVendorsLabel,
        }),
        (l.titles = {
          features: u.labelsFeatures,
          iabVendors: u.labelsIabVendors,
          nonIabPurposes: u.labelsNonIabPurposes,
          nonIabVendors: u.labelsNonIabVendors,
          purposes: u.labelsPurposes,
        }),
        (l.toggles = {
          consent: e.tcf2.togglesConsentToggleLabel,
          legitimateInterest: e.tcf2.togglesLegIntToggleLabel,
          specialFeaturesToggle: {
            offLabel: e.tcf2.togglesSpecialFeaturesToggleOff,
            onLabel: e.tcf2.togglesSpecialFeaturesToggleOn,
          },
        }),
        (l.vendor = {
          features: u.vendorFeatures,
          legitimateInterest: u.vendorLegitimateInterestPurposes,
          privacyPolicy: c.privacyPolicyLinkText,
          purposes: u.vendorPurpose,
          specialFeatures: u.vendorSpecialFeatures,
          specialPurposes: u.vendorSpecialPurposes,
          toggleAll: u.labelsActivateAllVendors,
        }),
        l
      );
    }
    return G(e, t), e;
  })(En),
  Hn = (function () {
    function t() {
      (this.aggregatedServices = []),
        (this.allLegacyServicesHaveName = !1),
        (this.isVariantLoaded = !1),
        (this.isAggregatorLoaded = !1),
        (this.language = ""),
        (this.translations = null),
        (this.botInstance = hn.getInstance()),
        (this.locationInstance = Xe.getInstance()),
        (this.rulesetInstance = Ln.getInstance()),
        (this.apiInstance = sn.getInstance()),
        (this._core = null),
        (this._coreJson = null),
        (this._data = null),
        (this._dpsJson = null),
        (this._labels = null),
        (this._legacySettings = null),
        (this._ui = null),
        (this.controllerIdInstance = Ke.getInstance()),
        (this.acceptAllImplicitlyOnInit = null),
        (this.denyAllExplicitlyOnInit = null);
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        (t.instance.allLegacyServicesHaveName = !1),
          (t.instance.core = null),
          (t.instance.data = null),
          (t.instance.labels = null),
          (t.instance.legacySettings = null),
          (t.instance.ui = null),
          (t.instance.dpsJson = null),
          (t.instance.coreJson = null);
      }),
      Object.defineProperty(t.prototype, "core", {
        get: function () {
          return this._core;
        },
        set: function (t) {
          this._core = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "coreJson", {
        get: function () {
          return this._coreJson;
        },
        set: function (t) {
          this._coreJson = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "data", {
        get: function () {
          return this._data;
        },
        set: function (t) {
          this._data = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "dpsJson", {
        get: function () {
          return this._dpsJson;
        },
        set: function (t) {
          this._dpsJson = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "labels", {
        get: function () {
          return this._labels;
        },
        set: function (t) {
          this._labels = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "legacySettings", {
        get: function () {
          return this._legacySettings;
        },
        set: function (t) {
          this._legacySettings = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(t.prototype, "ui", {
        get: function () {
          return this._ui;
        },
        set: function (t) {
          this._ui = t;
        },
        enumerable: !1,
        configurable: !0,
      }),
      (t.prototype.init = function (t, e, n) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function () {
            return (
              (this.language = n),
              (this.core = new On(t, n)),
              (this.coreJson = t),
              (this.dpsJson = e),
              (this.isAggregatorLoaded = !1),
              (this.allLegacyServicesHaveName = this.checkIfServiceNameExists(
                e.consentTemplates
              )),
              (this.isAggregatorLoaded = !1),
              [2]
            );
          });
        });
      }),
      (t.prototype.initData = function (t, e, n, i, r, o) {
        return (
          void 0 === n && (n = !0),
          void 0 === i && (i = !1),
          void 0 === r && (r = []),
          void 0 === o && (o = !1),
          ut(this, void 0, void 0, function () {
            var s,
              a,
              l,
              c,
              u,
              d,
              h = this;
            return dt(this, function (f) {
              switch (f.label) {
                case 0:
                  if (
                    ((a = (s = this).coreJson),
                    (l = s.dpsJson),
                    (c = s.legacySettings),
                    !a || !l)
                  )
                    return [2];
                  switch (
                    ((u = this.controllerIdInstance.value),
                    (d = (null == e ? void 0 : e.length)
                      ? e
                      : this.aggregatedServices),
                    t)
                  ) {
                    case 0:
                      return [3, 1];
                    case 2:
                      return [3, 3];
                    case 1:
                      return [3, 5];
                  }
                  return [3, 7];
                case 1:
                  return [
                    4,
                    __sc_import_cookie_banner("./p-14259c8e.js").then(function (
                      t
                    ) {
                      var e = new t.default(a, l, u, o);
                      h.data = e;
                    }),
                  ];
                case 2:
                  return f.sent(), [3, 8];
                case 3:
                  return c
                    ? [
                        4,
                        __sc_import_cookie_banner("./p-0a23fd04.js").then(
                          function (t) {
                            var e = t.default;
                            return ut(h, void 0, void 0, function () {
                              var t, o;
                              return dt(this, function (s) {
                                switch (s.label) {
                                  case 0:
                                    return (t =
                                      this.getDataTransferSettings()) && a.tcf2
                                      ? ((o = new e(
                                          c,
                                          a.tcf2,
                                          l,
                                          t,
                                          u,
                                          this.language,
                                          r
                                        )),
                                        (this.data = o),
                                        n ? [4, o.init(i)] : [3, 2])
                                      : [3, 2];
                                  case 1:
                                    s.sent(), (s.label = 2);
                                  case 2:
                                    return [2];
                                }
                              });
                            });
                          }
                        ),
                      ]
                    : [2];
                case 4:
                  return f.sent(), [3, 8];
                case 5:
                  return [
                    4,
                    __sc_import_cookie_banner("./p-4d78f8cb.js").then(function (
                      t
                    ) {
                      var e = new t.default(l, u, d);
                      h.data = e;
                    }),
                  ];
                case 6:
                  return f.sent(), [3, 8];
                case 7:
                  console.error("Usercentrics: Unknown variant"), (f.label = 8);
                case 8:
                  return (this.isVariantLoaded = !0), [2];
              }
            });
          })
        );
      }),
      (t.prototype.checkIfServiceNameExists = function (t) {
        return t.every(function (t) {
          var e;
          return (
            null != (null === (e = t._meta) || void 0 === e ? void 0 : e.name)
          );
        });
      }),
      (t.prototype.initLabels = function (t, e, n) {
        var i = this,
          r = i.coreJson,
          o = i.dpsJson,
          s = i.legacySettings,
          a = (null == n ? void 0 : n.length) ? n : this.aggregatedServices;
        if (o && this.core)
          if (s)
            switch (t) {
              case 0:
                var l = new zn(s, o, e, a);
                this.labels = l;
                break;
              case 1:
                var c = new In(s, o, e, a);
                this.labels = c;
                break;
              case 2:
                var u = new Bn(s, o, e, a);
                this.labels = u;
                break;
              default:
                console.error("Usercentrics: Unknown variant");
            }
          else {
            var d = new Dn(o, a, e),
              h = r
                ? {
                    label: "Powered by",
                    partnerUrlLabel: Vt(
                      r.labels.partnerPoweredByLinkText,
                      null
                    ),
                    urlLabel: "Usercentrics Consent Management",
                  }
                : void 0;
            this.labels = ct(ct({}, d), { poweredBy: h });
          }
        else
          console.error(
            "Usercentrics: You have to call the init method before!"
          );
      }),
      (t.prototype.initUI = function (t, e) {
        return ut(this, void 0, void 0, function () {
          var n,
            i,
            r,
            o = this;
          return dt(this, function (s) {
            switch (s.label) {
              case 0:
                return (
                  (i = (n = this).coreJson),
                  (r = n.legacySettings),
                  i
                    ? 2 !== t
                      ? [3, 2]
                      : [
                          4,
                          __sc_import_cookie_banner("./p-4a67bf15.js").then(
                            function (t) {
                              var e,
                                n = Yt.CAT,
                                s = !1;
                              r &&
                                ((n = r.secondLayer.defaultView),
                                (s = r.secondLayer.hideDataProcessingServices));
                              var a = new (0, t.default)(i, {
                                  defaultView: n,
                                  hideDataProcessingServices: s,
                                }),
                                l = i.enablePoweredBy
                                  ? {
                                      partnerUrl: i.partnerPoweredByUrl || null,
                                      url: Ce,
                                    }
                                  : null;
                              o.ui = ct(ct({}, a), {
                                customCss:
                                  (null ===
                                    (e = null == r ? void 0 : r.features) ||
                                  void 0 === e
                                    ? void 0
                                    : e.customCss) &&
                                  r.useUnsafeCustomCss &&
                                  null != r.stylesCss
                                    ? r.stylesCss
                                    : null,
                                poweredBy: l,
                              });
                            }
                          ),
                        ]
                    : [2]
                );
              case 1:
                return s.sent(), [2];
              case 2:
                if (!r) return [2];
                switch (e) {
                  case 0:
                    return [3, 3];
                  case 1:
                    return [3, 5];
                  case 2:
                    return [3, 7];
                }
                return [3, 9];
              case 3:
                return [
                  4,
                  __sc_import_cookie_banner("./p-be44a41c.js").then(function (
                    t
                  ) {
                    var e = new t.default(i, r);
                    o.ui = e;
                  }),
                ];
              case 4:
                return s.sent(), [3, 10];
              case 5:
                return [
                  4,
                  __sc_import_cookie_banner("./p-f6d88234.js").then(function (
                    t
                  ) {
                    var e = new t.default(i, r);
                    o.ui = e;
                  }),
                ];
              case 6:
                return s.sent(), [3, 10];
              case 7:
                return [
                  4,
                  __sc_import_cookie_banner("./p-c5303caf.js").then(function (
                    t
                  ) {
                    var e = new t.default(i, r);
                    o.ui = e;
                  }),
                ];
              case 8:
                return s.sent(), [3, 10];
              case 9:
                console.error("Usercentrics: Unknown variant"), (s.label = 10);
              case 10:
                return [2];
            }
          });
        });
      }),
      (t.prototype.getCcpaData = function () {
        return pe(this.data) ? this.data : null;
      }),
      (t.prototype.getDefaultData = function () {
        return (function (t) {
          return null != t && !pe(t) && !ve(t);
        })(this.data)
          ? this.data
          : null;
      }),
      (t.prototype.getTcfData = function () {
        return ve(this.data) ? this.data : null;
      }),
      (t.prototype.getCcpaLabels = function () {
        return ye(this.labels) ? this.labels : null;
      }),
      (t.prototype.getDefaultLabels = function () {
        return ke(this.labels) ? this.labels : null;
      }),
      (t.prototype.getTcfLabels = function () {
        return xe(this.labels) ? this.labels : null;
      }),
      (t.prototype.getCcpaUI = function () {
        return (function (t) {
          var e, n;
          return (
            null != t &&
            null !=
              (null === (e = t.firstLayer) || void 0 === e
                ? void 0
                : e.showShortDescriptionOnMobile) &&
            null ==
              (null === (n = t.firstLayer) || void 0 === n
                ? void 0
                : n.isCategoryTogglesEnabled)
          );
        })(this.ui)
          ? this.ui
          : null;
      }),
      (t.prototype.getDefaultUI = function () {
        return (function (t) {
          var e;
          return (
            null != t &&
            null !=
              (null === (e = t.firstLayer) || void 0 === e
                ? void 0
                : e.isCategoryTogglesEnabled)
          );
        })(this.ui)
          ? this.ui
          : null;
      }),
      (t.prototype.getTcfUI = function () {
        return (function (t) {
          var e;
          return (
            null != t &&
            null !=
              (null === (e = t.firstLayer) || void 0 === e
                ? void 0
                : e.hideNonIabPurposes)
          );
        })(this.ui)
          ? this.ui
          : null;
      }),
      (t.prototype.getDataExchangeSettings = function () {
        return this.core ? this.core.dataExchangeSettings : [];
      }),
      (t.prototype.getCategoriesData = function () {
        return this.data ? this.data.categories : [];
      }),
      (t.prototype.getCategoriesBaseData = function () {
        var t = this;
        return this.data
          ? this.data.categories.map(function (e) {
              return {
                isEssential: e.isEssential,
                isHidden: e.isHidden,
                services: t.getServicesBaseInfo().filter(function (t) {
                  return t.categorySlug === e.slug;
                }),
                slug: e.slug,
              };
            })
          : [];
      }),
      (t.prototype.getCategoriesLabels = function () {
        return this.labels && qe(this.labels) ? this.labels.categories : [];
      }),
      (t.prototype.getCategoriesDataAndLabels = function () {
        return (function (t, e, n) {
          return t.reduce(function (t, i) {
            var r = e.find(function (t) {
                return t.slug === i.slug;
              }),
              o = we(i.services, n);
            return r && t.push(ct(ct(ct({}, r), i), { services: o })), t;
          }, []);
        })(
          this.getCategoriesData(),
          this.getCategoriesLabels(),
          this.getServicesLabels()
        );
      }),
      (t.prototype.getCategoriesBasic = function () {
        var t = this.getCategoriesData(),
          e = this.getServicesLabels();
        return t.reduce(function (t, n) {
          return ft(
            ft([], ht(t), !1),
            [ct(ct({}, n), { services: ge(n.services, e) })],
            !1
          );
        }, []);
      }),
      (t.prototype.getCategoriesBaseInfo = function () {
        return this.getCategoriesDataAndLabels();
      }),
      (t.prototype.getCategoriesFullInfo = function (t, e) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return this.isAggregatorLoaded
                  ? [3, 2]
                  : [4, this.extendServices(t, e)];
              case 1:
                n.sent(), (n.label = 2);
              case 2:
                return [2, this.getCategoriesDataAndLabels()];
            }
          });
        });
      }),
      (t.prototype.getDataTransferSettings = function (t) {
        return this.core
          ? {
              controllerId: this.controllerIdInstance.value,
              id: this.core.id,
              selectedLanguage: this.core.language.selected,
              version: t || this.core.version,
            }
          : null;
      }),
      (t.prototype.getEssentialCategories = function () {
        return this.getCategoriesLabels().length
          ? this.getCategoriesDataAndLabels().reduce(function (t, e) {
              return e.isEssential ? ft(ft([], ht(t), !1), [e], !1) : t;
            }, [])
          : this.getCategoriesBasic().filter(function (t) {
              return t.isEssential;
            });
      }),
      (t.prototype.getEssentialCategoriesData = function () {
        return this.getCategoriesData().reduce(function (t, e) {
          return e.isEssential ? ft(ft([], ht(t), !1), [e], !1) : t;
        }, []);
      }),
      (t.prototype.getNonEssentialCategories = function () {
        return this.getCategoriesLabels().length
          ? this.getCategoriesDataAndLabels().reduce(function (t, e) {
              return e.isEssential ? t : ft(ft([], ht(t), !1), [e], !1);
            }, [])
          : this.getCategoriesBasic().filter(function (t) {
              return !t.isEssential;
            });
      }),
      (t.prototype.getNonEssentialCategoriesData = function () {
        return this.getCategoriesData().reduce(function (t, e) {
          return e.isEssential ? t : ft(ft([], ht(t), !1), [e], !1);
        }, []);
      }),
      (t.prototype.getGoogleConsentMode = function () {
        return !!this.core && this.core.googleConsentMode;
      }),
      (t.prototype.getServicesLabels = function () {
        return this.labels ? this.labels.services : [];
      }),
      (t.prototype.getServicesData = function () {
        return this.getCategoriesData().reduce(function (t, e) {
          return ft(ft([], ht(t), !1), ht(e.services), !1);
        }, []);
      }),
      (t.prototype.getServicesDataAndLabels = function () {
        var t = this.getServicesData();
        return we(t, this.getServicesLabels());
      }),
      (t.prototype.getServicesBaseInfo = function () {
        var t, e;
        return (
          (t = this.mapBaseServices(this.getServicesData())),
          (e = this.getServicesLabels()),
          t.reduce(function (t, n) {
            var i = e.find(function (t) {
              return t.id === n.id;
            });
            return ft(
              ft([], ht(t), !1),
              [ct(ct(ct({}, n), i || be), { id: n.id })],
              !1
            );
          }, [])
        );
      }),
      (t.prototype.getServicesFullInfo = function (t, e) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return this.isAggregatorLoaded
                  ? [3, 2]
                  : [4, this.extendServices(t, e)];
              case 1:
                n.sent(), (n.label = 2);
              case 2:
                return [2, this.getServicesDataAndLabels()];
            }
          });
        });
      }),
      (t.prototype.getServicesFromCategories = function (t) {
        return t.reduce(function (t, e) {
          return t.concat(e.services);
        }, []);
      }),
      (t.prototype.getServicesWithConsent = function () {
        return this.getServicesDataAndLabels().reduce(function (t, e) {
          return e.consent.status ? ft(ft([], ht(t), !1), [e], !1) : t;
        }, []);
      }),
      (t.prototype.areAllServicesAccepted = function () {
        return this.getServicesData().every(function (t) {
          return t.consent.status;
        });
      }),
      (t.prototype.areAllVendorsAndPurposesAccepted = function () {
        var t = this.getTcfData();
        return !!t && t.areAllPurposesAccepted() && t.areAllVendorsAccepted();
      }),
      (t.prototype.extendServices = function (t, e) {
        return ut(this, void 0, void 0, function () {
          var n, i;
          return dt(this, function (r) {
            switch (r.label) {
              case 0:
                return (n = this.dpsJson)
                  ? ((this.isAggregatorLoaded = !0), [4, this.fetchServices(n)])
                  : [2];
              case 1:
                return (i = r.sent()) && 0 !== i.length
                  ? ((this.aggregatedServices = i),
                    this.initLabels(t, e, i),
                    this.data &&
                      (this.data.categories = this.data.categories.map(
                        function (t) {
                          var e = n.categories.find(function (e) {
                            return e.categorySlug === t.slug;
                          });
                          return ct(ct({}, t), {
                            services: t.services.map(function (t) {
                              if (
                                n.consentTemplates.find(function (e) {
                                  return e.templateId === t.id;
                                }) &&
                                e
                              ) {
                                var r =
                                    null == i
                                      ? void 0
                                      : i.find(function (e) {
                                          return (
                                            t.id === e.templateId &&
                                            t.version === e.version
                                          );
                                        }),
                                  o = new Nn(r);
                                return ct(ct({}, t), o);
                              }
                              return t;
                            }),
                          });
                        }
                      )),
                    [2])
                  : [2];
            }
          });
        });
      }),
      (t.prototype.isCcpaEnabled = function () {
        var t;
        return (
          (null === (t = this.core) || void 0 === t
            ? void 0
            : t.isCcpaEnabled) || !1
        );
      }),
      (t.prototype.isCcpaAvailable = function () {
        var t;
        if (
          this.isCcpaEnabled() &&
          null !=
            (null === (t = this.coreJson) || void 0 === t ? void 0 : t.ccpa)
        )
          switch (this.coreJson.ccpa.region) {
            case Qt.US:
              return this.locationInstance.getIsUserInUS();
            case Qt.US_CA_ONLY:
              return this.locationInstance.getIsUserInCalifornia();
            default:
              return Promise.resolve(!0);
          }
        return Promise.resolve(!1);
      }),
      (t.prototype.isCrossDomainEnabled = function () {
        var t;
        return (
          (null === (t = this.core) || void 0 === t
            ? void 0
            : t.consentSharingIFrameIsActive) || !1
        );
      }),
      (t.prototype.isTcfEnabled = function () {
        var t;
        return (
          (null === (t = this.core) || void 0 === t
            ? void 0
            : t.isTcfEnabled) || !1
        );
      }),
      (t.prototype.isTcfAvailable = function () {
        var t;
        return (
          this.isTcfEnabled() &&
          null !=
            (null === (t = this.coreJson) || void 0 === t ? void 0 : t.tcf2)
        );
      }),
      (t.prototype.isTagLoggerActive = function () {
        var t;
        return (
          (null === (t = this.core) || void 0 === t
            ? void 0
            : t.isTagLoggerActive) || !1
        );
      }),
      (t.prototype.mergeServicesIntoExistingCategories = function (t) {
        return this.getCategoriesDataAndLabels().map(function (e) {
          return ct(ct({}, e), {
            services: e.services.map(function (e) {
              return (
                t.find(function (t) {
                  return t.id === e.id;
                }) || e
              );
            }),
          });
        });
      }),
      (t.prototype.mergeServicesDataIntoExistingCategories = function (t) {
        return this.getCategoriesData().map(function (e) {
          return ct(ct({}, e), {
            services: e.services.map(function (e) {
              return (
                t.find(function (t) {
                  return t.id === e.id;
                }) || e
              );
            }),
          });
        });
      }),
      (t.prototype.setCategories = function (t) {
        this.data && (this.data.categories = t);
      }),
      (t.prototype.setControllerId = function (t) {
        this.data && (this.data.controllerId = t),
          ve(this.data) && this.data.updateControllerId(t);
      }),
      (t.prototype.updateServicesLanguage = function (t) {
        this.data &&
          this.data.categories.map(function (e) {
            return ct(ct({}, e), {
              services: e.services.map(function (e) {
                return ct(ct({}, e), {
                  language: ct(ct({}, e.language), { selected: t }),
                });
              }),
            });
          });
      }),
      (t.prototype.shouldDenyAllExplicitlyOnInit = function () {
        var t;
        return ut(this, void 0, void 0, function () {
          var e;
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return null !== this.denyAllExplicitlyOnInit
                  ? [2, this.denyAllExplicitlyOnInit]
                  : ((e = this), [4, this.isCcpaAvailable()]);
              case 1:
                return (
                  (e.denyAllExplicitlyOnInit =
                    (n.sent() &&
                      !(null === (t = this.getCcpaData()) || void 0 === t
                        ? void 0
                        : t.isExplicitConsented) &&
                      !0 === navigator.globalPrivacyControl) ||
                    !1),
                  [2, this.denyAllExplicitlyOnInit]
                );
            }
          });
        });
      }),
      (t.prototype.shouldAcceptAllImplicitlyOnInit = function () {
        var t, e;
        return ut(this, void 0, void 0, function () {
          var n, i, r, o, s, a;
          return dt(this, function (l) {
            switch (l.label) {
              case 0:
                return null !== this.acceptAllImplicitlyOnInit
                  ? [2, this.acceptAllImplicitlyOnInit]
                  : ((n = this),
                    (o = this.botInstance.isRobot())
                      ? [3, 2]
                      : [4, this.isCcpaAvailable()]);
              case 1:
                (o = l.sent() && !navigator.globalPrivacyControl),
                  (l.label = 2);
              case 2:
                return (r = o)
                  ? [3, 5]
                  : (s =
                      null === (t = this.core) || void 0 === t
                        ? void 0
                        : t.acceptAllImplicitlyOutsideEU)
                  ? [4, this.locationInstance.getIsUserInEU()]
                  : [3, 4];
              case 3:
                (s = !l.sent()), (l.label = 4);
              case 4:
                (r = s), (l.label = 5);
              case 5:
                return (i = r)
                  ? [3, 8]
                  : (a = this.isTcfAvailable())
                  ? [
                      4,
                      null === (e = this.getTcfData()) || void 0 === e
                        ? void 0
                        : e.getGdprApplies(),
                    ]
                  : [3, 7];
              case 6:
                (a = !l.sent()), (l.label = 7);
              case 7:
                (i = a), (l.label = 8);
              case 8:
                return (
                  (n.acceptAllImplicitlyOnInit =
                    i ||
                    ("" !== this.apiInstance.getRulesetId() &&
                      this.rulesetInstance.getIsUsingNoShow() &&
                      this.rulesetInstance.getNoShow())),
                  [2, this.acceptAllImplicitlyOnInit]
                );
            }
          });
        });
      }),
      (t.prototype.shouldAcceptAllImplicitlyOnVendorAdded = function () {
        var t, e, n;
        return ut(this, void 0, void 0, function () {
          var i, r, o, s, a;
          return dt(this, function (l) {
            switch (l.label) {
              case 0:
                return (o = this.botInstance.isRobot())
                  ? [3, 2]
                  : [4, this.isCcpaAvailable()];
              case 1:
                (o =
                  l.sent() &&
                  !(null === (t = this.getCcpaData()) || void 0 === t
                    ? void 0
                    : t.isOptedOut)),
                  (l.label = 2);
              case 2:
                return (r = o)
                  ? [3, 5]
                  : (s =
                      null === (e = this.core) || void 0 === e
                        ? void 0
                        : e.acceptAllImplicitlyOutsideEU)
                  ? [4, this.locationInstance.getIsUserInEU()]
                  : [3, 4];
              case 3:
                (s = !l.sent()), (l.label = 4);
              case 4:
                (r = s), (l.label = 5);
              case 5:
                return (i = r)
                  ? [3, 8]
                  : (a = this.isTcfAvailable())
                  ? [
                      4,
                      null === (n = this.getTcfData()) || void 0 === n
                        ? void 0
                        : n.getGdprApplies(),
                    ]
                  : [3, 7];
              case 6:
                (a = !l.sent()), (l.label = 7);
              case 7:
                (i = a), (l.label = 8);
              case 8:
                return [
                  2,
                  i ||
                    ("" !== this.apiInstance.getRulesetId() &&
                      this.rulesetInstance.getIsUsingNoShow() &&
                      this.rulesetInstance.getNoShow()),
                ];
            }
          });
        });
      }),
      (t.prototype.shouldShowFirstLayerOnVersionChange = function () {
        var t = Rt.fetchSettingsVersion();
        if (this.core && t && jt(this.core.showFirstLayerOnVersionChange)) {
          var e = this.core.version.split("."),
            n = t.split(".");
          return (
            (Ft(this.core.showFirstLayerOnVersionChange, Q.MAJOR) &&
              e[0] !== n[0]) ||
            (Ft(this.core.showFirstLayerOnVersionChange, Q.MINOR) &&
              e[1] !== n[1]) ||
            (Ft(this.core.showFirstLayerOnVersionChange, Q.PATCH) &&
              e[2] !== n[2])
          );
        }
        return !1;
      }),
      (t.prototype.getUpdatedServicesWithConsent = function (t) {
        return this.getServicesDataAndLabels().map(function (e) {
          if (!e.isEssential) {
            var n = e;
            return (n.consent.status = t === Y.TRUE), n;
          }
          return e;
        });
      }),
      (t.prototype.getUpdatedServicesDataWithConsent = function (t) {
        return this.getServicesData().map(function (e) {
          if (!e.isEssential) {
            var n = e;
            return (n.consent.status = t === Y.TRUE), n;
          }
          return e;
        });
      }),
      (t.prototype.getUpdatedServicesWithDecisions = function (t) {
        return this.getServicesDataAndLabels().map(function (e) {
          var n = t.find(function (t) {
              return t.serviceId === e.id;
            }),
            i = e;
          return (
            (i.consent.status =
              e.isEssential || (n ? n.status : e.consent.status)),
            i
          );
        });
      }),
      (t.prototype.getUpdatedServicesDataWithDecisions = function (t) {
        return this.getServicesData().map(function (e) {
          var n = t.find(function (t) {
              return t.serviceId === e.id;
            }),
            i = e;
          return (
            (i.consent.status =
              e.isEssential || (n ? n.status : e.consent.status)),
            i
          );
        });
      }),
      (t.prototype.updateDataTransferSettings = function (t) {
        var e = t.id,
          n = t.selectedLanguage,
          i = t.version;
        this.core &&
          this.data &&
          ((this.data.controllerId = t.controllerId),
          (this.core.id = e),
          (this.core.language.selected = n),
          (this.core.version = i));
      }),
      (t.prototype.isTcfHistoryV2Disabled = function () {
        return !!ve(this.data) && !0 === this.data.tcfv2HistoryDisabled;
      }),
      (t.prototype.getTCFPurposeOneTreatment = function () {
        return (ve(this.data) && this.data.purposeOneTreatment) || !1;
      }),
      (t.prototype.getTCFStackIds = function () {
        return ve(this.data) ? this.data.stackIds : [];
      }),
      (t.prototype.getTCFVendorIds = function () {
        return ve(this.data) ? this.data.vendorIds : [];
      }),
      (t.prototype.getTCFDisclosedVendorsSegmentString = function () {
        var t;
        return null === (t = this.getTcfData()) || void 0 === t
          ? void 0
          : t.getTCFDisclosedVendorsSegmentString();
      }),
      (t.prototype.injectTCString = function (t) {
        return ut(this, void 0, void 0, function () {
          var e;
          return dt(this, function () {
            return (e = this.getTcfData()) ? [2, e.injectTCString(t)] : [2, !1];
          });
        });
      }),
      (t.prototype.fetchServices = function (t) {
        return ut(this, void 0, void 0, function () {
          var e, n, i, r;
          return dt(this, function (o) {
            switch (o.label) {
              case 0:
                return (e = on(t.consentTemplates)).length
                  ? ((n = sn.getInstance()),
                    (i = hn.getInstance()),
                    (r = []),
                    i.isRobot() ? [3, 2] : [4, n.fetchAggregatedServices(e)])
                  : [2, null];
              case 1:
                (r = o.sent()), (o.label = 2);
              case 2:
                return [2, r];
            }
          });
        });
      }),
      (t.prototype.mapBaseServices = function (t) {
        return t.map(function (t) {
          return {
            categorySlug: t.categorySlug,
            consent: t.consent,
            fetchSubServices: t.fetchSubServices,
            id: t.id,
            isEssential: t.isEssential,
            isHidden: t.isHidden,
            processorId: t.processorId,
            subServices: t.subServices,
            subServicesLength: t.subServicesLength,
            usesThirdCountry: t.usesThirdCountry,
            version: t.version,
          };
        });
      }),
      t
    );
  })(),
  Gn = (function () {
    function t() {
      (this.restoreAction = null),
        (this.apiInstance = sn.getInstance()),
        (this.controllerIdInstance = Ke.getInstance()),
        (this.eventDispatcherInstance = bn.getInstance()),
        (this.settingsV2 = Hn.getInstance()),
        (this.botInstance = hn.getInstance());
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        delete t.instance.userSessionData;
      }),
      (t.prototype.execute = function (t, e, n, i, r) {
        var o,
          s,
          a,
          l = this.settingsV2.getDataTransferSettings();
        if (l) {
          var c = t.map(function (t) {
              return Bt(l, t, n, i, t.categorySlug);
            }),
            u = Jn(e, c);
          if (
            !this.botInstance.isRobot() &&
            (this.apiInstance.saveConsents({
              consentString: r,
              dataTransferObjects: c,
            }),
            null === (o = this.settingsV2.core) || void 0 === o
              ? void 0
              : o.consentAPIv2)
          ) {
            var d = Ht({
              consentAction: n,
              consentString: r,
              dataTransferSettings: l,
              isAnalyticsEnabled:
                null === (s = this.settingsV2.core) || void 0 === s
                  ? void 0
                  : s.consentAnalytics,
              isCcpa: this.settingsV2.isCcpaEnabled(),
              isConsentXDeviceEnabled:
                null === (a = this.settingsV2.core) || void 0 === a
                  ? void 0
                  : a.consentXDevice,
              isTcf: !1,
              services: t,
            });
            this.apiInstance.saveConsentsV2(d);
          }
          this.settingsV2.setCategories(
            this.settingsV2.mergeServicesDataIntoExistingCategories(u)
          );
          var h = this.settingsV2.getServicesDataAndLabels(),
            f = Rt.mapSettings(l, h);
          Rt.saveSettings(f, h),
            Sn.enableScriptsForServicesWithConsent(
              this.settingsV2.getServicesWithConsent()
            ),
            this.eventDispatcherInstance.dispatch(
              c,
              this.settingsV2.getGoogleConsentMode()
            );
        }
      }),
      (t.prototype.getMergedServicesAndSettingsFromStorage = function (t) {
        var e = t,
          n = Rt.fetchSettings();
        if (n && e) {
          var i = this.settingsV2.getServicesFromCategories(
              this.settingsV2.getEssentialCategories()
            ),
            r = this.settingsV2.getServicesFromCategories(
              this.settingsV2.getEssentialCategoriesData()
            ),
            o = this.settingsV2.getServicesFromCategories(
              this.settingsV2.getNonEssentialCategories()
            ),
            s = this.settingsV2.getServicesFromCategories(
              this.settingsV2.getNonEssentialCategoriesData()
            ),
            a = this.getMergedAndUpdatedEssentialServices(i, n),
            l = this.getMergedAndUpdatedEssentialServices(r, n),
            c = this.getMergedNonEssentialServices(o, n),
            u = this.getMergedNonEssentialServices(s, n);
          return (
            n.controllerId !== this.controllerIdInstance.value &&
              "" === this.controllerIdInstance.value &&
              ((this.controllerIdInstance.value = n.controllerId),
              (e.controllerId = n.controllerId),
              ve(e) && e.updateControllerId(n.controllerId)),
            {
              dataTransferSettings: this.settingsV2.getDataTransferSettings(),
              mergedServices: a.mergedEssentialServices.concat(c),
              mergedServicesData: l.mergedEssentialServices.concat(u),
              mergedSettingsData: e,
              updatedEssentialServices: a.updatedEssentialServices,
            }
          );
        }
        return {
          dataTransferSettings: null,
          mergedServices: [],
          mergedServicesData: [],
          mergedSettingsData: e,
          updatedEssentialServices: [],
        };
      }),
      (t.prototype.getLatestConsentType = function (t) {
        return t.length > 0 ? t[t.length - 1].type : "implicit";
      }),
      (t.prototype.getLatestConsentAction = function (t) {
        return t.length > 0 ? t[t.length - 1].action : "onInitialPageLoad";
      }),
      (t.prototype.setUserSessionData = function (t) {
        this.userSessionData = t;
      }),
      (t.prototype.mergeServicesAndSettings = function (t, e, n, i, r) {
        var o,
          s,
          a,
          l = this;
        if (!n) return [];
        if (jt(i)) {
          var c = i.map(function (t) {
              return Bt(
                n,
                t,
                "onEssentialChange",
                l.getLatestConsentType(t.consent.history),
                null == t ? void 0 : t.categorySlug
              );
            }),
            u = Jn(e, c),
            d = Wn(e, u, r);
          if (
            (this.apiInstance.saveConsents({ dataTransferObjects: c }),
            null === (o = this.settingsV2.core) || void 0 === o
              ? void 0
              : o.consentAPIv2)
          ) {
            var h = Ht({
              consentAction: "onEssentialChange",
              dataTransferSettings: n,
              isAnalyticsEnabled:
                null === (s = this.settingsV2.core) || void 0 === s
                  ? void 0
                  : s.consentAnalytics,
              isCcpa: this.settingsV2.isCcpaEnabled(),
              isConsentXDeviceEnabled:
                null === (a = this.settingsV2.core) || void 0 === a
                  ? void 0
                  : a.consentXDevice,
              isTcf: this.settingsV2.isTcfAvailable(),
              services: i,
            });
            this.apiInstance.saveConsentsV2(h);
          }
          this.settingsV2.setCategories(
            this.settingsV2.mergeServicesDataIntoExistingCategories(u)
          ),
            Rt.saveSettings(Rt.mapSettings(n, d), d);
        } else
          this.settingsV2.setCategories(
            this.settingsV2.mergeServicesDataIntoExistingCategories(e)
          ),
            Rt.saveSettings(Rt.mapSettings(n, t), t);
        return t.map(function (t) {
          return Bt(
            n,
            t,
            l.getLatestConsentAction(t.consent.history),
            l.getLatestConsentType(t.consent.history),
            null == t ? void 0 : t.categorySlug
          );
        });
      }),
      (t.prototype.restoreUserSession = function (t) {
        var e, n, i;
        return ut(this, void 0, void 0, function () {
          var r;
          return dt(this, function (o) {
            switch (o.label) {
              case 0:
                return this.controllerIdInstance.value &&
                  this.controllerIdInstance.needsSessionRestore &&
                  (!(null === (e = this.settingsV2.core) || void 0 === e
                    ? void 0
                    : e.consentAPIv2) ||
                    ((null === (n = this.settingsV2.core) || void 0 === n
                      ? void 0
                      : n.consentAPIv2) &&
                      (null === (i = this.settingsV2.core) || void 0 === i
                        ? void 0
                        : i.consentXDevice)))
                  ? [
                      4,
                      this.getCrossDeviceSessionData(
                        this.controllerIdInstance.value
                      ),
                    ]
                  : [3, 2];
              case 1:
                (r = o.sent()), (o.label = 2);
              case 2:
                if (
                  (!r &&
                    this.userSessionData &&
                    (r = ct({}, this.userSessionData)),
                  !r &&
                    window[wt] &&
                    "function" == typeof window[wt].getUserSessionData)
                )
                  try {
                    (null ==
                    (r = JSON.parse(
                      window[wt].getUserSessionData(),
                      function (t, e) {
                        if ("timestamp" === t) {
                          var n = e.toString();
                          return -1 !== n.indexOf(".")
                            ? 1e3 * Number(n)
                            : Number(n);
                        }
                        return e;
                      }
                    ))
                      ? void 0
                      : r.consents) &&
                      (null == r ? void 0 : r.consents.length) &&
                      !r.consents.every(function (t) {
                        return t.action;
                      }) &&
                      ((r.consents = r.consents.map(function (t) {
                        return ct(ct({}, t), {
                          action: "onMobileSessionRestore",
                        });
                      })),
                      (this.restoreAction = "onMobileSessionRestore"));
                  } catch (_) {}
                return r || !Ot.isCrossDomainAvailable()
                  ? [3, 4]
                  : [4, this.getCrossDomainSessionData()];
              case 3:
                (r = o.sent()), (o.label = 4);
              case 4:
                return r && r.controllerId
                  ? [2, this.restoreData(r, t)]
                  : ((this.controllerIdInstance.needsSessionRestore = !1),
                    [2, !1]);
            }
          });
        });
      }),
      (t.prototype.getCrossDomainSessionData = function () {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (t) {
            switch (t.label) {
              case 0:
                return [
                  4,
                  Ot.getCrossDomainSessionData().catch(function () {
                    return console.warn(at.CROSS_DOMAIN_DATA_NOT_AVAILABLE), {};
                  }),
                ];
              case 1:
                return [2, t.sent()];
            }
          });
        });
      }),
      (t.prototype.getCrossDeviceSessionData = function (t) {
        var e, n;
        return ut(this, void 0, void 0, function () {
          var i, r, o, s, a, l, c, u, d, h, f;
          return dt(this, function (m) {
            switch (m.label) {
              case 0:
                return (
                  (i = [
                    "dWLDa0s-m",
                    "VkvM9IcSA",
                    "Zdgjo9gQh",
                    "r2tAWzO7",
                    "GVl-ixMH",
                  ]),
                  (r = this.apiInstance.getSettingsId()),
                  (o = this.settingsV2.isTcfAvailable()),
                  [4, this.settingsV2.isCcpaAvailable()]
                );
              case 1:
                return (
                  (s = m.sent()),
                  (a =
                    null === (e = this.settingsV2.core) || void 0 === e
                      ? void 0
                      : e.consentAPIv2),
                  (l = []),
                  (c = null),
                  (u = null),
                  a
                    ? [
                        4,
                        this.apiInstance
                          .fetchUserConsentsV2(o, s)
                          .catch(function () {
                            return (
                              console.warn(st.CROSS_DEVICE_DATA_NOT_AVAILABLE),
                              null
                            );
                          }),
                      ]
                    : [3, 3]
                );
              case 2:
                return (
                  (d = m.sent()),
                  (l =
                    null !== (n = null == d ? void 0 : d.consents) &&
                    void 0 !== n
                      ? n
                      : []),
                  o &&
                    ((-1 === i.indexOf(r) &&
                      this.settingsV2.isTcfHistoryV2Disabled()) ||
                      (c = null == d ? void 0 : d.tcf)),
                  s && (u = null == d ? void 0 : d.ccpa),
                  [3, 8]
                );
              case 3:
                return [
                  4,
                  this.apiInstance.fetchUserConsents().catch(function () {
                    return console.warn(st.CROSS_DEVICE_DATA_NOT_AVAILABLE), [];
                  }),
                ];
              case 4:
                return (
                  (h = m.sent()),
                  (l = h),
                  o
                    ? -1 === i.indexOf(r)
                      ? [3, 6]
                      : [
                          4,
                          this.apiInstance
                            .fetchUserTcfData()
                            .catch(function () {
                              return (
                                console.warn(
                                  st.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE
                                ),
                                null
                              );
                            }),
                        ]
                    : [3, 8]
                );
              case 5:
                return (c = m.sent()), [3, 8];
              case 6:
                return this.settingsV2.isTcfHistoryV2Disabled()
                  ? [3, 8]
                  : [
                      4,
                      this.apiInstance.fetchUserTcfDataV2().catch(function () {
                        return (
                          console.warn(st.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE),
                          null
                        );
                      }),
                    ];
              case 7:
                (c = m.sent()), (m.label = 8);
              case 8:
                return o && !c && Ot.isCrossDomainAvailable()
                  ? [4, this.getCrossDomainSessionData()]
                  : [3, 10];
              case 9:
                (f = m.sent()) && f.tcf && f.controllerId === t && (c = f.tcf),
                  (m.label = 10);
              case 10:
                return [
                  2,
                  ct(
                    ct(
                      {
                        consents: l,
                        controllerId: t,
                        language: this.apiInstance.getJsonFileLanguage(),
                      },
                      null !== c && { tcf: c }
                    ),
                    null !== u && { ccpa: u }
                  ),
                ];
            }
          });
        });
      }),
      (t.prototype.restoreData = function (t, e) {
        return ut(this, void 0, void 0, function () {
          var n,
            i,
            r,
            o,
            s,
            a,
            l,
            c,
            u,
            d,
            h,
            f,
            m,
            b,
            g,
            w,
            p,
            v,
            y = this;
          return dt(this, function (x) {
            switch (x.label) {
              case 0:
                return (
                  (n = t.controllerId),
                  (i = t.consents),
                  (r = t.tcf),
                  (o = t.ccpa),
                  (s = this.settingsV2.core),
                  (a = this.getDataFacadeServices(e)),
                  (l = Rt.fetchControllerId()),
                  (this.controllerIdInstance.value = n),
                  (c = Rt.fetchTCFData()),
                  (u = !1),
                  !n || (!jt(i) && a.length)
                    ? [3, 5]
                    : ((d = Yn(i)),
                      (h = Rt.fetchServices()),
                      "onSessionRestored" === t.consents[0].action &&
                      n === l &&
                      h.length === d.length &&
                      h[0].history.length > 0 &&
                      h[0].history[0].action &&
                      "onSessionRestored" === h[0].history[0].action
                        ? [3, 5]
                        : [3, 1])
                );
              case 1:
                return !jt(d) && a.length
                  ? [3, 5]
                  : ((f = []),
                    (m = []),
                    d.forEach(function (t) {
                      var e = a.findIndex(function (e) {
                        return e.id === t.templateId;
                      });
                      if (e > -1) {
                        var n = a[e],
                          i = n;
                        i.consent.status = t.status;
                        var r = m.findIndex(function (t) {
                          return t.id === n.id;
                        });
                        -1 === r ? m.push(i) : (m[r] = i), (a[e] = i);
                        var o = y.settingsV2.getDataTransferSettings(
                          t.settingsVersion
                        );
                        o &&
                          f.push(
                            Bt(o, i, t.action, t.updatedBy, n.categorySlug, {
                              timestamp:
                                "string" == typeof t.timestamp
                                  ? y.resolveTimestamp(t.timestamp)
                                  : t.timestamp,
                            })
                          );
                      }
                    }),
                    this.settingsV2.data && this.settingsV2.setControllerId(n),
                    (b = void 0),
                    (g = void 0),
                    s &&
                      d.length &&
                      (g = Jt(
                        d.map(function (t) {
                          return t.settingsVersion;
                        })
                      ).sort(se)).length &&
                      (b = g[g.length - 1]),
                    (w = Jn(a, f)),
                    (p = this.settingsV2.getDataTransferSettings(b))
                      ? l && n && n !== l
                        ? [4, Rt.clearAll()]
                        : [3, 3]
                      : [3, 4]);
              case 2:
                x.sent(), (x.label = 3);
              case 3:
                Rt.saveSettings(Rt.mapSettings(p, w), w), (x.label = 4);
              case 4:
                jt(d) && Rt.setUserActionPerformed(!0), (u = !0), (x.label = 5);
              case 5:
                return (
                  r &&
                    r.tcString &&
                    r.tcString !== c.tcString &&
                    (Rt.saveTCFData(r),
                    a.length || Rt.setUserActionPerformed(!0)),
                  (v = this.settingsV2.getCcpaData()),
                  o &&
                    o.ccpaString &&
                    v &&
                    (v.setIsOptedOut(o.ccpaString),
                    Rt.setCcpaString(o.ccpaString),
                    o.timestamp ? Rt.setCcpaTimeStamp(o) : Rt.clearCcpaData(),
                    Rt.setUserActionPerformed(!0)),
                  [2, u]
                );
            }
          });
        });
      }),
      (t.prototype.getDataFacadeServices = function (t) {
        var e = t.categories,
          n = t.consentTemplates;
        if (n.length > 0 && (0, this.settingsV2.checkIfServiceNameExists)(n))
          return n.map(function (t) {
            var n,
              i = e.find(function (e) {
                return e.categorySlug === t.categorySlug;
              });
            return {
              categorySlug: t.categorySlug,
              consent: _n(t, i),
              id: t.templateId,
              name:
                (null === (n = t._meta) || void 0 === n ? void 0 : n.name) ||
                "",
              processorId: "".concat(Be(Ye())),
              version: t.version,
            };
          });
        var i = this.settingsV2.getServicesDataAndLabels();
        return i.length > 0
          ? i.map(function (t) {
              return {
                categorySlug: t.categorySlug,
                consent: t.consent,
                id: t.id,
                name: t.name,
                processorId: t.processorId,
                version: t.version,
              };
            })
          : [];
      }),
      (t.prototype.getMergedAndUpdatedEssentialServices = function (t, e) {
        var n = this,
          i = [],
          r = t.map(function (t) {
            var r,
              o,
              s =
                null === (r = e.services) || void 0 === r
                  ? void 0
                  : r.find(function (e) {
                      return e.id === t.id;
                    });
            if (s) {
              var a = t;
              return (
                (a.consent.history = s.history),
                (a.consent.status = !0),
                (a.processorId = s.processorId),
                (a.categorySlug =
                  (null ===
                    (o = n.settingsV2
                      .getCategoriesBaseData()
                      .find(function (t) {
                        return t.services.some(function (t) {
                          return t.id === a.id;
                        });
                      })) || void 0 === o
                    ? void 0
                    : o.slug) || ""),
                s.status || i.push(a),
                a
              );
            }
            return t;
          });
        return { mergedEssentialServices: r, updatedEssentialServices: i };
      }),
      (t.prototype.getMergedNonEssentialServices = function (t, e) {
        return t.map(function (t) {
          var n,
            i,
            r =
              null === (n = e.services) || void 0 === n
                ? void 0
                : n.find(function (e) {
                    return e.id === t.id;
                  });
          if (r)
            return (
              ((o = t).consent.history = r.history),
              (o.consent.status = r.status),
              (o.processorId = r.processorId),
              o
            );
          if (0 === t.consent.history.length) {
            var o = t,
              s =
                null === (i = e.services) || void 0 === i
                  ? void 0
                  : i.find(function (t) {
                      return t.history.length > 0;
                    });
            return (
              (o.consent.history = [
                {
                  action: "onInitialPageLoad",
                  language: t.language ? t.language.selected : pn,
                  status: t.consent.status,
                  timestamp: new Date().getTime(),
                  type: "implicit",
                  versions:
                    s && s.history.length > 0
                      ? s.history[0].versions
                      : { application: "", service: t.version, settings: "" },
                },
              ]),
              o
            );
          }
          return t;
        });
      }),
      (t.prototype.resolveTimestamp = function (t) {
        return 10 === t.length ? 1e3 * parseInt(t, 10) : parseInt(t, 10);
      }),
      t
    );
  })(),
  Jn = function (t, e) {
    return t.map(function (t) {
      var n = e.filter(function (e) {
        return e.service.id === t.id;
      });
      if (jt(n)) {
        var i = t.consent.history,
          r = i.length + n.length,
          o = r <= 3 ? i : i.slice(r - 3),
          s = t;
        return (
          (s.consent.history = ft(
            ft([], ht(o), !1),
            ht(
              n.map(function (t) {
                return $n(t);
              })
            ),
            !1
          )),
          s
        );
      }
      return t;
    });
  },
  Wn = function (t, e, n) {
    return t.reduce(function (t, i) {
      var r = e.find(function (t) {
          return t.id === i.id;
        }),
        o = n.find(function (t) {
          return t.id === i.id;
        });
      return r && o
        ? ft(
            ft([], ht(t), !1),
            [
              {
                categorySlug: i.categorySlug,
                consent: r.consent,
                id: i.id,
                language: i.language,
                name: o.name,
                processorId: i.processorId,
                version: i.version,
              },
            ],
            !1
          )
        : ft([], ht(t), !1);
    }, []);
  },
  $n = function (t) {
    return {
      action: t.consent.action,
      language: t.settings.language,
      status: t.consent.status,
      timestamp: t.timestamp,
      type: t.consent.type,
      versions: {
        application: t.applicationVersion,
        service: t.service.version,
        settings: t.settings.version,
      },
    };
  },
  Yn = function (t) {
    return t.filter(function (t) {
      return !ze.includes(t.action);
    });
  },
  Kn = (function () {
    function t() {
      (this.primaryLanguage = ""), (this.apiInstance = sn.getInstance());
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.prototype.setPrimaryLanguage = function (t) {
        this.primaryLanguage = t;
      }),
      (t.prototype.getPrimaryLanguage = function () {
        return this.primaryLanguage;
      }),
      (t.prototype.resolveLanguage = function (t) {
        return (
          void 0 === t && (t = !1),
          ut(this, void 0, void 0, function () {
            var e, n, i, r, o;
            return dt(this, function (s) {
              switch (s.label) {
                case 0:
                  return (
                    (e = Rt.fetchUserCountryResponse()),
                    (n = []),
                    e
                      ? (Xe.getInstance().setUserCountryData({
                          code: e.countryCode,
                          name: e.countryName,
                          regionCode: e.regionCode,
                        }),
                        [3, 3])
                      : [3, 1]
                  );
                case 1:
                  return [4, this.apiInstance.fetchAvailableLanguages()];
                case 2:
                  (n = s.sent()), (s.label = 3);
                case 3:
                  if (!t) {
                    if (this.primaryLanguage)
                      return (
                        this.apiInstance.setJsonFileLanguage(
                          this.primaryLanguage
                        ),
                        [2]
                      );
                    if ((i = Rt.fetchLanguage()))
                      return this.apiInstance.setJsonFileLanguage(i), [2];
                  }
                  return n.length
                    ? [3, 5]
                    : [4, this.apiInstance.fetchAvailableLanguages()];
                case 4:
                  (n = s.sent()), (s.label = 5);
                case 5:
                  return (r = Xn(n))
                    ? (this.apiInstance.setJsonFileLanguage(r), [2])
                    : (o = Qn(n))
                    ? (this.apiInstance.setJsonFileLanguage(o), [2])
                    : n.length > 0
                    ? (this.apiInstance.setJsonFileLanguage(n[0]), [2])
                    : (this.apiInstance.setJsonFileLanguage(pn), [2]);
              }
            });
          })
        );
      }),
      t
    );
  })(),
  Qn = function (t) {
    var e = window.navigator;
    if (jt(e.languages))
      for (var n = 0; n < e.languages.length; n += 1) {
        var i = Zn(t, e.languages[n]);
        if (i) return i;
      }
    return Zn(t, null != e.language ? e.language : e.userLanguage);
  },
  Xn = function (t) {
    var e = document.documentElement.lang;
    return e ? Zn(t, e) : null;
  },
  Zn = function (t, e) {
    if (e) {
      var n = e.toLowerCase().replace("-", "_");
      if (Ft(t, n)) return n;
      var i = e.slice(0, 2);
      if (Ft(t, i)) return i;
    }
    return null;
  },
  ti = (function () {
    function t() {
      (this.initOptions = null),
        (this.isFirstTimePageVisit = !0),
        (this.selectedLayer = null),
        (this.shouldAcceptAllImplicitly = null),
        (this.shouldShowFirstLayerOnVersionChange = !1),
        (this.variant = null),
        (this.ampInstance = _e.getInstance()),
        (this.botInstance = hn.getInstance()),
        (this.settingsV2 = Hn.getInstance()),
        (this.rulesetInstance = Ln.getInstance()),
        (this.apiInstance = sn.getInstance());
    }
    return (
      (t.getInstance = function () {
        return t.instance || (t.instance = new t()), t.instance;
      }),
      (t.resetInstance = function () {
        (t.instance.selectedLayer = null),
          (t.instance.variant = null),
          (t.instance.shouldAcceptAllImplicitly = null),
          (t.instance.initOptions = null);
      }),
      (t.prototype.init = function (t) {
        return ut(this, void 0, void 0, function () {
          var e;
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return (
                  (this.initOptions = t),
                  (this.isFirstTimePageVisit = this.isFirstTimeVisit()),
                  null !== this.shouldAcceptAllImplicitly
                    ? [3, 2]
                    : ((e = this),
                      [4, this.settingsV2.shouldAcceptAllImplicitlyOnInit()])
                );
              case 1:
                (e.shouldAcceptAllImplicitly = n.sent()), (n.label = 2);
              case 2:
                return (
                  (this.shouldShowFirstLayerOnVersionChange =
                    this.settingsV2.shouldShowFirstLayerOnVersionChange()),
                  [2]
                );
            }
          });
        });
      }),
      (t.prototype.isFirstTimeVisit = function () {
        return !Rt.settingsExist() || this.botInstance.isRobot();
      }),
      (t.prototype.shouldShowNone = function () {
        return ut(this, void 0, void 0, function () {
          var t, e;
          return dt(this, function (n) {
            switch (n.label) {
              case 0:
                return (
                  (t = 0 === this.variant),
                  null !== this.shouldAcceptAllImplicitly
                    ? [3, 2]
                    : ((e = this),
                      [4, this.settingsV2.shouldAcceptAllImplicitlyOnInit()])
                );
              case 1:
                (e.shouldAcceptAllImplicitly = n.sent()), (n.label = 2);
              case 2:
                return this.apiInstance.getRulesetId() &&
                  this.rulesetInstance.getIsUsingNoShow()
                  ? [2, this.rulesetInstance.getNoShow()]
                  : [2, this.shouldAcceptAllImplicitly && !t];
            }
          });
        });
      }),
      (t.prototype.shouldShowFirstLayer = function (t) {
        var e,
          n,
          i,
          r = this.ampInstance.isAmpEnabled(),
          o = 0 === this.variant,
          s =
            (null === (e = t.ccpa) || void 0 === e
              ? void 0
              : e.showOnPageLoad) || !1;
        if (this.shouldAcceptAllImplicitly && !o) return !1;
        if (
          ((o ? s : !this.shouldAcceptAllImplicitly) &&
            this.isFirstTimePageVisit) ||
          this.shouldShowFirstLayerOnVersionChange ||
          (!Rt.fetchUserActionPerformed() && (!o || s)) ||
          r
        )
          return !0;
        switch (this.variant) {
          case 0:
            if (
              this.shouldShowFirstLayerForCcpa(
                null === (n = t.ccpa) || void 0 === n ? void 0 : n.reshowCMP,
                null === (i = t.ccpa) || void 0 === i
                  ? void 0
                  : i.reshowAfterDays
              )
            )
              return !0;
            break;
          case 2:
            var a = this.settingsV2.getTcfData();
            if (null == a ? void 0 : a.shouldResurfaceUI()) return !0;
            break;
          default:
            if (this.shouldForceReshowGDPRBanner()) return !0;
        }
        return !1;
      }),
      (t.prototype.shouldForceReshowGDPRBanner = function () {
        var t = this.settingsV2.core;
        if (!t) return !1;
        var e,
          n = t.reshowBanner,
          i = this.settingsV2
            .getServicesData()
            .reduce(function (t, e) {
              return ft(ft([], ht(t), !1), ht(e.consent.history), !1);
            }, [])
            .filter(function (t) {
              return (
                [
                  "onAcceptAllServices",
                  "onDenyAllServices",
                  "onUpdateServices",
                ].indexOf(t.action) > -1
              );
            })
            .sort(function (t, e) {
              return e.timestamp - t.timestamp;
            });
        if (n > 0 && i.length > 0) {
          var r = new Date(i[0].timestamp);
          return (
            r.setMonth(r.getMonth() + n),
            (e = r),
            new Date().getTime() - e.getTime() >= 0
          );
        }
        return !1;
      }),
      (t.prototype.shouldShowPrivacyButton = function (t) {
        var e = window.location.href,
          n = !t.privacyButtonUrls || 0 === t.privacyButtonUrls.contains.length;
        return (
          t.privacyButtonUrls &&
            t.privacyButtonUrls.contains.length > 0 &&
            t.privacyButtonUrls.contains.some(function (t) {
              return e.includes(t);
            }) &&
            (n = !0),
          t.privacyButtonIsVisible && n
        );
      }),
      (t.prototype.resolveUiVariant = function (t) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return null !== this.variant
                  ? [2, this.variant]
                  : [4, this.settingsV2.isCcpaAvailable()];
              case 1:
                return (
                  (this.variant = e.sent() ? 0 : t ? 2 : 1), [2, this.variant]
                );
            }
          });
        });
      }),
      (t.prototype.resolveUiInitialLayer = function (t) {
        return ut(this, void 0, void 0, function () {
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return [4, this.shouldShowNone()];
              case 1:
                return e.sent()
                  ? [2, 1]
                  : this.shouldShowFirstLayer(t)
                  ? [2, 0]
                  : this.shouldShowPrivacyButton(t)
                  ? [2, 2]
                  : [2, 1];
            }
          });
        });
      }),
      (t.prototype.resolveUIOptions = function (t) {
        var e;
        return ut(this, void 0, void 0, function () {
          var n, i, r, o;
          return dt(this, function (s) {
            switch (s.label) {
              case 0:
                return (
                  (n = this.ampInstance.isAmpEnabled()),
                  null !== this.variant
                    ? [3, 2]
                    : ((i = this), [4, this.resolveUiVariant(t.tcf2Enabled)])
                );
              case 1:
                (i.variant = s.sent()), (s.label = 2);
              case 2:
                return (
                  0 !== this.variant && Rt.clearCcpa(),
                  2 !== this.variant && Rt.clearTcf(),
                  (r = this),
                  (
                    null === (e = this.initOptions) || void 0 === e
                      ? void 0
                      : e.suppressCmpDisplay
                  )
                    ? ((o = 1), [3, 5])
                    : [3, 3]
                );
              case 3:
                return [4, this.resolveUiInitialLayer(t)];
              case 4:
                (o = s.sent()), (s.label = 5);
              case 5:
                return (
                  (r.selectedLayer = o),
                  [
                    2,
                    {
                      ampEnabled: n,
                      initialLayer: this.selectedLayer,
                      variant: this.variant,
                    },
                  ]
                );
            }
          });
        });
      }),
      (t.prototype.shouldShowFirstLayerForCcpa = function (t, e) {
        var n;
        void 0 === e && (e = 365);
        var i,
          r = this.settingsV2.legacySettings,
          o = (i = Rt.getCcpaData())
            ? (new Date().getTime() - i.timestamp) / 864e5
            : 0;
        return r || void 0 !== t
          ? null !==
              (n = null != t ? t : null == r ? void 0 : r.ccpa.reshowCMP) &&
              void 0 !== n &&
              n &&
              o > e
          : o > e;
      }),
      t
    );
  })(),
  ei = Object.freeze({
    initialize: function ({
      modulePath: t = ".",
      importFunctionName: e = "__import__",
    } = {}) {
      try {
        self[e] = new Function("u", "return import(u)");
      } catch (k) {
        const i = new URL(t, location),
          r = (t) => {
            URL.revokeObjectURL(t.src), t.remove();
          };
        (self[e] = (t) =>
          new Promise((n, o) => {
            const s = new URL(t, i);
            if (self[e].moduleMap[s]) return n(self[e].moduleMap[s]);
            const a = new Blob(
                [`import * as m from '${s}';`, `${e}.moduleMap['${s}']=m;`],
                { type: "text/javascript" }
              ),
              l = Object.assign(document.createElement("script"), {
                type: "module",
                src: URL.createObjectURL(a),
                onerror() {
                  o(new Error(`Failed to import: ${t}`)), r(l);
                },
                onload() {
                  n(self[e].moduleMap[s]), r(l);
                },
              });
            document.head.appendChild(l);
          })),
          (self[e].moduleMap = {});
      }
    },
  }),
  ni = (function () {
    A(e, D(Error));
    var t = R(e);
    function e(n) {
      var i;
      return S(this, e), ((i = t.call(this, n)).name = "DecodingError"), i;
    }
    return _(e);
  })(),
  ii = (function () {
    A(e, D(Error));
    var t = R(e);
    function e(n) {
      var i;
      return S(this, e), ((i = t.call(this, n)).name = "EncodingError"), i;
    }
    return _(e);
  })(),
  ri = (function () {
    A(e, D(Error));
    var t = R(e);
    function e(n) {
      var i;
      return S(this, e), ((i = t.call(this, n)).name = "GVLError"), i;
    }
    return _(e);
  })(),
  oi = (function () {
    A(e, D(Error));
    var t = R(e);
    function e(n, i) {
      var r,
        o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
      return (
        S(this, e),
        ((r = t.call(
          this,
          "invalid value ".concat(i, " passed for ").concat(n, " ").concat(o)
        )).name = "TCModelError"),
        r
      );
    }
    return _(e);
  })(),
  si = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t) {
            if (!/^[0-1]+$/.test(t)) throw new ii("Invalid bitField");
            var e = t.length % this.LCM;
            t += e ? "0".repeat(this.LCM - e) : "";
            for (var n = "", i = 0; i < t.length; i += this.BASIS)
              n += this.DICT[parseInt(t.substr(i, this.BASIS), 2)];
            return n;
          },
        },
        {
          key: "decode",
          value: function (t) {
            if (!/^[A-Za-z0-9\-_]+$/.test(t))
              throw new ni("Invalidly encoded Base64URL string");
            for (var e = "", n = 0; n < t.length; n++) {
              var i = this.REVERSE_DICT.get(t[n]).toString(2);
              e += "0".repeat(this.BASIS - i.length) + i;
            }
            return e;
          },
        },
      ]),
      t
    );
  })();
T(
  si,
  "DICT",
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
),
  T(
    si,
    "REVERSE_DICT",
    new Map([
      ["A", 0],
      ["B", 1],
      ["C", 2],
      ["D", 3],
      ["E", 4],
      ["F", 5],
      ["G", 6],
      ["H", 7],
      ["I", 8],
      ["J", 9],
      ["K", 10],
      ["L", 11],
      ["M", 12],
      ["N", 13],
      ["O", 14],
      ["P", 15],
      ["Q", 16],
      ["R", 17],
      ["S", 18],
      ["T", 19],
      ["U", 20],
      ["V", 21],
      ["W", 22],
      ["X", 23],
      ["Y", 24],
      ["Z", 25],
      ["a", 26],
      ["b", 27],
      ["c", 28],
      ["d", 29],
      ["e", 30],
      ["f", 31],
      ["g", 32],
      ["h", 33],
      ["i", 34],
      ["j", 35],
      ["k", 36],
      ["l", 37],
      ["m", 38],
      ["n", 39],
      ["o", 40],
      ["p", 41],
      ["q", 42],
      ["r", 43],
      ["s", 44],
      ["t", 45],
      ["u", 46],
      ["v", 47],
      ["w", 48],
      ["x", 49],
      ["y", 50],
      ["z", 51],
      ["0", 52],
      ["1", 53],
      ["2", 54],
      ["3", 55],
      ["4", 56],
      ["5", 57],
      ["6", 58],
      ["7", 59],
      ["8", 60],
      ["9", 61],
      ["-", 62],
      ["_", 63],
    ])
  ),
  T(si, "BASIS", 6),
  T(si, "LCM", 24);
var ai = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, [
        {
          key: "clone",
          value: function () {
            var t = this,
              e = new this.constructor();
            return (
              Object.keys(this).forEach(function (n) {
                var i = t.deepClone(t[n]);
                void 0 !== i && (e[n] = i);
              }),
              e
            );
          },
        },
        {
          key: "deepClone",
          value: function (t) {
            var e = x(t);
            if ("number" === e || "string" === e || "boolean" === e) return t;
            if (null !== t && "object" === e) {
              if ("function" == typeof t.clone) return t.clone();
              if (t instanceof Date) return new Date(t.getTime());
              if (void 0 !== t[Symbol.iterator]) {
                var n,
                  i = [],
                  r = V(t);
                try {
                  for (r.s(); !(n = r.n()).done; )
                    i.push(this.deepClone(n.value));
                } catch (E) {
                  r.e(E);
                } finally {
                  r.f();
                }
                return t instanceof Array ? i : new t.constructor(i);
              }
              var o = {};
              for (var s in t)
                t.hasOwnProperty(s) && (o[s] = this.deepClone(t[s]));
              return o;
            }
          },
        },
      ]),
      t
    );
  })(),
  li = (function () {
    A(e, ai);
    var t = R(e);
    function e() {
      var n;
      S(this, e);
      for (var i = arguments.length, r = new Array(i), o = 0; o < i; o++)
        r[o] = arguments[o];
      return T(L((n = t.call.apply(t, [this].concat(r)))), "root", null), n;
    }
    return (
      _(e, [
        {
          key: "isEmpty",
          value: function () {
            return !this.root;
          },
        },
        {
          key: "add",
          value: function (t) {
            var e,
              n = { value: t, left: null, right: null };
            if (this.isEmpty()) this.root = n;
            else
              for (e = this.root; ; )
                if (t < e.value) {
                  if (null === e.left) {
                    e.left = n;
                    break;
                  }
                  e = e.left;
                } else {
                  if (!(t > e.value)) break;
                  if (null === e.right) {
                    e.right = n;
                    break;
                  }
                  e = e.right;
                }
          },
        },
        {
          key: "get",
          value: function () {
            for (var t = [], e = this.root; e; )
              if (e.left) {
                for (var n = e.left; n.right && n.right != e; ) n = n.right;
                n.right == e
                  ? ((n.right = null), t.push(e.value), (e = e.right))
                  : ((n.right = e), (e = e.left));
              } else t.push(e.value), (e = e.right);
            return t;
          },
        },
        {
          key: "contains",
          value: function (t) {
            for (var e = !1, n = this.root; n; ) {
              if (n.value === t) {
                e = !0;
                break;
              }
              t > n.value ? (n = n.right) : t < n.value && (n = n.left);
            }
            return e;
          },
        },
        {
          key: "min",
          value: function () {
            for (
              var t,
                e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : this.root;
              e;

            )
              e.left ? (e = e.left) : ((t = e.value), (e = null));
            return t;
          },
        },
        {
          key: "max",
          value: function () {
            for (
              var t,
                e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : this.root;
              e;

            )
              e.right ? (e = e.right) : ((t = e.value), (e = null));
            return t;
          },
        },
        {
          key: "remove",
          value: function (t) {
            for (
              var e =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.root,
                n = null,
                i = "left";
              e;

            )
              if (t < e.value) (n = e), (e = e.left), (i = "left");
              else if (t > e.value) (n = e), (e = e.right), (i = "right");
              else {
                if (e.left || e.right)
                  if (e.left)
                    if (e.right) {
                      var r = this.min(e.right);
                      this.remove(r, e.right), (e.value = r);
                    } else n ? (n[i] = e.left) : (this.root = e.left);
                  else n ? (n[i] = e.right) : (this.root = e.right);
                else n ? (n[i] = null) : (this.root = null);
                e = null;
              }
          },
        },
      ]),
      e
    );
  })(),
  ci = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, [
        {
          key: "has",
          value: function (e) {
            return t.langSet.has(e);
          },
        },
        {
          key: "forEach",
          value: function (e) {
            t.langSet.forEach(e);
          },
        },
        {
          key: "size",
          get: function () {
            return t.langSet.size;
          },
        },
      ]),
      t
    );
  })();
T(
  ci,
  "langSet",
  new Set([
    "BG",
    "CA",
    "CS",
    "DA",
    "DE",
    "EL",
    "EN",
    "ES",
    "ET",
    "FI",
    "FR",
    "HR",
    "HU",
    "IT",
    "JA",
    "LT",
    "LV",
    "MT",
    "NL",
    "NO",
    "PL",
    "PT",
    "RO",
    "RU",
    "SK",
    "SL",
    "SV",
    "TR",
    "ZH",
  ])
);
var ui,
  di = _(function t() {
    S(this, t);
  });
T(di, "cmpId", "cmpId"),
  T(di, "cmpVersion", "cmpVersion"),
  T(di, "consentLanguage", "consentLanguage"),
  T(di, "consentScreen", "consentScreen"),
  T(di, "created", "created"),
  T(di, "supportOOB", "supportOOB"),
  T(di, "isServiceSpecific", "isServiceSpecific"),
  T(di, "lastUpdated", "lastUpdated"),
  T(di, "numCustomPurposes", "numCustomPurposes"),
  T(di, "policyVersion", "policyVersion"),
  T(di, "publisherCountryCode", "publisherCountryCode"),
  T(di, "publisherCustomConsents", "publisherCustomConsents"),
  T(
    di,
    "publisherCustomLegitimateInterests",
    "publisherCustomLegitimateInterests"
  ),
  T(di, "publisherLegitimateInterests", "publisherLegitimateInterests"),
  T(di, "publisherConsents", "publisherConsents"),
  T(di, "publisherRestrictions", "publisherRestrictions"),
  T(di, "purposeConsents", "purposeConsents"),
  T(di, "purposeLegitimateInterests", "purposeLegitimateInterests"),
  T(di, "purposeOneTreatment", "purposeOneTreatment"),
  T(di, "specialFeatureOptins", "specialFeatureOptins"),
  T(di, "useNonStandardStacks", "useNonStandardStacks"),
  T(di, "vendorConsents", "vendorConsents"),
  T(di, "vendorLegitimateInterests", "vendorLegitimateInterests"),
  T(di, "vendorListVersion", "vendorListVersion"),
  T(di, "vendorsAllowed", "vendorsAllowed"),
  T(di, "vendorsDisclosed", "vendorsDisclosed"),
  T(di, "version", "version"),
  (function (t) {
    (t[(t.NOT_ALLOWED = 0)] = "NOT_ALLOWED"),
      (t[(t.REQUIRE_CONSENT = 1)] = "REQUIRE_CONSENT"),
      (t[(t.REQUIRE_LI = 2)] = "REQUIRE_LI");
  })(ui || (ui = {}));
var hi = (function () {
  A(e, ai);
  var t = R(e);
  function e(n, i) {
    var r;
    return (
      S(this, e),
      T(L((r = t.call(this))), "purposeId_", void 0),
      T(L(r), "restrictionType", void 0),
      void 0 !== n && (r.purposeId = n),
      void 0 !== i && (r.restrictionType = i),
      r
    );
  }
  return (
    _(
      e,
      [
        {
          key: "hash",
          get: function () {
            if (!this.isValid())
              throw new Error("cannot hash invalid PurposeRestriction");
            return ""
              .concat(this.purposeId)
              .concat(e.hashSeparator)
              .concat(this.restrictionType);
          },
        },
        {
          key: "purposeId",
          get: function () {
            return this.purposeId_;
          },
          set: function (t) {
            this.purposeId_ = t;
          },
        },
        {
          key: "isValid",
          value: function () {
            return (
              Number.isInteger(this.purposeId) &&
              this.purposeId > 0 &&
              (this.restrictionType === ui.NOT_ALLOWED ||
                this.restrictionType === ui.REQUIRE_CONSENT ||
                this.restrictionType === ui.REQUIRE_LI)
            );
          },
        },
        {
          key: "isSameAs",
          value: function (t) {
            return (
              this.purposeId === t.purposeId &&
              this.restrictionType === t.restrictionType
            );
          },
        },
      ],
      [
        {
          key: "unHash",
          value: function (t) {
            var n = t.split(this.hashSeparator),
              i = new e();
            if (2 !== n.length) throw new oi("hash", t);
            return (
              (i.purposeId = parseInt(n[0], 10)),
              (i.restrictionType = parseInt(n[1], 10)),
              i
            );
          },
        },
      ]
    ),
    e
  );
})();
T(hi, "hashSeparator", "-");
var fi,
  mi,
  bi,
  gi = (function () {
    A(e, ai);
    var t = R(e);
    function e() {
      var n;
      S(this, e);
      for (var i = arguments.length, r = new Array(i), o = 0; o < i; o++)
        r[o] = arguments[o];
      return (
        T(L((n = t.call.apply(t, [this].concat(r)))), "bitLength", 0),
        T(L(n), "map", new Map()),
        T(L(n), "gvl_", void 0),
        n
      );
    }
    return (
      _(e, [
        {
          key: "has",
          value: function (t) {
            return this.map.has(t);
          },
        },
        {
          key: "isOkToHave",
          value: function (t, e, n) {
            var i,
              r = !0;
            if (null !== (i = this.gvl) && void 0 !== i && i.vendors) {
              var o = this.gvl.vendors[n];
              if (o)
                if (t === ui.NOT_ALLOWED)
                  r = o.legIntPurposes.includes(e) || o.purposes.includes(e);
                else if (o.flexiblePurposes.length)
                  switch (t) {
                    case ui.REQUIRE_CONSENT:
                      r =
                        o.flexiblePurposes.includes(e) &&
                        o.legIntPurposes.includes(e);
                      break;
                    case ui.REQUIRE_LI:
                      r =
                        o.flexiblePurposes.includes(e) &&
                        o.purposes.includes(e);
                  }
                else r = !1;
              else r = !1;
            }
            return r;
          },
        },
        {
          key: "add",
          value: function (t, e) {
            if (this.isOkToHave(e.restrictionType, e.purposeId, t)) {
              var n = e.hash;
              this.has(n) || (this.map.set(n, new li()), (this.bitLength = 0)),
                this.map.get(n).add(t);
            }
          },
        },
        {
          key: "restrictPurposeToLegalBasis",
          value: function (t) {
            for (
              var e = this.gvl.vendorIds,
                n = t.hash,
                i = (function () {
                  var t,
                    n,
                    i = V(e);
                  try {
                    for (i.s(); !(n = i.n()).done; ) t = n.value;
                  } catch (r) {
                    i.e(r);
                  } finally {
                    i.f();
                  }
                  return t;
                })(),
                r = 1;
              r <= i;
              r++
            )
              this.has(n) || (this.map.set(n, new li()), (this.bitLength = 0)),
                this.map.get(n).add(r);
          },
        },
        {
          key: "getVendors",
          value: function (t) {
            var e = [];
            if (t) {
              var n = t.hash;
              this.has(n) && (e = this.map.get(n).get());
            } else {
              var i = new Set();
              this.map.forEach(function (t) {
                t.get().forEach(function (t) {
                  i.add(t);
                });
              }),
                (e = Array.from(i));
            }
            return e;
          },
        },
        {
          key: "getRestrictionType",
          value: function (t, e) {
            var n;
            return (
              this.getRestrictions(t).forEach(function (t) {
                t.purposeId === e &&
                  (void 0 === n || n > t.restrictionType) &&
                  (n = t.restrictionType);
              }),
              n
            );
          },
        },
        {
          key: "vendorHasRestriction",
          value: function (t, e) {
            for (
              var n = !1, i = this.getRestrictions(t), r = 0;
              r < i.length && !n;
              r++
            )
              n = e.isSameAs(i[r]);
            return n;
          },
        },
        {
          key: "getMaxVendorId",
          value: function () {
            var t = 0;
            return (
              this.map.forEach(function (e) {
                t = Math.max(e.max(), t);
              }),
              t
            );
          },
        },
        {
          key: "getRestrictions",
          value: function (t) {
            var e = [];
            return (
              this.map.forEach(function (n, i) {
                t
                  ? n.contains(t) && e.push(hi.unHash(i))
                  : e.push(hi.unHash(i));
              }),
              e
            );
          },
        },
        {
          key: "getPurposes",
          value: function () {
            var t = new Set();
            return (
              this.map.forEach(function (e, n) {
                t.add(hi.unHash(n).purposeId);
              }),
              Array.from(t)
            );
          },
        },
        {
          key: "remove",
          value: function (t, e) {
            var n = e.hash,
              i = this.map.get(n);
            i &&
              (i.remove(t),
              i.isEmpty() && (this.map.delete(n), (this.bitLength = 0)));
          },
        },
        {
          key: "gvl",
          get: function () {
            return this.gvl_;
          },
          set: function (t) {
            var e = this;
            this.gvl_ ||
              ((this.gvl_ = t),
              this.map.forEach(function (t, n) {
                var i = hi.unHash(n);
                t.get().forEach(function (n) {
                  e.isOkToHave(i.restrictionType, i.purposeId, n) ||
                    t.remove(n);
                });
              }));
          },
        },
        {
          key: "isEmpty",
          value: function () {
            return 0 === this.map.size;
          },
        },
        {
          key: "numRestrictions",
          get: function () {
            return this.map.size;
          },
        },
      ]),
      e
    );
  })();
!(function (t) {
  (t.COOKIE = "cookie"), (t.WEB = "web"), (t.APP = "app");
})(fi || (fi = {})),
  (function (t) {
    (t.CORE = "core"),
      (t.VENDORS_DISCLOSED = "vendorsDisclosed"),
      (t.VENDORS_ALLOWED = "vendorsAllowed"),
      (t.PUBLISHER_TC = "publisherTC");
  })(mi || (mi = {}));
var wi,
  pi = _(function t() {
    S(this, t);
  });
T(pi, "ID_TO_KEY", [
  mi.CORE,
  mi.VENDORS_DISCLOSED,
  mi.VENDORS_ALLOWED,
  mi.PUBLISHER_TC,
]),
  T(
    pi,
    "KEY_TO_ID",
    (T((bi = {}), mi.CORE, 0),
    T(bi, mi.VENDORS_DISCLOSED, 1),
    T(bi, mi.VENDORS_ALLOWED, 2),
    T(bi, mi.PUBLISHER_TC, 3),
    bi)
  ),
  (wi = Symbol.iterator);
var vi,
  yi,
  xi,
  ki,
  qi,
  Si,
  Ci,
  _i,
  Ti,
  Ai,
  Ei,
  zi,
  Oi,
  Ii,
  Di,
  Li,
  Ni,
  Ri,
  Fi = (function () {
    A(e, ai);
    var t = R(e);
    function e() {
      var n;
      S(this, e);
      for (var i = arguments.length, r = new Array(i), o = 0; o < i; o++)
        r[o] = arguments[o];
      return (
        T(L((n = t.call.apply(t, [this].concat(r)))), "bitLength", 0),
        T(L(n), "maxId_", 0),
        T(L(n), "set_", new Set()),
        n
      );
    }
    return (
      _(e, [
        {
          key: wi,
          value: y().mark(function t() {
            var e;
            return y().wrap(
              function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      e = 1;
                    case 1:
                      if (!(e <= this.maxId)) {
                        t.next = 7;
                        break;
                      }
                      return (t.next = 4), [e, this.has(e)];
                    case 4:
                      e++, (t.next = 1);
                      break;
                    case 7:
                    case "end":
                      return t.stop();
                  }
              },
              t,
              this
            );
          }),
        },
        {
          key: "values",
          value: function () {
            return this.set_.values();
          },
        },
        {
          key: "maxId",
          get: function () {
            return this.maxId_;
          },
        },
        {
          key: "has",
          value: function (t) {
            return this.set_.has(t);
          },
        },
        {
          key: "unset",
          value: function (t) {
            var e = this;
            Array.isArray(t)
              ? t.forEach(function (t) {
                  return e.unset(t);
                })
              : "object" === x(t)
              ? this.unset(
                  Object.keys(t).map(function (t) {
                    return Number(t);
                  })
                )
              : (this.set_.delete(Number(t)),
                (this.bitLength = 0),
                t === this.maxId &&
                  ((this.maxId_ = 0),
                  this.set_.forEach(function (t) {
                    e.maxId_ = Math.max(e.maxId, t);
                  })));
          },
        },
        {
          key: "isIntMap",
          value: function (t) {
            var e = this;
            return (
              "object" === x(t) &&
              Object.keys(t).every(function (n) {
                var i = Number.isInteger(parseInt(n, 10));
                return (
                  (i = i && e.isValidNumber(t[n].id)) && void 0 !== t[n].name
                );
              })
            );
          },
        },
        {
          key: "isValidNumber",
          value: function (t) {
            return parseInt(t, 10) > 0;
          },
        },
        {
          key: "isSet",
          value: function (t) {
            var e = !1;
            return (
              t instanceof Set && (e = Array.from(t).every(this.isValidNumber)),
              e
            );
          },
        },
        {
          key: "set",
          value: function (t) {
            var e = this;
            if (Array.isArray(t))
              t.forEach(function (t) {
                return e.set(t);
              });
            else if (this.isSet(t)) this.set(Array.from(t));
            else if (this.isIntMap(t))
              this.set(
                Object.keys(t).map(function (t) {
                  return Number(t);
                })
              );
            else {
              if (!this.isValidNumber(t))
                throw new oi(
                  "set()",
                  t,
                  "must be positive integer array, positive integer, Set<number>, or IntMap"
                );
              this.set_.add(t),
                (this.maxId_ = Math.max(this.maxId, t)),
                (this.bitLength = 0);
            }
          },
        },
        {
          key: "empty",
          value: function () {
            this.set_ = new Set();
          },
        },
        {
          key: "forEach",
          value: function (t) {
            for (var e = 1; e <= this.maxId; e++) t(this.has(e), e);
          },
        },
        {
          key: "size",
          get: function () {
            return this.set_.size;
          },
        },
        {
          key: "setAll",
          value: function (t) {
            this.set(t);
          },
        },
      ]),
      e
    );
  })();
(vi = di.cmpId),
  (yi = di.cmpVersion),
  (xi = di.consentLanguage),
  (ki = di.consentScreen),
  (qi = di.created),
  (Si = di.isServiceSpecific),
  (Ci = di.lastUpdated),
  (_i = di.policyVersion),
  (Ti = di.publisherCountryCode),
  (Ai = di.publisherLegitimateInterests),
  (Ei = di.publisherConsents),
  (zi = di.purposeConsents),
  (Oi = di.purposeLegitimateInterests),
  (Ii = di.purposeOneTreatment),
  (Di = di.specialFeatureOptins),
  (Li = di.useNonStandardStacks),
  (Ni = di.vendorListVersion),
  (Ri = di.version);
var Pi = _(function t() {
  S(this, t);
});
T(Pi, vi, 12),
  T(Pi, yi, 12),
  T(Pi, xi, 12),
  T(Pi, ki, 6),
  T(Pi, qi, 36),
  T(Pi, Si, 1),
  T(Pi, Ci, 36),
  T(Pi, _i, 6),
  T(Pi, Ti, 12),
  T(Pi, Ai, 24),
  T(Pi, Ei, 24),
  T(Pi, zi, 24),
  T(Pi, Oi, 24),
  T(Pi, Ii, 1),
  T(Pi, Di, 12),
  T(Pi, Li, 1),
  T(Pi, Ni, 12),
  T(Pi, Ri, 6),
  T(Pi, "anyBoolean", 1),
  T(Pi, "encodingType", 1),
  T(Pi, "maxId", 16),
  T(Pi, "numCustomPurposes", 6),
  T(Pi, "numEntries", 12),
  T(Pi, "numRestrictions", 12),
  T(Pi, "purposeId", 6),
  T(Pi, "restrictionType", 2),
  T(Pi, "segmentType", 3),
  T(Pi, "singleOrRange", 1),
  T(Pi, "vendorId", 16);
var Ui,
  ji = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t) {
            return String(Number(t));
          },
        },
        {
          key: "decode",
          value: function (t) {
            return "1" === t;
          },
        },
      ]),
      t
    );
  })(),
  Mi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            var n;
            if (
              ("string" == typeof t && (t = parseInt(t, 10)),
              (n = t.toString(2)).length > e || t < 0)
            )
              throw new ii(
                "".concat(t, " too large to encode into ").concat(e)
              );
            return n.length < e && (n = "0".repeat(e - n.length) + n), n;
          },
        },
        {
          key: "decode",
          value: function (t, e) {
            if (e !== t.length) throw new ni("invalid bit length");
            return parseInt(t, 2);
          },
        },
      ]),
      t
    );
  })(),
  Vi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            return Mi.encode(Math.round(t.getTime() / 100), e);
          },
        },
        {
          key: "decode",
          value: function (t, e) {
            if (e !== t.length) throw new ni("invalid bit length");
            var n = new Date();
            return n.setTime(100 * Mi.decode(t, e)), n;
          },
        },
      ]),
      t
    );
  })(),
  Bi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            for (var n = "", i = 1; i <= e; i++) n += ji.encode(t.has(i));
            return n;
          },
        },
        {
          key: "decode",
          value: function (t, e) {
            if (t.length !== e)
              throw new ni("bitfield encoding length mismatch");
            for (var n = new Fi(), i = 1; i <= e; i++)
              ji.decode(t[i - 1]) && n.set(i);
            return (n.bitLength = t.length), n;
          },
        },
      ]),
      t
    );
  })(),
  Hi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            var n = (t = t.toUpperCase()).charCodeAt(0) - 65,
              i = t.charCodeAt(1) - 65;
            if (n < 0 || n > 25 || i < 0 || i > 25)
              throw new ii("invalid language code: ".concat(t));
            if (e % 2 == 1)
              throw new ii("numBits must be even, ".concat(e, " is not valid"));
            return Mi.encode(n, (e /= 2)) + Mi.encode(i, e);
          },
        },
        {
          key: "decode",
          value: function (t, e) {
            if (e !== t.length || t.length % 2)
              throw new ni("invalid bit length for language");
            var n = t.length / 2,
              i = Mi.decode(t.slice(0, n), n) + 65,
              r = Mi.decode(t.slice(n), n) + 65;
            return String.fromCharCode(i) + String.fromCharCode(r);
          },
        },
      ]),
      t
    );
  })(),
  Gi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t) {
            var e = Mi.encode(t.numRestrictions, Pi.numRestrictions);
            return (
              t.isEmpty() ||
                t.getRestrictions().forEach(function (n) {
                  (e += Mi.encode(n.purposeId, Pi.purposeId)),
                    (e += Mi.encode(n.restrictionType, Pi.restrictionType));
                  for (
                    var i = t.getVendors(n),
                      r = i.length,
                      o = 0,
                      s = 0,
                      a = "",
                      l = function (e) {
                        var n = i[e];
                        0 === s && (o++, (s = n));
                        var l = i[r - 1],
                          c = t.gvl.vendorIds;
                        if (
                          e === r - 1 ||
                          i[e + 1] >
                            (function (t) {
                              for (; ++t <= l && !c.has(t); );
                              return t;
                            })(n)
                        ) {
                          var u = !(n === s);
                          (a += ji.encode(u)),
                            (a += Mi.encode(s, Pi.vendorId)),
                            u && (a += Mi.encode(n, Pi.vendorId)),
                            (s = 0);
                        }
                      },
                      c = 0;
                    c < r;
                    c++
                  )
                    l(c);
                  (e += Mi.encode(o, Pi.numEntries)), (e += a);
                }),
              e
            );
          },
        },
        {
          key: "decode",
          value: function (t) {
            var e = 0,
              n = new gi(),
              i = Mi.decode(
                t.substr(e, Pi.numRestrictions),
                Pi.numRestrictions
              );
            e += Pi.numRestrictions;
            for (var r = 0; r < i; r++) {
              var o = Mi.decode(t.substr(e, Pi.purposeId), Pi.purposeId),
                s = Mi.decode(
                  t.substr((e += Pi.purposeId), Pi.restrictionType),
                  Pi.restrictionType
                );
              e += Pi.restrictionType;
              var a = new hi(o, s),
                l = Mi.decode(t.substr(e, Pi.numEntries), Pi.numEntries);
              e += Pi.numEntries;
              for (var c = 0; c < l; c++) {
                var u = ji.decode(t.substr(e, Pi.anyBoolean)),
                  d = Mi.decode(
                    t.substr((e += Pi.anyBoolean), Pi.vendorId),
                    Pi.vendorId
                  );
                if (((e += Pi.vendorId), u)) {
                  var h = Mi.decode(t.substr(e, Pi.vendorId), Pi.vendorId);
                  if (((e += Pi.vendorId), h < d))
                    throw new ni(
                      "Invalid RangeEntry: endVendorId "
                        .concat(h, " is less than ")
                        .concat(d)
                    );
                  for (var f = d; f <= h; f++) n.add(f, a);
                } else n.add(d, a);
              }
            }
            return (n.bitLength = e), n;
          },
        },
      ]),
      t
    );
  })();
!(function (t) {
  (t[(t.FIELD = 0)] = "FIELD"), (t[(t.RANGE = 1)] = "RANGE");
})(Ui || (Ui = {}));
var Ji = (function () {
  function t() {
    S(this, t);
  }
  return (
    _(t, null, [
      {
        key: "encode",
        value: function (t) {
          var e,
            n = [],
            i = [],
            r = Mi.encode(t.maxId, Pi.maxId),
            o = "",
            s = Pi.maxId + Pi.encodingType,
            a = s + t.maxId,
            l = 2 * Pi.vendorId + Pi.singleOrRange + Pi.numEntries,
            c = s + Pi.numEntries;
          return (
            t.forEach(function (r, s) {
              (o += ji.encode(r)),
                (e = t.maxId > l && c < a) &&
                  r &&
                  (t.has(s + 1)
                    ? 0 === i.length &&
                      (i.push(s), (c += Pi.singleOrRange), (c += Pi.vendorId))
                    : (i.push(s), (c += Pi.vendorId), n.push(i), (i = [])));
            }),
            e
              ? ((r += String(Ui.RANGE)), (r += this.buildRangeEncoding(n)))
              : ((r += String(Ui.FIELD)), (r += o)),
            r
          );
        },
      },
      {
        key: "decode",
        value: function (t, e) {
          var n,
            i = 0,
            r = Mi.decode(t.substr(i, Pi.maxId), Pi.maxId),
            o = Mi.decode(t.charAt((i += Pi.maxId)), Pi.encodingType);
          if (((i += Pi.encodingType), o === Ui.RANGE)) {
            if (((n = new Fi()), 1 === e)) {
              if ("1" === t.substr(i, 1))
                throw new ni("Unable to decode default consent=1");
              i++;
            }
            var s = Mi.decode(t.substr(i, Pi.numEntries), Pi.numEntries);
            i += Pi.numEntries;
            for (var a = 0; a < s; a++) {
              var l = ji.decode(t.charAt(i)),
                c = Mi.decode(
                  t.substr((i += Pi.singleOrRange), Pi.vendorId),
                  Pi.vendorId
                );
              if (((i += Pi.vendorId), l)) {
                var u = Mi.decode(t.substr(i, Pi.vendorId), Pi.vendorId);
                i += Pi.vendorId;
                for (var d = c; d <= u; d++) n.set(d);
              } else n.set(c);
            }
          } else {
            var h = t.substr(i, r);
            (i += r), (n = Bi.decode(h, r));
          }
          return (n.bitLength = i), n;
        },
      },
      {
        key: "buildRangeEncoding",
        value: function (t) {
          var e = Mi.encode(t.length, Pi.numEntries);
          return (
            t.forEach(function (t) {
              var n = 1 === t.length;
              (e += ji.encode(!n)),
                (e += Mi.encode(t[0], Pi.vendorId)),
                n || (e += Mi.encode(t[1], Pi.vendorId));
            }),
            e
          );
        },
      },
    ]),
    t
  );
})();
function Wi() {
  var t;
  return (
    T((t = {}), di.version, Mi),
    T(t, di.created, Vi),
    T(t, di.lastUpdated, Vi),
    T(t, di.cmpId, Mi),
    T(t, di.cmpVersion, Mi),
    T(t, di.consentScreen, Mi),
    T(t, di.consentLanguage, Hi),
    T(t, di.vendorListVersion, Mi),
    T(t, di.policyVersion, Mi),
    T(t, di.isServiceSpecific, ji),
    T(t, di.useNonStandardStacks, ji),
    T(t, di.specialFeatureOptins, Bi),
    T(t, di.purposeConsents, Bi),
    T(t, di.purposeLegitimateInterests, Bi),
    T(t, di.purposeOneTreatment, ji),
    T(t, di.publisherCountryCode, Hi),
    T(t, di.vendorConsents, Ji),
    T(t, di.vendorLegitimateInterests, Ji),
    T(t, di.publisherRestrictions, Gi),
    T(t, "segmentType", Mi),
    T(t, di.vendorsDisclosed, Ji),
    T(t, di.vendorsAllowed, Ji),
    T(t, di.publisherConsents, Bi),
    T(t, di.publisherLegitimateInterests, Bi),
    T(t, di.numCustomPurposes, Mi),
    T(t, di.publisherCustomConsents, Bi),
    T(t, di.publisherCustomLegitimateInterests, Bi),
    t
  );
}
var $i = _(function t() {
    var e;
    S(this, t),
      T(
        this,
        "1",
        T({}, mi.CORE, [
          di.version,
          di.created,
          di.lastUpdated,
          di.cmpId,
          di.cmpVersion,
          di.consentScreen,
          di.consentLanguage,
          di.vendorListVersion,
          di.purposeConsents,
          di.vendorConsents,
        ])
      ),
      T(
        this,
        "2",
        (T((e = {}), mi.CORE, [
          di.version,
          di.created,
          di.lastUpdated,
          di.cmpId,
          di.cmpVersion,
          di.consentScreen,
          di.consentLanguage,
          di.vendorListVersion,
          di.policyVersion,
          di.isServiceSpecific,
          di.useNonStandardStacks,
          di.specialFeatureOptins,
          di.purposeConsents,
          di.purposeLegitimateInterests,
          di.purposeOneTreatment,
          di.publisherCountryCode,
          di.vendorConsents,
          di.vendorLegitimateInterests,
          di.publisherRestrictions,
        ]),
        T(e, mi.PUBLISHER_TC, [
          di.publisherConsents,
          di.publisherLegitimateInterests,
          di.numCustomPurposes,
          di.publisherCustomConsents,
          di.publisherCustomLegitimateInterests,
        ]),
        T(e, mi.VENDORS_ALLOWED, [di.vendorsAllowed]),
        T(e, mi.VENDORS_DISCLOSED, [di.vendorsDisclosed]),
        e)
      );
  }),
  Yi = _(function t(e, n) {
    if (
      (S(this, t),
      T(this, "1", [mi.CORE]),
      T(this, "2", [mi.CORE]),
      2 === e.version)
    )
      if (e.isServiceSpecific) this[2].push(mi.PUBLISHER_TC);
      else {
        var i = !(!n || !n.isForVendors);
        (i && !0 !== e[di.supportOOB]) || this[2].push(mi.VENDORS_DISCLOSED),
          i &&
            (e[di.supportOOB] &&
              e[di.vendorsAllowed].size > 0 &&
              this[2].push(mi.VENDORS_ALLOWED),
            this[2].push(mi.PUBLISHER_TC));
      }
  }),
  Ki = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            var n,
              i = this;
            try {
              n = this.fieldSequence[String(t.version)][e];
            } catch (_) {
              throw new ii(
                "Unable to encode version: "
                  .concat(t.version, ", segment: ")
                  .concat(e)
              );
            }
            var r = "";
            e !== mi.CORE && (r = Mi.encode(pi.KEY_TO_ID[e], Pi.segmentType));
            var o = Wi();
            return (
              n.forEach(function (n) {
                var s = t[n],
                  a = o[n],
                  l = Pi[n];
                void 0 === l &&
                  i.isPublisherCustom(n) &&
                  (l = Number(t[di.numCustomPurposes]));
                try {
                  r += a.encode(s, l);
                } catch (_) {
                  throw new ii(
                    "Error encoding "
                      .concat(e, "->")
                      .concat(n, ": ")
                      .concat(_.message)
                  );
                }
              }),
              si.encode(r)
            );
          },
        },
        {
          key: "decode",
          value: function (t, e, n) {
            var i = this,
              r = si.decode(t),
              o = 0;
            n === mi.CORE &&
              (e.version = Mi.decode(
                r.substr(o, Pi[di.version]),
                Pi[di.version]
              )),
              n !== mi.CORE && (o += Pi.segmentType);
            var s = this.fieldSequence[String(e.version)][n],
              a = Wi();
            return (
              s.forEach(function (t) {
                var n = a[t],
                  s = Pi[t];
                if (
                  (void 0 === s &&
                    i.isPublisherCustom(t) &&
                    (s = Number(e[di.numCustomPurposes])),
                  0 !== s)
                ) {
                  var l = r.substr(o, s);
                  if (
                    ((e[t] = n.decode(l, n === Ji ? e.version : s)),
                    Number.isInteger(s))
                  )
                    o += s;
                  else {
                    if (!Number.isInteger(e[t].bitLength)) throw new ni(t);
                    o += e[t].bitLength;
                  }
                }
              }),
              e
            );
          },
        },
        {
          key: "isPublisherCustom",
          value: function (t) {
            return 0 === t.indexOf("publisherCustom");
          },
        },
      ]),
      t
    );
  })();
T(Ki, "fieldSequence", new $i());
var Qi = (function () {
  function t() {
    S(this, t);
  }
  return (
    _(t, null, [
      {
        key: "process",
        value: function (t, e) {
          var n = t.gvl;
          if (!n) throw new ii("Unable to encode TCModel without a GVL");
          if (!n.isReady)
            throw new ii(
              "Unable to encode TCModel tcModel.gvl.readyPromise is not resolved"
            );
          ((t = t.clone()).consentLanguage = n.language.toUpperCase()),
            (t.version =
              (null == e ? void 0 : e.version) > 0 &&
              (null == e ? void 0 : e.version) <= this.processor.length
                ? e.version
                : this.processor.length);
          var i = t.version - 1;
          if (!this.processor[i])
            throw new ii("Invalid version: ".concat(t.version));
          return this.processor[i](t, n);
        },
      },
    ]),
    t
  );
})();
T(Qi, "processor", [
  function (t) {
    return t;
  },
  function (t, e) {
    (t.publisherRestrictions.gvl = e), t.purposeLegitimateInterests.unset(1);
    var n = new Map();
    return (
      n.set("legIntPurposes", t.vendorLegitimateInterests),
      n.set("purposes", t.vendorConsents),
      n.forEach(function (n, i) {
        n.forEach(function (r, o) {
          if (r) {
            var s = e.vendors[o];
            if (!s || s.deletedDate) n.unset(o);
            else if (0 === s[i].length)
              if (
                "legIntPurposes" === i &&
                0 === s.purposes.length &&
                0 === s.legIntPurposes.length &&
                s.specialPurposes.length > 0
              );
              else if (t.isServiceSpecific)
                if (0 === s.flexiblePurposes.length) n.unset(o);
                else {
                  for (
                    var a = t.publisherRestrictions.getRestrictions(o),
                      l = !1,
                      c = 0,
                      u = a.length;
                    c < u && !l;
                    c++
                  )
                    l =
                      (a[c].restrictionType === ui.REQUIRE_CONSENT &&
                        "purposes" === i) ||
                      (a[c].restrictionType === ui.REQUIRE_LI &&
                        "legIntPurposes" === i);
                  l || n.unset(o);
                }
              else n.unset(o);
          }
        });
      }),
      t.vendorsDisclosed.set(e.vendors),
      t
    );
  },
]);
var Xi = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "absCall",
          value: function (t, e, n, i) {
            return new Promise(function (r, o) {
              var s = new XMLHttpRequest();
              (s.withCredentials = n),
                s.addEventListener("load", function () {
                  if (s.readyState == XMLHttpRequest.DONE)
                    if (s.status >= 200 && s.status < 300) {
                      var t = s.response;
                      if ("string" == typeof t)
                        try {
                          t = JSON.parse(t);
                        } catch (e) {}
                      r(t);
                    } else
                      o(
                        new Error(
                          "HTTP Status: "
                            .concat(s.status, " response type: ")
                            .concat(s.responseType)
                        )
                      );
                }),
                s.addEventListener("error", function () {
                  o(new Error("error"));
                }),
                s.addEventListener("abort", function () {
                  o(new Error("aborted"));
                }),
                s.open(null === e ? "GET" : "POST", t, !0),
                (s.responseType = "json"),
                (s.timeout = i),
                (s.ontimeout = function () {
                  o(new Error("Timeout " + i + "ms " + t));
                }),
                s.send(e);
            });
          },
        },
        {
          key: "post",
          value: function (t, e) {
            var n =
                arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
              i =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 0;
            return this.absCall(t, JSON.stringify(e), n, i);
          },
        },
        {
          key: "fetch",
          value: function (t) {
            var e =
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              n =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 0;
            return this.absCall(t, null, e, n);
          },
        },
      ]),
      t
    );
  })(),
  Zi = (function () {
    A(i, ai);
    var t,
      e,
      n = R(i);
    function i(t) {
      var e;
      S(this, i),
        T(L((e = n.call(this))), "readyPromise", void 0),
        T(L(e), "gvlSpecificationVersion", void 0),
        T(L(e), "vendorListVersion", void 0),
        T(L(e), "tcfPolicyVersion", void 0),
        T(L(e), "lastUpdated", void 0),
        T(L(e), "purposes", void 0),
        T(L(e), "specialPurposes", void 0),
        T(L(e), "features", void 0),
        T(L(e), "specialFeatures", void 0),
        T(L(e), "isReady_", !1),
        T(L(e), "vendors_", void 0),
        T(L(e), "vendorIds", void 0),
        T(L(e), "fullVendorList", void 0),
        T(L(e), "byPurposeVendorMap", void 0),
        T(L(e), "bySpecialPurposeVendorMap", void 0),
        T(L(e), "byFeatureVendorMap", void 0),
        T(L(e), "bySpecialFeatureVendorMap", void 0),
        T(L(e), "stacks", void 0),
        T(L(e), "lang_", void 0),
        T(L(e), "isLatest", !1);
      var r = i.baseUrl;
      if (((e.lang_ = i.DEFAULT_LANGUAGE), e.isVendorList(t)))
        e.populate(t), (e.readyPromise = Promise.resolve());
      else {
        if (!r)
          throw new ri("must specify GVL.baseUrl before loading GVL json");
        if (t > 0) {
          var o = t;
          i.CACHE.has(o)
            ? (e.populate(i.CACHE.get(o)), (e.readyPromise = Promise.resolve()))
            : ((r += i.versionedFilename.replace("[VERSION]", String(o))),
              (e.readyPromise = e.fetchJson(r)));
        } else
          i.CACHE.has(i.LATEST_CACHE_KEY)
            ? (e.populate(i.CACHE.get(i.LATEST_CACHE_KEY)),
              (e.readyPromise = Promise.resolve()))
            : ((e.isLatest = !0),
              (e.readyPromise = e.fetchJson(r + i.latestFilename)));
      }
      return e;
    }
    return (
      _(
        i,
        [
          {
            key: "cacheLanguage",
            value: function () {
              i.LANGUAGE_CACHE.has(this.lang_) ||
                i.LANGUAGE_CACHE.set(this.lang_, {
                  purposes: this.purposes,
                  specialPurposes: this.specialPurposes,
                  features: this.features,
                  specialFeatures: this.specialFeatures,
                  stacks: this.stacks,
                });
            },
          },
          {
            key: "fetchJson",
            value:
              ((e = q(
                y().mark(function t(e) {
                  return y().wrap(
                    function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            return (
                              (t.prev = 0),
                              (t.t0 = this),
                              (t.next = 4),
                              Xi.fetch(e)
                            );
                          case 4:
                            (t.t1 = t.sent),
                              t.t0.populate.call(t.t0, t.t1),
                              (t.next = 11);
                            break;
                          case 8:
                            throw (
                              ((t.prev = 8),
                              (t.t2 = t.catch(0)),
                              new ri(t.t2.message))
                            );
                          case 11:
                          case "end":
                            return t.stop();
                        }
                    },
                    t,
                    this,
                    [[0, 8]]
                  );
                })
              )),
              function (t) {
                return e.apply(this, arguments);
              }),
          },
          {
            key: "getJson",
            value: function () {
              return JSON.parse(
                JSON.stringify({
                  gvlSpecificationVersion: this.gvlSpecificationVersion,
                  vendorListVersion: this.vendorListVersion,
                  tcfPolicyVersion: this.tcfPolicyVersion,
                  lastUpdated: this.lastUpdated,
                  purposes: this.purposes,
                  specialPurposes: this.specialPurposes,
                  features: this.features,
                  specialFeatures: this.specialFeatures,
                  stacks: this.stacks,
                  vendors: this.fullVendorList,
                })
              );
            },
          },
          {
            key: "changeLanguage",
            value:
              ((t = q(
                y().mark(function t(e) {
                  var n, r, o, s;
                  return y().wrap(
                    function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            if (
                              ((n = e.toUpperCase()),
                              !i.consentLanguages.has(n))
                            ) {
                              t.next = 21;
                              break;
                            }
                            if (n === this.lang_) {
                              t.next = 19;
                              break;
                            }
                            if (((this.lang_ = n), !i.LANGUAGE_CACHE.has(n))) {
                              t.next = 9;
                              break;
                            }
                            for (o in (r = i.LANGUAGE_CACHE.get(n)))
                              r.hasOwnProperty(o) && (this[o] = r[o]);
                            t.next = 19;
                            break;
                          case 9:
                            return (
                              (s =
                                i.baseUrl +
                                i.languageFilename.replace("[LANG]", e)),
                              (t.prev = 10),
                              (t.next = 13),
                              this.fetchJson(s)
                            );
                          case 13:
                            this.cacheLanguage(), (t.next = 19);
                            break;
                          case 16:
                            throw (
                              ((t.prev = 16),
                              (t.t0 = t.catch(10)),
                              new ri(
                                "unable to load language: " + t.t0.message
                              ))
                            );
                          case 19:
                            t.next = 22;
                            break;
                          case 21:
                            throw new ri("unsupported language ".concat(e));
                          case 22:
                          case "end":
                            return t.stop();
                        }
                    },
                    t,
                    this,
                    [[10, 16]]
                  );
                })
              )),
              function (e) {
                return t.apply(this, arguments);
              }),
          },
          {
            key: "language",
            get: function () {
              return this.lang_;
            },
          },
          {
            key: "isVendorList",
            value: function (t) {
              return void 0 !== t && void 0 !== t.vendors;
            },
          },
          {
            key: "populate",
            value: function (t) {
              (this.purposes = t.purposes),
                (this.specialPurposes = t.specialPurposes),
                (this.features = t.features),
                (this.specialFeatures = t.specialFeatures),
                (this.stacks = t.stacks),
                this.isVendorList(t) &&
                  ((this.gvlSpecificationVersion = t.gvlSpecificationVersion),
                  (this.tcfPolicyVersion = t.tcfPolicyVersion),
                  (this.vendorListVersion = t.vendorListVersion),
                  (this.lastUpdated = t.lastUpdated),
                  "string" == typeof this.lastUpdated &&
                    (this.lastUpdated = new Date(this.lastUpdated)),
                  (this.vendors_ = t.vendors),
                  (this.fullVendorList = t.vendors),
                  this.mapVendors(),
                  (this.isReady_ = !0),
                  this.isLatest &&
                    i.CACHE.set(i.LATEST_CACHE_KEY, this.getJson()),
                  i.CACHE.has(this.vendorListVersion) ||
                    i.CACHE.set(this.vendorListVersion, this.getJson())),
                this.cacheLanguage();
            },
          },
          {
            key: "mapVendors",
            value: function (t) {
              var e = this;
              (this.byPurposeVendorMap = {}),
                (this.bySpecialPurposeVendorMap = {}),
                (this.byFeatureVendorMap = {}),
                (this.bySpecialFeatureVendorMap = {}),
                Object.keys(this.purposes).forEach(function (t) {
                  e.byPurposeVendorMap[t] = {
                    legInt: new Set(),
                    consent: new Set(),
                    flexible: new Set(),
                  };
                }),
                Object.keys(this.specialPurposes).forEach(function (t) {
                  e.bySpecialPurposeVendorMap[t] = new Set();
                }),
                Object.keys(this.features).forEach(function (t) {
                  e.byFeatureVendorMap[t] = new Set();
                }),
                Object.keys(this.specialFeatures).forEach(function (t) {
                  e.bySpecialFeatureVendorMap[t] = new Set();
                }),
                Array.isArray(t) ||
                  (t = Object.keys(this.fullVendorList).map(function (t) {
                    return +t;
                  })),
                (this.vendorIds = new Set(t)),
                (this.vendors_ = t.reduce(function (t, n) {
                  var i = e.vendors_[String(n)];
                  return (
                    i &&
                      void 0 === i.deletedDate &&
                      (i.purposes.forEach(function (t) {
                        e.byPurposeVendorMap[String(t)].consent.add(n);
                      }),
                      i.specialPurposes.forEach(function (t) {
                        e.bySpecialPurposeVendorMap[String(t)].add(n);
                      }),
                      i.legIntPurposes.forEach(function (t) {
                        e.byPurposeVendorMap[String(t)].legInt.add(n);
                      }),
                      i.flexiblePurposes &&
                        i.flexiblePurposes.forEach(function (t) {
                          e.byPurposeVendorMap[String(t)].flexible.add(n);
                        }),
                      i.features.forEach(function (t) {
                        e.byFeatureVendorMap[String(t)].add(n);
                      }),
                      i.specialFeatures.forEach(function (t) {
                        e.bySpecialFeatureVendorMap[String(t)].add(n);
                      }),
                      (t[n] = i)),
                    t
                  );
                }, {}));
            },
          },
          {
            key: "getFilteredVendors",
            value: function (t, e, n, i) {
              var r = this,
                o = t.charAt(0).toUpperCase() + t.slice(1),
                s = {};
              return (
                ("purpose" === t && n
                  ? this["by" + o + "VendorMap"][String(e)][n]
                  : this["by" + (i ? "Special" : "") + o + "VendorMap"][
                      String(e)
                    ]
                ).forEach(function (t) {
                  s[String(t)] = r.vendors[String(t)];
                }),
                s
              );
            },
          },
          {
            key: "getVendorsWithConsentPurpose",
            value: function (t) {
              return this.getFilteredVendors("purpose", t, "consent");
            },
          },
          {
            key: "getVendorsWithLegIntPurpose",
            value: function (t) {
              return this.getFilteredVendors("purpose", t, "legInt");
            },
          },
          {
            key: "getVendorsWithFlexiblePurpose",
            value: function (t) {
              return this.getFilteredVendors("purpose", t, "flexible");
            },
          },
          {
            key: "getVendorsWithSpecialPurpose",
            value: function (t) {
              return this.getFilteredVendors("purpose", t, void 0, !0);
            },
          },
          {
            key: "getVendorsWithFeature",
            value: function (t) {
              return this.getFilteredVendors("feature", t);
            },
          },
          {
            key: "getVendorsWithSpecialFeature",
            value: function (t) {
              return this.getFilteredVendors("feature", t, void 0, !0);
            },
          },
          {
            key: "vendors",
            get: function () {
              return this.vendors_;
            },
          },
          {
            key: "narrowVendorsTo",
            value: function (t) {
              this.mapVendors(t);
            },
          },
          {
            key: "isReady",
            get: function () {
              return this.isReady_;
            },
          },
          {
            key: "clone",
            value: function () {
              var t = new i(this.getJson());
              return (
                this.lang_ !== i.DEFAULT_LANGUAGE &&
                  t.changeLanguage(this.lang_),
                t
              );
            },
          },
        ],
        [
          {
            key: "baseUrl",
            get: function () {
              return this.baseUrl_;
            },
            set: function (t) {
              if (/^https?:\/\/vendorlist\.consensu\.org\//.test(t))
                throw new ri(
                  "Invalid baseUrl!  You may not pull directly from vendorlist.consensu.org and must provide your own cache"
                );
              t.length > 0 && "/" !== t[t.length - 1] && (t += "/"),
                (this.baseUrl_ = t);
            },
          },
          {
            key: "emptyLanguageCache",
            value: function (t) {
              var e = !1;
              return (
                void 0 === t && i.LANGUAGE_CACHE.size > 0
                  ? ((i.LANGUAGE_CACHE = new Map()), (e = !0))
                  : "string" == typeof t &&
                    this.consentLanguages.has(t.toUpperCase()) &&
                    (i.LANGUAGE_CACHE.delete(t.toUpperCase()), (e = !0)),
                e
              );
            },
          },
          {
            key: "emptyCache",
            value: function (t) {
              var e = !1;
              return (
                Number.isInteger(t) && t >= 0
                  ? (i.CACHE.delete(t), (e = !0))
                  : void 0 === t && ((i.CACHE = new Map()), (e = !0)),
                e
              );
            },
          },
          {
            key: "isInstanceOf",
            value: function (t) {
              return (
                "object" === x(t) && "function" == typeof t.narrowVendorsTo
              );
            },
          },
        ]
      ),
      i
    );
  })();
T(Zi, "LANGUAGE_CACHE", new Map()),
  T(Zi, "CACHE", new Map()),
  T(Zi, "LATEST_CACHE_KEY", 0),
  T(Zi, "DEFAULT_LANGUAGE", "EN"),
  T(Zi, "consentLanguages", new ci()),
  T(Zi, "baseUrl_", void 0),
  T(Zi, "latestFilename", "vendor-list.json"),
  T(Zi, "versionedFilename", "archives/vendor-list-v[VERSION].json"),
  T(Zi, "languageFilename", "purposes-[LANG].json");
var tr = (function () {
  A(e, ai);
  var t = R(e);
  function e(n) {
    var i;
    return (
      S(this, e),
      T(L((i = t.call(this))), "isServiceSpecific_", !1),
      T(L(i), "supportOOB_", !0),
      T(L(i), "useNonStandardStacks_", !1),
      T(L(i), "purposeOneTreatment_", !1),
      T(L(i), "publisherCountryCode_", "AA"),
      T(L(i), "version_", 2),
      T(L(i), "consentScreen_", 0),
      T(L(i), "policyVersion_", 2),
      T(L(i), "consentLanguage_", "EN"),
      T(L(i), "cmpId_", 0),
      T(L(i), "cmpVersion_", 0),
      T(L(i), "vendorListVersion_", 0),
      T(L(i), "numCustomPurposes_", 0),
      T(L(i), "gvl_", void 0),
      T(L(i), "created", void 0),
      T(L(i), "lastUpdated", void 0),
      T(L(i), "specialFeatureOptins", new Fi()),
      T(L(i), "purposeConsents", new Fi()),
      T(L(i), "purposeLegitimateInterests", new Fi()),
      T(L(i), "publisherConsents", new Fi()),
      T(L(i), "publisherLegitimateInterests", new Fi()),
      T(L(i), "publisherCustomConsents", new Fi()),
      T(L(i), "publisherCustomLegitimateInterests", new Fi()),
      T(L(i), "customPurposes", void 0),
      T(L(i), "vendorConsents", new Fi()),
      T(L(i), "vendorLegitimateInterests", new Fi()),
      T(L(i), "vendorsDisclosed", new Fi()),
      T(L(i), "vendorsAllowed", new Fi()),
      T(L(i), "publisherRestrictions", new gi()),
      n && (i.gvl = n),
      i.updated(),
      i
    );
  }
  return (
    _(e, [
      {
        key: "gvl",
        get: function () {
          return this.gvl_;
        },
        set: function (t) {
          Zi.isInstanceOf(t) || (t = new Zi(t)),
            (this.gvl_ = t),
            (this.publisherRestrictions.gvl = t);
        },
      },
      {
        key: "cmpId",
        get: function () {
          return this.cmpId_;
        },
        set: function (t) {
          if (((t = Number(t)), !(Number.isInteger(t) && t > 1)))
            throw new oi("cmpId", t);
          this.cmpId_ = t;
        },
      },
      {
        key: "cmpVersion",
        get: function () {
          return this.cmpVersion_;
        },
        set: function (t) {
          if (((t = Number(t)), !(Number.isInteger(t) && t > -1)))
            throw new oi("cmpVersion", t);
          this.cmpVersion_ = t;
        },
      },
      {
        key: "consentScreen",
        get: function () {
          return this.consentScreen_;
        },
        set: function (t) {
          if (((t = Number(t)), !(Number.isInteger(t) && t > -1)))
            throw new oi("consentScreen", t);
          this.consentScreen_ = t;
        },
      },
      {
        key: "consentLanguage",
        get: function () {
          return this.consentLanguage_;
        },
        set: function (t) {
          this.consentLanguage_ = t;
        },
      },
      {
        key: "publisherCountryCode",
        get: function () {
          return this.publisherCountryCode_;
        },
        set: function (t) {
          if (!/^([A-z]){2}$/.test(t)) throw new oi("publisherCountryCode", t);
          this.publisherCountryCode_ = t.toUpperCase();
        },
      },
      {
        key: "vendorListVersion",
        get: function () {
          return this.gvl
            ? this.gvl.vendorListVersion
            : this.vendorListVersion_;
        },
        set: function (t) {
          if ((t = Number(t) >> 0) < 0) throw new oi("vendorListVersion", t);
          this.vendorListVersion_ = t;
        },
      },
      {
        key: "policyVersion",
        get: function () {
          return this.gvl ? this.gvl.tcfPolicyVersion : this.policyVersion_;
        },
        set: function (t) {
          if (
            ((this.policyVersion_ = parseInt(t, 10)), this.policyVersion_ < 0)
          )
            throw new oi("policyVersion", t);
        },
      },
      {
        key: "version",
        get: function () {
          return this.version_;
        },
        set: function (t) {
          this.version_ = parseInt(t, 10);
        },
      },
      {
        key: "isServiceSpecific",
        get: function () {
          return this.isServiceSpecific_;
        },
        set: function (t) {
          this.isServiceSpecific_ = t;
        },
      },
      {
        key: "useNonStandardStacks",
        get: function () {
          return this.useNonStandardStacks_;
        },
        set: function (t) {
          this.useNonStandardStacks_ = t;
        },
      },
      {
        key: "supportOOB",
        get: function () {
          return this.supportOOB_;
        },
        set: function (t) {
          this.supportOOB_ = t;
        },
      },
      {
        key: "purposeOneTreatment",
        get: function () {
          return this.purposeOneTreatment_;
        },
        set: function (t) {
          this.purposeOneTreatment_ = t;
        },
      },
      {
        key: "setAllVendorConsents",
        value: function () {
          this.vendorConsents.set(this.gvl.vendors);
        },
      },
      {
        key: "unsetAllVendorConsents",
        value: function () {
          this.vendorConsents.empty();
        },
      },
      {
        key: "setAllVendorsDisclosed",
        value: function () {
          this.vendorsDisclosed.set(this.gvl.vendors);
        },
      },
      {
        key: "unsetAllVendorsDisclosed",
        value: function () {
          this.vendorsDisclosed.empty();
        },
      },
      {
        key: "setAllVendorsAllowed",
        value: function () {
          this.vendorsAllowed.set(this.gvl.vendors);
        },
      },
      {
        key: "unsetAllVendorsAllowed",
        value: function () {
          this.vendorsAllowed.empty();
        },
      },
      {
        key: "setAllVendorLegitimateInterests",
        value: function () {
          this.vendorLegitimateInterests.set(this.gvl.vendors);
        },
      },
      {
        key: "unsetAllVendorLegitimateInterests",
        value: function () {
          this.vendorLegitimateInterests.empty();
        },
      },
      {
        key: "setAllPurposeConsents",
        value: function () {
          this.purposeConsents.set(this.gvl.purposes);
        },
      },
      {
        key: "unsetAllPurposeConsents",
        value: function () {
          this.purposeConsents.empty();
        },
      },
      {
        key: "setAllPurposeLegitimateInterests",
        value: function () {
          this.purposeLegitimateInterests.set(this.gvl.purposes);
        },
      },
      {
        key: "unsetAllPurposeLegitimateInterests",
        value: function () {
          this.purposeLegitimateInterests.empty();
        },
      },
      {
        key: "setAllSpecialFeatureOptins",
        value: function () {
          this.specialFeatureOptins.set(this.gvl.specialFeatures);
        },
      },
      {
        key: "unsetAllSpecialFeatureOptins",
        value: function () {
          this.specialFeatureOptins.empty();
        },
      },
      {
        key: "setAll",
        value: function () {
          this.setAllVendorConsents(),
            this.setAllPurposeLegitimateInterests(),
            this.setAllSpecialFeatureOptins(),
            this.setAllPurposeConsents(),
            this.setAllVendorLegitimateInterests();
        },
      },
      {
        key: "unsetAll",
        value: function () {
          this.unsetAllVendorConsents(),
            this.unsetAllPurposeLegitimateInterests(),
            this.unsetAllSpecialFeatureOptins(),
            this.unsetAllPurposeConsents(),
            this.unsetAllVendorLegitimateInterests();
        },
      },
      {
        key: "numCustomPurposes",
        get: function () {
          var t = this.numCustomPurposes_;
          if ("object" === x(this.customPurposes)) {
            var e = Object.keys(this.customPurposes).sort(function (t, e) {
              return Number(t) - Number(e);
            });
            t = parseInt(e.pop(), 10);
          }
          return t;
        },
        set: function (t) {
          if (
            ((this.numCustomPurposes_ = parseInt(t, 10)),
            this.numCustomPurposes_ < 0)
          )
            throw new oi("numCustomPurposes", t);
        },
      },
      {
        key: "updated",
        value: function () {
          var t = new Date(),
            e = new Date(
              Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate())
            );
          (this.created = e), (this.lastUpdated = e);
        },
      },
    ]),
    e
  );
})();
T(tr, "consentLanguages", Zi.consentLanguages);
var er,
  nr,
  ir,
  rr,
  or,
  sr,
  ar = (function () {
    function t() {
      S(this, t);
    }
    return (
      _(t, null, [
        {
          key: "encode",
          value: function (t, e) {
            var n,
              i = "";
            return (
              (t = Qi.process(t, e)),
              (n = Array.isArray(null == e ? void 0 : e.segments)
                ? e.segments
                : new Yi(t, e)["" + t.version]).forEach(function (e, r) {
                var o = "";
                r < n.length - 1 && (o = "."), (i += Ki.encode(t, e) + o);
              }),
              i
            );
          },
        },
        {
          key: "decode",
          value: function (t, e) {
            var n = t.split("."),
              i = n.length;
            e || (e = new tr());
            for (var r = 0; r < i; r++) {
              var o = n[r],
                s = si.decode(o.charAt(0)).substr(0, Pi.segmentType),
                a = pi.ID_TO_KEY[Mi.decode(s, Pi.segmentType).toString()];
              Ki.decode(o, e, a);
            }
            return e;
          },
        },
      ]),
      t
    );
  })(),
  lr = function (t, e, n, i, r, o) {
    if (!t) return [];
    var s = t.gvl,
      a = t.publisherRestrictions,
      l = t.vendorConsents,
      c = t.vendorLegitimateInterests;
    if (!s) return [];
    var u = Rt.fetchTCFVendorsDisclosedObject(s.vendors),
      d = kr(a);
    return Object.values(s.vendors).map(function (t) {
      var a = Gt(t.legIntPurposes, s.purposes),
        h = Gt(t.purposes, s.purposes);
      r &&
        (h = h.filter(function (t) {
          return 1 !== t.id;
        }));
      var f = mr(t.id, u),
        m = a.map(function (t) {
          return t;
        }),
        b = h.map(function (t) {
          return t;
        });
      d.forEach(function (e) {
        switch (e.restrictionType) {
          case ui.REQUIRE_LI:
            b = b.filter(function (n) {
              return (
                n.id !== e.purposeId ||
                (t.flexiblePurposes.indexOf(n.id) > -1 && m.push(n), !1)
              );
            });
            break;
          case ui.REQUIRE_CONSENT:
            m = m.filter(function (n) {
              return (
                n.id !== e.purposeId ||
                (t.flexiblePurposes.indexOf(n.id) > -1 && b.push(n), !1)
              );
            });
            break;
          case ui.NOT_ALLOWED:
            (b = h.filter(function (t) {
              return t.id !== e.purposeId;
            })),
              (m = a.filter(function (t) {
                return t.id !== e.purposeId;
              }));
        }
      });
      var g = o.includes(t.id);
      return {
        consent: f ? l.has(t.id) : null,
        cookieMaxAgeSeconds:
          t.cookieMaxAgeSeconds && t.cookieMaxAgeSeconds >= 0
            ? t.cookieMaxAgeSeconds
            : null,
        cookieRefresh: Vt(t.cookieRefresh, null),
        deviceStorage: null,
        deviceStorageDisclosureUrl: t.deviceStorageDisclosureUrl || null,
        features: t.features.map(function (t) {
          return { id: t, name: s.features[t].name };
        }),
        flexiblePurposes: Gt(t.flexiblePurposes, s.purposes),
        id: t.id,
        legitimateInterestConsent: f ? c.has(t.id) : null,
        legitimateInterestPurposes: m,
        name: t.name,
        policyUrl: t.policyUrl,
        purposes: b,
        showConsentToggle: b.length > 0 && n,
        showLegitimateInterestConsentToggle: m.length > 0 && n && !i,
        showVendorOutsideEU: g,
        specialFeatures: Gt(
          t.specialFeatures.filter(function (t) {
            return !e.includes(t);
          }),
          s.specialFeatures
        ),
        specialPurposes: Gt(t.specialPurposes, s.specialPurposes),
        usesCookies: Vt(t.usesCookies, !1),
        usesNonCookieAccess: Vt(t.usesNonCookieAccess, null),
      };
    });
  },
  cr = function (t) {
    return {
      legitimateInterestPurposes: (null == t ? void 0 : t.legIntPurposes) || [],
      purposes: (null == t ? void 0 : t.purposes) || [],
    };
  },
  ur = function (t) {
    return t || "/browser-sdk/".concat(pt, "/cookie-bridge.html");
  },
  dr = function (t) {
    return t || "https://usercentrics.mgr.consensu.org:443";
  },
  hr = function (t, e) {
    if (!e || 0 === t.length) return [];
    var n = (function (t) {
      return Jt(
        t.reduce(function (t, e) {
          return t.concat(
            e.features.map(function (t) {
              return t.id;
            })
          );
        }, [])
      );
    })(t);
    return n.reduce(function (t, n) {
      var i = e[n];
      return i ? ft(ft([], ht(t), !1), [i], !1) : t;
    }, []);
  },
  fr = function (t, e) {
    return !t || !e;
  },
  mr = function (t, e) {
    return (
      void 0 === e && (e = Rt.fetchTCFVendorsDisclosedObject()), !0 === e[t]
    );
  },
  br = function (t, e, n, i, r) {
    var o = e.reduce(function (t, e) {
        return t
          .concat(
            e.purposes.map(function (t) {
              return t.id;
            })
          )
          .concat(
            e.legitimateInterestPurposes.map(function (t) {
              return t.id;
            })
          );
      }, []),
      s = xr(t, n, i).reduce(function (t, e) {
        return t.concat(e.purposeIds);
      }, []),
      a = Jt(o.concat(s));
    return r
      ? a.filter(function (t) {
          return 1 !== t;
        })
      : a;
  },
  gr = function (t, e, n, i, r, o, s, a, l) {
    if (!t || !e || !n) return [];
    var c = br(e, i, r, o, s),
      u = xr(e, r, o),
      d = Rt.fetchTCFData().vendors,
      h = t.purposeConsents,
      f = t.purposeLegitimateInterests,
      m = Jt(
        i
          .map(function (t) {
            return t.legitimateInterestPurposes.map(function (t) {
              return t.id;
            });
          })
          .reduce(function (t, e) {
            return t.concat(e);
          }, [])
      ),
      b = Jt(
        i
          .map(function (t) {
            return t.purposes.map(function (t) {
              return t.id;
            });
          })
          .reduce(function (t, e) {
            return t.concat(e);
          }, [])
      );
    return c.reduce(function (t, e) {
      var i = n[e];
      if (!i) return t;
      var r = u.find(function (t) {
        return t.purposeIds.includes(e);
      });
      return ft(
        ft([], ht(t), !1),
        [
          {
            consent: d.length ? h.has(e) : null,
            description: i.description,
            descriptionLegal: i.descriptionLegal,
            id: i.id,
            isPartOfASelectedStack: !!r,
            legitimateInterestConsent: d.length ? f.has(e) : null,
            name: i.name,
            showConsentToggle: b.includes(e) && a,
            showLegitimateInterestToggle:
              1 !== i.id && m.includes(e) && a && !l,
            stackId: (null == r ? void 0 : r.id) || null,
          },
        ],
        !1
      );
    }, []);
  },
  wr = function (t) {
    return {
      onIABLegalBasisChanged: t.resurfaceIABLegalBasisChanged,
      onPeriodEnded: t.resurfacePeriodEnded,
      onPurposeChanged: t.resurfacePurposeChanged,
      onVendorAdded: t.resurfaceVendorAdded,
    };
  },
  pr = function (t, e, n, i) {
    var r = e.reduce(function (t, e) {
        return t.concat(
          e.specialFeatures
            .filter(function (t) {
              return !n.includes(t.id);
            })
            .map(function (t) {
              return t.id;
            })
        );
      }, []),
      o = xr(t, n, i).reduce(function (t, e) {
        return t.concat(
          e.specialFeatureIds.filter(function (t) {
            return !n.includes(t);
          })
        );
      }, []);
    return Jt(r.concat(o));
  },
  vr = function (t, e, n, i, r, o) {
    if (!t || !e) return [];
    var s = pr(e.stacks, n, i, r),
      a = xr(e.stacks, i, r);
    return s.map(function (n) {
      var i = e.specialFeatures[n],
        r = a.find(function (t) {
          return t.specialFeatureIds.includes(n);
        });
      return {
        consent: t.specialFeatureOptins.has(n),
        description: i.description,
        descriptionLegal: i.descriptionLegal,
        id: i.id,
        isPartOfASelectedStack: !!r,
        name: i.name,
        showConsentToggle: o,
        stackId: (null == r ? void 0 : r.id) || null,
      };
    });
  },
  yr = function (t, e) {
    if (!t) return [];
    var n = (function (t) {
      return Jt(
        t.reduce(function (t, e) {
          return t.concat(
            e.specialPurposes.map(function (t) {
              return t.id;
            })
          );
        }, [])
      );
    })(e);
    return n.reduce(function (e, n) {
      var i = t[n];
      return i
        ? ft(
            ft([], ht(e), !1),
            [
              {
                description: i.description,
                descriptionLegal: i.descriptionLegal,
                id: i.id,
                name: i.name,
              },
            ],
            !1
          )
        : e;
    }, []);
  },
  xr = function (t, e, n) {
    return t
      ? n.reduce(function (n, i) {
          var r = t[i];
          return r
            ? ft(
                ft([], ht(n), !1),
                [
                  {
                    description: r.description,
                    id: r.id,
                    name: r.name,
                    purposeIds: r.purposes,
                    specialFeatureIds: r.specialFeatures.filter(function (t) {
                      return !e.includes(t);
                    }),
                  },
                ],
                !1
              )
            : n;
        }, [])
      : [];
  },
  kr = function (t) {
    return (
      (null == t
        ? void 0
        : t.getRestrictions().map(function (t) {
            return {
              purposeId: t.purposeId,
              restrictionType: t.restrictionType,
            };
          })) || []
    );
  },
  qr = function (t) {
    return (
      !!(null == t ? void 0 : t.timestamp) &&
      (Date.now() - t.timestamp) / 864e5 > 365
    );
  },
  Sr = function (t, e) {
    if (!(null == t ? void 0 : t.tcString)) return !1;
    var n = ar.decode(t.tcString);
    return (
      n.version !== (null == e ? void 0 : e.version) ||
      n.policyVersion !== e.policyVersion
    );
  },
  Cr = function (t, e) {
    return !(
      !(null == t ? void 0 : t.vendors) ||
      !(null == t ? void 0 : t.vendors.length) ||
      e.every(function (e) {
        return null == t
          ? void 0
          : t.vendors.find(function (t) {
              return t[_t.ID] === e.id;
            });
      })
    );
  },
  _r = function (t, e) {
    return !(
      !(null == t ? void 0 : t.vendors) ||
      !t.vendors.length ||
      (t.vendors.length && !t.vendors[0][_t.SPECIAL_PURPOSES]) ||
      t.vendors.every(function (t) {
        var n = e.find(function (e) {
          return e.id === t[_t.ID];
        });
        return (
          !n ||
          (t[_t.PURPOSES].sort().toString() ===
            n.purposes
              .map(function (t) {
                return t.id;
              })
              .sort()
              .toString() &&
            t[_t.LEGITIMATE_INTEREST].sort().toString() ===
              n.legitimateInterestPurposes
                .map(function (t) {
                  return t.id;
                })
                .sort()
                .toString() &&
            t[_t.SPECIAL_PURPOSES].sort().toString() ===
              n.specialPurposes
                .map(function (t) {
                  return t.id;
                })
                .sort()
                .toString())
        );
      })
    );
  },
  Tr = function (t) {
    return t.map(function (t) {
      var e = t.purposes,
        n = t.specialPurposes;
      return [
        t.id,
        t.legitimateInterestPurposes.map(function (t) {
          return t.id;
        }),
        e.map(function (t) {
          return t.id;
        }),
        n.map(function (t) {
          return t.id;
        }),
      ];
    });
  },
  Ar = function (t) {
    if (
      Zi.consentLanguages.has(t.toLocaleLowerCase()) ||
      Zi.consentLanguages.has(t.toUpperCase())
    )
      return t;
    var e = t.slice(0, 2);
    return Zi.consentLanguages.has(e.toLocaleLowerCase()) ||
      Zi.consentLanguages.has(e.toUpperCase())
      ? e
      : pn;
  },
  Er = function (t) {
    if (t && t.source && t.source.postMessage) {
      var e = "string" == typeof t.data,
        n = t.data;
      if (e)
        try {
          n = JSON.parse(t.data);
        } catch (C) {
          return;
        }
      if ("object" === x(n) && n.__tcfapiCall) {
        var i = n.__tcfapiCall;
        window.__tcfapi(
          i.command,
          i.version,
          function (n, r) {
            var o = {
                __tcfapiReturn: {
                  returnValue: n,
                  success: r,
                  callId: i.callId,
                },
              },
              s = e ? JSON.stringify(o) : o;
            try {
              t.source.postMessage(s, "*");
            } catch (T) {}
          },
          i.parameter
        );
      }
    }
  },
  zr = [],
  Or = function (t, e, n, i) {
    if (!t) return zr;
    switch (t) {
      case "ping":
        "function" == typeof n && n(!0, !1, "stub");
        break;
      case "pending":
        return zr;
      default:
        zr.push([t, e, n, i]);
    }
  },
  Ir = "__tcfapiLocator";
!(function (t) {
  (t.ACCEPT_ALL_SERVICES = "onAcceptAllServices"),
    (t.DENY_ALL_SERVICES = "onDenyAllServices"),
    (t.ESSENTIAL_CHANGE = "onEssentialChange"),
    (t.INITIAL_PAGE_LOAD = "onInitialPageLoad"),
    (t.NON_EU_REGION = "onNonEURegion"),
    (t.SESSION_RESTORED = "onSessionRestored"),
    (t.TCF_STRING_CHANGE = "onTcfStringChange"),
    (t.UPDATE_SERVICES = "onUpdateServices"),
    (t.MOBILE_SESSION_RESTORED = "onMobileSessionRestore");
})(er || (er = {})),
  (function (t) {
    (t.EXPLICIT = "explicit"), (t.IMPLICIT = "implicit");
  })(nr || (nr = {})),
  (function (t) {
    (t[(t.UNDEFINED = 0)] = "UNDEFINED"),
      (t[(t.CMP_SHOWN = 1)] = "CMP_SHOWN"),
      (t[(t.ACCEPT_ALL = 2)] = "ACCEPT_ALL"),
      (t[(t.DENY_ALL = 3)] = "DENY_ALL"),
      (t[(t.SAVE = 4)] = "SAVE"),
      (t[(t.ACCEPT_ALL_L1 = 5)] = "ACCEPT_ALL_L1"),
      (t[(t.DENY_ALL_L1 = 6)] = "DENY_ALL_L1"),
      (t[(t.SAVE_L1 = 7)] = "SAVE_L1"),
      (t[(t.ACCEPT_ALL_L2 = 8)] = "ACCEPT_ALL_L2"),
      (t[(t.DENY_ALL_L2 = 9)] = "DENY_ALL_L2"),
      (t[(t.SAVE_L2 = 10)] = "SAVE_L2"),
      (t[(t.COOKIE_POLICY_LINK = 11)] = "COOKIE_POLICY_LINK"),
      (t[(t.IMPRINT_LINK = 12)] = "IMPRINT_LINK"),
      (t[(t.MORE_INFORMATION_LINK = 13)] = "MORE_INFORMATION_LINK"),
      (t[(t.PRIVACY_POLICY_LINK = 14)] = "PRIVACY_POLICY_LINK"),
      (t[(t.CCPA_TOGGLES_ON = 15)] = "CCPA_TOGGLES_ON"),
      (t[(t.CCPA_TOGGLES_OFF = 16)] = "CCPA_TOGGLES_OFF");
  })(ir || (ir = {})),
  (function (t) {
    (t.API_NAME = "__uspapi"), (t.GET_USP_DATA = "getUSPData");
  })(rr || (rr = {})),
  (function (t) {
    (t[(t.FIRST_LAYER = 0)] = "FIRST_LAYER"),
      (t[(t.NONE = 1)] = "NONE"),
      (t[(t.PRIVACY_BUTTON = 2)] = "PRIVACY_BUTTON"),
      (t[(t.SECOND_LAYER = 3)] = "SECOND_LAYER");
  })(or || (or = {})),
  (function (t) {
    (t[(t.CCPA = 0)] = "CCPA"),
      (t[(t.DEFAULT = 1)] = "DEFAULT"),
      (t[(t.TCF = 2)] = "TCF");
  })(sr || (sr = {})),
  void 0 !== ei && ei.initialize({ modulePath: "/dir" });
var Dr = (function () {
  function t(t, e) {
    var n;
    if (
      ((this.ampInstance = _e.getInstance()),
      (this.apiInstance = sn.getInstance()),
      (this.botInstance = hn.getInstance()),
      (this.controllerIdInstance = Ke.getInstance()),
      (this.dataFacadeInstance = Gn.getInstance()),
      (this.eventDispatcherInstance = bn.getInstance()),
      (this.initOptions = {}),
      (this.isConsentRequired = null),
      (this.languageInstance = Kn.getInstance()),
      (this.storageServiceInstance = Rt.getInstance()),
      (this.locationInstance = Xe.getInstance()),
      (this.settingsV2 = Hn.getInstance()),
      (this.uiInstance = ti.getInstance()),
      (this.domains = null),
      (this.rulesetRule = { name: "", noShow: !0, settingsId: "" }),
      e && (this.initOptions = e),
      this.apiInstance.setEuMode(!0 === (null == e ? void 0 : e.euMode)),
      (this.domains = (n = window.UC_UI_DOMAINS)
        ? Object.entries(n).reduce(
            function (t, e) {
              var n,
                i,
                r = e[0],
                o = e[1];
              return "/" === o.slice(-1)
                ? ct(ct({}, t), (((n = {})[r] = o.slice(0, -1)), n))
                : ct(ct({}, t), (((i = {})[r] = o), i));
            },
            {
              aggregator: "",
              app: "",
              cdn: "",
              consents: "",
              consentsV2: "",
              consentsV2Fetch: "",
              crossDomainConsentSharingIFrame: "",
              graphql: "",
              trackingEvent: "",
            }
          )
        : null),
      this.apiInstance.setDomains(
        !0 === (null == e ? void 0 : e.sandboxEnv),
        this.domains
      ),
      (null == e ? void 0 : e.createTcfApiStub) &&
        "undefined" != typeof window &&
        (window.__tcfapi ||
          (!(function () {
            for (var t = window, n = !1; t; ) {
              try {
                if (t.frames[Ir]) {
                  n = !0;
                  break;
                }
              } catch (e) {}
              if (t === window.top) {
                n = !1;
                break;
              }
              t = t.parent;
            }
            return n;
          })() &&
            (oe(function () {
              return !!window.document.body;
            }, "").then(function () {
              var t = window.document.createElement("iframe");
              (t.style.cssText = "display:none"),
                (t.name = Ir),
                window.document.body.appendChild(t);
            }),
            1) &&
            (window.addEventListener("message", Er, !1),
            (window.__tcfapi = Or)))),
      (null == e ? void 0 : e.useRulesetId)
        ? this.apiInstance.setRulesetId(t)
        : this.apiInstance.setSettingsId(t),
      (this.controllerIdInstance.value = ""),
      (null == e ? void 0 : e.controllerId) &&
        !(null == e ? void 0 : e.useRulesetId) &&
        (this.controllerIdInstance.value = e.controllerId),
      (null == e ? void 0 : e.language) &&
        this.languageInstance.setPrimaryLanguage(e.language),
      (null == e ? void 0 : e.settingsCache) &&
        this.apiInstance.setJsonCacheBustingString(e.settingsCache),
      (null == e ? void 0 : e.version) &&
        this.apiInstance.setJsonFileVersion(e.version),
      (null == e ? void 0 : e.userCountryData) &&
        "object" === x(e.userCountryData) &&
        Object.keys(e.userCountryData).every(function (t) {
          return "string" == typeof t;
        }) &&
        this.locationInstance.setUserCountryData(e.userCountryData),
      (null == e ? void 0 : e.userSessionData) &&
        this.dataFacadeInstance.setUserSessionData(e.userSessionData),
      (null == e ? void 0 : e.ampEnabled) &&
        this.ampInstance.setIsAmpEnabled(!0),
      (null == e ? void 0 : e.blockDataLayerPush) &&
        this.eventDispatcherInstance.setBlockDataLayerPush(!0),
      (null == e ? void 0 : e.storeServiceIdToNameMapping) &&
        this.storageServiceInstance.setStoreServiceIdToNameMapping(
          null == e ? void 0 : e.storeServiceIdToNameMapping
        ),
      (null == e ? void 0 : e.disableTracking) &&
        (this.initOptions.disableTracking = !0),
      (null == e ? void 0 : e.disableServerConsents) &&
        this.apiInstance.setDisableServerConsents(!0),
      (null == e ? void 0 : e.disableServerConsents) &&
        (null == e ? void 0 : e.controllerId))
    )
      throw new Error(
        "Usercentrics: disableServerConsents and controllerId should not be present at the same time in the InitOptions!"
      );
    (this.initOptions.prefetchServices = Vt(
      null == e ? void 0 : e.prefetchServices,
      !0
    )),
      (this.setTrackingPixel = this.setTrackingPixel.bind(this));
  }
  return (
    (t.prototype.fetchCoreAndDps = function () {
      return ut(this, void 0, void 0, function () {
        var t, e, n;
        return dt(this, function (i) {
          switch (i.label) {
            case 0:
              return [4, this.loadSettings()];
            case 1:
              return (
                (t = i.sent()),
                (e = {
                  buttonDisplayLocation: (r = t).buttonDisplayLocation,
                  buttonPrivacyCloseIcon: r.buttonPrivacyCloseIcon,
                  buttonPrivacyOpenIconUrl: r.buttonPrivacyOpenIconUrl,
                  ccpa:
                    ((a = r.ccpa),
                    {
                      iabAgreementExists: a.iabAgreementExists,
                      isActive: a.isActive,
                      region: a.region,
                      reshowAfterDays: a.reshowAfterDays,
                      showOnPageLoad: a.showOnPageLoad,
                    }),
                  consentAnalytics: r.consentAnalytics,
                  consentAPIv2: r.consentAPIv2,
                  consentSharingIFrameIsActive: r.consentSharingIFrameIsActive,
                  consentXDevice: r.consentXDevice,
                  customization:
                    ((s = r.customization),
                    s
                      ? ct(
                          ct(
                            {
                              color: s.color
                                ? {
                                    primary: s.color.primary,
                                    privacyButtonBackground:
                                      s.color.privacyButtonBackground,
                                    privacyButtonIcon:
                                      s.color.privacyButtonIcon,
                                  }
                                : null,
                            },
                            s.privacyButtonSizeMobile && {
                              privacyButtonSizeMobile:
                                s.privacyButtonSizeMobile,
                            }
                          ),
                          s.privacyButtonSizeDesktop && {
                            privacyButtonSizeDesktop:
                              s.privacyButtonSizeDesktop,
                          }
                        )
                      : s),
                  dataExchangeOnPage: r.dataExchangeOnPage,
                  displayOnlyForEU: r.displayOnlyForEU,
                  enableBotDetection: r.enableBotDetection,
                  enablePoweredBy: r.enablePoweredBy,
                  googleConsentMode: r.googleConsentMode,
                  interactionAnalytics: r.interactionAnalytics,
                  labels: {
                    partnerPoweredByLinkText: r.labels.partnerPoweredByLinkText,
                    poweredBy: r.labels.poweredBy,
                  },
                  languagesAvailable: r.languagesAvailable,
                  partnerPoweredByUrl: r.partnerPoweredByUrl,
                  privacyButtonIsVisible: r.privacyButtonIsVisible,
                  privacyButtonUrls: r.privacyButtonUrls,
                  reshowBanner: r.reshowBanner,
                  settingsId: r.settingsId,
                  showInitialViewForVersionChange:
                    r.showInitialViewForVersionChange,
                  tagLoggerIsActive: r.tagLoggerIsActive,
                  tcf2:
                    ((o = r.tcf2),
                    {
                      resurfaceIABLegalBasisChanged:
                        o.resurfaceIABLegalBasisChanged,
                      resurfacePeriodEnded: o.resurfacePeriodEnded,
                      resurfacePurposeChanged: o.resurfacePurposeChanged,
                      resurfaceVendorAdded: o.resurfaceVendorAdded,
                    }),
                  tcf2Enabled: r.tcf2Enabled,
                  variants: r.variants,
                  version: r.version,
                }),
                (n = (function (t) {
                  return {
                    categories: t.categories,
                    consentTemplates: t.consentTemplates,
                  };
                })(t)),
                [2, { core: e, dps: n }]
              );
          }
          var r, o, s, a;
        });
      });
    }),
    (t.prototype.init = function () {
      var t;
      return ut(this, void 0, void 0, function () {
        var e,
          n,
          i,
          r,
          o,
          s,
          a,
          l,
          c,
          u,
          d,
          h,
          f,
          m,
          b,
          g,
          w,
          p,
          v,
          y = this;
        return dt(this, function (x) {
          switch (x.label) {
            case 0:
              return (
                Rt.getInstance().init(),
                this.apiInstance.getRulesetId()
                  ? ((e = this), [4, Ln.getInstance().resolveSettingsId()])
                  : [3, 2]
              );
            case 1:
              (e.rulesetRule = x.sent()),
                this.apiInstance.setSettingsId(this.rulesetRule.settingsId),
                this.initOptions.controllerIds &&
                  this.controllerIdInstance.setControllerIdByResolvedSettingsId(
                    this.rulesetRule.settingsId,
                    this.initOptions.controllerIds
                  ),
                (x.label = 2);
            case 2:
              return (
                Rt.clearOnNewSettingsId(this.apiInstance.getSettingsId()),
                Rt.migrateLegacySettings(this.apiInstance.getSettingsId()),
                (n = Rt.fetchServices()),
                (i =
                  null == n
                    ? void 0
                    : n
                        .map(function (t) {
                          return t.history;
                        })
                        .flat()
                        .reduce(function (t, e) {
                          return (null == t ? void 0 : t.timestamp) <
                            e.timestamp
                            ? e
                            : t;
                        })),
                (r = "explicit" === (null == i ? void 0 : i.type)),
                [4, this.languageInstance.resolveLanguage()]
              );
            case 3:
              x.sent(), (x.label = 4);
            case 4:
              return x.trys.push([4, 6, , 9]), [4, this.fetchCoreAndDps()];
            case 5:
              if (
                ((a = x.sent()),
                (u = a.dps),
                !(c = a.core).languagesAvailable.includes(
                  this.apiInstance.getJsonFileLanguage()
                ))
              )
                throw new Error("Using non allowed language");
              return (o = c), (s = u), [3, 9];
            case 6:
              return (
                x.sent(),
                this.languageInstance.setPrimaryLanguage(""),
                [4, this.languageInstance.resolveLanguage(!0)]
              );
            case 7:
              return x.sent(), [4, this.fetchCoreAndDps()];
            case 8:
              return (l = x.sent()), (o = c = l.core), (s = u = l.dps), [3, 9];
            case 9:
              if (!o || !s) throw new Error();
              return (
                (this.botInstance.isBotEnabled = o.enableBotDetection),
                !o.consentSharingIFrameIsActive || this.botInstance.isRobot()
                  ? [3, 11]
                  : [
                      4,
                      Ot.init(
                        { useEuCdn: this.initOptions.euMode || !1 },
                        this.domains
                      )
                        .then(function () {
                          return ut(y, void 0, void 0, function () {
                            var t;
                            return dt(this, function (e) {
                              switch (e.label) {
                                case 0:
                                  return (
                                    Ot.setCrossDomainId(
                                      this.apiInstance.getSettingsId()
                                    ),
                                    Ot.setIsCrossDomainAvailable(!0),
                                    Ot.setUseEuCdn(
                                      this.initOptions.euMode || !1
                                    ),
                                    this.languageInstance.getPrimaryLanguage()
                                      ? [3, 3]
                                      : [
                                          4,
                                          Ot.getCrossDomainLanguage().catch(
                                            function () {
                                              return (
                                                console.warn(
                                                  at.CROSS_DOMAIN_LANGUAGE_NOT_AVAILABLE
                                                ),
                                                ""
                                              );
                                            }
                                          ),
                                        ]
                                  );
                                case 1:
                                  return (
                                    (t = e.sent()), [4, this.changeLanguage(t)]
                                  );
                                case 2:
                                  e.sent(), (e.label = 3);
                                case 3:
                                  return [2];
                              }
                            });
                          });
                        })
                        .catch(function (t) {
                          Ot.setIsCrossDomainAvailable(!1),
                            Ot.removeIFrame(At),
                            console.warn(
                              at.CROSS_DOMAIN_FEATURE_NOT_AVAILABLE,
                              t
                            );
                        }),
                    ]
              );
            case 10:
              x.sent(), (x.label = 11);
            case 11:
              return (
                this.botInstance.isRobot()
                  ? (this.initOptions.suppressCmpDisplay = !0)
                  : this.initOptions.disableTracking ||
                    this.addSessionTrackingPixel(),
                (d = this.apiInstance.getJsonFileLanguage()),
                [4, this.settingsV2.init(o, s, d)]
              );
            case 12:
              return (
                x.sent(), [4, this.uiInstance.resolveUiVariant(o.tcf2Enabled)]
              );
            case 13:
              return (
                (h = x.sent()),
                [
                  4,
                  this.settingsV2.initData(
                    h,
                    [],
                    !1,
                    !0 === this.initOptions.euMode,
                    this.initOptions.excludeAcceptAllVendors,
                    r
                  ),
                ]
              );
            case 14:
              return x.sent(), [4, this.apiInstance.fetchTranslations()];
            case 15:
              return (
                (f = x.sent()),
                !this.initOptions.prefetchServices &&
                this.settingsV2.allLegacyServicesHaveName
                  ? [3, 17]
                  : [4, this.settingsV2.extendServices(h, f)]
              );
            case 16:
              x.sent(),
                this.apiInstance.resetAggregatedServicesCache(),
                (x.label = 17);
            case 17:
              return (
                this.controllerIdInstance.setNeedSessionRestore(),
                [4, this.dataFacadeInstance.restoreUserSession(s)]
              );
            case 18:
              return (
                (m = x.sent()) ||
                  (this.controllerIdInstance.init(),
                  this.settingsV2.data &&
                    this.settingsV2.setControllerId(
                      this.controllerIdInstance.value
                    )),
                [4, this.uiInstance.init(this.initOptions)]
              );
            case 19:
              return (
                x.sent(),
                (b = this.settingsV2.getTcfData()),
                ve(this.settingsV2.data) && b
                  ? [
                      4,
                      this.settingsV2.data.init(!0 === this.initOptions.euMode),
                    ]
                  : [3, 21]
              );
            case 20:
              x.sent(), (x.label = 21);
            case 21:
              return (
                this.settingsV2.initLabels(h, f),
                (g = []),
                Rt.settingsExist() &&
                  (g = this.processStorageServicesAndSettings(
                    this.settingsV2.data
                  )),
                this.botInstance.isRobot() ||
                  (this.apiInstance.saveConsentsFromBuffer(),
                  this.apiInstance.saveConsentsV2FromBuffer()),
                [4, this.uiInstance.resolveUIOptions(o)]
              );
            case 22:
              return (
                (w = x.sent()),
                (p = w.initialLayer),
                (v = Rt.fetchTCFData()),
                m &&
                  b &&
                  Rt.saveTCFData(
                    ct(ct({}, v), { vendors: Tr(b.getTCFData().vendors) })
                  ),
                this.setIsConsentRequired(
                  this.uiInstance.shouldShowFirstLayer(o)
                ),
                this.isConsentRequired && Rt.setUserActionPerformed(!1),
                this.settingsV2.initLabels(h, f),
                [4, this.settingsV2.initUI(p, h)]
              );
            case 23:
              return (
                x.sent(),
                b
                  ? !(
                      0 === p ||
                      ((null === (t = this.initOptions) || void 0 === t
                        ? void 0
                        : t.suppressCmpDisplay) &&
                        this.getIsConsentRequired())
                    ) || this.botInstance.isRobot()
                    ? [3, 25]
                    : [4, b.setUIAsOpen()]
                  : [3, 27]
              );
            case 24:
              return x.sent(), [3, 27];
            case 25:
              return [4, b.setUIAsClosed()];
            case 26:
              x.sent(), (x.label = 27);
            case 27:
              return !this.settingsV2.isTagLoggerActive() ||
                this.botInstance.isRobot()
                ? [3, 29]
                : [
                    4,
                    __sc_import_cookie_banner("./p-7c556fcb.js").then(function (
                      t
                    ) {
                      new t.default().initTagLogger();
                    }),
                  ];
            case 28:
              x.sent(), (x.label = 29);
            case 29:
              return (
                this.eventDispatcherInstance.init(
                  this.settingsV2.getDataExchangeSettings()
                ),
                [4, this.updateStorage(n, g, m)]
              );
            case 30:
              return x.sent(), [2, w];
          }
        });
      });
    }),
    (t.prototype.acceptAllForTCF = function (t) {
      return ut(this, void 0, void 0, function () {
        var e;
        return dt(this, function (n) {
          switch (n.label) {
            case 0:
              return (e = this.settingsV2.getTcfData())
                ? [4, e.acceptAllDisclosed(t)]
                : [3, 2];
            case 1:
              n.sent(), (n.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.acceptAllServices = function (t) {
      return (
        void 0 === t && (t = "explicit"),
        ut(this, void 0, void 0, function () {
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return (
                  this.dataFacadeInstance.execute(
                    this.settingsV2.getUpdatedServicesWithConsent(Y.TRUE),
                    this.settingsV2.getUpdatedServicesDataWithConsent(Y.TRUE),
                    "onAcceptAllServices",
                    t
                  ),
                  [4, this.saveUserActionPerformed()]
                );
              case 1:
                return e.sent(), [2];
            }
          });
        })
      );
    }),
    (t.prototype.changeLanguage = function (t) {
      var e;
      return ut(this, void 0, void 0, function () {
        var n, i, r, o, s, a, l, c, u, d, h, f, m, b, g, w;
        return dt(this, function (p) {
          switch (p.label) {
            case 0:
              return (
                (n =
                  null === (e = this.settingsV2.core) || void 0 === e
                    ? void 0
                    : e.language.available),
                (i =
                  n &&
                  n.some(function (e) {
                    return e === t;
                  })),
                (r = t !== this.apiInstance.getJsonFileLanguage() && i),
                (s = (o = this.settingsV2).core),
                (a = o.data),
                r && a && s
                  ? (this.apiInstance.setJsonFileLanguage(t),
                    this.apiInstance.resetTranslationsCache(),
                    (this.settingsV2.language = t),
                    [4, this.fetchCoreAndDps()])
                  : [3, 8]
              );
            case 1:
              return (
                (l = p.sent().dps),
                (this.settingsV2.dpsJson = l),
                (u = (c = this.uiInstance).selectedLayer),
                (d = c.variant),
                [4, this.apiInstance.fetchTranslations()]
              );
            case 2:
              return (
                (h = p.sent()),
                null === d || null === u || null == l
                  ? [3, 6]
                  : !this.settingsV2.isAggregatorLoaded &&
                    this.settingsV2.checkIfServiceNameExists(l.consentTemplates)
                  ? [3, 4]
                  : [4, this.settingsV2.extendServices(d, h)]
              );
            case 3:
              return p.sent(), [3, 5];
            case 4:
              this.settingsV2.initLabels(d, h), (p.label = 5);
            case 5:
              this.apiInstance.resetAggregatedServicesCache(), (p.label = 6);
            case 6:
              return (
                this.settingsV2.updateServicesLanguage(t),
                (f =
                  this.dataFacadeInstance.getMergedServicesAndSettingsFromStorage(
                    a
                  )),
                (m = f.mergedServices),
                (b = f.mergedServicesData),
                (g = f.mergedSettingsData),
                (s.language.selected = t),
                (g.categories =
                  this.settingsV2.mergeServicesDataIntoExistingCategories(b)),
                (this.settingsV2.data = g),
                (w = this.settingsV2.getDataTransferSettings()) &&
                  Rt.saveSettings(Rt.mapSettings(w, m), m),
                ve(g) ? [4, g.changeLanguage(t)] : [3, 8]
              );
            case 7:
              p.sent(), (p.label = 8);
            case 8:
              return [2];
          }
        });
      });
    }),
    (t.prototype.denyAllForTCF = function (t) {
      return ut(this, void 0, void 0, function () {
        var e;
        return dt(this, function (n) {
          switch (n.label) {
            case 0:
              return (e = this.settingsV2.getTcfData())
                ? [4, e.denyAllDisclosed(t)]
                : [3, 2];
            case 1:
              n.sent(), (n.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.denyAllServices = function (t) {
      return (
        void 0 === t && (t = "explicit"),
        ut(this, void 0, void 0, function () {
          return dt(this, function (e) {
            switch (e.label) {
              case 0:
                return (
                  this.dataFacadeInstance.execute(
                    this.settingsV2.getUpdatedServicesWithConsent(Y.FALSE),
                    this.settingsV2.getUpdatedServicesDataWithConsent(Y.FALSE),
                    "onDenyAllServices",
                    t
                  ),
                  [4, this.saveUserActionPerformed()]
                );
              case 1:
                return e.sent(), [2];
            }
          });
        })
      );
    }),
    (t.prototype.fetchIsUserInEU = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function () {
          return [2, this.locationInstance.getIsUserInEU()];
        });
      });
    }),
    (t.prototype.fetchUserCountry = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function () {
          return [2, this.locationInstance.getUserCountryData()];
        });
      });
    }),
    (t.prototype.getAbTestVariant = function () {
      return this.apiInstance.getAbTestVariant();
    }),
    (t.prototype.getCategoriesBaseInfo = function () {
      return this.settingsV2.getCategoriesBaseInfo();
    }),
    (t.prototype.getCategoriesFullInfo = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return [4, this.apiInstance.fetchTranslations()];
            case 1:
              return (
                (t = e.sent()),
                [
                  2,
                  this.settingsV2.getCategoriesFullInfo(
                    this.uiInstance.variant,
                    t
                  ),
                ]
              );
          }
        });
      });
    }),
    (t.prototype.getCcpaOptOutStatus = function () {
      var t;
      return (
        (null === (t = this.settingsV2.getCcpaData()) || void 0 === t
          ? void 0
          : t.getIsOptedOut()) || !1
      );
    }),
    (t.prototype.getCcpaExplicitNoticeStatus = function () {
      var t;
      return (
        (null === (t = this.settingsV2.getCcpaData()) || void 0 === t
          ? void 0
          : t.getExplicitNotice()) || !1
      );
    }),
    (t.prototype.saveOptOutForCcpa = function (t, e) {
      return (
        void 0 === e && (e = "explicit"),
        ut(this, void 0, void 0, function () {
          var n, i;
          return dt(this, function (r) {
            switch (r.label) {
              case 0:
                return (n = this.settingsV2.getCcpaData()) &&
                  n.getIsOptedOut() !== t
                  ? (n.setCcpaStorage(t),
                    (i = {
                      consentAction: t
                        ? "onDenyAllServices"
                        : "onAcceptAllServices",
                      consentStatus: t ? Y.FALSE : Y.TRUE,
                      consentString: { CCPA: Rt.getCcpaString() },
                    }),
                    this.dataFacadeInstance.execute(
                      this.settingsV2.getUpdatedServicesWithConsent(
                        i.consentStatus
                      ),
                      this.settingsV2.getUpdatedServicesDataWithConsent(
                        i.consentStatus
                      ),
                      i.consentAction,
                      e,
                      i.consentString
                    ),
                    [4, this.saveUserActionPerformed()])
                  : [2];
              case 1:
                return r.sent(), [2];
            }
          });
        })
      );
    }),
    (t.prototype.saveDefaultForCcpa = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return Rt.setCcpaTimeStamp(), [4, this.saveUserActionPerformed()];
            case 1:
              return t.sent(), [2];
          }
        });
      });
    }),
    (t.prototype.getControllerId = function () {
      return this.controllerIdInstance.value;
    }),
    (t.prototype.getServicesBaseInfo = function () {
      return this.settingsV2.getServicesBaseInfo();
    }),
    (t.prototype.getServicesFullInfo = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return [4, this.apiInstance.fetchTranslations()];
            case 1:
              return (
                (t = e.sent()),
                [
                  2,
                  this.settingsV2.getServicesFullInfo(
                    this.uiInstance.variant,
                    t
                  ),
                ]
              );
          }
        });
      });
    }),
    (t.prototype.getSettingsCore = function () {
      var t = this.settingsV2.core;
      if (!t)
        throw new Error(
          "Usercentrics: You have to call the init method before!"
        );
      return t;
    }),
    (t.prototype.getSettingsLabels = function () {
      var t = this.settingsV2.labels;
      if (!t)
        throw new Error(
          "Usercentrics: You have to call the init method before!"
        );
      return t;
    }),
    (t.prototype.getSettingsData = function () {
      var t = this.settingsV2.data;
      if (!t)
        throw new Error(
          "Usercentrics: You have to call the init method before!"
        );
      return t;
    }),
    (t.prototype.getSettingsUI = function () {
      return this.settingsV2.ui;
    }),
    (t.prototype.getAriaLabels = function () {
      var t, e;
      return qe(this.settingsV2.labels) &&
        null !=
          (null === (t = this.settingsV2.labels) || void 0 === t
            ? void 0
            : t.ariaLabels)
        ? null === (e = this.settingsV2.labels) || void 0 === e
          ? void 0
          : e.ariaLabels
        : Se;
    }),
    (t.prototype.getTCFData = function () {
      var t = this.settingsV2.getTcfData();
      return t ? t.getTCFData() : null;
    }),
    (t.prototype.getTCFDisclosedVendorsSegmentString = function () {
      return this.settingsV2.getTCFDisclosedVendorsSegmentString();
    }),
    (t.prototype.injectTCString = function (t) {
      return this.settingsV2.injectTCString(t);
    }),
    (t.prototype.setTCFUIAsClosed = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return (t = this.settingsV2.getTcfData())
                ? [4, t.setUIAsClosed()]
                : [3, 2];
            case 1:
              e.sent(), (e.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.setTCFUIAsOpen = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return (t = this.settingsV2.getTcfData())
                ? [4, t.setUIAsOpen()]
                : [3, 2];
            case 1:
              e.sent(), (e.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.updateChoicesForTCF = function (t, e) {
      return ut(this, void 0, void 0, function () {
        var n;
        return dt(this, function (i) {
          switch (i.label) {
            case 0:
              return (n = this.settingsV2.getTcfData())
                ? [4, n.updateChoices(t, e)]
                : [3, 2];
            case 1:
              i.sent(), (i.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.areAllConsentsAccepted = function () {
      return this.settingsV2.isTcfAvailable()
        ? this.settingsV2.areAllVendorsAndPurposesAccepted() &&
            this.settingsV2.areAllServicesAccepted()
        : this.settingsV2.areAllServicesAccepted();
    }),
    (t.prototype.restoreUserSession = function (t) {
      var e, n;
      return ut(this, void 0, void 0, function () {
        var i;
        return dt(this, function (r) {
          switch (r.label) {
            case 0:
              return (null === (e = this.settingsV2.core) || void 0 === e
                ? void 0
                : e.consentAPIv2) &&
                !(null === (n = this.settingsV2.core) || void 0 === n
                  ? void 0
                  : n.consentXDevice)
                ? (console.warn(st.CROSS_DEVICE_FEATURE_DISABLED),
                  (this.controllerIdInstance.needsSessionRestore = !1),
                  [2])
                : ((this.controllerIdInstance.value = t),
                  (this.controllerIdInstance.needsSessionRestore = !0),
                  this.settingsV2.setControllerId(t),
                  (i = this.settingsV2.dpsJson)
                    ? [4, this.dataFacadeInstance.restoreUserSession(i)]
                    : [3, 2]);
            case 1:
              r.sent() &&
                this.enableServicesScripts(
                  this.processStorageServicesAndSettings(this.settingsV2.data),
                  this.settingsV2.getGoogleConsentMode(),
                  "onSessionRestored"
                ),
                (r.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.clearStorage = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return [4, Rt.clearAll()];
            case 1:
              return t.sent(), [2];
          }
        });
      });
    }),
    (t.prototype.postMessageAmp = function (t, e, n) {
      return ut(this, void 0, void 0, function () {
        var i,
          r,
          o,
          s,
          a,
          l,
          c,
          u,
          d = this;
        return dt(this, function (h) {
          switch (h.label) {
            case 0:
              return (
                (i = this.settingsV2.isTcfAvailable()),
                [4, this.settingsV2.isCcpaAvailable()]
              );
            case 1:
              return (
                (r = h.sent()),
                (o = function () {
                  var t = d.settingsV2.getTcfData();
                  return i && (null == t ? void 0 : t.getTCString)
                    ? t.getTCString()
                    : r
                    ? Rt.getCcpaString()
                    : "";
                }),
                (s = function () {
                  return ut(d, void 0, void 0, function () {
                    var t, e, n, o;
                    return dt(this, function (s) {
                      switch (s.label) {
                        case 0:
                          return (
                            (o = this.settingsV2.getTcfData()),
                            i && o
                              ? ((t = $.TCF_V2), [4, o.getGdprApplies()])
                              : [3, 2]
                          );
                        case 1:
                          return (
                            (e = s.sent()),
                            (n = this.settingsV2.getTCFPurposeOneTreatment()),
                            [3, 3]
                          );
                        case 2:
                          r && (t = $.CCPA), (s.label = 3);
                        case 3:
                          return [
                            2,
                            ct(
                              { consentStringType: t },
                              i && { gdprApplies: e, purposeOne: n }
                            ),
                          ];
                      }
                    });
                  });
                }),
                (l = [{ action: e, type: t }]),
                (c = t === J.CONSENT_RESPONSE && e !== W.DISMISS && (r || i))
                  ? ((u = {}), [4, s()])
                  : [3, 3]
              );
            case 2:
              (u.consentMetadata = h.sent()),
                (u.info = o()),
                (c = u),
                (h.label = 3);
            case 3:
              return (
                (a = ct.apply(void 0, [
                  ct.apply(void 0, l.concat([c])),
                  n && { initialHeight: n },
                ])),
                [
                  2,
                  new Promise(function (t, e) {
                    try {
                      window.parent.postMessage(ct({}, a), "*"), t();
                    } catch (n) {
                      e(n);
                    }
                  }),
                ]
              );
          }
        });
      });
    }),
    (t.prototype.acceptAllAmp = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return [4, this.postMessageAmp(J.CONSENT_RESPONSE, W.ACCEPT)];
            case 1:
              return t.sent(), [2];
          }
        });
      });
    }),
    (t.prototype.denyAllAmp = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return [4, this.postMessageAmp(J.CONSENT_RESPONSE, W.REJECT)];
            case 1:
              return t.sent(), [2];
          }
        });
      });
    }),
    (t.prototype.saveTCFDataAmp = function (t) {
      return ut(this, void 0, void 0, function () {
        var e;
        return dt(this, function (n) {
          switch (n.label) {
            case 0:
              return (
                (e = t.every(function (t) {
                  return t.status;
                })),
                0 === t.length || e
                  ? [4, this.postMessageAmp(J.CONSENT_RESPONSE, W.ACCEPT)]
                  : [3, 2]
              );
            case 1:
              return n.sent(), [3, 4];
            case 2:
              return [4, this.postMessageAmp(J.CONSENT_RESPONSE, W.REJECT)];
            case 3:
              n.sent(), (n.label = 4);
            case 4:
              return [2];
          }
        });
      });
    }),
    (t.prototype.dismissAmp = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return [4, this.postMessageAmp(J.CONSENT_RESPONSE, W.DISMISS)];
            case 1:
              return t.sent(), [2];
          }
        });
      });
    }),
    (t.prototype.enterFullscreenAmp = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function () {
          return [2, this.postMessageAmp(J.CONSENT_UI, W.FULLSCREEN)];
        });
      });
    }),
    (t.prototype.uiReadyAmp = function () {
      return ut(this, void 0, void 0, function () {
        var t, e, n;
        return dt(this, function () {
          return (
            (e = "60vh"),
            (t = this.settingsV2.labels) &&
              qe(t) &&
              ((n = t.firstLayer.description.default.length),
              window.screen.height > 700 && n <= 250 && (e = "50vh")),
            [2, this.postMessageAmp(J.CONSENT_UI, W.READY, e)]
          );
        });
      });
    }),
    (t.prototype.saveUserActionPerformed = function () {
      return ut(this, void 0, void 0, function () {
        return dt(this, function (t) {
          switch (t.label) {
            case 0:
              return (
                Rt.setUserActionPerformed(!0),
                this.setIsConsentRequired(!1),
                this.uiInstance.selectedLayer
                  ? [
                      4,
                      this.settingsV2.initUI(
                        this.uiInstance.selectedLayer,
                        this.uiInstance.variant
                      ),
                    ]
                  : [3, 2]
              );
            case 1:
              t.sent(), (t.label = 2);
            case 2:
              return [2];
          }
        });
      });
    }),
    (t.prototype.updateServices = function (t, e) {
      return (
        void 0 === e && (e = "explicit"),
        ut(this, void 0, void 0, function () {
          var n, i;
          return dt(this, function (r) {
            switch (r.label) {
              case 0:
                return (
                  (n = this.settingsV2.getUpdatedServicesWithDecisions(t)),
                  (i = this.settingsV2.getUpdatedServicesDataWithDecisions(t)),
                  jt(n) &&
                    this.dataFacadeInstance.execute(
                      n,
                      i,
                      "onUpdateServices",
                      e
                    ),
                  [4, this.saveUserActionPerformed()]
                );
              case 1:
                return r.sent(), [2];
            }
          });
        })
      );
    }),
    (t.prototype.updateLayer = function (t) {
      return ut(this, void 0, void 0, function () {
        var e;
        return dt(this, function (n) {
          switch (n.label) {
            case 0:
              return (
                (e = this.uiInstance.selectedLayer),
                (this.uiInstance.selectedLayer = t),
                t === e
                  ? [2]
                  : [4, this.settingsV2.initUI(t, this.uiInstance.variant)]
              );
            case 1:
              return n.sent(), 3 !== t ? [3, 3] : [4, this.loadServices()];
            case 2:
              n.sent(), (n.label = 3);
            case 3:
              return [2];
          }
        });
      });
    }),
    (t.prototype.loadServices = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return this.settingsV2.isAggregatorLoaded ||
                !this.uiInstance.selectedLayer
                ? [2]
                : [4, this.apiInstance.fetchTranslations()];
            case 1:
              return (
                (t = e.sent()),
                [4, this.settingsV2.extendServices(this.uiInstance.variant, t)]
              );
            case 2:
              return (
                e.sent(), this.apiInstance.resetAggregatedServicesCache(), [2]
              );
          }
        });
      });
    }),
    (t.prototype.loadSettings = function () {
      return ut(this, void 0, void 0, function () {
        var t;
        return dt(this, function (e) {
          switch (e.label) {
            case 0:
              return [4, this.apiInstance.fetchSettingsJson()];
            case 1:
              return (
                (t = e.sent()), (this.settingsV2.legacySettings = t), [2, t]
              );
          }
        });
      });
    }),
    (t.prototype.updateStorage = function (t, e, n) {
      return ut(this, void 0, void 0, function () {
        var i, r, o;
        return dt(this, function (s) {
          switch (s.label) {
            case 0:
              return [4, this.settingsV2.shouldDenyAllExplicitlyOnInit()];
            case 1:
              return s.sent()
                ? (this.dataFacadeInstance.execute(
                    this.settingsV2.getUpdatedServicesWithConsent(Y.FALSE),
                    this.settingsV2.getUpdatedServicesDataWithConsent(Y.FALSE),
                    "onDenyAllServices",
                    "explicit"
                  ),
                  [3, 7])
                : [3, 2];
            case 2:
              return this.uiInstance.isFirstTimeVisit()
                ? [4, this.settingsV2.shouldAcceptAllImplicitlyOnInit()]
                : [3, 4];
            case 3:
              return (
                s.sent()
                  ? this.dataFacadeInstance.execute(
                      this.settingsV2.getUpdatedServicesWithConsent(Y.TRUE),
                      this.settingsV2.getUpdatedServicesDataWithConsent(Y.TRUE),
                      "onNonEURegion",
                      this.botInstance.isRobot() ? "explicit" : "implicit"
                    )
                  : this.dataFacadeInstance.execute(
                      this.settingsV2.getServicesDataAndLabels(),
                      this.settingsV2.getServicesData(),
                      "onInitialPageLoad",
                      "implicit"
                    ),
                [3, 7]
              );
            case 4:
              return (
                (i =
                  null != e
                    ? e
                    : this.processStorageServicesAndSettings(
                        this.settingsV2.data
                      )),
                (a = this.settingsV2.getServicesData()),
                (r =
                  ((l = t) &&
                    !a.every(function (t) {
                      return l.find(function (e) {
                        return e.id === t.id;
                      });
                    })) ||
                  !1)
                  ? [
                      4,
                      this.settingsV2.shouldAcceptAllImplicitlyOnVendorAdded(),
                    ]
                  : [3, 6]
              );
            case 5:
              (r = s.sent()), (s.label = 6);
            case 6:
              r
                ? this.dataFacadeInstance.execute(
                    this.settingsV2.getUpdatedServicesWithConsent(Y.TRUE),
                    this.settingsV2.getUpdatedServicesDataWithConsent(Y.TRUE),
                    "onNonEURegion",
                    this.botInstance.isRobot() ? "explicit" : "implicit"
                  )
                : ((o =
                    n && this.dataFacadeInstance.restoreAction
                      ? this.dataFacadeInstance.restoreAction
                      : "onInitialPageLoad"),
                  this.enableServicesScripts(
                    i,
                    this.settingsV2.getGoogleConsentMode(),
                    o
                  ),
                  (this.dataFacadeInstance.restoreAction = null)),
                (s.label = 7);
            case 7:
              return [2];
          }
          var a, l;
        });
      });
    }),
    (t.prototype.enableScriptsForServicesWithConsent = function () {
      Sn.enableScriptsForServicesWithConsent(
        this.settingsV2.getServicesWithConsent()
      );
    }),
    (t.prototype.setTrackingPixel = function (t) {
      var e;
      !this.initOptions.disableTracking &&
        (null === (e = this.settingsV2.coreJson) || void 0 === e
          ? void 0
          : e.interactionAnalytics) &&
        this.apiInstance.setTrackingPixel(t);
    }),
    (t.prototype.addSessionTrackingPixel = function () {
      new Image().src = this.apiInstance.createSessionTrackingUrl();
    }),
    (t.prototype.processStorageServicesAndSettings = function (t) {
      if (!t || !this.settingsV2.labels) return [];
      var e =
        this.dataFacadeInstance.getMergedServicesAndSettingsFromStorage(t);
      return this.dataFacadeInstance.mergeServicesAndSettings(
        e.mergedServices,
        e.mergedServicesData,
        e.dataTransferSettings,
        e.updatedEssentialServices,
        this.settingsV2.labels.services
      );
    }),
    (t.prototype.enableServicesScripts = function (t, e, n) {
      Sn.enableScriptsForServicesWithConsent(
        this.settingsV2.getServicesWithConsent()
      ),
        this.eventDispatcherInstance.dispatch(t, e, n);
    }),
    (t.prototype.setIsConsentRequired = function (t) {
      this.isConsentRequired = !0 === t;
    }),
    (t.prototype.getIsConsentRequired = function () {
      return this.isConsentRequired;
    }),
    t
  );
})();
const Lr = [
    { name: "YouTube", regex: /(youtube|youtu.be)/i, id: "YouTube Video" },
    {
      name: "Google Maps",
      regex: /(maps\/embed|maps\\embed)/i,
      id: "Google Maps",
    },
  ],
  Nr = (t) => t?.language?.selected || document.documentElement.lang || "en",
  Rr = (t = "") => (["ar"].includes(t) ? "rtl" : "ltr"),
  Fr = (t = "") =>
    ["&nbsp;", "<s*/?div.*?>", "<s*/?font.*?>", "<s*/?span.*?>"].reduce(
      (e, n) => {
        const i = e || t.trim(),
          r = new RegExp(n, "gi");
        return i.replace(r, "");
      },
      ""
    ),
  Pr = class {
    constructor(e) {
      t(this, e),
        (this.direction = "ltr"),
        (this.firstRender = !0),
        (this.ucInitialized = !1),
        (this.bannerLabels = void 0),
        (this.bannerVisible = !1),
        (this.currentLanguage = "en"),
        (this.internalLegalPages = void 0),
        (this.internalVariant = void 0),
        (this.labels = void 0),
        (this.languages = void 0),
        (this.showNotification = !1),
        (this.baseSettings = void 0),
        (this.settingsLabels = void 0),
        (this.categories = null),
        (this.settingsId = void 0),
        (this.variant = void 0),
        (this.initialLanguage = void 0),
        (this.legalPages = void 0);
    }
    parseLegalPagesProp(t) {
      t && ((this.internalLegalPages = JSON.parse(t)), this.getFooterLinks());
    }
    componentWillLoad() {
      this.initializeUC(),
        this.handleVariantInitialization(),
        this.addWorkbenchLink(),
        this.parseLegalPagesProp(this.legalPages);
    }
    componentWillRender() {
      this.firstRender && this.initialLanguage
        ? this.UC?.changeLanguage(this.initialLanguage)
            .then()
            .catch()
            .finally(() => {
              (this.firstRender = !1), this.updateContent();
            })
        : this.updateContent();
    }
    componentDidRender() {
      this.bannerVisible &&
        this.internalVariant !== m.SettingsPage &&
        this.el &&
        setTimeout(() => {
          s(this.el);
        });
    }
    disconnectedCallback() {
      setTimeout(() => {
        a(this.el);
      }),
        l();
    }
    ucChangeLanguage() {
      this.updateContent();
    }
    privacyShieldShowModal(t) {
      this.toggleConsentInfoModal(t.detail.id);
    }
    consentsLoaded() {
      c(this.el), u(this.el);
    }
    consentsUpdated() {
      this.updateUsercentricsData(),
        this.createPrivacyShields(),
        this.removePrivacyShields(),
        a(this.el),
        l();
    }
    trackEvents(t) {
      p.trackEvent(this.UC, t.detail);
    }
    toggleHandler() {
      this.toggleConsentInfoModal();
    }
    toggleNotification() {
      this.showNotification = !1;
    }
    async getServices() {
      return this.UC?.getServicesFullInfo();
    }
    async updateServices(t, e) {
      (this.userDecision = this.updateUserDecision(t, e)),
        this.handlerSaveSelection();
    }
    async changeLanguage(t) {
      this.UC.changeLanguage(t).then(() => {
        this.updateContent(),
          this.dispatchCustomEvent("usercentrics-change-language", {
            language: t,
          });
      });
    }
    async getConsents() {
      return p.getAllConsents(this.categories);
    }
    async getConsentsByCategory() {
      return p.getConsentsByCategory(this.categories, this.bannerVisible);
    }
    async getLanguageSettings() {
      return this.baseSettings?.language;
    }
    async togglePrivacyShield(t, e = document, n, i) {
      Lr?.forEach(async (r) => {
        const o = t?.match(r.regex);
        if (!o) return;
        const s = () => e.querySelector("iframe"),
          a = () => e.querySelector("cmm-privacy-shield-overlay");
        if (await this.getConsentStatus(r)) {
          if (s()) return;
          const r = this.createIframe(t, n, i);
          if ((e.appendChild(r), !a())) return;
          e.removeChild(a());
        } else {
          if (a()) return;
          const o = this.createPrivacyShieldOverlay(r, t, n, i);
          if ((e.appendChild(o), !s())) return;
          e.removeChild(s());
        }
      });
    }
    async createPrivacyShields(t = document) {
      t.querySelectorAll("iframe")?.forEach((e, n) => {
        Lr?.forEach(async (i) => {
          const r = e.getAttribute("src"),
            o = r?.match(i.regex);
          if (!o) return;
          if (await this.getConsentStatus(i)) return;
          const s = this.createPrivacyShieldOverlay(
            i,
            r,
            e.offsetHeight,
            e.offsetWidth,
            n + 1
          );
          e.parentElement?.replaceChild(s, e),
            t
              .querySelector(`#privacy-shield-${n + 1}`)
              ?.shadowRoot?.appendChild(e);
        });
      });
    }
    async removePrivacyShields(t = document) {
      t.querySelectorAll("cmm-privacy-shield-overlay")?.forEach((t) => {
        Lr?.forEach(async (e) => {
          const n = t.shadowRoot.querySelector("iframe"),
            i = n?.getAttribute("src")?.match(e.regex);
          i &&
            (await this.getConsentStatus(e)) &&
            t.parentElement?.replaceChild(n, t);
        });
      });
    }
    async updatePrivacyShieldContent(t = document) {
      t.querySelectorAll("cmm-privacy-shield-overlay").forEach((t) => {
        t.setAttribute("language", this.currentLanguage),
          t.setAttribute("direction", this.direction),
          t.updateContent();
      });
    }
    async getLabelsForPrivacyShield(t) {
      return f(this.currentLanguage, t, this.labels);
    }
    async getDirection() {
      return Rr(this.currentLanguage);
    }
    createPrivacyShieldOverlay(t, e, n, i, r) {
      const o = document.createElement("cmm-privacy-shield-overlay");
      return (
        this.currentLanguage &&
          o.setAttribute("language", this.currentLanguage),
        this.direction && o.setAttribute("direction", this.direction),
        this.labels &&
          o.setAttribute("labels", `${JSON.stringify(this.labels)}`),
        t && o.setAttribute("technology", `${JSON.stringify(t)}`),
        e && o.setAttribute("src", e),
        n && o.setAttribute("height", `${n}`),
        i && o.setAttribute("width", `${i}`),
        r && o.setAttribute("id", `privacy-shield-${r}`),
        o
      );
    }
    createIframe(t, e, n) {
      const i = document.createElement("iframe");
      return (
        t && i.setAttribute("src", t),
        e && i.setAttribute("height", `${e}`),
        n && i.setAttribute("width", `${n}`),
        i
      );
    }
    dispatchUsercentricsConsentsLoaded() {
      const t = p.getAllConsents(this.categories);
      this.dispatchCustomEvent("usercentrics-consents-loaded", { consents: t });
    }
    initializeUC() {
      const t = new Dr(this.settingsId, { storeServiceIdToNameMapping: !0 });
      t.init().then((e) => {
        (this.UC = t), (this.categories = t.getCategoriesBaseInfo());
        const n = p.getAllConsents(this.categories);
        this.setConsentsInLocalStorage(n),
          (this.baseSettings = t.getSettingsCore()),
          (this.settingsLabels = t.getSettingsLabels()),
          (this.userDecision = p.getUserDecision(this.categories)),
          this.setInternalLabels().then(() => {
            if (
              (this.createPrivacyShields(),
              this.removePrivacyShields(),
              this.createMutationObservers(),
              (this.bannerVisible = 0 === e?.initialLayer),
              this.bannerVisible && p.trackEvent(this.UC, 1),
              this.isSettingsPage())
            )
              return null;
            this.dispatchUsercentricsConsentsLoaded(),
              this.isSmallScreen() && this.blockBodyScroll(this.bannerVisible);
          }),
          this.isPerformanceEnvironment();
      });
    }
    isPerformanceEnvironment() {
      const t = window?.location?.search,
        e = new URLSearchParams(t).get("pagespeed");
      e && "true" === e && !this.isSettingsPage()
        ? this.handlerAcceptAll()
        : (this.ucInitialized = !0);
    }
    async getConsentStatus(t) {
      return (await this.UC?.getServicesFullInfo())?.some((e) => {
        const n = e?.name?.includes(t?.id),
          i = e?.consent?.status;
        return n && i;
      });
    }
    handleVariantInitialization() {
      return this.variant || this.isSettingsPage()
        ? ((this.internalVariant = this.variant), Promise.resolve())
        : this.settingsId
        ? this.setInternalVariant()
        : ((this.variant = b), Promise.resolve());
    }
    addWorkbenchLink() {
      const t = window?.workbenchConfig || window?.workbench,
        e = document.querySelectorAll('link[href*="workbench/core/"]');
      if (
        (d(window, { transformTagName: (t) => `${t.replace("wb-", "wb7-")}` }),
        !t && !e.length)
      ) {
        const t = document.createElement("link");
        t.setAttribute(
          "href",
          "https://assets.oneweb.mercedes-benz.com/plugin/workbench/core/7.32.0/css/globals.css"
        ),
          t.setAttribute("rel", "stylesheet"),
          document.querySelector("cmm-cookie-banner").appendChild(t);
      }
    }
    isSettingsPage() {
      return this.variant === m.SettingsPage;
    }
    blockBodyScroll(t = !1) {
      if (!t)
        return document.body.classList.remove("cmp-cookie-banner--fixed"), null;
      document.body.classList.add("cmp-cookie-banner--fixed");
      const e = document.createElement("style");
      (e.textContent = ".cmp-cookie-banner--fixed { overflow: hidden }"),
        document.head.appendChild(e);
    }
    isSmallScreen() {
      return window.innerWidth < 768;
    }
    setInternalVariant() {
      return ((t = this.settingsId),
      fetch(
        `https://api.oneweb.mercedes-benz.com/cmm-var/v1/variants/settings/${t}`,
        { headers: { "Content-Type": "application/json" }, method: "GET" }
      )
        .then((t) => t.json())
        .then((t) => t)
        .catch((t) => {
          throw new Error(t);
        }))
        .then((t) => {
          const e = t?.variant;
          (this.internalVariant = e || b), (this.variant = e || b);
        })
        .catch(() => {
          (this.internalVariant = b), (this.variant = b);
        });
      var t;
    }
    async setInternalLabels() {
      const t = this.baseSettings?.language?.available,
        e = t?.join(","),
        n = { language: e, settingsId: this.settingsId },
        i = await ((t) => {
          const e = new URLSearchParams(t);
          return fetch(
            `https://api.oneweb.mercedes-benz.com/cmm-lab/v1/labels/findByLanguages?${e}`,
            { headers: { "Content-Type": "application/json" }, method: "GET" }
          )
            .then((t) => t.json())
            .then((t) => t)
            .catch((t) => {
              throw new Error(t);
            });
        })(n),
        r = i?.textLabels,
        o = i?.languages,
        s = [];
      r.forEach((t) => {
        const e = s.find((e) => Object.keys(e)[0] === t.language);
        if (e) {
          const n = s.indexOf(e);
          s[n][t.language][t.textKey] = t.text;
        } else s.push({ [t.language]: { [t.textKey]: t.text } });
      }),
        (this.languages = o),
        (this.labels = s);
    }
    handleCloseBanner() {
      this.internalVariant === m.Information && this.handlerAcceptAll();
    }
    handlerAcceptAll(t = !0) {
      p.acceptAllConsents(this.UC)
        .then(() => {
          p.trackEvent(this.UC, t ? 5 : 8), this.updateConsents();
        })
        .catch((t) => {
          console.error(
            t || "Error: There was an issue with accept all consents"
          );
        });
    }
    handlerDeny() {
      p.denyConsentsExceptRequired(this.UC)
        .then(() => {
          this.updateConsents(), p.trackEvent(this.UC, 3);
        })
        .catch((t) => {
          console.error(t || "Error: There was an issue with deny consents");
        });
    }
    handlerSaveSelection(t = !0) {
      p.saveConsentSelection(this.UC, this.userDecision)
        .then(() => {
          p.trackEvent(this.UC, t ? 7 : 10), this.updateConsents();
        })
        .catch((t) => {
          console.error(t || "Error: There was an issue with save consents");
        });
    }
    updateUsercentricsData() {
      (this.baseSettings = this.UC.getSettingsCore()),
        (this.settingsLabels = this.UC.getSettingsLabels()),
        (this.categories = this.UC.getCategoriesBaseInfo()),
        (this.userDecision = p.getUserDecision(this.categories));
    }
    updateContent() {
      (this.baseSettings = this.UC?.getSettingsCore()),
        (this.settingsLabels = this.UC?.getSettingsLabels()),
        (this.categories = this.UC?.getCategoriesBaseInfo()),
        (this.userDecision = p.getUserDecision(this.categories)),
        (this.currentLanguage = Nr(this.baseSettings)),
        (this.direction = Rr(this.currentLanguage)),
        (this.bannerLabels = ((t, e) => {
          const n = h(t, e),
            i = h("en", e)?.en,
            r = n?.[t];
          return {
            close: r?.close || i?.close,
            consentChanged: r?.consent_changed || i?.consent_changed,
            hideDetails: r?.hideDetails || i?.hideDetails,
            selectAll: r?.select_all || i?.select_all,
            showDetails: r?.showDetails || i?.showDetails,
          };
        })(this.currentLanguage, this.labels)),
        this.updatePrivacyShieldContent();
    }
    createMutationObservers() {
      new MutationObserver((t) => {
        t.forEach(() => {
          this.createPrivacyShields(), this.removePrivacyShields();
        });
      }).observe(document.body, { attributes: !1, childList: !0, subtree: !0 });
    }
    hideCustomBanner() {
      (this.bannerVisible = !1), this.blockBodyScroll();
    }
    setConsentsInLocalStorage(t) {
      const e = p.consentsArrayToObjectConverter(t);
      localStorage.setItem("cmp_consents", JSON.stringify(e));
    }
    updateConsents(t = !0) {
      this.updateUsercentricsData();
      const e = p.getAllConsents(this.categories);
      this.setConsentsInLocalStorage(e),
        this.dispatchCustomEvent("usercentrics-consents-updated", {
          consents: e,
        }),
        this.internalVariant === m.SettingsPage &&
          ((this.showNotification = t), this.hideNotification()),
        this.hideCustomBanner();
    }
    hideNotification() {
      setTimeout(() => {
        this.showNotification = !1;
      }, 1e4);
    }
    async toggleConsentInfoModal(t) {
      const e = document.querySelector("cmm-consent-overlay");
      if ((e?.parentNode.removeChild(e), t)) {
        this.bannerVisible &&
          this.internalVariant !== m.SettingsPage &&
          ((this.lastActiveElement = this.el.shadowRoot.activeElement),
          a(this.el),
          l());
        const e = (await this.UC?.getServicesFullInfo())?.find(
            (e) => e?.id === t
          ),
          n = this.el.shadowRoot
            .querySelector(
              `[data-test="handle-consent-change"][data-template-id="${t}"]`
            )
            ?.getAttribute("data-category"),
          i = document.createElement("cmm-consent-overlay");
        i.setAttribute("direction", this.direction),
          i.setAttribute(
            "settings-labels",
            `${JSON.stringify(this.settingsLabels)}`
          ),
          i.setAttribute("service-data", `${JSON.stringify(e)}`),
          i.setAttribute("category", n),
          document.body.appendChild(i);
      } else
        this.bannerVisible &&
          this.internalVariant !== m.SettingsPage &&
          (setTimeout(() => {
            this.lastActiveElement?.focus();
          }),
          c(this.el),
          u(this.el));
    }
    updateUserDecision(t, e) {
      return this.userDecision.map(
        (n) => (n.serviceId === t && (n.status = e), n)
      );
    }
    getStateForCheckbox(t, e) {
      let n = w.Partial;
      return t.length === e.length ? (n = w.All) : e.length || (n = w.None), n;
    }
    getStateForCategoryCheckbox(t) {
      const e = t.classList.contains(w.None),
        n = t.classList.contains(w.Partial);
      return e || n ? w.All : w.None;
    }
    setClassForCategoryCheckboxes(t, e) {
      t.forEach((t) => {
        null == t.getAttribute("disabled") &&
          (Object.values(w).forEach((e) => {
            t.classList.remove(e);
          }),
          t.classList.add(e));
      });
    }
    updateServiceCheckboxes(t, e) {
      t.forEach((t) => {
        null == t.getAttribute("disabled") && (t.checked = e === w.All);
        const n = t.getAttribute("data-template-id");
        this.userDecision = this.updateUserDecision(n, t.checked);
      });
    }
    setClassForSelectAllCheckbox(t) {
      Object.values(w).forEach((e) => {
        t.classList.remove(e);
      }),
        t.classList.add(p.getCheckboxAllClass(this.userDecision));
    }
    handleServiceChange(t) {
      const e = t.target,
        n = e.getAttribute("data-template-id"),
        i = e.getAttribute("data-category"),
        r = e.checked,
        o = this.el.shadowRoot.querySelector(
          `.cmm-cookie-banner.cmm-cookie-banner--${this.internalVariant}`
        ),
        s = o.querySelectorAll(
          `\n      [data-category-wrapper="${i}"] .consent-list input[type="checkbox"]`
        ),
        a = o.querySelectorAll(
          `\n      [data-category-wrapper="${i}"] .consent-list input[type="checkbox"]:checked`
        ),
        l = o.querySelectorAll(
          `\n    .category-label input[type="checkbox"][data-category="${i}"]`
        ),
        c = o.querySelector('.select-all--label input[type="checkbox"]'),
        u = this.getStateForCheckbox(s, a);
      this.setClassForCategoryCheckboxes(l, u),
        (this.userDecision = this.updateUserDecision(n, r)),
        this.setClassForSelectAllCheckbox(c);
    }
    handleCategoryChange(t) {
      const e = t.target,
        n = e.getAttribute("data-category"),
        i = this.el.shadowRoot.querySelector(
          `.cmm-cookie-banner.cmm-cookie-banner--${this.internalVariant}`
        ),
        r = i.querySelectorAll(
          `\n    [data-category-wrapper="${n}"] .consent-list input[type="checkbox"]`
        ),
        o = i.querySelectorAll(
          `\n      .category-label input[type="checkbox"][data-category="${n}"]`
        ),
        s = i.querySelector('.select-all--label input[type="checkbox"]'),
        a = this.getStateForCategoryCheckbox(e);
      this.setClassForCategoryCheckboxes(o, a),
        this.updateServiceCheckboxes(r, a),
        this.setClassForSelectAllCheckbox(s);
    }
    handleSelectAllChange(t) {
      const e = t.target,
        n = this.el.shadowRoot.querySelector(
          `.cmm-cookie-banner.cmm-cookie-banner--${this.internalVariant}`
        ),
        i = n.querySelectorAll(
          'input[type="checkbox"].cmm-checkbox-input--category'
        ),
        r = n.querySelectorAll('.consent-list input[type="checkbox"]'),
        o = this.getStateForCategoryCheckbox(e);
      this.setClassForCategoryCheckboxes(i, o),
        this.updateServiceCheckboxes(r, o),
        this.setClassForSelectAllCheckbox(e);
    }
    handleChangeLanguage(t) {
      const e = t.target.getAttribute("data-language");
      this.UC.changeLanguage(e).then(() => {
        this.updateContent(),
          this.dispatchCustomEvent("usercentrics-change-language", {
            language: e,
          });
      });
    }
    dispatchCustomEvent(t, e = {}) {
      const n = new CustomEvent(t, { bubbles: !0, detail: e });
      document?.dispatchEvent(n);
    }
    scrollToDetails(t) {
      const e = this.el.shadowRoot.querySelector(".cmm-cookie-banner__content"),
        n = e?.querySelector("#cookie-settings");
      if (
        (n &&
          !e?.classList.contains("settings-expanded") &&
          e.classList.add("settings-expanded"),
        n)
      ) {
        const i = n.querySelector(
          `.category-item[data-category-wrapper="${t}"]`
        );
        this.scrollToElement(e, i);
      }
    }
    handlerToggleDetails() {
      const t = this.el.shadowRoot.querySelector(".cmm-cookie-banner__content"),
        e = t?.querySelector("#cookie-settings");
      if (e)
        if (t?.classList.contains("settings-expanded"))
          t.classList.remove("settings-expanded");
        else {
          t.classList.add("settings-expanded");
          const n = e.querySelector(".select-all-item");
          this.scrollToElement(t, n);
        }
    }
    scrollToElement(t, e) {
      setTimeout(() => {
        t?.scrollTo &&
          t.scrollTo({ top: e?.offsetTop - 20, left: 0, behavior: "smooth" }),
          setTimeout(() => {
            s(e);
          }, 300);
      }, 300);
    }
    toggleCategoryDetails(t) {
      const e = t?.label;
      this.el.shadowRoot
        .querySelector(".cmm-cookie-banner__content")
        .querySelector(`.category-item[data-category-wrapper="${e}"]`)
        .classList.toggle("category-item--expanded");
    }
    getCookieSettingsLabels() {
      const t = this.settingsLabels,
        e = t?.buttons?.acceptAll,
        n = t?.buttons?.save,
        i = this.bannerLabels?.close,
        r = this.bannerLabels?.consentChanged,
        o = this.bannerLabels?.hideDetails,
        s = this.bannerLabels?.selectAll,
        a = this.bannerLabels?.showDetails;
      return {
        acceptAll: e,
        close: i,
        consentChanged: r,
        hideDetails: o,
        save: n,
        selectAll: s,
        showDetails: a,
      };
    }
    getHeadingContent() {
      const t = this.settingsLabels,
        e = t?.firstLayer?.title,
        n = t?.firstLayer?.description?.default,
        i = Fr(n)?.split("<br>");
      return {
        title: e,
        description: i.map((t) =>
          t.includes("---")
            ? t
                .replace("---", '<wb7-text class="hint-text" size="s">')
                .replace("---", "</wb7-text>")
            : t
        ),
      };
    }
    getButtonLabels() {
      const t = this.settingsLabels,
        e = t?.buttons?.acceptAll,
        n = t?.buttons?.denyAll,
        i = t?.buttons?.save,
        r = t?.buttons?.showSecondLayer,
        o = this.bannerLabels?.close,
        s = this.bannerLabels?.showDetails;
      return {
        acceptAll: e,
        close: o,
        deny: n,
        save: i,
        showDetails: s,
        toggle: r,
      };
    }
    getFooterLinks() {
      const t = this.legalPages && this.legalPages.length,
        e = this.settingsLabels,
        n = e?.links?.privacyPolicy?.label,
        i = e?.links?.imprint?.label,
        r = this.internalLegalPages?.[this.currentLanguage]?.imprint,
        o = this.internalLegalPages?.[this.currentLanguage]?.privacyPolicy;
      return [
        { url: t && r ? r : e?.links?.privacyPolicy?.url, label: n, event: 14 },
        { url: t && o ? o : e?.links?.imprint?.url, label: i, event: 12 },
      ];
    }
    bannerVisibility() {
      return this.bannerVisible ? "visible" : "";
    }
    render() {
      return n(
        i,
        null,
        this.internalVariant &&
          this.ucInitialized &&
          n(
            "div",
            {
              "data-nosnippet": !0,
              dir: this.direction,
              class: `cmm-cookie-banner cmm-cookie-banner--${this.internalVariant}`,
            },
            this.internalVariant !== m.SettingsPage
              ? n(
                  "div",
                  {
                    class: `cmm-cookie-banner__wrapper ${this.bannerVisibility()}`,
                    "aria-label": this.getHeadingContent().title,
                    "aria-modal": "true",
                    role: "dialog",
                    tabindex: 0,
                  },
                  n("div", {
                    class: "cmm-cookie-banner__overlay",
                    "data-test": "handle-close-banner",
                    onClick: () => this.handleCloseBanner(),
                  }),
                  n(
                    "div",
                    { class: "cmm-cookie-banner__content", tabIndex: 0 },
                    n("cmm-languages-list", {
                      languages: this.languages,
                      languageSelected: Nr(this.baseSettings),
                      handleChangeLanguage: (t) => this.handleChangeLanguage(t),
                    }),
                    n("cmm-heading-section", {
                      content: this.getHeadingContent(),
                    }),
                    this.internalVariant === m.Categories &&
                      n("cmm-category-overview", {
                        categories: this.categories,
                        handleCategoryChange: (t) =>
                          this.handleCategoryChange(t),
                        scrollToDetails: (t) => this.scrollToDetails(t),
                      }),
                    n("cmm-buttons-wrapper", {
                      labels: this.getButtonLabels(),
                      variant: this.internalVariant,
                      handlerAcceptAll: () => this.handlerAcceptAll(),
                      handlerDeny: () => this.handlerDeny(),
                      handlerToggleDetails: () => this.handlerToggleDetails(),
                      handlerSaveSelection: () => this.handlerSaveSelection(),
                    }),
                    n("cmm-footer-links", { links: this.getFooterLinks() }),
                    n("cmm-cookie-settings", {
                      categories: this.categories,
                      direction: this.direction,
                      labels: this.getCookieSettingsLabels(),
                      showNotification: this.showNotification,
                      userDecision: this.userDecision,
                      variant: this.internalVariant,
                      handleCategoryChange: (t) => this.handleCategoryChange(t),
                      handlerAcceptAll: () => this.handlerAcceptAll(!1),
                      handlerSaveSelection: () => this.handlerSaveSelection(!1),
                      handlerToggleDetails: () => this.handlerToggleDetails(),
                      handleSelectAllChange: (t) =>
                        this.handleSelectAllChange(t),
                      handleServiceChange: (t) => this.handleServiceChange(t),
                      toggleCategoryDetails: (t) =>
                        this.toggleCategoryDetails(t),
                      toggleConsentInfoModal: (t) =>
                        this.toggleConsentInfoModal(t),
                    })
                  )
                )
              : n(
                  "div",
                  { class: "cmm-cookie-banner__settings-page" },
                  n("cmm-heading-section", {
                    content: this.getHeadingContent(),
                  }),
                  n("cmm-cookie-settings", {
                    categories: this.categories,
                    direction: this.direction,
                    labels: this.getCookieSettingsLabels(),
                    showNotification: this.showNotification,
                    userDecision: this.userDecision,
                    variant: this.internalVariant,
                    handleCategoryChange: (t) => this.handleCategoryChange(t),
                    handlerAcceptAll: () => this.handlerAcceptAll(!1),
                    handlerSaveSelection: () => this.handlerSaveSelection(!1),
                    handlerToggleDetails: () => this.handlerToggleDetails(),
                    handleSelectAllChange: (t) => this.handleSelectAllChange(t),
                    handleServiceChange: (t) => this.handleServiceChange(t),
                    toggleCategoryDetails: (t) => this.toggleCategoryDetails(t),
                    toggleConsentInfoModal: (t) =>
                      this.toggleConsentInfoModal(t),
                  })
                )
          )
      );
    }
    get el() {
      return r(this);
    }
    static get watchers() {
      return { legalPages: ["parseLegalPagesProp"] };
    }
  };
Pr.style =
  '*,*::before,*::after{-webkit-box-sizing:border-box;box-sizing:border-box}html{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}body{margin:0;padding:0}summary{list-style-type:none}fieldset{border:none;padding:0}legend{padding:0}button{margin:0}.wb-skip-link{position:absolute;width:0.0625rem;height:0.0625rem;margin:0;clip:rect(0.0625rem, 0.0625rem, 0.0625rem, 0.0625rem);overflow:hidden}.wb-skip-link:focus{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem;margin:var(--wb-spacing-3xs);padding:var(--wb-spacing-3xs);display:inline-block;width:auto;height:auto;clip:initial;outline:0.0625rem solid;color:currentColor}.wb-skip-link:focus sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-skip-link:focus sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-grid-container{width:var(--wb-grid-width);margin:0 auto;position:relative;display:block}.wb-grid-container--full-width{max-width:100%;width:100%}.wb-grid-row{--vertical-grid-gap:var(--wb-spacing-3xs);display:grid;grid-template-columns:repeat(12, 1fr);grid-gap:var(--vertical-grid-gap) var(--wb-grid-gutter-width)}.wb-grid-col--allow-overflow-x{overflow-x:visible}.wb-grid-col--scroll-overflow-x{overflow-x:scroll}.wb-grid-col--auto-overflow{overflow:auto}.wb-grid-col-offset-mq1-auto{grid-column-start:auto}.wb-grid-col-offset-mq1-1{grid-column-start:1}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq1-2{grid-column-start:2}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq1-3{grid-column-start:3}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq1-4{grid-column-start:4}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq1-5{grid-column-start:5}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq1-6{grid-column-start:6}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq1-7{grid-column-start:7}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq1-8{grid-column-start:8}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq1-9{grid-column-start:9}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq1-10{grid-column-start:10}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq1-11{grid-column-start:11}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq1-12{grid-column-start:12}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-12{display:unset;grid-column-end:span 12}@media (min-width: 30rem){.wb-grid-col-offset-mq2-auto{grid-column-start:auto}.wb-grid-col-offset-mq2-1{grid-column-start:1}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq2-2{grid-column-start:2}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq2-3{grid-column-start:3}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq2-4{grid-column-start:4}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq2-5{grid-column-start:5}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq2-6{grid-column-start:6}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq2-7{grid-column-start:7}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq2-8{grid-column-start:8}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq2-9{grid-column-start:9}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq2-10{grid-column-start:10}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq2-11{grid-column-start:11}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq2-12{grid-column-start:12}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-12{display:unset;grid-column-end:span 12}}@media (min-width: 48rem){.wb-grid-col-offset-mq3-auto{grid-column-start:auto}.wb-grid-col-offset-mq3-1{grid-column-start:1}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq3-2{grid-column-start:2}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq3-3{grid-column-start:3}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq3-4{grid-column-start:4}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq3-5{grid-column-start:5}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq3-6{grid-column-start:6}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq3-7{grid-column-start:7}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq3-8{grid-column-start:8}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq3-9{grid-column-start:9}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq3-10{grid-column-start:10}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq3-11{grid-column-start:11}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq3-12{grid-column-start:12}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-12{display:unset;grid-column-end:span 12}}@media (min-width: 64rem){.wb-grid-col-offset-mq4-auto{grid-column-start:auto}.wb-grid-col-offset-mq4-1{grid-column-start:1}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq4-2{grid-column-start:2}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq4-3{grid-column-start:3}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq4-4{grid-column-start:4}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq4-5{grid-column-start:5}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq4-6{grid-column-start:6}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq4-7{grid-column-start:7}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq4-8{grid-column-start:8}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq4-9{grid-column-start:9}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq4-10{grid-column-start:10}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq4-11{grid-column-start:11}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq4-12{grid-column-start:12}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-12{display:unset;grid-column-end:span 12}}@media (min-width: 80rem){.wb-grid-col-offset-mq5-auto{grid-column-start:auto}.wb-grid-col-offset-mq5-1{grid-column-start:1}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq5-2{grid-column-start:2}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq5-3{grid-column-start:3}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq5-4{grid-column-start:4}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq5-5{grid-column-start:5}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq5-6{grid-column-start:6}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq5-7{grid-column-start:7}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq5-8{grid-column-start:8}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq5-9{grid-column-start:9}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq5-10{grid-column-start:10}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq5-11{grid-column-start:11}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq5-12{grid-column-start:12}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-12{display:unset;grid-column-end:span 12}}@media (min-width: 90rem){.wb-grid-col-offset-mq6-auto{grid-column-start:auto}.wb-grid-col-offset-mq6-1{grid-column-start:1}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq6-2{grid-column-start:2}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq6-3{grid-column-start:3}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq6-4{grid-column-start:4}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq6-5{grid-column-start:5}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq6-6{grid-column-start:6}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq6-7{grid-column-start:7}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq6-8{grid-column-start:8}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq6-9{grid-column-start:9}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq6-10{grid-column-start:10}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq6-11{grid-column-start:11}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq6-12{grid-column-start:12}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-12{display:unset;grid-column-end:span 12}}[class^=wb-scroll-lock],[class*=" wb-scroll-lock"]{position:fixed;width:100%;overflow-y:hidden}.wb-heading-xl{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2.5rem;line-height:3rem}@media (min-width: 64rem){.wb-heading-xl{font-size:4rem;line-height:4.5rem}}.wb-heading-xl sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xl sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2rem;line-height:2.5rem}@media (min-width: 64rem){.wb-heading-l{font-size:3rem;line-height:3.75rem}}.wb-heading-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:1.625rem;line-height:2rem}@media (min-width: 64rem){.wb-heading-m{font-size:2.125rem;line-height:2.75rem}}.wb-heading-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.25rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-s{font-size:1.5rem;line-height:2rem}}.wb-heading-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-xs{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.125rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-xs{font-size:1.25rem;line-height:1.75rem}}.wb-heading-xs sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xs sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-chinese{--wb-font-title:"Hanyi", "DaimlerCAC-Regular", "Hanyi-Ext", "SimSun", serif}.wb-text-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l{font-size:1.125rem;line-height:1.75rem}}.wb-text-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-l-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l-strong{font-size:1.125rem;line-height:1.75rem}}.wb-text-l-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m{font-size:1rem;line-height:1.5rem}}.wb-text-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m-strong{font-size:1rem;line-height:1.5rem}}.wb-text-m-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s{font-size:0.875rem;line-height:1.25rem}}.wb-text-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s-strong{font-size:0.875rem;line-height:1.25rem}}.wb-text-s-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}@font-face{font-family:"MBCorpo Title";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoATitleCond-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:bold;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Bold-Web.woff2") format("woff2")}@font-face{font-family:"DaimlerCAC-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCAC-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCS-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCS-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCACArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCACArab-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCSArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCSArab-Regular.woff2") format("woff2")}@font-face{font-family:"Hanyi";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi.woff") format("woff")}@font-face{font-family:"Hanyi-Ext";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi-Ext.woff") format("woff")}:root,:host{--wb-grid-gutter-width:0.5rem;--wb-grid-content-width:90vw;--wb-spacing-3xs:0.25rem;--wb-spacing-xxs:0.5rem;--wb-spacing-xs:1rem;--wb-spacing-s:1.5rem;--wb-spacing-m:2rem;--wb-spacing-l:3rem;--wb-spacing-xl:4rem;--wb-spacing-xxl:5rem;--wb-transparent:hsla(0, 0%, 0%, 0);--wb-white:hsl(0, 0%, 100%);--wb-white-opacity-high:hsla(0, 0%, 100%, 0.85);--wb-white-opacity-medium:hsla(0, 0%, 100%, 0.56);--wb-white-opacity-low:hsla(0, 0%, 100%, 0.25);--wb-white-opacity-extra-low:hsla(0, 0%, 100%, 0.15);--wb-black:hsl(0, 0%, 0%);--wb-black-opacity-high:hsla(0, 0%, 0%, 0.75);--wb-black-opacity-medium:hsla(0, 0%, 0%, 0.56);--wb-black-opacity-low:hsla(0, 0%, 0%, 0.1);--wb-black-opacity-extra-low:hsla(0, 0%, 0%, 0.05);--wb-blue-5:hsl(207.3, 100%, 8.6%);--wb-blue-10:hsl(206.8, 100%, 12.7%);--wb-blue-15:hsl(205.8, 100%, 16.9%);--wb-blue-20:hsl(206.6, 98.1%, 21.2%);--wb-blue-25:hsl(206.5, 98.4%, 25.3%);--wb-blue-30:hsl(207, 97.4%, 30%);--wb-blue-35:hsl(206.6, 97.7%, 33.9%);--wb-blue-40:hsl(206.5, 96.9%, 38.4%);--wb-blue-45:hsl(206.4, 100%, 42%);--wb-blue-50:hsl(206.4, 100%, 49.4%);--wb-blue-55:hsl(206.4, 97.4%, 54.3%);--wb-blue-60:hsl(206.4, 98.1%, 59.6%);--wb-blue-65:hsl(206.7, 97.8%, 64.9%);--wb-blue-70:hsl(206.2, 97.4%, 69.6%);--wb-blue-75:hsl(206.9, 100%, 75.1%);--wb-blue-80:hsl(206.4, 98%, 80%);--wb-blue-85:hsl(206.8, 97.4%, 85.1%);--wb-blue-90:hsl(207.1, 100%, 90%);--wb-blue-95:hsl(204, 100%, 95.1%);--wb-green-5:hsl(125.7, 67.7%, 6.1%);--wb-green-10:hsl(127.7, 68.9%, 8.8%);--wb-green-15:hsl(127.3, 67.2%, 12%);--wb-green-20:hsl(127.1, 66.2%, 15.1%);--wb-green-25:hsl(126.8, 67.4%, 18%);--wb-green-30:hsl(126.7, 66.7%, 21.2%);--wb-green-35:hsl(127.3, 67.2%, 23.9%);--wb-green-40:hsl(126.5, 66.7%, 27.1%);--wb-green-45:hsl(127, 67.3%, 30%);--wb-green-50:hsl(126.9, 66.3%, 38.4%);--wb-green-55:hsl(127.2, 51.5%, 44.5%);--wb-green-60:hsl(126.9, 41.3%, 50.6%);--wb-green-65:hsl(126.6, 41.6%, 57.1%);--wb-green-70:hsl(126.9, 41.5%, 63.1%);--wb-green-75:hsl(127.4, 41.4%, 69.2%);--wb-green-80:hsl(126.9, 41.3%, 75.3%);--wb-green-85:hsl(127.7, 41.1%, 81.4%);--wb-green-90:hsl(126.9, 41.9%, 87.8%);--wb-green-95:hsl(124.6, 41.9%, 93.9%);--wb-red-5:hsl(0, 72%, 9.8%);--wb-red-10:hsl(0, 73.3%, 14.7%);--wb-red-15:hsl(0, 74%, 19.6%);--wb-red-20:hsl(0, 73%, 24.7%);--wb-red-25:hsl(0, 73.3%, 29.4%);--wb-red-30:hsl(0, 73.7%, 34.3%);--wb-red-35:hsl(358, 71.2%, 40.8%);--wb-red-40:hsl(0, 73.3%, 44.1%);--wb-red-45:hsl(0, 73.6%, 49%);--wb-red-50:hsl(0, 100%, 64.5%);--wb-red-55:hsl(0, 100%, 68%);--wb-red-60:hsl(0, 100%, 71.6%);--wb-red-65:hsl(0, 100%, 75.1%);--wb-red-70:hsl(0, 100%, 78.6%);--wb-red-75:hsl(0, 100%, 82.4%);--wb-red-80:hsl(0, 100%, 85.9%);--wb-red-85:hsl(0, 100%, 89.4%);--wb-red-90:hsl(0, 100%, 92.9%);--wb-red-95:hsl(0, 100%, 96.5%);--wb-yellow-5:hsl(49.6, 100%, 9%);--wb-yellow-10:hsl(48.9, 100%, 13.7%);--wb-yellow-15:hsl(49, 100%, 18.2%);--wb-yellow-20:hsl(49.1, 100%, 22.7%);--wb-yellow-25:hsl(48.8, 100%, 27.3%);--wb-yellow-30:hsl(48.9, 100%, 31.8%);--wb-yellow-35:hsl(48.7, 100%, 36.5%);--wb-yellow-40:hsl(48.8, 100%, 41%);--wb-yellow-45:hsl(48.9, 100%, 45.5%);--wb-yellow-50:hsl(49, 100%, 49%);--wb-yellow-55:hsl(48.8, 96.6%, 54.3%);--wb-yellow-60:hsl(48.9, 96.2%, 59.2%);--wb-yellow-65:hsl(48.8, 96.7%, 64.3%);--wb-yellow-70:hsl(48.8, 96.2%, 69.4%);--wb-yellow-75:hsl(49, 96.9%, 74.7%);--wb-yellow-80:hsl(49.2, 96.2%, 79.6%);--wb-yellow-85:hsl(48.8, 97.4%, 84.9%);--wb-yellow-90:hsl(49.2, 96.2%, 89.8%);--wb-yellow-95:hsl(48, 100%, 95.1%);--wb-grey-5:hsl(0, 0%, 5.1%);--wb-grey-10:hsl(0, 0%, 10.2%);--wb-grey-15:hsl(0, 0%, 14.9%);--wb-grey-20:hsl(0, 0%, 20%);--wb-grey-25:hsl(0, 0%, 25.9%);--wb-grey-30:hsl(0, 0%, 31%);--wb-grey-35:hsl(0, 0%, 36.1%);--wb-grey-40:hsl(0, 0%, 41.2%);--wb-grey-45:hsl(0, 0%, 46.3%);--wb-grey-50:hsl(0, 0%, 51.8%);--wb-grey-55:hsl(0, 0%, 56.9%);--wb-grey-60:hsl(0, 0%, 62.4%);--wb-grey-65:hsl(0, 0%, 67.8%);--wb-grey-70:hsl(0, 0%, 73.3%);--wb-grey-75:hsl(0, 0%, 78.8%);--wb-grey-80:hsl(0, 0%, 85.9%);--wb-grey-85:hsl(0, 0%, 91%);--wb-grey-90:hsl(0, 0%, 95.7%);--wb-grey-95:hsl(0, 0%, 97.3%);--wb-mb-brand:hsl(206.4, 100%, 42%);--wb-mb-background:hsl(0, 0%, 100%);--wb-amg-red-5:hsl(0, 86%, 29%);--wb-amg-red-10:hsl(0, 86%, 29%);--wb-amg-red-15:hsl(0, 86%, 29%);--wb-amg-red-20:hsl(0, 86%, 29%);--wb-amg-red-25:hsl(0, 86%, 29%);--wb-amg-red-30:hsl(0, 86%, 29%);--wb-amg-red-35:hsl(358, 71.2%, 40.8%);--wb-amg-red-40:hsl(358, 71.2%, 40.8%);--wb-amg-red-45:hsl(358, 71.2%, 40.8%);--wb-amg-red-50:hsl(358, 71.2%, 40.8%);--wb-amg-red-55:hsl(358, 71.2%, 40.8%);--wb-amg-red-60:hsl(358, 71.2%, 40.8%);--wb-amg-red-65:hsl(358, 71.2%, 40.8%);--wb-amg-red-70:hsl(358, 71.2%, 40.8%);--wb-amg-red-75:hsl(358, 71.2%, 40.8%);--wb-amg-red-80:hsl(358, 71.2%, 40.8%);--wb-amg-red-85:hsl(358, 71.2%, 40.8%);--wb-amg-red-90:hsl(358, 71.2%, 40.8%);--wb-amg-red-95:hsl(358, 71.2%, 40.8%);--wb-amg-brand:hsl(358, 71.2%, 40.8%);--wb-amg-background:hsl(0, 0%, 0%);--wb-maybach-black-5:hsl(0, 0%, 0%);--wb-maybach-black-10:hsl(0, 0%, 0%);--wb-maybach-black-15:hsl(0, 0%, 0%);--wb-maybach-black-20:hsl(0, 0%, 0%);--wb-maybach-black-25:hsl(0, 0%, 20%);--wb-maybach-black-30:hsl(0, 0%, 0%);--wb-maybach-black-35:hsl(0, 0%, 20%);--wb-maybach-black-40:hsl(0, 0%, 20%);--wb-maybach-black-45:hsl(0, 0%, 0%);--wb-maybach-black-50:hsl(0, 0%, 0%);--wb-maybach-black-55:hsl(0, 0%, 0%);--wb-maybach-black-60:hsl(0, 0%, 20%);--wb-maybach-black-65:hsl(0, 0%, 20%);--wb-maybach-black-70:hsl(0, 0%, 20%);--wb-maybach-black-75:hsl(0, 0%, 20%);--wb-maybach-black-80:hsl(0, 0%, 20%);--wb-maybach-black-85:hsl(0, 0%, 20%);--wb-maybach-black-90:hsl(0, 0%, 20%);--wb-maybach-black-95:hsl(0, 0%, 20%);--wb-maybach-brand:hsl(0, 0%, 0%);--wb-maybach-background:hsl(36, 23.1%, 87.3%);--wb-font-title:"MBCorpo Title", "DaimlerCAC-Regular", "DaimlerCACArab-Regular", serif;--wb-font-text:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-font-text-bold:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-shadow-s:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.125rem 0.25rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-m:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.25rem 0.5rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-l:0 0 0.25rem 0 rgba(0, 0, 0, 0.1), 0 1rem 1.5rem 0 rgba(0, 0, 0, 0.1);--wb-fade:cubic-bezier(0, 0, 0.3, 1);--wb-move:cubic-bezier(0.3, 0, 0, 1);--wb-open:cubic-bezier(0.25, 0.1, 0.25, 1);--wb-border-width-none:0rem;--wb-border-width-s:0.0625rem;--wb-border-width-m:0.125rem;--wb-radius-none:0rem;--wb-radius-s:0.125rem;--wb-radius-m:0.25rem;--wb-radius-l:0.5rem;--wb-radius-full:50%;--wb-grid-width:min(var(--wb-grid-content-width), 105rem);--wb-grid-column-width:min(calc((var(--wb-grid-content-width) - 11 * var(--wb-grid-gutter-width)) / 12), 6.9166666667rem);--wb-opacity-1:5%;--wb-opacity-2:25%;--wb-opacity-3:40%;--wb-opacity-4:50%;--wb-opacity-5:75%;--wb-opacity-6:100%;--wb-opacity-none:0%;--wb-opacity-base:100%;--linear-gradient-blue-45:linear-gradient(to top, var(--wb-blue-45) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-blue-50:linear-gradient(to top, var(--wb-blue-50) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-white:linear-gradient(to top, var(--wb-white) 1px, transparent 1px);--linear-gradient-black:linear-gradient(to top, var(--wb-black) 1px, transparent 1px)}@media (min-width: 48rem){:root,:host{--wb-grid-gutter-width:1rem;--wb-grid-content-width:86vw}}@media (min-width: 64rem){:root,:host{--wb-spacing-xs:1.5rem;--wb-spacing-s:2rem;--wb-spacing-m:3rem;--wb-spacing-l:4rem;--wb-spacing-xl:5rem;--wb-spacing-xxl:5.5rem}}@media (min-width: 80rem){:root,:host{--wb-grid-gutter-width:1.5rem}}@media (min-width: 90rem){:root,:host{--wb-grid-gutter-width:2rem;--wb-spacing-l:4.5rem;--wb-spacing-xl:5.5rem;--wb-spacing-xxl:6rem}}wb-360-viewer:not(:defined),wb-accordion:not(:defined),wb-accordion-item:not(:defined),wb-aspect-ratio:not(:defined),wb-banner-teaser:not(:defined),wb-bar-loader:not(:defined),wb-breadcrumb:not(:defined),wb-breadcrumbs:not(:defined),wb-button-group-item:not(:defined),wb-button-group:not(:defined),wb-button:not(:defined),wb-card-layout-nba:not(:defined),wb-card:not(:defined),wb-checkbox:not(:defined),wb-control-error:not(:defined),wb-control-hint:not(:defined),wb-counter:not(:defined),wb-data-table:not(:defined),wb-datepicker-control:not(:defined),wb-datepicker:not(:defined),wb-dot-navigation:not(:defined),wb-dropdown:not(:defined),wb-eco-label:not(:defined),wb-eco-rating:not(:defined),wb-error-section:not(:defined),wb-file-input:not(:defined),wb-fly-in:not(:defined),wb-gallery:not(:defined),wb-gallery-item:not(:defined),wb-grid:not(:defined),wb-grid-col:not(:defined),wb-grid-row:not(:defined),wb-header-bar:not(:defined),wb-header-button:not(:defined),wb-header-desktop-fly-in:not(:defined),wb-header-fly-in-container:not(:defined),wb-header-fly-in-item:not(:defined),wb-header-language-menu-item:not(:defined),wb-header-language-menu:not(:defined),wb-header-meta-link:not(:defined),wb-header-mobile-fly-in:not(:defined),wb-header-navigation-item:not(:defined),wb-header-navigation:not(:defined),wb-header-tool-list-item:not(:defined),wb-header-tool-list:not(:defined),wb-heading:not(:defined),wb-highlight-slider:not(:defined),wb-horizontal-scroll:not(:defined),wb-icon:not(:defined),wb-info-item:not(:defined),wb-input-action:not(:defined),wb-input:not(:defined),wb-interactive-tag:not(:defined),wb-link:not(:defined),wb-list-group-item:not(:defined),wb-list-group:not(:defined),wb-list-item:not(:defined),wb-list:not(:defined),wb-load-more:not(:defined),wb-modal-level:not(:defined),wb-modal:not(:defined),wb-multi-select:not(:defined),wb-notification-host:not(:defined),wb-notification:not(:defined),wb-overlay-context:not(:defined),wb-pagination:not(:defined),wb-placeholder:not(:defined),wb-popover:not(:defined),wb-price:not(:defined),wb-progress:not(:defined),wb-radio-button:not(:defined),wb-radio-group:not(:defined),wb-range-slider:not(:defined),wb-round-button:not(:defined),wb-select:not(:defined),wb-selection-card:not(:defined),wb-skeleton:not(:defined),wb-slider:not(:defined),wb-slider-item:not(:defined),wb-sphere-view:not(:defined),wb-spinner:not(:defined),wb-stage:not(:defined),wb-step:not(:defined),wb-stepper:not(:defined),wb-subnavigation:not(:defined),wb-subnavigation-fly-in:not(:defined),wb-subnavigation-fly-in-item:not(:defined),wb-subnavigation-item:not(:defined),wb-tab:not(:defined),wb-tab-content:not(:defined),wb-table:not(:defined),wb-table-cell:not(:defined),wb-table-header:not(:defined),wb-table-row:not(:defined),wb-tabs:not(:defined),wb-tag:not(:defined),wb-text:not(:defined),wb-toggle:not(:defined),wb-tooltip:not(:defined),wb-tree:not(:defined),wb-tree-items:not(:defined),wb-value-slider:not(:defined),wb-vehicle-tile:not(:defined),wb-vertical-scroll:not(:defined),wb-video:not(:defined),wb-visually-hidden:not(:defined){visibility:hidden}[theme=light]{}[theme=dark]{}:host{--cmm-color-overlay-opacity:rgb(0 0 0 / 40%);--cmm-color-modal-opacity:rgb(0 0 0 / 80%)}:host .cmm-cookie-banner__wrapper{position:fixed;top:0;left:0;right:0;bottom:0;color:var(--wb-grey-15, #262626);z-index:2000;opacity:0;visibility:hidden;-webkit-transition:opacity 0.25s, visibility 0.25s;transition:opacity 0.25s, visibility 0.25s}:host .cmm-cookie-banner__wrapper.visible{opacity:1;visibility:visible}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:var(--cmm-color-overlay-opacity, rgba(0, 0, 0, 0.4));color:var(--wb-grey-15, #262626);-webkit-transition:opacity 0.25s, visibility 0.25s;transition:opacity 0.25s, visibility 0.25s;z-index:2001}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content{position:absolute;bottom:0;left:0;right:0;margin:0 auto;width:95%;max-width:1200px;max-height:70vh;background-color:var(--wb-white, #fff);padding:var(--wb-spacing-xs, 1rem) var(--wb-spacing-xs, 1rem) 0 var(--wb-spacing-xs, 1rem);border-top-right-radius:4px;border-top-left-radius:4px;-webkit-box-shadow:0 0 4px 0 rgba(0, 0, 0, 0.1), 0 16px 24px 0 rgba(0, 0, 0, 0.1);box-shadow:0 0 4px 0 rgba(0, 0, 0, 0.1), 0 16px 24px 0 rgba(0, 0, 0, 0.1);overflow-x:hidden;overflow-y:auto;-webkit-overflow-scrolling:touch;z-index:2002;outline:none}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .main-title{margin:0 0 var(--wb-spacing-xs, 1rem)}@media screen and (min-width: 768px){:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .main-title{font-family:var(--wb-font-title, "MBCorpo Title", "DaimlerCAC-Regular", "DaimlerCACArab-Regular", serif);font-style:normal;font-weight:400;font-size:2.125rem;line-height:2.75rem}}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .main-description{margin-bottom:var(--wb-spacing-xs, 1rem)}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .hint-text{margin:var(--wb-spacing-xs, 1rem) 0}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .toggle-button>cmm-icon{-webkit-transform:rotate(180deg);transform:rotate(180deg);-webkit-transition:250ms;transition:250ms}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content.settings-expanded #cookie-settings{display:block}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content.settings-expanded .toggle-button>cmm-icon{-webkit-transform:rotate(0);transform:rotate(0)}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .category-item .consent-list{display:none}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .category-item .toggle-button cmm-icon{-webkit-transform:rotate(180deg);transform:rotate(180deg);-webkit-transition:250ms;transition:250ms}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .category-item--expanded .consent-list{display:grid}:host .cmm-cookie-banner__wrapper .cmm-cookie-banner__content .category-item--expanded .toggle-button cmm-icon{-webkit-transform:rotate(0deg);transform:rotate(0deg);-webkit-transition:250ms;transition:250ms}:host .toggle-button{padding:0;border:none;outline:none;background:none;display:block;font-size:1rem;cursor:pointer;margin:0 auto var(--wb-spacing-xs, 1rem);color:var(--wb-blue-45, #0078d6)}:host .toggle-button cmm-icon{display:block;width:32px;height:auto;margin:0 auto}:host .button-group{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}@media screen and (min-width: 768px){:host .button-group{-ms-flex-direction:row;flex-direction:row;-ms-flex-pack:end;justify-content:flex-end}}:host .button-group .button{width:100%;margin-bottom:var(--wb-spacing-xs, 1rem);text-align:center}:host .button-group .button--accept-all{-ms-flex-order:1;order:1}:host .button-group .button--toggle-cookie-details{-ms-flex-order:2;order:2}:host .button-group .button--only-technically-necessary,:host .button-group .button--confirm-selection{-ms-flex-order:3;order:3}:host .button-group .button__icon{margin-right:0.5rem}@media screen and (min-width: 768px){:host .button-group .button{width:auto;margin:0 0 1rem 1rem}:host .button-group .button--accept-all{-ms-flex-order:3;order:3}:host .button-group .button--toggle-cookie-details{-ms-flex-order:2;order:2}:host .button-group .button--only-technically-necessary,:host .button-group .button--confirm-selection{-ms-flex-order:1;order:1}}:host .cmm-cookie-banner__settings-page{background-color:var(--wb-white, #fff);color:var(--wb-grey-15, #262626);padding:var(--wb-spacing-m, 2rem) var(--wb-spacing-xs, 1rem)}:host .cmm-cookie-banner__settings-page .main-title{margin:0 0 var(--wb-spacing-xs, 1rem) 0}:host .cmm-cookie-banner__settings-page .main-description{margin-bottom:var(--wb-spacing-xs, 1rem)}:host .cmm-cookie-banner__settings-page .hint-text{margin:var(--wb-spacing-xs, 1rem) 0}@media screen and (min-width: 768px){:host .cmm-cookie-banner__settings-page .main-title{font-family:var(--wb-font-title, "MBCorpo Title", "DaimlerCAC-Regular", "DaimlerCACArab-Regular", serif);font-style:normal;font-weight:400;font-size:2.125rem;line-height:2.75rem}}:host .cmm-cookie-banner__settings-page #cookie-settings{display:block}:host #cookie-settings{display:none}:host .select-all-item{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem;display:-ms-flexbox;display:flex;margin-bottom:var(--wb-spacing-s, 2rem)}@media (min-width: 64rem){:host .select-all-item{font-size:1rem;line-height:1.5rem}}:host .select-all-item sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}:host .select-all-item sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}:host .category-overview{margin:var(--wb-spacing-xs, 1rem) 0}@media screen and (min-width: 768px){:host .category-overview{display:-ms-flexbox;display:flex;-ms-flex-pack:justify;justify-content:space-between}}:host .category-overview-item{font-size:17px;margin:0}@media screen and (max-width: 768px){:host .category-overview-item{margin:var(--wb-spacing-xxs, 0.5rem) 0}}@media screen and (min-width: 1080px){:host .category-overview-item{-ms-flex:1;flex:1}}:host .category-overview-item .cmm-checkbox-fake{font-size:27px}:host .category-item:not(:last-of-type)::after{content:"";display:block;width:50px;height:1px;background:var(--wb-black, #000);margin:var(--wb-spacing-s, 2rem) 0 var(--wb-spacing-s, 2rem)}:host .category-select-all{font-weight:bold;display:-ms-flexbox;display:flex}:host .category-description{margin:var(--wb-spacing-xs, 1rem) 0}:host .consent-list{padding-left:var(--wb-spacing-m, 2rem);margin-bottom:var(--wb-spacing-xs, 1rem);display:grid;grid-template-columns:1fr;width:100%}@media screen and (min-width: 768px){:host .consent-list{grid-template-columns:1fr 1fr}}@media screen and (min-width: 1080px){:host .consent-list{grid-template-columns:1fr 1fr 1fr}}:host .consent-item{display:-ms-flexbox;display:flex;-moz-column-break-inside:avoid;-webkit-column-break-inside:avoid;break-inside:avoid;margin-bottom:var(--wb-spacing-xs, 1rem)}@media screen and (min-width: 1080px){:host .consent-item{padding-right:var(--wb-spacing-m, 2rem);line-height:1.4}}:host .consent-item__information{-ms-flex-positive:2;flex-grow:2}:host .consent-item__name{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem;display:inline;margin-right:0.5em}@media (min-width: 64rem){:host .consent-item__name{font-size:1rem;line-height:1.5rem}}:host .consent-item__name sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}:host .consent-item__name sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}:host .consent-item__icon{padding:0;border:none;outline:none;background:none;display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-ms-flex-negative:0;flex-shrink:0;font-size:1rem;width:1.4em;height:1.4em;color:var(--wb-grey-60, #9f9f9f);cursor:pointer;vertical-align:bottom}:host .consent-item__icon:focus{outline-offset:0.3125rem;outline-style:solid;outline-width:0.0625rem}:host [dir=rtl].cmm-cookie-banner .cmm-checkbox-fake{margin-left:10px;margin-right:0}:host [dir=rtl].cmm-cookie-banner .consent-item__name{margin-right:0;margin-left:0.5em}ul{list-style:none;margin:0;padding:0}.cmm-checkbox{display:-ms-flexbox;display:flex;-ms-flex-align:start;align-items:flex-start;-ms-flex-pack:start;justify-content:flex-start;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;margin-right:0.75em;--checkbox-size:23px}.cmm-checkbox input{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0, 0, 0, 0);white-space:nowrap;-webkit-clip-path:inset(50%);clip-path:inset(50%);border:0}.cmm-checkbox input:not([disabled],.cmm-checkbox-input--category):checked+.cmm-checkbox-fake,.cmm-checkbox input:not([disabled]).selected-all+.cmm-checkbox-fake{background:var(--wb-blue-45, #0078d6);border-color:var(--wb-blue-45, #0078d6)}.cmm-checkbox input.cmm-checkbox-input--category.selected-partial+.cmm-checkbox-fake{background:var(--wb-blue-45, #0078d6);border-color:var(--wb-blue-45, #0078d6)}.cmm-checkbox input.cmm-checkbox-input--category.selected-partial+.cmm-checkbox-fake::after{content:"";width:0.6em;height:2px;background:var(--wb-white, #fff)}.cmm-checkbox input:not(.cmm-checkbox-input--category):checked+.cmm-checkbox-fake::after,.cmm-checkbox input.selected-all+.cmm-checkbox-fake::after{content:"";width:0.67em;height:0.25em;border-bottom:2px solid var(--wb-white, #fff);border-left:2px solid var(--wb-white, #fff);-webkit-transform:rotate(-45deg) translate(0.04em, -0.025em);transform:rotate(-45deg) translate(0.04em, -0.025em)}.cmm-checkbox input[disabled]+.cmm-checkbox-fake{background:var(--wb-grey-70, #bbb);cursor:not-allowed}.cmm-checkbox input:focus+.cmm-checkbox-fake{outline:1px solid var(--wb-blue-45, #0078d6)}.cmm-checkbox-fake{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;-ms-flex-negative:0;flex-shrink:0;font-size:var(--checkbox-size);width:1em;height:1em;border:1px solid var(--wb-grey-70, #bbb);background:var(--wb-grey-95, #f8f8f8);margin-right:10px;cursor:pointer}';
const Ur = class {
  constructor(e) {
    t(this, e),
      (this.categories = null),
      (this.direction = "ltr"),
      (this.labels = null),
      (this.showNotification = void 0),
      (this.userDecision = void 0),
      (this.variant = void 0),
      (this.handleCategoryChange = void 0),
      (this.handlerAcceptAll = void 0),
      (this.handlerSaveSelection = void 0),
      (this.handlerToggleDetails = void 0),
      (this.handleSelectAllChange = void 0),
      (this.handleServiceChange = void 0),
      (this.toggleCategoryDetails = void 0),
      (this.toggleConsentInfoModal = void 0);
  }
  getCategoryDescription(t) {
    const e = Fr(t)?.split("<br>");
    return e.map((t) => {
      let e = t;
      if (t.includes("<a")) {
        const n = document.createElement("div");
        (n.innerHTML = t),
          n.querySelectorAll("a").forEach((t) => {
            t.removeAttribute("style"),
              t.removeAttribute("class"),
              t.setAttribute("variant", "inline"),
              t.setAttribute("target", "_blank");
          }),
          (e = n.innerHTML
            .replace(/<a/g, "<wb7-link")
            .replace(/<\/a/g, "</wb7-link"));
      }
      return e;
    });
  }
  render() {
    return n(
      i,
      null,
      n(
        "div",
        { id: "cookie-settings" },
        n(
          "div",
          { class: "cookie-settings-content" },
          n(
            "ul",
            null,
            n(
              "li",
              { class: "select-all-item" },
              n(
                "label",
                { class: "select-all--label cmm-checkbox" },
                n("input", {
                  type: "checkbox",
                  checked: !1,
                  class: `cmm-checkbox-input cmm-checkbox-input--category ${p.getCheckboxAllClass(
                    this.userDecision
                  )}`,
                  "data-test": "handle-select-all-change",
                  onClick: (t) => this.handleSelectAllChange(t),
                }),
                n("div", { class: "cmm-checkbox-fake" }),
                this.labels?.selectAll
              )
            ),
            this.categories?.map((t) =>
              n(
                "li",
                {
                  class: "category-item",
                  "data-category-wrapper": t.label,
                  key: t.label,
                },
                n(
                  "div",
                  { class: "category-select-all" },
                  n(
                    "label",
                    { class: "category-label cmm-checkbox" },
                    n("input", {
                      type: "checkbox",
                      checked: p.getCategoryChecked(t) || t.isEssential,
                      class: `cmm-checkbox-input cmm-checkbox-input--category ${p.getCheckboxClass(
                        t
                      )}`,
                      disabled: t.isEssential,
                      "data-category": t.label,
                      "data-test": "handle-category-change",
                      onClick: (t) => this.handleCategoryChange(t),
                    }),
                    n("div", { class: "cmm-checkbox-fake" }),
                    t.label
                  )
                ),
                t.description &&
                  Array.isArray(this.getCategoryDescription(t.description))
                  ? this.getCategoryDescription(t.description).map((e) =>
                      n("wb7-text", {
                        class: "category-description",
                        size: "m",
                        innerHTML: e,
                        key: `category-${t.slug}`,
                      })
                    )
                  : "",
                this.variant !== m.SettingsPage &&
                  n(
                    "wb7-button",
                    {
                      class: "toggle-button",
                      size: "s",
                      variant: "tertiary",
                      "data-test": "toggle-category-details",
                      "aria-label": this.labels?.showDetails,
                      onClick: () => this.toggleCategoryDetails(t),
                    },
                    n("cmm-icon", { name: o.ARROW_UP })
                  ),
                n(
                  "ul",
                  { class: "consent-list" },
                  t?.services?.map((e) =>
                    n(
                      "li",
                      { class: "consent-item" },
                      n(
                        "label",
                        { class: "consent-label cmm-checkbox" },
                        n("input", {
                          type: "checkbox",
                          checked: e.consent.status,
                          class: "cmm-checkbox-input",
                          disabled: e.isEssential || t.isEssential,
                          onClick: (t) => this.handleServiceChange(t),
                          "data-test": "handle-consent-change",
                          "data-template-id": e.id,
                          "data-category": t.label,
                        }),
                        n("div", { class: "cmm-checkbox-fake" }),
                        n(
                          "div",
                          { class: "consent-item__information" },
                          n("span", { class: "consent-item__name" }, e.name),
                          n(
                            "button",
                            {
                              type: "button",
                              class: "consent-item__icon",
                              "data-test": "toggle-consent-info-modal",
                              "aria-label": e.name,
                              onClick: () => this.toggleConsentInfoModal(e.id),
                            },
                            n("cmm-icon", { name: o.INFO })
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
          ),
          this.variant !== m.SettingsPage &&
            n(
              "wb7-button",
              {
                class: "toggle-button",
                "data-test": "toggle-cookie-details",
                variant: "tertiary",
                size: "s",
                onClick: () => this.handlerToggleDetails(),
              },
              n("cmm-icon", { name: o.ARROW_UP, "aria-hidden": "true" }),
              this.labels?.hideDetails
            ),
          n(
            "div",
            { class: "button-group" },
            this.variant !== m.Information &&
              n(
                "wb7-button",
                {
                  class: "button button--confirm-selection",
                  "data-test": "handle-confirm-selection-button",
                  variant: "secondary",
                  size: "s",
                  onClick: () => this.handlerSaveSelection(),
                },
                this.labels?.save
              ),
            n(
              "wb7-button",
              {
                class: "button button--accept-all",
                "data-test": "handle-accept-all-button",
                variant: "secondary",
                size: "s",
                onClick: () => this.handlerAcceptAll(),
              },
              this.variant === m.Information
                ? this.labels?.close
                : this.labels?.acceptAll
            )
          ),
          this.showNotification &&
            n("cmm-notification", {
              direction: this.direction,
              content: this.labels?.consentChanged,
            })
        )
      )
    );
  }
};
Ur.style =
  ".toggle-button{margin:0 auto var(--wb-spacing-xs, 1rem);display:block;width:-moz-fit-content;width:-webkit-fit-content;width:fit-content}.category-label{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.category-label{font-size:1rem;line-height:1.5rem}}.category-label sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.category-label sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}";
const jr = class {
  constructor(n) {
    t(this, n),
      (this.trackEvent = e(this, "trackEvent", 7)),
      (this.links = void 0);
  }
  handleClick(t, e) {
    this.trackEvent.emit(e.event);
  }
  render() {
    return (
      !!this.links &&
      n(
        i,
        null,
        n(
          "footer",
          { class: "footer-links" },
          n(
            "ul",
            { class: "footer-links__list", "data-test": "footer-links" },
            this.links.map((t, e) =>
              n(
                "li",
                { key: `link-${e}` },
                n(
                  "wb7-link",
                  {
                    class: "footer-links__list__item",
                    href: t.url,
                    variant: "standalone",
                    onClick: (e) => this.handleClick(e, t),
                  },
                  t.label
                )
              )
            )
          )
        )
      )
    );
  }
};
jr.style =
  "@media screen and (min-width: 768px){.footer-links{display:-ms-flexbox;display:flex;-ms-flex-flow:row-reverse;flex-flow:row-reverse;-ms-flex-pack:justify;justify-content:space-between;-ms-flex-align:center;align-items:center}}.footer-links__list{display:-ms-flexbox;display:flex;-ms-flex-pack:end;justify-content:flex-end;margin-bottom:var(--wb-spacing-xs, 1rem)}.footer-links__list__item{font-weight:400;margin-left:10px}";
const Mr = class {
    constructor(e) {
      t(this, e), (this.content = null);
    }
    render() {
      return n(
        i,
        null,
        n(
          "div",
          { class: "heading-section" },
          this.content?.title
            ? n(
                "wb7-heading",
                { class: "main-title", size: "xs" },
                this.content.title
              )
            : "",
          this.content?.description && Array.isArray(this.content?.description)
            ? this.content?.description.map((t) =>
                n("wb7-text", {
                  class: "main-description",
                  size: "l",
                  tag: "p",
                  innerHTML: t,
                })
              )
            : ""
        )
      );
    }
  },
  Vr = {
    ARROW_UP:
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10.566 9.192l1.414-1.414 7.071 7.07-1.414 1.415z"/><path d="M4.949 14.808l7.07-7.07 1.415 1.414-7.07 7.07z"/></svg>',
    CLOSE:
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.657 16.243L13.414 12l4.243-4.243-1.414-1.414L12 10.586 7.757 6.343 6.343 7.757 10.586 12l-4.243 4.243 1.414 1.414L12 13.414l4.243 4.243 1.414-1.414z"/></svg>',
    INFO: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm-.235 2.22a1.75 1.75 0 1 1-1.75 1.75 1.75 1.75 0 0 1 1.75-1.75zm3.75 14h-7v-1.5h2v-6h-2v-1.5h5v7.5h2z"/></svg>',
  },
  Br = class {
    constructor(e) {
      t(this, e), (this.icon = void 0), (this.name = void 0);
    }
    connectedCallback() {
      this.name && (this.icon = Vr[this.name]);
    }
    render() {
      return (
        !!this.icon &&
        n(i, null, n("div", { class: "cmm-icon", innerHTML: this.icon }))
      );
    }
  };
Br.style =
  '*,*::before,*::after{-webkit-box-sizing:border-box;box-sizing:border-box}html{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}body{margin:0;padding:0}summary{list-style-type:none}fieldset{border:none;padding:0}legend{padding:0}button{margin:0}.wb-skip-link{position:absolute;width:0.0625rem;height:0.0625rem;margin:0;clip:rect(0.0625rem, 0.0625rem, 0.0625rem, 0.0625rem);overflow:hidden}.wb-skip-link:focus{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem;margin:var(--wb-spacing-3xs);padding:var(--wb-spacing-3xs);display:inline-block;width:auto;height:auto;clip:initial;outline:0.0625rem solid;color:currentColor}.wb-skip-link:focus sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-skip-link:focus sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-grid-container{width:var(--wb-grid-width);margin:0 auto;position:relative;display:block}.wb-grid-container--full-width{max-width:100%;width:100%}.wb-grid-row{--vertical-grid-gap:var(--wb-spacing-3xs);display:grid;grid-template-columns:repeat(12, 1fr);grid-gap:var(--vertical-grid-gap) var(--wb-grid-gutter-width)}.wb-grid-col--allow-overflow-x{overflow-x:visible}.wb-grid-col--scroll-overflow-x{overflow-x:scroll}.wb-grid-col--auto-overflow{overflow:auto}.wb-grid-col-offset-mq1-auto{grid-column-start:auto}.wb-grid-col-offset-mq1-1{grid-column-start:1}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq1-2{grid-column-start:2}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq1-3{grid-column-start:3}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq1-4{grid-column-start:4}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq1-5{grid-column-start:5}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq1-6{grid-column-start:6}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq1-7{grid-column-start:7}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq1-8{grid-column-start:8}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq1-9{grid-column-start:9}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq1-10{grid-column-start:10}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq1-11{grid-column-start:11}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq1-12{grid-column-start:12}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-12{display:unset;grid-column-end:span 12}@media (min-width: 30rem){.wb-grid-col-offset-mq2-auto{grid-column-start:auto}.wb-grid-col-offset-mq2-1{grid-column-start:1}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq2-2{grid-column-start:2}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq2-3{grid-column-start:3}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq2-4{grid-column-start:4}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq2-5{grid-column-start:5}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq2-6{grid-column-start:6}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq2-7{grid-column-start:7}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq2-8{grid-column-start:8}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq2-9{grid-column-start:9}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq2-10{grid-column-start:10}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq2-11{grid-column-start:11}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq2-12{grid-column-start:12}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-12{display:unset;grid-column-end:span 12}}@media (min-width: 48rem){.wb-grid-col-offset-mq3-auto{grid-column-start:auto}.wb-grid-col-offset-mq3-1{grid-column-start:1}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq3-2{grid-column-start:2}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq3-3{grid-column-start:3}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq3-4{grid-column-start:4}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq3-5{grid-column-start:5}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq3-6{grid-column-start:6}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq3-7{grid-column-start:7}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq3-8{grid-column-start:8}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq3-9{grid-column-start:9}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq3-10{grid-column-start:10}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq3-11{grid-column-start:11}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq3-12{grid-column-start:12}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-12{display:unset;grid-column-end:span 12}}@media (min-width: 64rem){.wb-grid-col-offset-mq4-auto{grid-column-start:auto}.wb-grid-col-offset-mq4-1{grid-column-start:1}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq4-2{grid-column-start:2}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq4-3{grid-column-start:3}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq4-4{grid-column-start:4}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq4-5{grid-column-start:5}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq4-6{grid-column-start:6}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq4-7{grid-column-start:7}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq4-8{grid-column-start:8}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq4-9{grid-column-start:9}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq4-10{grid-column-start:10}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq4-11{grid-column-start:11}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq4-12{grid-column-start:12}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-12{display:unset;grid-column-end:span 12}}@media (min-width: 80rem){.wb-grid-col-offset-mq5-auto{grid-column-start:auto}.wb-grid-col-offset-mq5-1{grid-column-start:1}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq5-2{grid-column-start:2}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq5-3{grid-column-start:3}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq5-4{grid-column-start:4}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq5-5{grid-column-start:5}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq5-6{grid-column-start:6}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq5-7{grid-column-start:7}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq5-8{grid-column-start:8}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq5-9{grid-column-start:9}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq5-10{grid-column-start:10}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq5-11{grid-column-start:11}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq5-12{grid-column-start:12}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-12{display:unset;grid-column-end:span 12}}@media (min-width: 90rem){.wb-grid-col-offset-mq6-auto{grid-column-start:auto}.wb-grid-col-offset-mq6-1{grid-column-start:1}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq6-2{grid-column-start:2}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq6-3{grid-column-start:3}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq6-4{grid-column-start:4}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq6-5{grid-column-start:5}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq6-6{grid-column-start:6}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq6-7{grid-column-start:7}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq6-8{grid-column-start:8}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq6-9{grid-column-start:9}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq6-10{grid-column-start:10}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq6-11{grid-column-start:11}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq6-12{grid-column-start:12}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-12{display:unset;grid-column-end:span 12}}[class^=wb-scroll-lock],[class*=" wb-scroll-lock"]{position:fixed;width:100%;overflow-y:hidden}.wb-heading-xl{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2.5rem;line-height:3rem}@media (min-width: 64rem){.wb-heading-xl{font-size:4rem;line-height:4.5rem}}.wb-heading-xl sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xl sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2rem;line-height:2.5rem}@media (min-width: 64rem){.wb-heading-l{font-size:3rem;line-height:3.75rem}}.wb-heading-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:1.625rem;line-height:2rem}@media (min-width: 64rem){.wb-heading-m{font-size:2.125rem;line-height:2.75rem}}.wb-heading-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.25rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-s{font-size:1.5rem;line-height:2rem}}.wb-heading-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-xs{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.125rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-xs{font-size:1.25rem;line-height:1.75rem}}.wb-heading-xs sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xs sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-chinese{--wb-font-title:"Hanyi", "DaimlerCAC-Regular", "Hanyi-Ext", "SimSun", serif}.wb-text-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l{font-size:1.125rem;line-height:1.75rem}}.wb-text-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-l-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l-strong{font-size:1.125rem;line-height:1.75rem}}.wb-text-l-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m{font-size:1rem;line-height:1.5rem}}.wb-text-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m-strong{font-size:1rem;line-height:1.5rem}}.wb-text-m-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s{font-size:0.875rem;line-height:1.25rem}}.wb-text-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s-strong{font-size:0.875rem;line-height:1.25rem}}.wb-text-s-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}@font-face{font-family:"MBCorpo Title";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoATitleCond-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:bold;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Bold-Web.woff2") format("woff2")}@font-face{font-family:"DaimlerCAC-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCAC-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCS-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCS-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCACArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCACArab-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCSArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCSArab-Regular.woff2") format("woff2")}@font-face{font-family:"Hanyi";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi.woff") format("woff")}@font-face{font-family:"Hanyi-Ext";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi-Ext.woff") format("woff")}:root,:host{--wb-grid-gutter-width:0.5rem;--wb-grid-content-width:90vw;--wb-spacing-3xs:0.25rem;--wb-spacing-xxs:0.5rem;--wb-spacing-xs:1rem;--wb-spacing-s:1.5rem;--wb-spacing-m:2rem;--wb-spacing-l:3rem;--wb-spacing-xl:4rem;--wb-spacing-xxl:5rem;--wb-transparent:hsla(0, 0%, 0%, 0);--wb-white:hsl(0, 0%, 100%);--wb-white-opacity-high:hsla(0, 0%, 100%, 0.85);--wb-white-opacity-medium:hsla(0, 0%, 100%, 0.56);--wb-white-opacity-low:hsla(0, 0%, 100%, 0.25);--wb-white-opacity-extra-low:hsla(0, 0%, 100%, 0.15);--wb-black:hsl(0, 0%, 0%);--wb-black-opacity-high:hsla(0, 0%, 0%, 0.75);--wb-black-opacity-medium:hsla(0, 0%, 0%, 0.56);--wb-black-opacity-low:hsla(0, 0%, 0%, 0.1);--wb-black-opacity-extra-low:hsla(0, 0%, 0%, 0.05);--wb-blue-5:hsl(207.3, 100%, 8.6%);--wb-blue-10:hsl(206.8, 100%, 12.7%);--wb-blue-15:hsl(205.8, 100%, 16.9%);--wb-blue-20:hsl(206.6, 98.1%, 21.2%);--wb-blue-25:hsl(206.5, 98.4%, 25.3%);--wb-blue-30:hsl(207, 97.4%, 30%);--wb-blue-35:hsl(206.6, 97.7%, 33.9%);--wb-blue-40:hsl(206.5, 96.9%, 38.4%);--wb-blue-45:hsl(206.4, 100%, 42%);--wb-blue-50:hsl(206.4, 100%, 49.4%);--wb-blue-55:hsl(206.4, 97.4%, 54.3%);--wb-blue-60:hsl(206.4, 98.1%, 59.6%);--wb-blue-65:hsl(206.7, 97.8%, 64.9%);--wb-blue-70:hsl(206.2, 97.4%, 69.6%);--wb-blue-75:hsl(206.9, 100%, 75.1%);--wb-blue-80:hsl(206.4, 98%, 80%);--wb-blue-85:hsl(206.8, 97.4%, 85.1%);--wb-blue-90:hsl(207.1, 100%, 90%);--wb-blue-95:hsl(204, 100%, 95.1%);--wb-green-5:hsl(125.7, 67.7%, 6.1%);--wb-green-10:hsl(127.7, 68.9%, 8.8%);--wb-green-15:hsl(127.3, 67.2%, 12%);--wb-green-20:hsl(127.1, 66.2%, 15.1%);--wb-green-25:hsl(126.8, 67.4%, 18%);--wb-green-30:hsl(126.7, 66.7%, 21.2%);--wb-green-35:hsl(127.3, 67.2%, 23.9%);--wb-green-40:hsl(126.5, 66.7%, 27.1%);--wb-green-45:hsl(127, 67.3%, 30%);--wb-green-50:hsl(126.9, 66.3%, 38.4%);--wb-green-55:hsl(127.2, 51.5%, 44.5%);--wb-green-60:hsl(126.9, 41.3%, 50.6%);--wb-green-65:hsl(126.6, 41.6%, 57.1%);--wb-green-70:hsl(126.9, 41.5%, 63.1%);--wb-green-75:hsl(127.4, 41.4%, 69.2%);--wb-green-80:hsl(126.9, 41.3%, 75.3%);--wb-green-85:hsl(127.7, 41.1%, 81.4%);--wb-green-90:hsl(126.9, 41.9%, 87.8%);--wb-green-95:hsl(124.6, 41.9%, 93.9%);--wb-red-5:hsl(0, 72%, 9.8%);--wb-red-10:hsl(0, 73.3%, 14.7%);--wb-red-15:hsl(0, 74%, 19.6%);--wb-red-20:hsl(0, 73%, 24.7%);--wb-red-25:hsl(0, 73.3%, 29.4%);--wb-red-30:hsl(0, 73.7%, 34.3%);--wb-red-35:hsl(358, 71.2%, 40.8%);--wb-red-40:hsl(0, 73.3%, 44.1%);--wb-red-45:hsl(0, 73.6%, 49%);--wb-red-50:hsl(0, 100%, 64.5%);--wb-red-55:hsl(0, 100%, 68%);--wb-red-60:hsl(0, 100%, 71.6%);--wb-red-65:hsl(0, 100%, 75.1%);--wb-red-70:hsl(0, 100%, 78.6%);--wb-red-75:hsl(0, 100%, 82.4%);--wb-red-80:hsl(0, 100%, 85.9%);--wb-red-85:hsl(0, 100%, 89.4%);--wb-red-90:hsl(0, 100%, 92.9%);--wb-red-95:hsl(0, 100%, 96.5%);--wb-yellow-5:hsl(49.6, 100%, 9%);--wb-yellow-10:hsl(48.9, 100%, 13.7%);--wb-yellow-15:hsl(49, 100%, 18.2%);--wb-yellow-20:hsl(49.1, 100%, 22.7%);--wb-yellow-25:hsl(48.8, 100%, 27.3%);--wb-yellow-30:hsl(48.9, 100%, 31.8%);--wb-yellow-35:hsl(48.7, 100%, 36.5%);--wb-yellow-40:hsl(48.8, 100%, 41%);--wb-yellow-45:hsl(48.9, 100%, 45.5%);--wb-yellow-50:hsl(49, 100%, 49%);--wb-yellow-55:hsl(48.8, 96.6%, 54.3%);--wb-yellow-60:hsl(48.9, 96.2%, 59.2%);--wb-yellow-65:hsl(48.8, 96.7%, 64.3%);--wb-yellow-70:hsl(48.8, 96.2%, 69.4%);--wb-yellow-75:hsl(49, 96.9%, 74.7%);--wb-yellow-80:hsl(49.2, 96.2%, 79.6%);--wb-yellow-85:hsl(48.8, 97.4%, 84.9%);--wb-yellow-90:hsl(49.2, 96.2%, 89.8%);--wb-yellow-95:hsl(48, 100%, 95.1%);--wb-grey-5:hsl(0, 0%, 5.1%);--wb-grey-10:hsl(0, 0%, 10.2%);--wb-grey-15:hsl(0, 0%, 14.9%);--wb-grey-20:hsl(0, 0%, 20%);--wb-grey-25:hsl(0, 0%, 25.9%);--wb-grey-30:hsl(0, 0%, 31%);--wb-grey-35:hsl(0, 0%, 36.1%);--wb-grey-40:hsl(0, 0%, 41.2%);--wb-grey-45:hsl(0, 0%, 46.3%);--wb-grey-50:hsl(0, 0%, 51.8%);--wb-grey-55:hsl(0, 0%, 56.9%);--wb-grey-60:hsl(0, 0%, 62.4%);--wb-grey-65:hsl(0, 0%, 67.8%);--wb-grey-70:hsl(0, 0%, 73.3%);--wb-grey-75:hsl(0, 0%, 78.8%);--wb-grey-80:hsl(0, 0%, 85.9%);--wb-grey-85:hsl(0, 0%, 91%);--wb-grey-90:hsl(0, 0%, 95.7%);--wb-grey-95:hsl(0, 0%, 97.3%);--wb-mb-brand:hsl(206.4, 100%, 42%);--wb-mb-background:hsl(0, 0%, 100%);--wb-amg-red-5:hsl(0, 86%, 29%);--wb-amg-red-10:hsl(0, 86%, 29%);--wb-amg-red-15:hsl(0, 86%, 29%);--wb-amg-red-20:hsl(0, 86%, 29%);--wb-amg-red-25:hsl(0, 86%, 29%);--wb-amg-red-30:hsl(0, 86%, 29%);--wb-amg-red-35:hsl(358, 71.2%, 40.8%);--wb-amg-red-40:hsl(358, 71.2%, 40.8%);--wb-amg-red-45:hsl(358, 71.2%, 40.8%);--wb-amg-red-50:hsl(358, 71.2%, 40.8%);--wb-amg-red-55:hsl(358, 71.2%, 40.8%);--wb-amg-red-60:hsl(358, 71.2%, 40.8%);--wb-amg-red-65:hsl(358, 71.2%, 40.8%);--wb-amg-red-70:hsl(358, 71.2%, 40.8%);--wb-amg-red-75:hsl(358, 71.2%, 40.8%);--wb-amg-red-80:hsl(358, 71.2%, 40.8%);--wb-amg-red-85:hsl(358, 71.2%, 40.8%);--wb-amg-red-90:hsl(358, 71.2%, 40.8%);--wb-amg-red-95:hsl(358, 71.2%, 40.8%);--wb-amg-brand:hsl(358, 71.2%, 40.8%);--wb-amg-background:hsl(0, 0%, 0%);--wb-maybach-black-5:hsl(0, 0%, 0%);--wb-maybach-black-10:hsl(0, 0%, 0%);--wb-maybach-black-15:hsl(0, 0%, 0%);--wb-maybach-black-20:hsl(0, 0%, 0%);--wb-maybach-black-25:hsl(0, 0%, 20%);--wb-maybach-black-30:hsl(0, 0%, 0%);--wb-maybach-black-35:hsl(0, 0%, 20%);--wb-maybach-black-40:hsl(0, 0%, 20%);--wb-maybach-black-45:hsl(0, 0%, 0%);--wb-maybach-black-50:hsl(0, 0%, 0%);--wb-maybach-black-55:hsl(0, 0%, 0%);--wb-maybach-black-60:hsl(0, 0%, 20%);--wb-maybach-black-65:hsl(0, 0%, 20%);--wb-maybach-black-70:hsl(0, 0%, 20%);--wb-maybach-black-75:hsl(0, 0%, 20%);--wb-maybach-black-80:hsl(0, 0%, 20%);--wb-maybach-black-85:hsl(0, 0%, 20%);--wb-maybach-black-90:hsl(0, 0%, 20%);--wb-maybach-black-95:hsl(0, 0%, 20%);--wb-maybach-brand:hsl(0, 0%, 0%);--wb-maybach-background:hsl(36, 23.1%, 87.3%);--wb-font-title:"MBCorpo Title", "DaimlerCAC-Regular", "DaimlerCACArab-Regular", serif;--wb-font-text:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-font-text-bold:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-shadow-s:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.125rem 0.25rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-m:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.25rem 0.5rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-l:0 0 0.25rem 0 rgba(0, 0, 0, 0.1), 0 1rem 1.5rem 0 rgba(0, 0, 0, 0.1);--wb-fade:cubic-bezier(0, 0, 0.3, 1);--wb-move:cubic-bezier(0.3, 0, 0, 1);--wb-open:cubic-bezier(0.25, 0.1, 0.25, 1);--wb-border-width-none:0rem;--wb-border-width-s:0.0625rem;--wb-border-width-m:0.125rem;--wb-radius-none:0rem;--wb-radius-s:0.125rem;--wb-radius-m:0.25rem;--wb-radius-l:0.5rem;--wb-radius-full:50%;--wb-grid-width:min(var(--wb-grid-content-width), 105rem);--wb-grid-column-width:min(calc((var(--wb-grid-content-width) - 11 * var(--wb-grid-gutter-width)) / 12), 6.9166666667rem);--wb-opacity-1:5%;--wb-opacity-2:25%;--wb-opacity-3:40%;--wb-opacity-4:50%;--wb-opacity-5:75%;--wb-opacity-6:100%;--wb-opacity-none:0%;--wb-opacity-base:100%;--linear-gradient-blue-45:linear-gradient(to top, var(--wb-blue-45) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-blue-50:linear-gradient(to top, var(--wb-blue-50) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-white:linear-gradient(to top, var(--wb-white) 1px, transparent 1px);--linear-gradient-black:linear-gradient(to top, var(--wb-black) 1px, transparent 1px)}@media (min-width: 48rem){:root,:host{--wb-grid-gutter-width:1rem;--wb-grid-content-width:86vw}}@media (min-width: 64rem){:root,:host{--wb-spacing-xs:1.5rem;--wb-spacing-s:2rem;--wb-spacing-m:3rem;--wb-spacing-l:4rem;--wb-spacing-xl:5rem;--wb-spacing-xxl:5.5rem}}@media (min-width: 80rem){:root,:host{--wb-grid-gutter-width:1.5rem}}@media (min-width: 90rem){:root,:host{--wb-grid-gutter-width:2rem;--wb-spacing-l:4.5rem;--wb-spacing-xl:5.5rem;--wb-spacing-xxl:6rem}}wb-360-viewer:not(:defined),wb-accordion:not(:defined),wb-accordion-item:not(:defined),wb-aspect-ratio:not(:defined),wb-banner-teaser:not(:defined),wb-bar-loader:not(:defined),wb-breadcrumb:not(:defined),wb-breadcrumbs:not(:defined),wb-button-group-item:not(:defined),wb-button-group:not(:defined),wb-button:not(:defined),wb-card-layout-nba:not(:defined),wb-card:not(:defined),wb-checkbox:not(:defined),wb-control-error:not(:defined),wb-control-hint:not(:defined),wb-counter:not(:defined),wb-data-table:not(:defined),wb-datepicker-control:not(:defined),wb-datepicker:not(:defined),wb-dot-navigation:not(:defined),wb-dropdown:not(:defined),wb-eco-label:not(:defined),wb-eco-rating:not(:defined),wb-error-section:not(:defined),wb-file-input:not(:defined),wb-fly-in:not(:defined),wb-gallery:not(:defined),wb-gallery-item:not(:defined),wb-grid:not(:defined),wb-grid-col:not(:defined),wb-grid-row:not(:defined),wb-header-bar:not(:defined),wb-header-button:not(:defined),wb-header-desktop-fly-in:not(:defined),wb-header-fly-in-container:not(:defined),wb-header-fly-in-item:not(:defined),wb-header-language-menu-item:not(:defined),wb-header-language-menu:not(:defined),wb-header-meta-link:not(:defined),wb-header-mobile-fly-in:not(:defined),wb-header-navigation-item:not(:defined),wb-header-navigation:not(:defined),wb-header-tool-list-item:not(:defined),wb-header-tool-list:not(:defined),wb-heading:not(:defined),wb-highlight-slider:not(:defined),wb-horizontal-scroll:not(:defined),wb-icon:not(:defined),wb-info-item:not(:defined),wb-input-action:not(:defined),wb-input:not(:defined),wb-interactive-tag:not(:defined),wb-link:not(:defined),wb-list-group-item:not(:defined),wb-list-group:not(:defined),wb-list-item:not(:defined),wb-list:not(:defined),wb-load-more:not(:defined),wb-modal-level:not(:defined),wb-modal:not(:defined),wb-multi-select:not(:defined),wb-notification-host:not(:defined),wb-notification:not(:defined),wb-overlay-context:not(:defined),wb-pagination:not(:defined),wb-placeholder:not(:defined),wb-popover:not(:defined),wb-price:not(:defined),wb-progress:not(:defined),wb-radio-button:not(:defined),wb-radio-group:not(:defined),wb-range-slider:not(:defined),wb-round-button:not(:defined),wb-select:not(:defined),wb-selection-card:not(:defined),wb-skeleton:not(:defined),wb-slider:not(:defined),wb-slider-item:not(:defined),wb-sphere-view:not(:defined),wb-spinner:not(:defined),wb-stage:not(:defined),wb-step:not(:defined),wb-stepper:not(:defined),wb-subnavigation:not(:defined),wb-subnavigation-fly-in:not(:defined),wb-subnavigation-fly-in-item:not(:defined),wb-subnavigation-item:not(:defined),wb-tab:not(:defined),wb-tab-content:not(:defined),wb-table:not(:defined),wb-table-cell:not(:defined),wb-table-header:not(:defined),wb-table-row:not(:defined),wb-tabs:not(:defined),wb-tag:not(:defined),wb-text:not(:defined),wb-toggle:not(:defined),wb-tooltip:not(:defined),wb-tree:not(:defined),wb-tree-items:not(:defined),wb-value-slider:not(:defined),wb-vehicle-tile:not(:defined),wb-vertical-scroll:not(:defined),wb-video:not(:defined),wb-visually-hidden:not(:defined){visibility:hidden}[theme=light]{}[theme=dark]{}:host{display:-ms-inline-flexbox;display:inline-flex;height:24px;width:24px;margin:0 auto}:host .cmm-icon{display:block;height:auto;width:100%}:host svg{display:block;fill:var(--wb-grey-60, #9f9f9f);fill:currentcolor;margin:0 auto;height:24px;width:24px}';
const Hr = class {
  constructor(e) {
    t(this, e),
      (this.handleChangeLanguage = void 0),
      (this.languages = null),
      (this.languageSelected = void 0);
  }
  hasLanguageAvailables() {
    return this.languages?.length && this.languages?.length > 1;
  }
  getLanguageLabel(t) {
    return (t?.label || t?.code)?.toLocaleUpperCase();
  }
  activedLanguage(t) {
    return (
      this.languageSelected?.toLocaleUpperCase() === this.getLanguageLabel(t)
    );
  }
  render() {
    return n(
      i,
      null,
      this.hasLanguageAvailables() &&
        n(
          "wb7-button-group",
          { class: "cmm-languages-list" },
          this.languages.map((t) =>
            n(
              "wb7-button-group-item",
              {
                key: t?.code,
                variant: "tertiary",
                size: "s",
                class:
                  "cmm-languages-list__item " +
                  (this.activedLanguage(t)
                    ? "cmm-languages-list__item--actived"
                    : "cmm-languages-list__item--non-actived"),
                "data-language": t?.code,
                "data-test": "handle-change-language",
                onClick: (t) => this.handleChangeLanguage(t),
              },
              this.getLanguageLabel(t)
            )
          )
        )
    );
  }
};
Hr.style =
  '.cmm-languages-list{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-bottom:var(--wb-spacing-xs, 1rem)}.cmm-languages-list__item--actived::after{content:" ";display:block;width:100%;height:2px;border-bottom:2px solid var(--wb-blue-40)}.cmm-languages-list__item--non-actived::after{content:" ";display:block;width:100%;height:2px;border-bottom:2px solid rgba(0, 0, 0, 0)}';
const Gr = class {
  constructor(n) {
    t(this, n),
      (this.toggleNotification = e(this, "toggleNotification", 7)),
      (this.content = void 0),
      (this.direction = "ltr");
  }
  toggleHandler(t) {
    this.toggleNotification.emit(t);
  }
  render() {
    return n(
      i,
      null,
      n(
        "div",
        { class: "cmm-notification", dir: this.direction },
        n("p", { class: "cmm-notification__content" }, this.content),
        n(
          "button",
          {
            type: "button",
            "aria-label": "Dismiss notification",
            class: "cmm-notification__button",
            onClick: (t) => this.toggleHandler(t),
          },
          n("cmm-icon", { name: o.CLOSE })
        )
      )
    );
  }
};
Gr.style =
  '*,*::before,*::after{-webkit-box-sizing:border-box;box-sizing:border-box}html{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}body{margin:0;padding:0}summary{list-style-type:none}fieldset{border:none;padding:0}legend{padding:0}button{margin:0}.wb-skip-link{position:absolute;width:0.0625rem;height:0.0625rem;margin:0;clip:rect(0.0625rem, 0.0625rem, 0.0625rem, 0.0625rem);overflow:hidden}.wb-skip-link:focus{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem;margin:var(--wb-spacing-3xs);padding:var(--wb-spacing-3xs);display:inline-block;width:auto;height:auto;clip:initial;outline:0.0625rem solid;color:currentColor}.wb-skip-link:focus sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-skip-link:focus sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-grid-container{width:var(--wb-grid-width);margin:0 auto;position:relative;display:block}.wb-grid-container--full-width{max-width:100%;width:100%}.wb-grid-row{--vertical-grid-gap:var(--wb-spacing-3xs);display:grid;grid-template-columns:repeat(12, 1fr);grid-gap:var(--vertical-grid-gap) var(--wb-grid-gutter-width)}.wb-grid-col--allow-overflow-x{overflow-x:visible}.wb-grid-col--scroll-overflow-x{overflow-x:scroll}.wb-grid-col--auto-overflow{overflow:auto}.wb-grid-col-offset-mq1-auto{grid-column-start:auto}.wb-grid-col-offset-mq1-1{grid-column-start:1}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq1-2{grid-column-start:2}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq1-3{grid-column-start:3}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq1-4{grid-column-start:4}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq1-5{grid-column-start:5}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq1-6{grid-column-start:6}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq1-7{grid-column-start:7}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq1-8{grid-column-start:8}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq1-9{grid-column-start:9}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq1-10{grid-column-start:10}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq1-11{grid-column-start:11}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq1-12{grid-column-start:12}.wb-grid-col-mq1-hide{display:none}.wb-grid-col-mq1-12{display:unset;grid-column-end:span 12}@media (min-width: 30rem){.wb-grid-col-offset-mq2-auto{grid-column-start:auto}.wb-grid-col-offset-mq2-1{grid-column-start:1}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq2-2{grid-column-start:2}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq2-3{grid-column-start:3}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq2-4{grid-column-start:4}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq2-5{grid-column-start:5}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq2-6{grid-column-start:6}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq2-7{grid-column-start:7}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq2-8{grid-column-start:8}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq2-9{grid-column-start:9}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq2-10{grid-column-start:10}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq2-11{grid-column-start:11}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq2-12{grid-column-start:12}.wb-grid-col-mq2-hide{display:none}.wb-grid-col-mq2-12{display:unset;grid-column-end:span 12}}@media (min-width: 48rem){.wb-grid-col-offset-mq3-auto{grid-column-start:auto}.wb-grid-col-offset-mq3-1{grid-column-start:1}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq3-2{grid-column-start:2}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq3-3{grid-column-start:3}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq3-4{grid-column-start:4}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq3-5{grid-column-start:5}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq3-6{grid-column-start:6}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq3-7{grid-column-start:7}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq3-8{grid-column-start:8}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq3-9{grid-column-start:9}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq3-10{grid-column-start:10}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq3-11{grid-column-start:11}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq3-12{grid-column-start:12}.wb-grid-col-mq3-hide{display:none}.wb-grid-col-mq3-12{display:unset;grid-column-end:span 12}}@media (min-width: 64rem){.wb-grid-col-offset-mq4-auto{grid-column-start:auto}.wb-grid-col-offset-mq4-1{grid-column-start:1}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq4-2{grid-column-start:2}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq4-3{grid-column-start:3}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq4-4{grid-column-start:4}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq4-5{grid-column-start:5}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq4-6{grid-column-start:6}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq4-7{grid-column-start:7}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq4-8{grid-column-start:8}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq4-9{grid-column-start:9}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq4-10{grid-column-start:10}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq4-11{grid-column-start:11}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq4-12{grid-column-start:12}.wb-grid-col-mq4-hide{display:none}.wb-grid-col-mq4-12{display:unset;grid-column-end:span 12}}@media (min-width: 80rem){.wb-grid-col-offset-mq5-auto{grid-column-start:auto}.wb-grid-col-offset-mq5-1{grid-column-start:1}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq5-2{grid-column-start:2}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq5-3{grid-column-start:3}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq5-4{grid-column-start:4}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq5-5{grid-column-start:5}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq5-6{grid-column-start:6}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq5-7{grid-column-start:7}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq5-8{grid-column-start:8}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq5-9{grid-column-start:9}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq5-10{grid-column-start:10}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq5-11{grid-column-start:11}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq5-12{grid-column-start:12}.wb-grid-col-mq5-hide{display:none}.wb-grid-col-mq5-12{display:unset;grid-column-end:span 12}}@media (min-width: 90rem){.wb-grid-col-offset-mq6-auto{grid-column-start:auto}.wb-grid-col-offset-mq6-1{grid-column-start:1}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-1{display:unset;grid-column-end:span 1}.wb-grid-col-offset-mq6-2{grid-column-start:2}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-2{display:unset;grid-column-end:span 2}.wb-grid-col-offset-mq6-3{grid-column-start:3}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-3{display:unset;grid-column-end:span 3}.wb-grid-col-offset-mq6-4{grid-column-start:4}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-4{display:unset;grid-column-end:span 4}.wb-grid-col-offset-mq6-5{grid-column-start:5}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-5{display:unset;grid-column-end:span 5}.wb-grid-col-offset-mq6-6{grid-column-start:6}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-6{display:unset;grid-column-end:span 6}.wb-grid-col-offset-mq6-7{grid-column-start:7}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-7{display:unset;grid-column-end:span 7}.wb-grid-col-offset-mq6-8{grid-column-start:8}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-8{display:unset;grid-column-end:span 8}.wb-grid-col-offset-mq6-9{grid-column-start:9}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-9{display:unset;grid-column-end:span 9}.wb-grid-col-offset-mq6-10{grid-column-start:10}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-10{display:unset;grid-column-end:span 10}.wb-grid-col-offset-mq6-11{grid-column-start:11}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-11{display:unset;grid-column-end:span 11}.wb-grid-col-offset-mq6-12{grid-column-start:12}.wb-grid-col-mq6-hide{display:none}.wb-grid-col-mq6-12{display:unset;grid-column-end:span 12}}[class^=wb-scroll-lock],[class*=" wb-scroll-lock"]{position:fixed;width:100%;overflow-y:hidden}.wb-heading-xl{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2.5rem;line-height:3rem}@media (min-width: 64rem){.wb-heading-xl{font-size:4rem;line-height:4.5rem}}.wb-heading-xl sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xl sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:2rem;line-height:2.5rem}@media (min-width: 64rem){.wb-heading-l{font-size:3rem;line-height:3.75rem}}.wb-heading-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-title);font-style:normal;font-weight:normal;font-size:1.625rem;line-height:2rem}@media (min-width: 64rem){.wb-heading-m{font-size:2.125rem;line-height:2.75rem}}.wb-heading-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.25rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-s{font-size:1.5rem;line-height:2rem}}.wb-heading-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-xs{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1.125rem;line-height:1.75rem}@media (min-width: 64rem){.wb-heading-xs{font-size:1.25rem;line-height:1.75rem}}.wb-heading-xs sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem));position:relative;inset-block-end:0.5em}.wb-heading-xs sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-heading-chinese{--wb-font-title:"Hanyi", "DaimlerCAC-Regular", "Hanyi-Ext", "SimSun", serif}.wb-text-l{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l{font-size:1.125rem;line-height:1.75rem}}.wb-text-l sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-l-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:1rem;line-height:1.5rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-l-strong{font-size:1.125rem;line-height:1.75rem}}.wb-text-l-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-l-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m{font-size:1rem;line-height:1.5rem}}.wb-text-m sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-m-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.875rem;line-height:1.25rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-m-strong{font-size:1rem;line-height:1.5rem}}.wb-text-m-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-m-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-style:normal;font-weight:normal;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s{font-size:0.875rem;line-height:1.25rem}}.wb-text-s sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}.wb-text-s-strong{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-style:normal;font-weight:bold;font-size:0.75rem;line-height:1rem;letter-spacing:0.0125rem}@media (min-width: 64rem){.wb-text-s-strong{font-size:0.875rem;line-height:1.25rem}}.wb-text-s-strong sup{line-height:0;font-size:max(0.625rem, min(0.6em, 1rem))}.wb-text-s-strong sub{line-height:0;font-size:max(0.45em, min(0.7em, 0.875rem))}@font-face{font-family:"MBCorpo Title";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoATitleCond-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Regular-Web.woff2") format("woff2")}@font-face{font-family:"MBCorpo Text";font-weight:bold;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/MBCorpoSText-Bold-Web.woff2") format("woff2")}@font-face{font-family:"DaimlerCAC-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCAC-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCS-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCS-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCACArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCACArab-Regular.woff2") format("woff2")}@font-face{font-family:"DaimlerCSArab-Regular";font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF2/DaimlerCSArab-Regular.woff2") format("woff2")}@font-face{font-family:"Hanyi";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi.woff") format("woff")}@font-face{font-family:"Hanyi-Ext";font-weight:normal;font-style:normal;font-display:swap;src:url("https://assets.oneweb.mercedes-benz.com/plugin/workbench/fonts/2.1.0/WOFF/Hanyi-Ext.woff") format("woff")}:root,:host{--wb-grid-gutter-width:0.5rem;--wb-grid-content-width:90vw;--wb-spacing-3xs:0.25rem;--wb-spacing-xxs:0.5rem;--wb-spacing-xs:1rem;--wb-spacing-s:1.5rem;--wb-spacing-m:2rem;--wb-spacing-l:3rem;--wb-spacing-xl:4rem;--wb-spacing-xxl:5rem;--wb-transparent:hsla(0, 0%, 0%, 0);--wb-white:hsl(0, 0%, 100%);--wb-white-opacity-high:hsla(0, 0%, 100%, 0.85);--wb-white-opacity-medium:hsla(0, 0%, 100%, 0.56);--wb-white-opacity-low:hsla(0, 0%, 100%, 0.25);--wb-white-opacity-extra-low:hsla(0, 0%, 100%, 0.15);--wb-black:hsl(0, 0%, 0%);--wb-black-opacity-high:hsla(0, 0%, 0%, 0.75);--wb-black-opacity-medium:hsla(0, 0%, 0%, 0.56);--wb-black-opacity-low:hsla(0, 0%, 0%, 0.1);--wb-black-opacity-extra-low:hsla(0, 0%, 0%, 0.05);--wb-blue-5:hsl(207.3, 100%, 8.6%);--wb-blue-10:hsl(206.8, 100%, 12.7%);--wb-blue-15:hsl(205.8, 100%, 16.9%);--wb-blue-20:hsl(206.6, 98.1%, 21.2%);--wb-blue-25:hsl(206.5, 98.4%, 25.3%);--wb-blue-30:hsl(207, 97.4%, 30%);--wb-blue-35:hsl(206.6, 97.7%, 33.9%);--wb-blue-40:hsl(206.5, 96.9%, 38.4%);--wb-blue-45:hsl(206.4, 100%, 42%);--wb-blue-50:hsl(206.4, 100%, 49.4%);--wb-blue-55:hsl(206.4, 97.4%, 54.3%);--wb-blue-60:hsl(206.4, 98.1%, 59.6%);--wb-blue-65:hsl(206.7, 97.8%, 64.9%);--wb-blue-70:hsl(206.2, 97.4%, 69.6%);--wb-blue-75:hsl(206.9, 100%, 75.1%);--wb-blue-80:hsl(206.4, 98%, 80%);--wb-blue-85:hsl(206.8, 97.4%, 85.1%);--wb-blue-90:hsl(207.1, 100%, 90%);--wb-blue-95:hsl(204, 100%, 95.1%);--wb-green-5:hsl(125.7, 67.7%, 6.1%);--wb-green-10:hsl(127.7, 68.9%, 8.8%);--wb-green-15:hsl(127.3, 67.2%, 12%);--wb-green-20:hsl(127.1, 66.2%, 15.1%);--wb-green-25:hsl(126.8, 67.4%, 18%);--wb-green-30:hsl(126.7, 66.7%, 21.2%);--wb-green-35:hsl(127.3, 67.2%, 23.9%);--wb-green-40:hsl(126.5, 66.7%, 27.1%);--wb-green-45:hsl(127, 67.3%, 30%);--wb-green-50:hsl(126.9, 66.3%, 38.4%);--wb-green-55:hsl(127.2, 51.5%, 44.5%);--wb-green-60:hsl(126.9, 41.3%, 50.6%);--wb-green-65:hsl(126.6, 41.6%, 57.1%);--wb-green-70:hsl(126.9, 41.5%, 63.1%);--wb-green-75:hsl(127.4, 41.4%, 69.2%);--wb-green-80:hsl(126.9, 41.3%, 75.3%);--wb-green-85:hsl(127.7, 41.1%, 81.4%);--wb-green-90:hsl(126.9, 41.9%, 87.8%);--wb-green-95:hsl(124.6, 41.9%, 93.9%);--wb-red-5:hsl(0, 72%, 9.8%);--wb-red-10:hsl(0, 73.3%, 14.7%);--wb-red-15:hsl(0, 74%, 19.6%);--wb-red-20:hsl(0, 73%, 24.7%);--wb-red-25:hsl(0, 73.3%, 29.4%);--wb-red-30:hsl(0, 73.7%, 34.3%);--wb-red-35:hsl(358, 71.2%, 40.8%);--wb-red-40:hsl(0, 73.3%, 44.1%);--wb-red-45:hsl(0, 73.6%, 49%);--wb-red-50:hsl(0, 100%, 64.5%);--wb-red-55:hsl(0, 100%, 68%);--wb-red-60:hsl(0, 100%, 71.6%);--wb-red-65:hsl(0, 100%, 75.1%);--wb-red-70:hsl(0, 100%, 78.6%);--wb-red-75:hsl(0, 100%, 82.4%);--wb-red-80:hsl(0, 100%, 85.9%);--wb-red-85:hsl(0, 100%, 89.4%);--wb-red-90:hsl(0, 100%, 92.9%);--wb-red-95:hsl(0, 100%, 96.5%);--wb-yellow-5:hsl(49.6, 100%, 9%);--wb-yellow-10:hsl(48.9, 100%, 13.7%);--wb-yellow-15:hsl(49, 100%, 18.2%);--wb-yellow-20:hsl(49.1, 100%, 22.7%);--wb-yellow-25:hsl(48.8, 100%, 27.3%);--wb-yellow-30:hsl(48.9, 100%, 31.8%);--wb-yellow-35:hsl(48.7, 100%, 36.5%);--wb-yellow-40:hsl(48.8, 100%, 41%);--wb-yellow-45:hsl(48.9, 100%, 45.5%);--wb-yellow-50:hsl(49, 100%, 49%);--wb-yellow-55:hsl(48.8, 96.6%, 54.3%);--wb-yellow-60:hsl(48.9, 96.2%, 59.2%);--wb-yellow-65:hsl(48.8, 96.7%, 64.3%);--wb-yellow-70:hsl(48.8, 96.2%, 69.4%);--wb-yellow-75:hsl(49, 96.9%, 74.7%);--wb-yellow-80:hsl(49.2, 96.2%, 79.6%);--wb-yellow-85:hsl(48.8, 97.4%, 84.9%);--wb-yellow-90:hsl(49.2, 96.2%, 89.8%);--wb-yellow-95:hsl(48, 100%, 95.1%);--wb-grey-5:hsl(0, 0%, 5.1%);--wb-grey-10:hsl(0, 0%, 10.2%);--wb-grey-15:hsl(0, 0%, 14.9%);--wb-grey-20:hsl(0, 0%, 20%);--wb-grey-25:hsl(0, 0%, 25.9%);--wb-grey-30:hsl(0, 0%, 31%);--wb-grey-35:hsl(0, 0%, 36.1%);--wb-grey-40:hsl(0, 0%, 41.2%);--wb-grey-45:hsl(0, 0%, 46.3%);--wb-grey-50:hsl(0, 0%, 51.8%);--wb-grey-55:hsl(0, 0%, 56.9%);--wb-grey-60:hsl(0, 0%, 62.4%);--wb-grey-65:hsl(0, 0%, 67.8%);--wb-grey-70:hsl(0, 0%, 73.3%);--wb-grey-75:hsl(0, 0%, 78.8%);--wb-grey-80:hsl(0, 0%, 85.9%);--wb-grey-85:hsl(0, 0%, 91%);--wb-grey-90:hsl(0, 0%, 95.7%);--wb-grey-95:hsl(0, 0%, 97.3%);--wb-mb-brand:hsl(206.4, 100%, 42%);--wb-mb-background:hsl(0, 0%, 100%);--wb-amg-red-5:hsl(0, 86%, 29%);--wb-amg-red-10:hsl(0, 86%, 29%);--wb-amg-red-15:hsl(0, 86%, 29%);--wb-amg-red-20:hsl(0, 86%, 29%);--wb-amg-red-25:hsl(0, 86%, 29%);--wb-amg-red-30:hsl(0, 86%, 29%);--wb-amg-red-35:hsl(358, 71.2%, 40.8%);--wb-amg-red-40:hsl(358, 71.2%, 40.8%);--wb-amg-red-45:hsl(358, 71.2%, 40.8%);--wb-amg-red-50:hsl(358, 71.2%, 40.8%);--wb-amg-red-55:hsl(358, 71.2%, 40.8%);--wb-amg-red-60:hsl(358, 71.2%, 40.8%);--wb-amg-red-65:hsl(358, 71.2%, 40.8%);--wb-amg-red-70:hsl(358, 71.2%, 40.8%);--wb-amg-red-75:hsl(358, 71.2%, 40.8%);--wb-amg-red-80:hsl(358, 71.2%, 40.8%);--wb-amg-red-85:hsl(358, 71.2%, 40.8%);--wb-amg-red-90:hsl(358, 71.2%, 40.8%);--wb-amg-red-95:hsl(358, 71.2%, 40.8%);--wb-amg-brand:hsl(358, 71.2%, 40.8%);--wb-amg-background:hsl(0, 0%, 0%);--wb-maybach-black-5:hsl(0, 0%, 0%);--wb-maybach-black-10:hsl(0, 0%, 0%);--wb-maybach-black-15:hsl(0, 0%, 0%);--wb-maybach-black-20:hsl(0, 0%, 0%);--wb-maybach-black-25:hsl(0, 0%, 20%);--wb-maybach-black-30:hsl(0, 0%, 0%);--wb-maybach-black-35:hsl(0, 0%, 20%);--wb-maybach-black-40:hsl(0, 0%, 20%);--wb-maybach-black-45:hsl(0, 0%, 0%);--wb-maybach-black-50:hsl(0, 0%, 0%);--wb-maybach-black-55:hsl(0, 0%, 0%);--wb-maybach-black-60:hsl(0, 0%, 20%);--wb-maybach-black-65:hsl(0, 0%, 20%);--wb-maybach-black-70:hsl(0, 0%, 20%);--wb-maybach-black-75:hsl(0, 0%, 20%);--wb-maybach-black-80:hsl(0, 0%, 20%);--wb-maybach-black-85:hsl(0, 0%, 20%);--wb-maybach-black-90:hsl(0, 0%, 20%);--wb-maybach-black-95:hsl(0, 0%, 20%);--wb-maybach-brand:hsl(0, 0%, 0%);--wb-maybach-background:hsl(36, 23.1%, 87.3%);--wb-font-title:"MBCorpo Title", "DaimlerCAC-Regular", "DaimlerCACArab-Regular", serif;--wb-font-text:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-font-text-bold:"MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif;--wb-shadow-s:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.125rem 0.25rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-m:0 0 0.125rem 0 rgba(0, 0, 0, 0.1), 0 0.25rem 0.5rem 0 rgba(0, 0, 0, 0.1);--wb-shadow-l:0 0 0.25rem 0 rgba(0, 0, 0, 0.1), 0 1rem 1.5rem 0 rgba(0, 0, 0, 0.1);--wb-fade:cubic-bezier(0, 0, 0.3, 1);--wb-move:cubic-bezier(0.3, 0, 0, 1);--wb-open:cubic-bezier(0.25, 0.1, 0.25, 1);--wb-border-width-none:0rem;--wb-border-width-s:0.0625rem;--wb-border-width-m:0.125rem;--wb-radius-none:0rem;--wb-radius-s:0.125rem;--wb-radius-m:0.25rem;--wb-radius-l:0.5rem;--wb-radius-full:50%;--wb-grid-width:min(var(--wb-grid-content-width), 105rem);--wb-grid-column-width:min(calc((var(--wb-grid-content-width) - 11 * var(--wb-grid-gutter-width)) / 12), 6.9166666667rem);--wb-opacity-1:5%;--wb-opacity-2:25%;--wb-opacity-3:40%;--wb-opacity-4:50%;--wb-opacity-5:75%;--wb-opacity-6:100%;--wb-opacity-none:0%;--wb-opacity-base:100%;--linear-gradient-blue-45:linear-gradient(to top, var(--wb-blue-45) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-blue-50:linear-gradient(to top, var(--wb-blue-50) 2px, transparent 2px), linear-gradient(to top, var(--wb-grey-70) 1px, transparent 1px);--linear-gradient-white:linear-gradient(to top, var(--wb-white) 1px, transparent 1px);--linear-gradient-black:linear-gradient(to top, var(--wb-black) 1px, transparent 1px)}@media (min-width: 48rem){:root,:host{--wb-grid-gutter-width:1rem;--wb-grid-content-width:86vw}}@media (min-width: 64rem){:root,:host{--wb-spacing-xs:1.5rem;--wb-spacing-s:2rem;--wb-spacing-m:3rem;--wb-spacing-l:4rem;--wb-spacing-xl:5rem;--wb-spacing-xxl:5.5rem}}@media (min-width: 80rem){:root,:host{--wb-grid-gutter-width:1.5rem}}@media (min-width: 90rem){:root,:host{--wb-grid-gutter-width:2rem;--wb-spacing-l:4.5rem;--wb-spacing-xl:5.5rem;--wb-spacing-xxl:6rem}}wb-360-viewer:not(:defined),wb-accordion:not(:defined),wb-accordion-item:not(:defined),wb-aspect-ratio:not(:defined),wb-banner-teaser:not(:defined),wb-bar-loader:not(:defined),wb-breadcrumb:not(:defined),wb-breadcrumbs:not(:defined),wb-button-group-item:not(:defined),wb-button-group:not(:defined),wb-button:not(:defined),wb-card-layout-nba:not(:defined),wb-card:not(:defined),wb-checkbox:not(:defined),wb-control-error:not(:defined),wb-control-hint:not(:defined),wb-counter:not(:defined),wb-data-table:not(:defined),wb-datepicker-control:not(:defined),wb-datepicker:not(:defined),wb-dot-navigation:not(:defined),wb-dropdown:not(:defined),wb-eco-label:not(:defined),wb-eco-rating:not(:defined),wb-error-section:not(:defined),wb-file-input:not(:defined),wb-fly-in:not(:defined),wb-gallery:not(:defined),wb-gallery-item:not(:defined),wb-grid:not(:defined),wb-grid-col:not(:defined),wb-grid-row:not(:defined),wb-header-bar:not(:defined),wb-header-button:not(:defined),wb-header-desktop-fly-in:not(:defined),wb-header-fly-in-container:not(:defined),wb-header-fly-in-item:not(:defined),wb-header-language-menu-item:not(:defined),wb-header-language-menu:not(:defined),wb-header-meta-link:not(:defined),wb-header-mobile-fly-in:not(:defined),wb-header-navigation-item:not(:defined),wb-header-navigation:not(:defined),wb-header-tool-list-item:not(:defined),wb-header-tool-list:not(:defined),wb-heading:not(:defined),wb-highlight-slider:not(:defined),wb-horizontal-scroll:not(:defined),wb-icon:not(:defined),wb-info-item:not(:defined),wb-input-action:not(:defined),wb-input:not(:defined),wb-interactive-tag:not(:defined),wb-link:not(:defined),wb-list-group-item:not(:defined),wb-list-group:not(:defined),wb-list-item:not(:defined),wb-list:not(:defined),wb-load-more:not(:defined),wb-modal-level:not(:defined),wb-modal:not(:defined),wb-multi-select:not(:defined),wb-notification-host:not(:defined),wb-notification:not(:defined),wb-overlay-context:not(:defined),wb-pagination:not(:defined),wb-placeholder:not(:defined),wb-popover:not(:defined),wb-price:not(:defined),wb-progress:not(:defined),wb-radio-button:not(:defined),wb-radio-group:not(:defined),wb-range-slider:not(:defined),wb-round-button:not(:defined),wb-select:not(:defined),wb-selection-card:not(:defined),wb-skeleton:not(:defined),wb-slider:not(:defined),wb-slider-item:not(:defined),wb-sphere-view:not(:defined),wb-spinner:not(:defined),wb-stage:not(:defined),wb-step:not(:defined),wb-stepper:not(:defined),wb-subnavigation:not(:defined),wb-subnavigation-fly-in:not(:defined),wb-subnavigation-fly-in-item:not(:defined),wb-subnavigation-item:not(:defined),wb-tab:not(:defined),wb-tab-content:not(:defined),wb-table:not(:defined),wb-table-cell:not(:defined),wb-table-header:not(:defined),wb-table-row:not(:defined),wb-tabs:not(:defined),wb-tag:not(:defined),wb-text:not(:defined),wb-toggle:not(:defined),wb-tooltip:not(:defined),wb-tree:not(:defined),wb-tree-items:not(:defined),wb-value-slider:not(:defined),wb-vehicle-tile:not(:defined),wb-vertical-scroll:not(:defined),wb-video:not(:defined),wb-visually-hidden:not(:defined){visibility:hidden}[theme=light]{}[theme=dark]{}:host{--highlight-color:var(--wb-blue-45, #0078d6);--variant-color:var(--wb-green-45, #198025);--icon-color:var(--variant-color);display:block;position:fixed;left:0;right:0;bottom:1em;margin:0 auto;max-width:512px;min-width:300px;width:-moz-fit-content;width:-webkit-fit-content;width:fit-content;background:var(--wb-grey-15, #262626);border:2px solid var(--variant-color);border-color:var(--variant-color);border-radius:4px;color:var(--wb-white, #fff);-webkit-box-shadow:0 0 4px 0 rgba(0, 0, 0, 0.1), 0 16px 24px 0 rgba(0, 0, 0, 0.1);box-shadow:0 0 4px 0 rgba(0, 0, 0, 0.1), 0 16px 24px 0 rgba(0, 0, 0, 0.1);z-index:2010}:host .cmm-notification__content{font-family:var(--wb-font-text, "MBCorpo Text", "DaimlerCS-Regular", "DaimlerCSArab-Regular", sans-serif);font-size:1rem;font-style:normal;font-weight:400;line-height:1.5rem;margin:0;padding:16px;padding-right:56px}:host .cmm-notification__button{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:var(--wb-grey-15, #262626);border:1px solid var(--wb-grey-20, #333);border-radius:100%;-webkit-box-shadow:none;box-shadow:none;position:absolute;top:10px;right:10px;height:36px;width:36px;color:var(--wb-white, #fff);display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center}:host .cmm-notification__button:hover{background-color:var(--wb-grey-15, #262626);border-color:var(--wb-grey-40, #696969)}:host .cmm-notification__button:focus{background-color:var(--wb-grey-15, #262626);border-color:var(--highlight-color)}[dir=rtl].cmm-notification .cmm-notification__content{padding-left:56px;padding-right:16px}[dir=rtl].cmm-notification .cmm-notification__button{left:10px;right:initial}';
export {
  ar as $,
  gr as A,
  Ar as B,
  jt as C,
  ut as D,
  br as E,
  hr as F,
  vr as G,
  yr as H,
  An as I,
  Zi as J,
  xr as K,
  Jt as L,
  mi as M,
  dt as N,
  Sr as O,
  Hn as P,
  Cr as Q,
  Qt as R,
  Rt as S,
  _r as T,
  ht as U,
  ft as V,
  qr as W,
  hi as X,
  tr as Y,
  ui as Z,
  Nn as _,
  Be as a,
  yn as a0,
  vn as a1,
  xn as a2,
  kn as a3,
  St as a4,
  mr as a5,
  lr as a6,
  Tr as a7,
  Xe as a8,
  hn as a9,
  Gr as aA,
  cr as aa,
  Ut as ab,
  ur as ac,
  dr as ad,
  Vt as ae,
  wr as af,
  fr as ag,
  Yt as ah,
  ce as ai,
  le as aj,
  ot as ak,
  fe as al,
  me as am,
  Ce as an,
  rt as ao,
  nt as ap,
  de as aq,
  he as ar,
  g as as,
  v as at,
  Pr as au,
  Ur as av,
  jr as aw,
  Mr as ax,
  Br as ay,
  Hr as az,
  G as b,
  Kt as c,
  sn as d,
  vt as e,
  on as f,
  A as g,
  Ot as h,
  R as i,
  S as j,
  T as k,
  L as l,
  U as m,
  xt as n,
  _ as o,
  pr as p,
  at as q,
  qt as r,
  kt as s,
  yt as t,
  E as u,
  _n as v,
  ct as w,
  Ye as x,
  P as y,
  rr as z,
};
