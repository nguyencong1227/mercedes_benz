/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { ae as i, ah as l, ai as o } from "./p-6c6818e1.js";
import "./p-a7d21f71.js";
import "./p-54a36ea4.js";
import "https://assets.oneweb.mercedes-benz.com/plugin/workbench/core/7.32.0/loader/index.js";
import "./p-c1686f45.js";
export default function (s, t) {
  var n, e, d, u, a, r, v, c;
  (this.customCss = null),
    (this.hideDataProcessingServices = i(t.hideDataProcessingServices, !1)),
    (this.defaultView = i(t.defaultView, l.CAT)),
    (this.backgroundColor = i(
      o(
        (null ===
          (e =
            null === (n = s.customization) || void 0 === n
              ? void 0
              : n.color) || void 0 === e
          ? void 0
          : e.privacyButtonBackground) ||
          (null ===
            (u =
              null === (d = s.customization) || void 0 === d
                ? void 0
                : d.color) || void 0 === u
            ? void 0
            : u.primary)
      ),
      null
    )),
    (this.desktopSize = i(
      null === (a = s.customization) || void 0 === a
        ? void 0
        : a.privacyButtonSizeDesktop,
      null
    )),
    (this.iconColor = i(
      o(
        null ===
          (v =
            null === (r = s.customization) || void 0 === r
              ? void 0
              : r.color) || void 0 === v
          ? void 0
          : v.privacyButtonIcon
      ),
      null
    )),
    (this.mobileSize = i(
      null === (c = s.customization) || void 0 === c
        ? void 0
        : c.privacyButtonSizeMobile,
      null
    )),
    (this.iconUrl = i(s.buttonPrivacyOpenIconUrl, null)),
    (this.position = (function (i) {
      switch (i) {
        case "tl":
        case "tr":
        case "bl":
        case "br":
          return i;
        default:
          return "bl";
      }
    })(s.buttonDisplayLocation));
}
