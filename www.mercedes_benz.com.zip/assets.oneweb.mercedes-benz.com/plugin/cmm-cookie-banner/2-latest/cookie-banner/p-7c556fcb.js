/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { V as n, U as t, d as e } from "./p-6c6818e1.js";
import "./p-a7d21f71.js";
import "./p-54a36ea4.js";
import "https://assets.oneweb.mercedes-benz.com/plugin/workbench/core/7.32.0/loader/index.js";
import "./p-c1686f45.js";
var o = (function () {
  function o() {
    this.apiInstance = e.getInstance();
  }
  return (
    (o.prototype.getTargets = function (e) {
      var o = this;
      return e.reduce(function (e, r) {
        if (
          "mark" !== r.entryType &&
          "measure" !== r.entryType &&
          "paint" !== r.entryType
        ) {
          var i = o.extractSubdomain(r.name);
          if (-1 === e.indexOf(i)) return n(n([], t(e), !1), [i], !1);
        }
        return e;
      }, []);
    }),
    (o.prototype.initTagLogger = function () {
      var n = this;
      window.addEventListener("beforeunload", function () {
        document.addEventListener("visibilitychange", function () {
          "hidden" === document.visibilityState && n.updateLog();
        });
      });
    }),
    (o.prototype.extractSubdomain = function (n) {
      var t,
        e = n.split("/");
      return (
        n.indexOf("://") > -1
          ? ((t = "".concat(e[2])), e[3] && (t += "/".concat(e[3])))
          : ((t = "".concat(e[0])), e[1] && (t += "/".concat(e[1]))),
        "".concat(t.split("?")[0])
      );
    }),
    (o.prototype.updateLog = function () {
      if (
        Object.prototype.hasOwnProperty.call(window, "performance") &&
        "function" == typeof performance.getEntries
      ) {
        var n = window.performance.getEntries();
        this.apiInstance.updateTagLoggerData(this.getTargets(n));
      } else
        console.log(
          "UC Warning: tag logger functionality is not supported by your browser."
        );
    }),
    o
  );
})();
export default o;
