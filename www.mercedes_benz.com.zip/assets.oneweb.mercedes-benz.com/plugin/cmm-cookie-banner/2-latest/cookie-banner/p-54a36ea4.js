/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var n;
!(function (n) {
  (n.ARROW_UP = "ARROW_UP"), (n.CLOSE = "CLOSE"), (n.INFO = "INFO");
})(n || (n = {}));
const t = [
    "a[href]",
    "area[href]",
    'input:not([disabled]):not([type="hidden"]):not([aria-hidden])',
    "select:not([disabled]):not([aria-hidden])",
    "textarea:not([disabled]):not([aria-hidden])",
    "button:not([disabled]):not([aria-hidden])",
    "iframe",
    "object",
    "embed",
    "[contenteditable]",
    '[tabindex]:not([tabindex^="-"])',
    ".wb-link:not([disabled]):not([aria-hidden])",
    '.wb-input:not([disabled]):not([type="hidden"]):not([aria-hidden])',
    ".wb-select:not([disabled]):not([aria-hidden])",
    ".wb-button:not([disabled]):not([aria-hidden])",
    ".wb-button-group-item:not([disabled]):not([aria-hidden])",
  ],
  e = (n) => {
    let e = [];
    return n
      ? (n.shadowRoot &&
          (e = Array.from(n.shadowRoot.querySelectorAll(t.join(", ")))),
        0 === e.length && (e = Array.from(n.querySelectorAll(t.join(", ")))),
        e)
      : [];
  },
  i = (n) =>
    n.shadowRoot ? i(n.shadowRoot?.querySelector(":first-child")) : n,
  a = (n) => {
    if (!n) return;
    const t = e(n);
    if (0 === t.length) return;
    const a = t.filter((n) => null !== n.offsetParent);
    0 !== a.length &&
      setTimeout(() => {
        i(a[0]).focus();
      }, 500);
  };
function d(n) {
  n?.addEventListener("keydown", r);
}
function o(n) {
  n?.removeEventListener("keydown", r);
}
function r(n) {
  "Tab" === n.key &&
    (function (n) {
      const t = n.target;
      let d = e(t);
      if (0 !== d.length)
        if (
          ((d = d.filter((n) => null !== n.offsetParent)),
          t.shadowRoot.contains(t.shadowRoot.activeElement))
        ) {
          const e = d.indexOf(t.shadowRoot.activeElement);
          n.shiftKey &&
            0 === e &&
            (i(d[d.length - 1]).focus(), n.preventDefault()),
            !n.shiftKey &&
              d.length > 0 &&
              e === d.length - 1 &&
              (i(d[0]).focus(), n.preventDefault());
        } else a(t);
    })(n);
}
const s = new Set(),
  l = ["script", "style"];
function b(n) {
  n !== document.body &&
    n.parentElement &&
    (Array.from(n.parentElement.children)
      .filter(
        (t) =>
          t !== n &&
          !((n) => {
            const t = n.tagName.toLowerCase();
            return l.includes(t);
          })(t)
      )
      .forEach((n) => {
        const t = n.getAttribute("aria-hidden");
        "true" !== t &&
          ((n.dataset.previousAriaHidden = t || "false"), s.add(n)),
          n.setAttribute("aria-hidden", "true");
      }),
    b(n.parentElement));
}
function c() {
  s.forEach((n) => {
    const t = n.dataset.previousAriaHidden;
    t && "false" !== t
      ? n.setAttribute("aria-hidden", t)
      : n.removeAttribute("aria-hidden"),
      delete n.dataset.previousAriaHidden;
  }),
    s.clear();
}
export { n as I, c as a, d as b, b as c, o as r, a as s };
