/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
const t = (t, e) => e?.find((e) => Object.keys(e)[0] === t),
  e = (e, n, o) => {
    const r = n?.toLowerCase().replace(/\s|_/g, ""),
      a = t(e, o),
      i = t("en", o)?.en,
      s = a?.[e];
    return {
      headlineText: s?.[`${r}_headline`] || i?.[`${r}_headline`],
      descriptionText: s?.[`${r}_description`] || i?.[`${r}_description`],
      primaryButtonText: s?.[`${r}_primaryButton`] || i?.[`${r}_primaryButton`],
      secondaryButtonText:
        s?.[`${r}_secondaryButton`] || i?.[`${r}_secondaryButton`],
    };
  };
export { e as a, t as g };
