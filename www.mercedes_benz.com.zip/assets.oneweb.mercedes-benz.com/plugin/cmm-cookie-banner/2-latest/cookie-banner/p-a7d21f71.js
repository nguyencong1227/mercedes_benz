/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
const e = "cookie-banner";
let n,
  t,
  l = !1;
const s = {},
  o = (e) => "object" == (e = typeof e) || "function" === e;
function i(e) {
  var n, t, l;
  return null !==
    (l =
      null ===
        (t =
          null === (n = e.head) || void 0 === n
            ? void 0
            : n.querySelector('meta[name="csp-nonce"]')) || void 0 === t
        ? void 0
        : t.getAttribute("content")) && void 0 !== l
    ? l
    : void 0;
}
const c = (e, n, ...t) => {
    let l = null,
      s = null,
      i = !1,
      c = !1;
    const a = [],
      u = (n) => {
        for (let t = 0; t < n.length; t++)
          (l = n[t]),
            Array.isArray(l)
              ? u(l)
              : null != l &&
                "boolean" != typeof l &&
                ((i = "function" != typeof e && !o(l)) && (l += ""),
                i && c ? (a[a.length - 1].t += l) : a.push(i ? r(null, l) : l),
                (c = i));
      };
    if ((u(t), n)) {
      n.key && (s = n.key);
      {
        const e = n.className || n.class;
        e &&
          (n.class =
            "object" != typeof e
              ? e
              : Object.keys(e)
                  .filter((n) => e[n])
                  .join(" "));
      }
    }
    const f = r(e, null);
    return (f.l = n), a.length > 0 && (f.o = a), (f.i = s), f;
  },
  r = (e, n) => ({ u: 0, h: e, t: n, m: null, o: null, l: null, i: null }),
  a = {},
  u = (e) => z(e).p,
  f = (e, n, t) => {
    const l = u(e);
    return {
      emit: (e) =>
        d(l, n, {
          bubbles: !!(4 & t),
          composed: !!(2 & t),
          cancelable: !!(1 & t),
          detail: e,
        }),
    };
  },
  d = (e, n, t) => {
    const l = ne.ce(n, t);
    return e.dispatchEvent(l), l;
  },
  h = new WeakMap(),
  m = (e) => "sc-" + e.$,
  y = (e, n, t, l, s, i) => {
    if (t !== l) {
      let r = I(e, n),
        a = n.toLowerCase();
      if ("class" === n) {
        const n = e.classList,
          s = b(t),
          o = b(l);
        n.remove(...s.filter((e) => e && !o.includes(e))),
          n.add(...o.filter((e) => e && !s.includes(e)));
      } else if ("style" === n) {
        for (const n in t)
          (l && null != l[n]) ||
            (n.includes("-") ? e.style.removeProperty(n) : (e.style[n] = ""));
        for (const n in l)
          (t && l[n] === t[n]) ||
            (n.includes("-")
              ? e.style.setProperty(n, l[n])
              : (e.style[n] = l[n]));
      } else if ("key" === n);
      else if (r || "o" !== n[0] || "n" !== n[1]) {
        const a = o(l);
        if ((r || (a && null !== l)) && !s)
          try {
            if (e.tagName.includes("-")) e[n] = l;
            else {
              const s = null == l ? "" : l;
              "list" === n ? (r = !1) : (null != t && e[n] == s) || (e[n] = s);
            }
          } catch (c) {}
        null == l || !1 === l
          ? (!1 === l && "" !== e.getAttribute(n)) || e.removeAttribute(n)
          : (!r || 4 & i || s) &&
            !a &&
            e.setAttribute(n, (l = !0 === l ? "" : l));
      } else
        (n =
          "-" === n[2] ? n.slice(3) : I(Y, a) ? a.slice(2) : a[2] + n.slice(3)),
          t && ne.rel(e, n, t, !1),
          l && ne.ael(e, n, l, !1);
    }
  },
  p = /\s/,
  b = (e) => (e ? e.split(p) : []),
  $ = (e, n, t, l) => {
    const o = 11 === n.m.nodeType && n.m.host ? n.m.host : n.m,
      i = (e && e.l) || s,
      c = n.l || s;
    for (l in i) l in c || y(o, l, i[l], void 0, t, n.u);
    for (l in c) y(o, l, i[l], c[l], t, n.u);
  },
  w = (e, t, l) => {
    const s = t.o[l];
    let o,
      i,
      c = 0;
    if (null !== s.t) o = s.m = ee.createTextNode(s.t);
    else if (
      ((o = s.m = ee.createElement(s.h)),
      $(null, s, !1),
      null != n && o["s-si"] !== n && o.classList.add((o["s-si"] = n)),
      s.o)
    )
      for (c = 0; c < s.o.length; ++c) (i = w(e, s, c)), i && o.appendChild(i);
    return o;
  },
  v = (e, n, l, s, o, i) => {
    let c,
      r = e;
    for (r.shadowRoot && r.tagName === t && (r = r.shadowRoot); o <= i; ++o)
      s[o] && ((c = w(null, l, o)), c && ((s[o].m = c), r.insertBefore(c, n)));
  },
  g = (e, n, t, l) => {
    for (; n <= t; ++n) (l = e[n]) && l.m.remove();
  },
  j = (e, n) => e.h === n.h && e.i === n.i,
  k = (e, n) => {
    const t = (n.m = e.m),
      l = e.o,
      s = n.o,
      o = n.t;
    null === o
      ? ($(e, n, !1),
        null !== l && null !== s
          ? ((e, n, t, l) => {
              let s,
                o,
                i = 0,
                c = 0,
                r = 0,
                a = 0,
                u = n.length - 1,
                f = n[0],
                d = n[u],
                h = l.length - 1,
                m = l[0],
                y = l[h];
              for (; i <= u && c <= h; )
                if (null == f) f = n[++i];
                else if (null == d) d = n[--u];
                else if (null == m) m = l[++c];
                else if (null == y) y = l[--h];
                else if (j(f, m)) k(f, m), (f = n[++i]), (m = l[++c]);
                else if (j(d, y)) k(d, y), (d = n[--u]), (y = l[--h]);
                else if (j(f, y))
                  k(f, y),
                    e.insertBefore(f.m, d.m.nextSibling),
                    (f = n[++i]),
                    (y = l[--h]);
                else if (j(d, m))
                  k(d, m), e.insertBefore(d.m, f.m), (d = n[--u]), (m = l[++c]);
                else {
                  for (r = -1, a = i; a <= u; ++a)
                    if (n[a] && null !== n[a].i && n[a].i === m.i) {
                      r = a;
                      break;
                    }
                  r >= 0
                    ? ((o = n[r]),
                      o.h !== m.h
                        ? (s = w(n && n[c], t, r))
                        : (k(o, m), (n[r] = void 0), (s = o.m)),
                      (m = l[++c]))
                    : ((s = w(n && n[c], t, c)), (m = l[++c])),
                    s && f.m.parentNode.insertBefore(s, f.m);
                }
              i > u
                ? v(e, null == l[h + 1] ? null : l[h + 1].m, t, l, c, h)
                : c > h && g(n, i, u);
            })(t, l, n, s)
          : null !== s
          ? (null !== e.t && (t.textContent = ""),
            v(t, null, n, s, 0, s.length - 1))
          : null !== l && g(l, 0, l.length - 1))
      : e.t !== o && (t.data = o);
  },
  S = (e, n) => {
    n && !e.v && n["s-p"] && n["s-p"].push(new Promise((n) => (e.v = n)));
  },
  _ = (e, n) => {
    if (((e.u |= 16), !(4 & e.u))) return S(e, e.g), fe(() => C(e, n));
    e.u |= 512;
  },
  C = (e, n) => {
    const t = e.j;
    let l;
    return (
      n &&
        ((e.u |= 256),
        e.k && (e.k.map(([e, n]) => R(t, e, n)), (e.k = null)),
        (l = R(t, "componentWillLoad"))),
      (l = x(l, () => R(t, "componentWillRender"))),
      x(l, () => O(e, t, n))
    );
  },
  O = async (e, n, t) => {
    const l = e.p,
      s = l["s-rc"];
    t &&
      ((e) => {
        const n = e.S,
          t = e.p,
          l = n.u,
          s = ((e, n) => {
            var t;
            let l = m(n);
            const s = X.get(l);
            if (((e = 11 === e.nodeType ? e : ee), s))
              if ("string" == typeof s) {
                let n,
                  o = h.get((e = e.head || e));
                if ((o || h.set(e, (o = new Set())), !o.has(l))) {
                  {
                    (n = ee.createElement("style")), (n.innerHTML = s);
                    const l = null !== (t = ne._) && void 0 !== t ? t : i(ee);
                    null != l && n.setAttribute("nonce", l),
                      e.insertBefore(n, e.querySelector("link"));
                  }
                  o && o.add(l);
                }
              } else
                e.adoptedStyleSheets.includes(s) ||
                  (e.adoptedStyleSheets = [...e.adoptedStyleSheets, s]);
            return l;
          })(te && t.shadowRoot ? t.shadowRoot : t.getRootNode(), n);
        10 & l && ((t["s-sc"] = s), t.classList.add(s + "-h"));
      })(e);
    M(e, n), s && (s.map((e) => e()), (l["s-rc"] = void 0));
    {
      const n = l["s-p"],
        t = () => N(e);
      0 === n.length
        ? t()
        : (Promise.all(n).then(t), (e.u |= 4), (n.length = 0));
    }
  },
  M = (e, l) => {
    try {
      (l = l.render()),
        (e.u &= -17),
        (e.u |= 2),
        ((e, l) => {
          const s = e.p,
            o = e.S,
            i = e.C || r(null, null),
            u = ((e) => e && e.h === a)(l) ? l : c(null, null, l);
          (t = s.tagName),
            o.O && ((u.l = u.l || {}), o.O.map(([e, n]) => (u.l[n] = s[e]))),
            (u.h = null),
            (u.u |= 4),
            (e.C = u),
            (u.m = i.m = s.shadowRoot || s),
            (n = s["s-sc"]),
            k(i, u);
        })(e, l);
    } catch (s) {
      J(s, e.p);
    }
    return null;
  },
  N = (e) => {
    const n = e.p,
      t = e.j,
      l = e.g;
    R(t, "componentDidRender"),
      64 & e.u ||
        ((e.u |= 64), E(n), R(t, "componentDidLoad"), e.M(n), l || P()),
      e.N(n),
      e.v && (e.v(), (e.v = void 0)),
      512 & e.u && ue(() => _(e, !1)),
      (e.u &= -517);
  },
  P = () => {
    E(ee.documentElement),
      ue(() => d(Y, "appload", { detail: { namespace: e } }));
  },
  R = (e, n, t) => {
    if (e && e[n])
      try {
        return e[n](t);
      } catch (l) {
        J(l);
      }
  },
  x = (e, n) => (e && e.then ? e.then(n) : n()),
  E = (e) => e.classList.add("hydrated"),
  L = (e, n, t) => {
    if (n.P) {
      e.watchers && (n.R = e.watchers);
      const l = Object.entries(n.P),
        s = e.prototype;
      if (
        (l.map(([e, [l]]) => {
          31 & l || (2 & t && 32 & l)
            ? Object.defineProperty(s, e, {
                get() {
                  return ((e, n) => z(this).L.get(n))(0, e);
                },
                set(t) {
                  ((e, n, t, l) => {
                    const s = z(e),
                      i = s.p,
                      c = s.L.get(n),
                      r = s.u,
                      a = s.j;
                    if (
                      ((t = ((e, n) =>
                        null == e || o(e)
                          ? e
                          : 4 & n
                          ? "false" !== e && ("" === e || !!e)
                          : 1 & n
                          ? e + ""
                          : e)(t, l.P[n][0])),
                      (!(8 & r) || void 0 === c) &&
                        t !== c &&
                        (!Number.isNaN(c) || !Number.isNaN(t)) &&
                        (s.L.set(n, t), a))
                    ) {
                      if (l.R && 128 & r) {
                        const e = l.R[n];
                        e &&
                          e.map((e) => {
                            try {
                              a[e](t, c, n);
                            } catch (l) {
                              J(l, i);
                            }
                          });
                      }
                      2 == (18 & r) && _(s, !1);
                    }
                  })(this, e, t, n);
                },
                configurable: !0,
                enumerable: !0,
              })
            : 1 & t &&
              64 & l &&
              Object.defineProperty(s, e, {
                value(...n) {
                  const t = z(this);
                  return t.W.then(() => t.j[e](...n));
                },
              });
        }),
        1 & t)
      ) {
        const t = new Map();
        (s.attributeChangedCallback = function (e, n, l) {
          ne.jmp(() => {
            const n = t.get(e);
            if (this.hasOwnProperty(n)) (l = this[n]), delete this[n];
            else if (
              s.hasOwnProperty(n) &&
              "number" == typeof this[n] &&
              this[n] == l
            )
              return;
            this[n] = (null !== l || "boolean" != typeof this[n]) && l;
          });
        }),
          (e.observedAttributes = l
            .filter(([e, n]) => 15 & n[0])
            .map(([e, l]) => {
              const s = l[1] || e;
              return t.set(s, e), 512 & l[0] && n.O.push([e, s]), s;
            }));
      }
    }
    return e;
  },
  W = (e) => {
    R(e, "connectedCallback");
  },
  A = (e, n) => {
    class t extends Array {
      item(e) {
        return this[e];
      }
    }
    if (8 & n.u) {
      const n = e.__lookupGetter__("childNodes");
      Object.defineProperty(e, "children", {
        get() {
          return this.childNodes.map((e) => 1 === e.nodeType);
        },
      }),
        Object.defineProperty(e, "childElementCount", {
          get: () => e.children.length,
        }),
        Object.defineProperty(e, "childNodes", {
          get() {
            const e = n.call(this);
            if (0 == (1 & ne.u) && 2 & z(this).u) {
              const n = new t();
              for (let t = 0; t < e.length; t++) {
                const l = e[t]["s-nr"];
                l && n.push(l);
              }
              return n;
            }
            return t.from(e);
          },
        });
    }
  },
  T = (e, n = {}) => {
    var t;
    const l = [],
      s = n.exclude || [],
      o = Y.customElements,
      c = ee.head,
      r = c.querySelector("meta[charset]"),
      a = ee.createElement("style"),
      u = [];
    let f,
      d = !0;
    Object.assign(ne, n),
      (ne.A = new URL(n.resourcesUrl || "./", ee.baseURI).href),
      e.map((e) => {
        e[1].map((n) => {
          const t = { u: n[0], $: n[1], P: n[2], T: n[3] };
          (t.P = n[2]),
            (t.T = n[3]),
            (t.O = []),
            (t.R = {}),
            !te && 1 & t.u && (t.u |= 8);
          const i = t.$,
            c = class extends HTMLElement {
              constructor(e) {
                super(e),
                  G((e = this), t),
                  1 & t.u &&
                    (te
                      ? e.attachShadow({ mode: "open" })
                      : "shadowRoot" in e || (e.shadowRoot = e)),
                  A(e, t);
              }
              connectedCallback() {
                f && (clearTimeout(f), (f = null)),
                  d
                    ? u.push(this)
                    : ne.jmp(() =>
                        ((e) => {
                          if (0 == (1 & ne.u)) {
                            const n = z(e),
                              t = n.S,
                              l = () => {};
                            if (1 & n.u) D(e, n, t.T), W(n.j);
                            else {
                              n.u |= 1;
                              {
                                let t = e;
                                for (; (t = t.parentNode || t.host); )
                                  if (t["s-p"]) {
                                    S(n, (n.g = t));
                                    break;
                                  }
                              }
                              t.P &&
                                Object.entries(t.P).map(([n, [t]]) => {
                                  if (31 & t && e.hasOwnProperty(n)) {
                                    const t = e[n];
                                    delete e[n], (e[n] = t);
                                  }
                                }),
                                (async (e, n, t, l, s) => {
                                  if (0 == (32 & n.u)) {
                                    {
                                      if (((n.u |= 32), (s = Q(t)).then)) {
                                        const e = () => {};
                                        (s = await s), e();
                                      }
                                      s.isProxied ||
                                        ((t.R = s.watchers),
                                        L(s, t, 2),
                                        (s.isProxied = !0));
                                      const e = () => {};
                                      n.u |= 8;
                                      try {
                                        new s(n);
                                      } catch (c) {
                                        J(c);
                                      }
                                      (n.u &= -9), (n.u |= 128), e(), W(n.j);
                                    }
                                    if (s.style) {
                                      let e = s.style;
                                      const n = m(t);
                                      if (!X.has(n)) {
                                        const l = () => {};
                                        8 & t.u &&
                                          (e = await __sc_import_cookie_banner(
                                            "./p-3508048d.js"
                                          ).then((t) => t.scopeCss(e, n, !1))),
                                          ((e, n, t) => {
                                            let l = X.get(e);
                                            se && t
                                              ? ((l = l || new CSSStyleSheet()),
                                                "string" == typeof l
                                                  ? (l = n)
                                                  : l.replaceSync(n))
                                              : (l = n),
                                              X.set(e, l);
                                          })(n, e, !!(1 & t.u)),
                                          l();
                                      }
                                    }
                                  }
                                  const o = n.g,
                                    i = () => _(n, !0);
                                  o && o["s-rc"] ? o["s-rc"].push(i) : i();
                                })(0, n, t);
                            }
                            l();
                          }
                        })(this)
                      );
              }
              disconnectedCallback() {
                ne.jmp(() =>
                  (() => {
                    if (0 == (1 & ne.u)) {
                      const e = z(this),
                        n = e.j;
                      e.D && (e.D.map((e) => e()), (e.D = void 0)),
                        R(n, "disconnectedCallback");
                    }
                  })()
                );
              }
              componentOnReady() {
                return z(this).H;
              }
            };
          (t.U = e[0]),
            s.includes(i) || o.get(i) || (l.push(i), o.define(i, L(c, t, 1)));
        });
      });
    {
      (a.innerHTML = l + "{visibility:hidden}.hydrated{visibility:inherit}"),
        a.setAttribute("data-styles", "");
      const e = null !== (t = ne._) && void 0 !== t ? t : i(ee);
      null != e && a.setAttribute("nonce", e),
        c.insertBefore(a, r ? r.nextSibling : c.firstChild);
    }
    (d = !1),
      u.length
        ? u.map((e) => e.connectedCallback())
        : ne.jmp(() => (f = setTimeout(P, 30)));
  },
  D = (e, n, t) => {
    t &&
      t.map(([t, l, s]) => {
        const o = U(e, t),
          i = H(n, s),
          c = q(t);
        ne.ael(o, l, i, c), (n.D = n.D || []).push(() => ne.rel(o, l, i, c));
      });
  },
  H = (e, n) => (t) => {
    try {
      256 & e.u ? e.j[n](t) : (e.k = e.k || []).push([n, t]);
    } catch (l) {
      J(l);
    }
  },
  U = (e, n) => (4 & n ? ee : e),
  q = (e) => 0 != (2 & e),
  F = (e) => (ne._ = e),
  V = new WeakMap(),
  z = (e) => V.get(e),
  B = (e, n) => V.set((n.j = e), n),
  G = (e, n) => {
    const t = { u: 0, p: e, S: n, L: new Map() };
    return (
      (t.W = new Promise((e) => (t.N = e))),
      (t.H = new Promise((e) => (t.M = e))),
      (e["s-p"] = []),
      (e["s-rc"] = []),
      D(e, t, n.T),
      V.set(e, t)
    );
  },
  I = (e, n) => n in e,
  J = (e, n) => (0, console.error)(e, n),
  K = new Map(),
  Q = (e) => {
    const n = e.$.replace(/-/g, "_"),
      t = e.U,
      l = K.get(t);
    return l
      ? l[n]
      : __sc_import_cookie_banner(`./${t}.entry.js`).then(
          (e) => (K.set(t, e), e[n]),
          J
        );
    /*!__STENCIL_STATIC_IMPORT_SWITCH__*/
  },
  X = new Map(),
  Y = "undefined" != typeof window ? window : {},
  Z = Y.CSS,
  ee = Y.document || { head: {} },
  ne = {
    u: 0,
    A: "",
    jmp: (e) => e(),
    raf: (e) => requestAnimationFrame(e),
    ael: (e, n, t, l) => e.addEventListener(n, t, l),
    rel: (e, n, t, l) => e.removeEventListener(n, t, l),
    ce: (e, n) => new CustomEvent(e, n),
  },
  te = (() => (ee.head.attachShadow + "").indexOf("[native") > -1)(),
  le = (e) => Promise.resolve(e),
  se = (() => {
    try {
      return (
        new CSSStyleSheet(),
        "function" == typeof new CSSStyleSheet().replaceSync
      );
    } catch (e) {}
    return !1;
  })(),
  oe = [],
  ie = [],
  ce = (e, n) => (t) => {
    e.push(t), l || ((l = !0), n && 4 & ne.u ? ue(ae) : ne.raf(ae));
  },
  re = (e) => {
    for (let t = 0; t < e.length; t++)
      try {
        e[t](performance.now());
      } catch (n) {
        J(n);
      }
    e.length = 0;
  },
  ae = () => {
    re(oe), re(ie), (l = oe.length > 0) && ne.raf(ae);
  },
  ue = (e) => le().then(e),
  fe = ce(ie, !0);
export {
  Z as C,
  a as H,
  e as N,
  le as a,
  T as b,
  f as c,
  ee as d,
  u as g,
  c as h,
  ne as p,
  B as r,
  F as s,
  Y as w,
};
