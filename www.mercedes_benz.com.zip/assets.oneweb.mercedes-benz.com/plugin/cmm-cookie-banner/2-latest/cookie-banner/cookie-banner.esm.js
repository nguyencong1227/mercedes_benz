/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import {
  p as e,
  w as a,
  d as n,
  N as t,
  a as i,
  b as o,
} from "./p-a7d21f71.js";
export { s as setNonce } from "./p-a7d21f71.js";
(() => {
  e.t = a.__cssshim;
  const o = Array.from(n.querySelectorAll("script")).find(
      (e) =>
        new RegExp(`/${t}(\\.esm)?\\.js($|\\?|#)`).test(e.src) ||
        e.getAttribute("data-stencil-namespace") === t
    ),
    s = o["data-opts"] || {};
  return "onbeforeload" in o && !history.scrollRestoration
    ? { then() {} }
    : ((s.resourcesUrl = new URL(
        ".",
        new URL(o.getAttribute("data-resources-url") || o.src, a.location.href)
      ).href),
      ((i, o) => {
        const s = `__sc_import_${t.replace(/\s|-/g, "_")}`;
        try {
          a[s] = new Function("w", `return import(w);//${Math.random()}`);
        } catch (l) {
          const t = new Map();
          a[s] = (l) => {
            var c;
            const r = new URL(l, i).href;
            let g = t.get(r);
            if (!g) {
              const i = n.createElement("script");
              (i.type = "module"),
                (i.crossOrigin = o.crossOrigin),
                (i.src = URL.createObjectURL(
                  new Blob([`import * as m from '${r}'; window.${s}.m = m;`], {
                    type: "application/javascript",
                  })
                ));
              const l =
                null !== (c = e.i) && void 0 !== c
                  ? c
                  : (function (e) {
                      var a, n, t;
                      return null !==
                        (t =
                          null ===
                            (n =
                              null === (a = e.head) || void 0 === a
                                ? void 0
                                : a.querySelector('meta[name="csp-nonce"]')) ||
                          void 0 === n
                            ? void 0
                            : n.getAttribute("content")) && void 0 !== t
                        ? t
                        : void 0;
                    })(n);
              null != l && i.setAttribute("nonce", l),
                (g = new Promise((e) => {
                  i.onload = () => {
                    e(a[s].m), i.remove();
                  };
                })),
                t.set(r, g),
                n.head.appendChild(i);
            }
            return g;
          };
        }
      })(s.resourcesUrl, o),
      a.customElements
        ? i(s)
        : __sc_import_cookie_banner("./p-c3ec6642.js").then(() => s));
})().then((e) =>
  o(
    [
      [
        "p-f72b3915",
        [
          [
            1,
            "cmm-consent-overlay",
            {
              category: [1],
              direction: [1],
              serviceData: [1, "service-data"],
              settingsLabels: [1, "settings-labels"],
              data: [32],
              settings: [32],
            },
          ],
        ],
      ],
      [
        "p-e03d2767",
        [
          [
            1,
            "cmm-privacy-shield-overlay",
            {
              language: [1],
              direction: [1],
              technology: [1],
              labels: [1],
              src: [1],
              height: [8],
              width: [8],
              descriptionText: [32],
              headlineText: [32],
              primaryButtonText: [32],
              secondaryButtonText: [32],
              updateContent: [64],
            },
          ],
        ],
      ],
      [
        "p-a93a22d0",
        [
          [
            1,
            "cmm-cookie-banner",
            {
              settingsId: [1, "settings-id"],
              variant: [1537],
              initialLanguage: [1, "initial-language"],
              legalPages: [1, "legal-pages"],
              bannerLabels: [32],
              bannerVisible: [32],
              currentLanguage: [32],
              internalLegalPages: [32],
              internalVariant: [32],
              labels: [32],
              languages: [32],
              showNotification: [32],
              baseSettings: [32],
              settingsLabels: [32],
              categories: [32],
              getServices: [64],
              updateServices: [64],
              changeLanguage: [64],
              getConsents: [64],
              getConsentsByCategory: [64],
              getLanguageSettings: [64],
              togglePrivacyShield: [64],
              createPrivacyShields: [64],
              removePrivacyShields: [64],
              updatePrivacyShieldContent: [64],
              getLabelsForPrivacyShield: [64],
              getDirection: [64],
            },
            [
              [6, "usercentrics-change-language", "ucChangeLanguage"],
              [6, "privacy-shield-show-modal", "privacyShieldShowModal"],
              [6, "usercentrics-consents-loaded", "consentsLoaded"],
              [6, "usercentrics-consents-updated", "consentsUpdated"],
              [6, "trackEvent", "trackEvents"],
              [6, "toggleOverlay", "toggleHandler"],
              [6, "toggleNotification", "toggleNotification"],
            ],
          ],
          [
            0,
            "cmm-cookie-settings",
            {
              categories: [16],
              direction: [1],
              labels: [16],
              showNotification: [4, "show-notification"],
              userDecision: [16],
              variant: [1],
              handleCategoryChange: [16],
              handlerAcceptAll: [16],
              handlerSaveSelection: [16],
              handlerToggleDetails: [16],
              handleSelectAllChange: [16],
              handleServiceChange: [16],
              toggleCategoryDetails: [16],
              toggleConsentInfoModal: [16],
            },
          ],
          [
            0,
            "cmm-buttons-wrapper",
            {
              handlerAcceptAll: [16],
              handlerDeny: [16],
              handlerToggleDetails: [16],
              handlerSaveSelection: [16],
              labels: [16],
              variant: [1],
            },
          ],
          [
            0,
            "cmm-category-overview",
            {
              handleCategoryChange: [16],
              scrollToDetails: [16],
              categories: [16],
            },
          ],
          [0, "cmm-footer-links", { links: [16] }],
          [0, "cmm-heading-section", { content: [16] }],
          [
            0,
            "cmm-languages-list",
            {
              handleChangeLanguage: [16],
              languages: [16],
              languageSelected: [1, "language-selected"],
            },
          ],
          [1, "cmm-notification", { content: [1], direction: [1] }],
          [1, "cmm-icon", { name: [1], icon: [32] }],
        ],
      ],
    ],
    e
  )
);
