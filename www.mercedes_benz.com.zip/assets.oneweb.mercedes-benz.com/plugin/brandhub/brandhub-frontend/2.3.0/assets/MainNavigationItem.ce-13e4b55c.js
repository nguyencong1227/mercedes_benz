import { P as m, C as d } from "./ParentComponentMixin-b739cccc.js";
import { T as b } from "./TrackingPushService-374dd83c.js";
import { J as u, a as l } from "./JumpToEventBus-9bec3b36.js";
import {
  d as h,
  o as n,
  c as e,
  h as a,
  t as o,
  n as r,
  B as v,
} from "./index.js";
import { _ as c } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ShadowDom-bc0a555e.js";
import "./mitt-f7ef348c.js";
const g = h({
    name: "MainNavigationItem",
    props: {
      itemText: String,
      itemLink: String,
      editMode: Boolean,
      flyoutUrl: String,
      itemIndex: Number,
    },
    mixins: [m],
    data() {
      return {
        subNavigationItems: new d(),
        fadeIn: !1,
        isActive: !1,
        initial: !0,
        activeSubNavItem: null,
        notHovered: !1,
      };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-main-navigation-item--edit-mode": this.editMode,
          "brandhub-main-navigation-item--in": this.fadeIn,
          "brandhub-main-navigation-item--active": this.isActive,
        };
      },
    },
    methods: {
      focusItem() {
        this.itemIndex === 0 && this.$el.focus();
      },
      onItemClick() {
        this.itemText &&
          b.pushTrackingAttributes(
            "link",
            "Main Navigation",
            this.itemText,
            this.itemLink
          ),
          (this.isActive = !0);
        const i = new CustomEvent("mainNavClicked", {
          bubbles: !0,
          composed: !0,
          detail: { clickedItem: this },
        });
        this.$el.dispatchEvent(i);
      },
    },
    created() {
      this.initParentComponentMixin(this.subNavigationItems, [
        "SubNavigationItem",
      ]),
        u.on(l.JumpToNavigation, this.focusItem);
    },
    mounted() {
      window.innerWidth <= 768 && (this.fadeIn = !0),
        setTimeout(() => {
          this.fadeIn = !0;
        }, 25);
    },
  }),
  p = `.brandhub-main-navigation-item{opacity:0;pointer-events:none;transform:translateY(2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out;align-items:center;background-color:transparent;border:none;box-sizing:border-box;color:var(--link-color, currentColor);cursor:pointer;display:flex;font-family:inherit;font-size:inherit;height:100%;line-height:inherit;padding:1.0714285714rem 2.5714285714rem;text-decoration:none;transition:transform .8s var(--ease-out-expo) var(--fade-in-delay),opacity .8s ease-out var(--fade-in-delay),color .4s ease-in-out .1s,padding-bottom .7s ease-in-out}.brandhub-main-navigation-item--in{opacity:1;pointer-events:auto;transform:translateY(0)}@media (min-width: 1024px){.brandhub-main-navigation-item{padding:.7142857143rem 1.6428571429rem calc(.7142857143rem + (var(--scroll-progress) * 2.1428571429rem))}}@media (min-width: 1440px){.brandhub-main-navigation-item{padding:.7142857143rem 2.5714285714rem calc(.7142857143rem + (var(--scroll-progress) * 2.1428571429rem))}}.brandhub-main-navigation-item:hover,.brandhub-main-navigation-item--active{color:var(--wb-white);transition-delay:0s}.brandhub-main-navigation-item:focus-visible{outline:none}.brandhub-main-navigation-item:focus-visible .brandhub-main-navigation-item__text{position:relative}.brandhub-main-navigation-item:focus-visible .brandhub-main-navigation-item__text:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-main-navigation-item:focus-visible .brandhub-main-navigation-item__text:after{left:-.5rem;padding-right:.5rem;top:-.2142857143rem}.brandhub-main-navigation-item.focus-visible{outline:none}.brandhub-main-navigation-item.focus-visible .brandhub-main-navigation-item__text{position:relative}.brandhub-main-navigation-item.focus-visible .brandhub-main-navigation-item__text:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-main-navigation-item.focus-visible .brandhub-main-navigation-item__text:after{left:-.5rem;padding-right:.5rem;top:-.2142857143rem}.brandhub-main-navigation-item:focus{outline:none}.brandhub-main-navigation-item .subnavigationitem{display:none}.brandhub-main-navigation-item--edit-mode .new{background:#a0a0a0;border-radius:4px;height:2.875rem;min-width:8rem}
`,
  f = ["href"],
  _ = { class: "brandhub-main-navigation-item__text" },
  k = { class: "brandhub-main-navigation-item__text" };
function x(i, t, y, C, I, w) {
  return i.itemLink
    ? (n(),
      e(
        "a",
        {
          key: 0,
          class: r(["brandhub-main-navigation-item", i.rootClass]),
          href: i.itemLink,
        },
        [a("span", _, o(i.itemText), 1)],
        10,
        f
      ))
    : (n(),
      e(
        "button",
        {
          key: 1,
          class: r(["brandhub-main-navigation-item", i.rootClass]),
          onClick:
            t[0] || (t[0] = (...s) => i.onItemClick && i.onItemClick(...s)),
        },
        [a("span", k, o(i.itemText), 1), v(i.$slots, "default")],
        2
      ));
}
const A = c(g, [
  ["render", x],
  ["styles", [p]],
]);
export { A as default };
