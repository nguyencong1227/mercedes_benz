import { m as t } from "./mitt-f7ef348c.js";
var a = ((o) => (
  (o.JumpToNavigation = "jump_to_navigation"),
  (o.JumpToFooter = "jump_to_footer"),
  o
))(a || {});
const r = t();
export { r as J, a };
