import { _ as i } from "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import { p as N } from "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import { _ as o } from "./_plugin-vue_export-helper-c27b6911.js";
import {
  j as n,
  w as c,
  o as s,
  c as t,
  F as l,
  D as u,
  e as m,
  h as d,
  n as p,
} from "./index.js";
import "./index-12214b95.js";
const h = `.brandhub-picture{width:100%}.brandhub-picture--cover,.brandhub-picture--contain{display:block;height:100%}.brandhub-picture--cover,.brandhub-picture--cover img{object-fit:cover}.brandhub-picture--contain,.brandhub-picture--contain img{object-fit:contain}
`,
  b = ["srcset", "media"],
  f = ["src", "alt"];
function g(e, v, _, k, C, $) {
  const a = n("intersect");
  return c(
    (s(),
    t("picture", null, [
      e.sources && e.sources.length > 0
        ? (s(!0),
          t(
            l,
            { key: 0 },
            u(
              e.sources,
              (r) => (
                s(),
                t(
                  "source",
                  {
                    key: `image-source-${r.src}-${r.maxWidth}`,
                    srcset: r.src,
                    media: e.mq(r.maxWidth),
                  },
                  null,
                  8,
                  b
                )
              )
            ),
            128
          ))
        : m("", !0),
      d(
        "img",
        {
          src: e.fallbackImage,
          alt: e.alt,
          class: p(["brandhub-picture", [e.modifierClass, e.imageClass]]),
          ref: "img",
        },
        null,
        10,
        f
      ),
    ])),
    [
      [
        a,
        {
          observerOptions: e.observerOptions,
          onChange: e.handleIntersectChange,
        },
      ],
    ]
  );
}
const D = o(i, [
  ["render", g],
  ["styles", [h]],
]);
export { D as default, N as placeholderUrl };
