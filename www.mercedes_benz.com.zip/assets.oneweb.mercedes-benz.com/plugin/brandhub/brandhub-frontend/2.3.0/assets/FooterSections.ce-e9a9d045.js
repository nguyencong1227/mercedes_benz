import { P as u, C as p } from "./ParentComponentMixin-b739cccc.js";
import { R as f } from "./ResizeUpdateMixin-a56b9b41.js";
import "./BrandSafeHyphens-ffe3b60a.js";
import "./index-12214b95.js";
import { B as g } from "./BackgroundColorMixin-87cd4cac.js";
import {
  d as b,
  i as h,
  o as l,
  c as a,
  h as d,
  F as v,
  D as I,
  B as c,
  n as w,
  g as _,
} from "./index.js";
import { _ as S } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ShadowDom-bc0a555e.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const C = 70,
  E = b({
    name: "FooterSections",
    props: { editMode: Boolean, pageOpenedInEditMode: Boolean },
    mixins: [u, f, g],
    setup() {
      const e = h(),
        t = h();
      return { wrapperElement: e, itemPlaceholders: t };
    },
    data() {
      return { items: new p(), activeItemIndex: null, overflowHeight: 0 };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-footer-sections--edit-mode":
            this.editModeOrPageOpenedInEditMode,
        };
      },
      rootStyle() {
        return {
          "--wrapper-height": `${this.items.length * 100 + 50}vh`,
          "--overflow-height": `${this.overflowHeight}px`,
        };
      },
      editModeOrPageOpenedInEditMode() {
        return this.editMode || this.pageOpenedInEditMode;
      },
    },
    methods: {
      onItemAdded() {
        this.updateHeight();
      },
      resizeEnd() {
        this.updateHeight();
      },
      updateHeight() {
        if (this.items) {
          const e = this.items.last();
          if (e) {
            const t = getComputedStyle(e.$el).bottom,
              i = parseInt(t.replace("px", ""), 10);
            this.overflowHeight = Math.max(-i, 0);
          }
        }
      },
      handleFocus(e) {
        const t = e.target;
        if (this.$el.contains(t)) {
          const s = t.getAttribute("item-index");
          if (s !== "") {
            const o = Number(s);
            Number.isNaN(o) || (this.activeItemIndex = o);
          }
        }
      },
      handleScroll() {
        if (this.wrapperElement) {
          const { top: e } = this.wrapperElement.getBoundingClientRect();
          this.handleScrollCalculation(e, window.innerHeight);
        }
      },
      handleScrollCalculation(e, t) {
        const i = t * (C / 80),
          s = Math.abs(e);
        let o = Math.floor(s / i);
        const n = this.items.length;
        if (
          (o > 0 && e > 0 && (o = null),
          o !== null && o >= n && (o = n),
          o === null)
        )
          this.activeItemIndex = null;
        else if (o < n) {
          const r = this.items.items.find((m) => m.itemIndex === o);
          this.activeItemIndex = r ? r.index : null;
        }
      },
      onSubItemFocused(e) {
        const t = e.detail.item.parentIndex;
        this.scrollToIndex(t, null);
      },
      onSitemapItemFocused(e) {
        const t = this.items.length - 1;
        t !== this.activeItemIndex && (this.activeItemIndex = t);
        const i = e.detail.item.$el,
          s =
            window.scrollY +
            i.getBoundingClientRect().top -
            (window.innerHeight || document.documentElement.clientHeight) * 0.5;
        this.scrollToIndex(t, s);
      },
      scrollToIndex(e, t) {
        if (this.itemPlaceholders && this.itemPlaceholders[e]) {
          const i = this.itemPlaceholders[e],
            s =
              (window.innerHeight || document.documentElement.clientHeight) *
              0.25,
            o = window.scrollY;
          let n = o + i.getBoundingClientRect().top;
          t && t > n && (n = t), Math.abs(n - o) > s && window.scrollTo(0, n);
        }
      },
    },
    watch: {
      activeItemIndex(e, t) {
        e !== null && t !== null
          ? e > t
            ? (this.items.items[e].fadeIn(), this.items.items[t].fadeOut(!0))
            : e < t &&
              (this.items.items[e].fadeIn(), this.items.items[t].fadeOut(!1))
          : e !== null && t === null
          ? this.items.items[e].fadeIn()
          : e === null && t !== null && this.items.items[t].fadeOut(!0);
      },
    },
    created() {
      this.initParentComponentMixin(
        this.items,
        ["FooterSectionsItem", "FooterSitemap"],
        this.onItemAdded
      ),
        this.updateHeight();
    },
    mounted() {
      this.editModeOrPageOpenedInEditMode ||
        (window.addEventListener("scroll", this.handleScroll, { passive: !0 }),
        this.$el.addEventListener(
          "footerSectionsItemFocused",
          this.onSubItemFocused
        ),
        this.$el.addEventListener(
          "footerSitemapItemFocused",
          this.onSitemapItemFocused
        ));
    },
    updated() {
      this.updateHeight();
    },
  }),
  M = `.brandhub-footer-sections{background-color:var(--background-color);display:flex;flex-direction:column;height:var(--wrapper-height);margin-bottom:var(--overflow-height, 0);position:relative}.brandhub-footer-sections--edit-mode{height:auto}.brandhub-footer-sections__item-placeholders{bottom:0;left:0;overflow:hidden;position:absolute;right:0;top:0}.brandhub-footer-sections__item-placeholder{height:100vh}.brandhub-footer-sections__content{height:100vh;left:0;position:sticky;top:0;width:100%}.brandhub-footer-sections--edit-mode .brandhub-footer-sections__content{height:auto;position:relative}.brandhub-footer-sections__wrapper{display:flex;height:50%;position:absolute;top:40%;width:100%}.brandhub-footer-sections--edit-mode .brandhub-footer-sections__wrapper{height:auto;position:relative;top:auto}
`,
  H = { class: "brandhub-footer-sections__item-placeholders" },
  F = ["extra-threshold"],
  y = { class: "brandhub-footer-sections__content" };
function O(e, t, i, s, o, n) {
  return (
    l(),
    a(
      "div",
      {
        class: w(["brandhub-footer-sections", e.rootClass]),
        style: _([e.rootStyle, e.getBackgroundColorStyle]),
        ref: "wrapperElement",
      },
      [
        d("div", H, [
          (l(!0),
          a(
            v,
            null,
            I(
              e.items.length,
              (r) => (
                l(),
                a(
                  "div",
                  {
                    key: r,
                    "extra-threshold":
                      r === e.items.length && e.overflowHeight
                        ? e.overflowHeight
                        : null,
                    ref_for: !0,
                    ref: "itemPlaceholders",
                    class: "brandhub-footer-sections__item-placeholder",
                  },
                  null,
                  8,
                  F
                )
              )
            ),
            128
          )),
        ]),
        d("div", y, [
          d(
            "div",
            {
              class: "brandhub-footer-sections__wrapper",
              onFocusin:
                t[0] || (t[0] = (...r) => e.handleFocus && e.handleFocus(...r)),
            },
            [c(e.$slots, "default"), c(e.$slots, "sectionItems")],
            32
          ),
        ]),
      ],
      6
    )
  );
}
const A = S(E, [
  ["render", O],
  ["styles", [M]],
]);
export { A as default };
