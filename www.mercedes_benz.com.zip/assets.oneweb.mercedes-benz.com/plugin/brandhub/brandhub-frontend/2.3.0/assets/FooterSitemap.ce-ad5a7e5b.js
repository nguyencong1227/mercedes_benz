import {
  d as n,
  a as r,
  _ as a,
  r as d,
  j as m,
  w as s,
  o as p,
  c as h,
  h as t,
  f as l,
  B as f,
  n as c,
  g as b,
} from "./index.js";
import { I as _ } from "./index-12214b95.js";
import { P as u, C as g } from "./ParentComponentMixin-b739cccc.js";
import { B as w } from "./BackgroundColorMixin-87cd4cac.js";
import { _ as x } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ShadowDom-bc0a555e.js";
const v = r(() =>
    a(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  I = n({
    props: {
      headlineText: String,
      editMode: Boolean,
      pageOpenedInEditMode: Boolean,
    },
    components: { WordFade: v },
    directives: { intersect: _ },
    mixins: [u, w],
    data() {
      return { items: new g(), isShown: !1 };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-footer-sitemap--edit-mode":
            this.editModeOrPageOpenedInEditMode,
          "brandhub-footer-sitemap--show": this.isShown,
        };
      },
      editModeOrPageOpenedInEditMode() {
        return this.editMode || this.pageOpenedInEditMode;
      },
    },
    methods: {
      fadeInItems() {
        for (const e of this.items.items) e.fadeIn = !0;
      },
      handleIntersection(e) {
        e ? this.fadeInItems() : this.fadeOut();
      },
      fadeIn() {
        this.fadeInItems(), (this.isShown = !0);
      },
      fadeOut() {
        for (const e of this.items.items) e.fadeIn = !1;
        this.isShown = !1;
      },
    },
    created() {
      this.initParentComponentMixin(this.items, ["FooterSitemapItem"]);
    },
  }),
  C = `.brandhub-footer-sitemap{background-color:var(--background-color);padding-left:1.1428571429rem;padding-right:1.1428571429rem}@media (min-width: 768px){.brandhub-footer-sitemap{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-footer-sitemap{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-footer-sitemap{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-footer-sitemap{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-footer-sitemap__container{column-gap:2rem;padding-bottom:12rem;padding-top:12rem}@media (min-width: 480px){.brandhub-footer-sitemap__container{row-gap:2.5714285714rem}}@media (min-width: 768px){.brandhub-footer-sitemap__container{column-gap:2.2857142857rem;display:flex}}@media (min-width: 1024px){.brandhub-footer-sitemap__container{column-gap:3.4285714286rem}}@media (min-width: 1280px){.brandhub-footer-sitemap__container{padding-bottom:13.7142857143rem;padding-top:13.7142857143rem;row-gap:5rem}}@media (min-width: 1440px){.brandhub-footer-sitemap__container{column-gap:3.1428571429rem}}.brandhub-footer-sitemap__container--show{opacity:1;pointer-events:auto;transition-duration:1.5s}.brandhub-footer-sitemap__container--edit-mode{margin-bottom:2rem;margin-top:2rem;opacity:1;pointer-events:auto;position:relative;transition:none}.brandhub-footer-sitemap__container--edit-mode .new{background:#a0a0a0;border-radius:4px;height:2.875rem;min-width:8rem}.brandhub-footer-sitemap__container--edit-mode .new{width:11rem}.brandhub-footer-sitemap__line{border-top:1px solid var(--wb-grey-20);padding-top:var(--spacer-s)}.brandhub-footer-sitemap__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;color:var(--text-color);font-size:1.8571428571rem;line-height:2.2857142857rem;margin-bottom:4.5714285714rem;min-width:11.5rem}@media (min-width: 768px){.brandhub-footer-sitemap__headline{font-size:2.4285714286rem;line-height:3.1428571429rem;min-width:17.4285714286rem}}@media (min-width: 1440px){.brandhub-footer-sitemap__headline{font-size:3.4285714286rem;line-height:4.2857142857rem;min-width:19.2857142857rem}}.brandhub-footer-sitemap__items{display:grid;gap:2.2857142857rem;grid-template-columns:minmax(120px,1fr) minmax(120px,1fr);overflow:hidden}@media (max-width: 767px){.brandhub-footer-sitemap__items{padding-left:2rem}}@media (min-width: 1024px){.brandhub-footer-sitemap__items{display:flex;flex-wrap:wrap;gap:4.5714285714rem}}
`,
  y = t("div", { class: "brandhub-footer-sitemap__line" }, null, -1),
  M = { class: "brandhub-footer-sitemap__container" },
  B = { class: "brandhub-footer-sitemap__headline" },
  S = { class: "brandhub-footer-sitemap__items" };
function O(e, k, E, P, z, $) {
  const i = d("word-fade"),
    o = m("intersect");
  return s(
    (p(),
    h(
      "div",
      {
        class: c(["brandhub-footer-sitemap", e.rootClass]),
        style: b(e.getBackgroundColorStyle),
      },
      [
        y,
        t("div", M, [
          t("div", B, [
            l(i, { "animated-text": e.headlineText }, null, 8, [
              "animated-text",
            ]),
          ]),
          t("div", S, [f(e.$slots, "default")]),
        ]),
      ],
      6
    )),
    [
      [
        o,
        {
          true: ["brandhub-footer-sitemap--in"],
          onChange: e.handleIntersection,
        },
      ],
    ]
  );
}
const j = x(I, [
  ["render", O],
  ["styles", [C]],
]);
export { j as default };
