import { C as d } from "./ChildComponentMixin-dd022493.js";
import { T as m } from "./TrackingPushService-374dd83c.js";
import {
  d as p,
  o as n,
  c as a,
  h as o,
  t as l,
  F as b,
  D as u,
  n as h,
  g as c,
} from "./index.js";
import { _ as f } from "./_plugin-vue_export-helper-c27b6911.js";
const _ = p({
    props: {
      listHeadline: String,
      listJson: String,
      editMode: Boolean,
      pageOpenedInEditMode: Boolean,
    },
    mixins: [d],
    data() {
      return { index: 0, fadeIn: !1 };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-footer-sitemap-item--in": this.fadeIn,
          "brandhub-footer-sitemap-item--edit-mode":
            this.editModeOrPageOpenedInEditMode,
        };
      },
      editModeOrPageOpenedInEditMode() {
        return this.editMode || this.pageOpenedInEditMode;
      },
      linkList() {
        return this.listJson ? JSON.parse(this.listJson).links : [];
      },
    },
    methods: {
      hasLink(e) {
        return !!e.url;
      },
      onItemClick(e) {
        if (this.hasLink(e)) {
          const i = e.url,
            s = e.text;
          m.pushTrackingAttributes("link", "Footer Sitemap", s, i);
        }
      },
      onFocusIn() {
        this.$el.dispatchEvent(
          new CustomEvent("footerSitemapItemFocused", {
            bubbles: !0,
            composed: !0,
            detail: { item: this },
          })
        );
      },
    },
    created() {
      this.initChildComponentMixin("FooterSitemapItem");
    },
  }),
  g = `.brandhub-footer-sitemap-item{color:var(--text-color);margin:0;opacity:0;padding:0;pointer-events:auto;transform:translate(-2.1428571429rem);transition:transform 1s cubic-bezier(.28,.98,.63,.99),opacity .8s ease-out;transition-delay:var(--transition-delay)}.brandhub-footer-sitemap-item--in,.brandhub-footer-sitemap-item--edit-mode{opacity:1;pointer-events:auto;transform:translate(0);transition-delay:0s}.brandhub-footer-sitemap-item__link-list{list-style:none;margin:0;padding:0}.brandhub-footer-sitemap-item__link-tag{color:var(--wb-grey-60);text-decoration:none}.brandhub-footer-sitemap-item__link-tag:focus-visible{outline:3px solid rgba(0,120,214,.8)}.brandhub-footer-sitemap-item__headline{font-size:1rem;font-weight:400;margin-block-end:0;margin-block-start:0}@media (max-width: 479px){.brandhub-footer-sitemap-item__headline,.brandhub-footer-sitemap-item__link-tag{display:block;line-height:1rem;margin-bottom:.5714285714rem;text-overflow:ellipsis;width:100%}}.brandhub-footer-sitemap-item__link-text{color:var(--wb-grey-60);transition:color .4s ease-in-out}.brandhub-footer-sitemap-item__link-text:hover{color:var(--text-color);font-size:1rem}
`,
  k = ["id"],
  y = ["aria-labelledby"],
  v = ["href", "target", "onClick"],
  x = { class: "brandhub-footer-sitemap-item__link-text" };
function C(e, i, s, I, F, M) {
  return (
    n(),
    a(
      "div",
      {
        class: h(["brandhub-footer-sitemap-item", e.rootClass]),
        style: c(`--transition-delay: ${200 + e.index * 50}ms`),
      },
      [
        o(
          "h3",
          {
            class: "brandhub-footer-sitemap-item__headline",
            id: "list-headline-" + e.index,
          },
          l(e.listHeadline),
          9,
          k
        ),
        o(
          "ul",
          {
            class: "brandhub-footer-sitemap-item__link-list",
            "aria-labelledby": "list-headline-" + e.index,
          },
          [
            (n(!0),
            a(
              b,
              null,
              u(
                e.linkList,
                (t) => (
                  n(),
                  a(
                    "li",
                    {
                      class: "brandhub-footer-sitemap-item__link",
                      key: t.text,
                    },
                    [
                      o(
                        "a",
                        {
                          class: "brandhub-footer-sitemap-item__link-tag",
                          href: t.url,
                          target: t.target,
                          onFocusin:
                            i[0] ||
                            (i[0] = (...r) => e.onFocusIn && e.onFocusIn(...r)),
                          onClick: (r) => e.onItemClick(t),
                        },
                        [o("span", x, l(t.text), 1)],
                        40,
                        v
                      ),
                    ]
                  )
                )
              ),
              128
            )),
          ],
          8,
          y
        ),
      ],
      6
    )
  );
}
const $ = f(_, [
  ["render", C],
  ["styles", [g]],
]);
export { $ as default };
