class r {
  static isInDocument(t) {
    let e = t;
    for (; e && e.parentNode; ) {
      if (e.parentNode === document) return !0;
      e.parentNode instanceof DocumentFragment
        ? (e = e.parentNode.host)
        : (e = e.parentNode);
    }
    return !1;
  }
}
export { r as S };
