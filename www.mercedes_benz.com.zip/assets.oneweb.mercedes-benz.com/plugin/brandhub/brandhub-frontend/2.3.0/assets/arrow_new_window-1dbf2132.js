import { o as t, c as r, h as e } from "./index.js";
const o = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20" },
  n = e(
    "g",
    {
      fill: "currentColor",
      "fill-rule": "evenodd",
      transform: "translate(1 2)",
    },
    [
      e("rect", { width: "16", height: "2", x: ".146", rx: "1" }),
      e("rect", {
        width: "19",
        height: "2",
        x: "-2",
        y: "7.646",
        rx: "1",
        transform: "rotate(-45 7.5 8.646)",
      }),
      e("rect", { width: "2", height: "16", x: "14.146", rx: "1" }),
    ],
    -1
  ),
  s = [n];
function c(a, h) {
  return t(), r("svg", o, [...s]);
}
const d = { render: c };
export { d as default, c as render };
