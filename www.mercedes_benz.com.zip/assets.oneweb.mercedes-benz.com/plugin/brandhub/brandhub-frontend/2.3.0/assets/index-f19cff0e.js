var h = {};
(function (e) {
  Object.defineProperty(e, "__esModule", { value: !0 }),
    (e.sanitizeUrl = e.BLANK_URL = void 0);
  var u = /^([^\w]*)(javascript|data|vbscript)/im,
    l = /&#(\w+)(^\w|;)?/g,
    c = /&(newline|tab);/gi,
    n = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim,
    v = /^.+(:|&colon;)/gim,
    o = [".", "/"];
  e.BLANK_URL = "about:blank";
  function m(t) {
    return o.indexOf(t[0]) > -1;
  }
  function d(t) {
    var r = t.replace(n, "");
    return r.replace(l, function (a, i) {
      return String.fromCharCode(i);
    });
  }
  function f(t) {
    if (!t) return e.BLANK_URL;
    var r = d(t).replace(c, "").replace(n, "").trim();
    if (!r) return e.BLANK_URL;
    if (m(r)) return r;
    var a = r.match(v);
    if (!a) return r;
    var i = a[0];
    return u.test(i) ? e.BLANK_URL : r;
  }
  e.sanitizeUrl = f;
})(h);
export { h as d };
