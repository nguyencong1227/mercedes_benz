import { C as m } from "./ChildComponentMixin-dd022493.js";
import h from "./WordFade-cd7ee7b7.js";
import { P as l, C as c } from "./ParentComponentMixin-b739cccc.js";
import { B as b } from "./BackgroundColorMixin-87cd4cac.js";
import {
  d as f,
  i as r,
  r as p,
  o as u,
  c as _,
  h as o,
  n as s,
  g as w,
  f as g,
  B as a,
} from "./index.js";
import { _ as x } from "./_plugin-vue_export-helper-c27b6911.js";
import "./BrandSafeHyphens-ffe3b60a.js";
import "./index-12214b95.js";
import "./ShadowDom-bc0a555e.js";
const I = f({
    name: "FooterSectionsItem",
    props: {
      editMode: Boolean,
      pageOpenedInEditMode: Boolean,
      sectionHeadline: String,
      itemIndex: Number,
    },
    components: { WordFade: h },
    mixins: [m, l, b],
    setup() {
      const e = r(),
        t = r();
      return { headline: e, wordFade: t };
    },
    data() {
      return {
        items: new c(),
        isShown: !1,
        isHiddenBelow: !1,
        isHiddenAbove: !1,
      };
    },
    computed: {
      myItemIndex() {
        return `--item-index: ${this.itemIndex}`;
      },
      editModeOrPageOpenedInEditMode() {
        return this.editMode || this.pageOpenedInEditMode;
      },
      rootClass() {
        return {
          "brandhub-footer-sections-item--edit-mode":
            this.editModeOrPageOpenedInEditMode,
        };
      },
      hideAndShowClass() {
        return {
          "brandhub-footer-sections-item__link-container--shown": this.isShown,
          "brandhub-footer-sections-item__link-container--hidden-above":
            this.isHiddenAbove,
          "brandhub-footer-sections-item__link-container--hidden-below":
            this.isHiddenBelow,
        };
      },
      highlightHeadline() {
        return {
          "brandhub-footer-sections-item__headline--shown": this.isShown,
        };
      },
    },
    methods: {
      onItemAdded(e) {
        e.parentIndex = this.index;
      },
      updateSubItemsParentIndex() {
        for (const e of this.items.items) e.parentIndex = this.index;
      },
      jumpToThisSection() {
        const e = window.document.querySelector("brandhub-footer-sections");
        if (e) {
          const t = e.shadowRoot;
          if (t) {
            const n = t.querySelector(
              ".brandhub-footer-sections__item-placeholders"
            );
            this.itemIndex &&
              n &&
              n.children.length >= this.itemIndex &&
              n.children[this.itemIndex].scrollIntoView({ behavior: "smooth" });
          }
        }
      },
      fadeIn() {
        (this.isHiddenAbove = !1),
          (this.isHiddenBelow = !1),
          this.delay(500).then(this.fadeInTest);
      },
      fadeInTest() {
        this.isShown = !0;
      },
      fadeOut(e = !0) {
        (this.isHiddenAbove = !1),
          (this.isHiddenBelow = !1),
          e ? (this.isHiddenAbove = !0) : (this.isHiddenBelow = !0),
          (this.isShown = !1);
      },
      resetContainerState(e) {
        e.propertyName === "transform" &&
          (e.target.className.includes(
            "brandhub-footer-sections-item__link-container--shown brandhub-footer-sections-item__link-container--hidden-above"
          ) ||
            e.target.className.includes(
              "brandhub-footer-sections-item__link-container--shown brandhub-footer-sections-item__link-container--hidden-below"
            )) &&
          ((this.isHiddenBelow = !1),
          (this.isHiddenAbove = !1),
          (this.isShown = !1));
      },
      delay(e) {
        return new Promise((t) => {
          setTimeout(t, e);
        });
      },
    },
    watch: {
      index() {
        this.updateSubItemsParentIndex();
      },
    },
    created() {
      this.initChildComponentMixin("FooterSectionsItem"),
        this.initParentComponentMixin(
          this.items,
          ["SubFooterSectionsItem"],
          this.onItemAdded
        );
    },
    mounted() {
      this.editModeOrPageOpenedInEditMode && this.fadeIn();
    },
  }),
  v = `.brandhub-footer-sections-item{background-color:transparent;display:flex;height:100%;pointer-events:none;position:absolute;width:100%}.brandhub-footer-sections-item--edit-mode{height:auto;margin-bottom:2rem;margin-top:2rem;position:relative}.brandhub-footer-sections-item__container{padding-left:1.1428571429rem;padding-right:1.1428571429rem;align-items:flex-start;column-gap:1.1428571429rem;display:flex;width:100%}@media (min-width: 768px){.brandhub-footer-sections-item__container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-footer-sections-item__container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-footer-sections-item__container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-footer-sections-item__container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 768px){.brandhub-footer-sections-item__container{column-gap:2.2857142857rem}}@media (min-width: 1024px){.brandhub-footer-sections-item__container{column-gap:3.4285714286rem}}@media (min-width: 1440px){.brandhub-footer-sections-item__container{column-gap:3.1428571429rem}}.brandhub-footer-sections-item__link-container{opacity:0;pointer-events:none;transform:translate(-3.5714285714rem);transition:opacity .5s,transform .5s;transition-delay:0s}.brandhub-footer-sections-item__link-container--shown{opacity:1;pointer-events:auto;transform:translate(0);transition:opacity .4s,transform .4s;transition-delay:.1s}.brandhub-footer-sections-item__link-container--hidden-above,.brandhub-footer-sections-item__link-container--hidden-below{opacity:0;pointer-events:none;transition:opacity .75s,transform .75s cubic-bezier(.46,0,1,.5);transition-delay:0s}.brandhub-footer-sections-item__link-container--hidden-above{transform:translateY(-10em)}.brandhub-footer-sections-item__link-container--hidden-below{transform:translateY(10em)}.brandhub-footer-sections-item--edit-mode .brandhub-footer-sections-item__link-container{opacity:1;pointer-events:auto;transform:translate(0);transition:none;transition-delay:0s}.brandhub-footer-sections-item__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;background:none;border:none;color:var(--wb-grey-45);cursor:pointer;font-size:2.2857142857rem;line-height:2.8571428571rem;outline:inherit;padding:0;pointer-events:auto;position:relative;text-decoration:none;top:calc(var(--item-index) * 2.5714285714rem);transition:color .4s ease-in-out;width:calc(50% - .5714285714rem)}.brandhub-footer-sections-item__headline--shown,.brandhub-footer-sections-item__headline:hover{color:var(--text-color)}@media (min-width: 768px){.brandhub-footer-sections-item__headline{font-size:3.4285714286rem;line-height:4.2857142857rem;top:calc(var(--item-index) * 3.7142857143rem);width:17.4285714286rem}}@media (min-width: 1440px){.brandhub-footer-sections-item__headline{font-size:4.5714285714rem;line-height:5.1428571429rem;top:calc(var(--item-index) * 4.8571428571rem);width:19.2857142857rem}}.brandhub-footer-sections-item__word-fade:focus-visible{position:relative;outline:none}.brandhub-footer-sections-item__word-fade:focus-visible:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}
`,
  S = { class: "brandhub-footer-sections-item__container" };
function y(e, t, n, C, k, H) {
  const d = p("word-fade");
  return (
    u(),
    _(
      "div",
      { class: s(["brandhub-footer-sections-item", e.rootClass]) },
      [
        o("div", S, [
          o(
            "button",
            {
              class: s([
                "brandhub-footer-sections-item__headline",
                e.highlightHeadline,
              ]),
              tabindex: "-1",
              ref: "headline",
              style: w(e.myItemIndex),
              onClick:
                t[0] ||
                (t[0] = (...i) =>
                  e.jumpToThisSection && e.jumpToThisSection(...i)),
            },
            [
              g(
                d,
                {
                  class: "brandhub-footer-sections-item__word-fade",
                  role: "navigation",
                  tabindex: 0,
                  "animated-text": e.sectionHeadline,
                  "text-align": "left",
                  ref: "wordFade",
                },
                null,
                8,
                ["animated-text"]
              ),
            ],
            6
          ),
          o(
            "nav",
            {
              class: s([
                "brandhub-footer-sections-item__link-container",
                e.hideAndShowClass,
              ]),
              onTransitionend: t[1] || (t[1] = (i) => e.resetContainerState(i)),
              onTransitioncancel:
                t[2] || (t[2] = (i) => e.resetContainerState(i)),
            },
            [a(e.$slots, "default"), a(e.$slots, "sectionSubItems")],
            34
          ),
        ]),
      ],
      2
    )
  );
}
const E = x(I, [
  ["render", y],
  ["styles", [v]],
]);
export { E as default };
