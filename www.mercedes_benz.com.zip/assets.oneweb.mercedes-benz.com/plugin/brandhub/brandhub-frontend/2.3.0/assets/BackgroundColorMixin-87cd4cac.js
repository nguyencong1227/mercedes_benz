import { d as e } from "./index.js";
const a = e({
  props: { bgColor: String },
  computed: {
    getBackgroundColorStyle() {
      let o, r;
      return (
        this.bgColor === "background-white"
          ? ((o = "var(--text-on-base-color)"), (r = "var(--base-color)"))
          : this.bgColor === "background-theme"
          ? ((o = "var(--campaign-gradient)"), (r = "var(--campaign-text)"))
          : ((o = "var(--base-color)"), (r = "var(--text-on-base-color)")),
        { "--background-color": o, "--text-color": r }
      );
    },
  },
});
export { a as B };
