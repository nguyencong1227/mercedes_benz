import { d as e, o as a, c as o, n as s } from "./index.js";
import { _ as n } from "./_plugin-vue_export-helper-c27b6911.js";
const t = e({
    name: "BrandhubSpacer",
    props: {
      bgColor: {
        type: String,
        default: "primary",
        validator: (r) => ["inverted", "primary", "theme"].includes(r),
      },
    },
    computed: {
      rootClasses() {
        return {
          "brandhub-spacer--color-inverted": this.bgColor === "inverted",
          "brandhub-spacer--color-primary": this.bgColor === "primary",
          "brandhub-spacer--color-theme": this.bgColor === "theme",
        };
      },
    },
  }),
  c = `.brandhub-spacer{height:7rem}.brandhub-spacer--color-primary{background:var(--base-color)}.brandhub-spacer--color-inverted{background:var(--text-on-base-color)}.brandhub-spacer--color-theme{background:var(--campaign-gradient)}
`;
function p(r, d, l, b, i, m) {
  return (
    a(), o("div", { class: s(["brandhub-spacer", r.rootClasses]) }, null, 2)
  );
}
const g = n(t, [
  ["render", p],
  ["styles", [c]],
]);
export { g as default };
