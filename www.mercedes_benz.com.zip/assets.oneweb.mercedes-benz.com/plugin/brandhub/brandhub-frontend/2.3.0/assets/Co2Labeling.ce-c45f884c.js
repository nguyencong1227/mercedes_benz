import {
  d as C,
  a as b,
  _ as s,
  r as i,
  o as e,
  c as l,
  h as c,
  F as g,
  D as h,
  e as t,
  n as _,
  t as o,
  b as r,
} from "./index.js";
import { i as k } from "./i18next-3def9235.js";
import { _ as V } from "./_plugin-vue_export-helper-c27b6911.js";
const I = "CO₂-Emissionen kombiniert",
  T = "Kraftstoffverbrauch kombiniert",
  P = { co2: I, "fuel e comp": "Stromverbrauch kombiniert", fuelcomp: T },
  E = "CO₂-Emissionen kombiniert",
  L = "Kraftstoffverbrauch kombiniert",
  w = { co2: E, "fuel e comp": "Stromverbrauch kombiniert", fuelcomp: L };
function N() {
  const n = k.createInstance();
  return (
    n.init({
      lng:
        document.body.dataset.analyticsLanguage ||
        {}.VUE_APP_I18N_LOCALE ||
        "en",
      resources: { en: { translation: P }, de: { translation: w } },
    }),
    n
  );
}
const S = b(() =>
    s(
      () => import("./fuel-consumption-1d3a2eea.js"),
      ["./fuel-consumption-1d3a2eea.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  O = b(() =>
    s(
      () => import("./pollution-f3628f6e.js"),
      ["./pollution-f3628f6e.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  A = b(() =>
    s(
      () => import("./energy-consumption-e8f26acb.js"),
      ["./energy-consumption-e8f26acb.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  B = b(() =>
    s(
      () => import("./fuel-consumption-1d3a2eea.js"),
      ["./fuel-consumption-1d3a2eea.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  D = b(() =>
    s(
      () => import("./fuel-e-comp-94a260a6.js"),
      ["./fuel-e-comp-94a260a6.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  W = b(() =>
    s(
      () => import("./co2-c61804ce.js"),
      ["./co2-c61804ce.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  M = C({
    name: "Co2Labeling",
    components: {
      IconFuelConsumption: S,
      IconFuelPollution: O,
      IconEnergyConsumption: A,
      IconGasUpdated: B,
      IconEnergyUpdated: D,
      IconCo2Updated: W,
    },
    props: {
      labelingJson: String,
      modelName: String,
      testProcedure: String,
      fuelConsumption: String,
      fuelPollution: String,
      energyConsumption: String,
      labelingText: String,
      hideModelName: Boolean,
      hideLabeling: Boolean,
      layoutVariant: {
        type: String,
        default: "icons-legacy",
        validator: (n) =>
          ["icons-legacy", "icons", "text", "text-large"].includes(n),
      },
    },
    setup: () => {
      const { t: n } = N();
      return { t: n };
    },
    computed: {
      rootClasses() {
        return {
          "brandhub-co2-labeling--variant-icons-legacy":
            this.layoutVariant === "icons-legacy",
          "brandhub-co2-labeling--variant-icons":
            this.layoutVariant === "icons",
          "brandhub-co2-labeling--variant-text": this.layoutVariant === "text",
          "brandhub-co2-labeling--variant-text-large":
            this.layoutVariant === "text-large",
          "brandhub-co2-labeling--has-entries": this.hasEntries,
          "brandhub-co2-labeling--has-text": this.hasText,
        };
      },
      labelingInformation() {
        return this.labelingJson
          ? JSON.parse(this.labelingJson)
          : [
              {
                modelName: this.modelName,
                testProcedure: this.testProcedure,
                fuelConsumption: this.fuelConsumption,
                fuelPollution: this.fuelPollution,
                energyConsumption: this.energyConsumption,
                labelingText: this.labelingText,
              },
            ];
      },
      labelingInformationWithValues() {
        return this.labelingInformation
          ? this.labelingInformation.filter(
              (n) =>
                !!(n.fuelConsumption || n.fuelPollution || n.energyConsumption)
            )
          : null;
      },
      labelingInformationWithText() {
        if (!this.labelingInformation) return null;
        const n = [];
        return this.labelingInformation.filter((u) =>
          !u.labelingText || n.includes(u.labelingText)
            ? !1
            : (n.push(u.labelingText), !0)
        );
      },
      hasEntries() {
        return (
          this.labelingInformationWithValues &&
          this.labelingInformationWithValues.length > 0
        );
      },
      hasText() {
        return (
          this.labelingInformationWithText &&
          this.labelingInformationWithText.length > 0
        );
      },
      hasLabeling() {
        return !!(
          this.labelingJson ||
          this.labelingText ||
          this.fuelConsumption ||
          this.fuelPollution ||
          this.energyConsumption
        );
      },
    },
  }),
  R = `.brandhub-co2-labeling{color:var(--co2-labeling-color);font-family:MBCorpo Text Condensed Light,MBCorpo Text,sans-serif;font-size:var(--co2-labeling-font-size, 1.1428571429rem);line-height:1.25}.brandhub-co2-labeling a,.brandhub-co2-labeling a:link,.brandhub-co2-labeling a:visited,.brandhub-co2-labeling a:active,.brandhub-co2-labeling a:hover{color:var(--co2-labeling-color);text-decoration:none}.brandhub-co2-labeling p{margin:0;padding:0}.brandhub-co2-labeling__models{display:block}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__models{display:inline}.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__models{margin-bottom:.7142857143rem}.brandhub-co2-labeling__model{display:block}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__model,.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__model{display:inline}.brandhub-co2-labeling__model-name{display:inline-block;margin-right:.7142857143rem;white-space:nowrap}@media (max-width: 767px){.brandhub-co2-labeling__model-name--very-long{white-space:normal}}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__model-name,.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__model-name{display:inline;margin-right:0}.brandhub-co2-labeling--variant-icons-legacy .brandhub-co2-labeling__entry{display:inline-block;margin-right:.7142857143rem}@media (max-width: 767px){.brandhub-co2-labeling--variant-icons-legacy .brandhub-co2-labeling__entry{display:block}}.brandhub-co2-labeling--variant-icons .brandhub-co2-labeling__entry,.brandhub-co2-labeling--variant-icons-legacy .brandhub-co2-labeling__entry{display:inline-block;margin-right:1.0714285714rem}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__entry,.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__entry{display:inline}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__entry:not(:last-child):after,.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__entry:not(:last-child):after{content:"; "}.brandhub-co2-labeling--variant-text .brandhub-co2-labeling__model:not(:last-child) .brandhub-co2-labeling__entry:last-child:after,.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__model:not(:last-child) .brandhub-co2-labeling__entry:last-child:after{content:". ";display:inline}.brandhub-co2-labeling--variant-text.brandhub-co2-labeling--has-text .brandhub-co2-labeling__model:last-child .brandhub-co2-labeling__entry:last-child:after{content:". ";display:inline}.brandhub-co2-labeling__entry-label{white-space:normal}.brandhub-co2-labeling__entry-value{white-space:nowrap}.brandhub-co2-labeling__icon{height:1.2857142857rem;margin-right:.25rem;vertical-align:top;width:1.2857142857rem}@media (max-width: 767px){.brandhub-co2-labeling__icon{margin-right:.25rem;width:1.072rem}}.brandhub-co2-labeling__text{display:inline;width:100%}.brandhub-co2-labeling--variant-text-large .brandhub-co2-labeling__text{display:block}.brandhub-co2-labeling--variant-text-large.brandhub-co2-labeling--has-entries .brandhub-co2-labeling__text{font-size:min(.8571428571rem,2vh)}.brandhub-co2-labeling__text p{display:inline;margin:0}.brandhub-co2-labeling__text p+p{display:block}
`,
  $ = { class: "brandhub-co2-labeling__models" },
  J = ["textContent"],
  z = { class: "brandhub-co2-labeling__model-inner" },
  F = { key: 0, class: "brandhub-co2-labeling__entry" },
  U = ["textContent"],
  H = ["textContent"],
  K = { key: 1, class: "brandhub-co2-labeling__entry" },
  G = ["textContent"],
  j = ["textContent"],
  q = { key: 2, class: "brandhub-co2-labeling__entry" },
  Q = ["textContent"],
  X = ["textContent"],
  Y = ["innerHTML"];
function Z(n, u, nn, en, an, tn) {
  const m = i("icon-fuel-consumption"),
    p = i("icon-gas-updated"),
    y = i("icon-energy-consumption"),
    f = i("icon-energy-updated"),
    x = i("icon-fuel-pollution"),
    v = i("icon-co2-updated");
  return n.hasLabeling
    ? (e(),
      l(
        "div",
        { key: 0, class: _(["brandhub-co2-labeling", n.rootClasses]) },
        [
          c("div", $, [
            (e(!0),
            l(
              g,
              null,
              h(
                n.labelingInformationWithValues,
                (a, d) => (
                  e(),
                  l(
                    "div",
                    {
                      class: "brandhub-co2-labeling__model",
                      key: "model-" + d,
                    },
                    [
                      a.modelName && !n.hideModelName
                        ? (e(),
                          l(
                            "span",
                            {
                              key: 0,
                              class: _([
                                "brandhub-co2-labeling__model-name",
                                {
                                  "brandhub-co2-labeling__model-name--very-long":
                                    a.modelName.length > 35,
                                },
                              ]),
                              textContent: o(a.modelName + ": "),
                            },
                            null,
                            10,
                            J
                          ))
                        : t("", !0),
                      c("span", z, [
                        a.fuelConsumption
                          ? (e(),
                            l("span", F, [
                              n.layoutVariant === "icons-legacy"
                                ? (e(),
                                  r(m, {
                                    key: 0,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "icons"
                                ? (e(),
                                  r(p, {
                                    key: 1,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "text" ||
                              n.layoutVariant === "text-large"
                                ? (e(),
                                  l(
                                    "span",
                                    {
                                      key: 2,
                                      class:
                                        "brandhub-co2-labeling__entry-label",
                                      textContent: o(
                                        (a.testProcedure
                                          ? a.testProcedure + ": "
                                          : "") +
                                          n.t("fuelcomp") +
                                          ": "
                                      ),
                                    },
                                    null,
                                    8,
                                    U
                                  ))
                                : t("", !0),
                              c(
                                "span",
                                {
                                  class: "brandhub-co2-labeling__entry-value",
                                  textContent: o(a.fuelConsumption),
                                },
                                null,
                                8,
                                H
                              ),
                            ]))
                          : t("", !0),
                        a.energyConsumption
                          ? (e(),
                            l("span", K, [
                              n.layoutVariant === "icons-legacy"
                                ? (e(),
                                  r(y, {
                                    key: 0,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "icons"
                                ? (e(),
                                  r(f, {
                                    key: 1,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "text" ||
                              n.layoutVariant === "text-large"
                                ? (e(),
                                  l(
                                    "span",
                                    {
                                      key: 2,
                                      class:
                                        "brandhub-co2-labeling__entry-label",
                                      textContent: o(
                                        (!a.fuelConsumption && a.testProcedure
                                          ? a.testProcedure + ": "
                                          : "") +
                                          n.t("fuel e comp") +
                                          ": "
                                      ),
                                    },
                                    null,
                                    8,
                                    G
                                  ))
                                : t("", !0),
                              c(
                                "span",
                                {
                                  class: "brandhub-co2-labeling__entry-value",
                                  textContent: o(a.energyConsumption),
                                },
                                null,
                                8,
                                j
                              ),
                            ]))
                          : t("", !0),
                        a.fuelPollution
                          ? (e(),
                            l("span", q, [
                              n.layoutVariant === "icons-legacy"
                                ? (e(),
                                  r(x, {
                                    key: 0,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "icons"
                                ? (e(),
                                  r(v, {
                                    key: 1,
                                    class: "brandhub-co2-labeling__icon",
                                  }))
                                : t("", !0),
                              n.layoutVariant === "text" ||
                              n.layoutVariant === "text-large"
                                ? (e(),
                                  l(
                                    "span",
                                    {
                                      key: 2,
                                      class:
                                        "brandhub-co2-labeling__entry-label",
                                      textContent: o(n.t("co2") + ": "),
                                    },
                                    null,
                                    8,
                                    Q
                                  ))
                                : t("", !0),
                              c(
                                "span",
                                {
                                  class: "brandhub-co2-labeling__entry-value",
                                  textContent: o(a.fuelPollution),
                                },
                                null,
                                8,
                                X
                              ),
                            ]))
                          : t("", !0),
                      ]),
                    ]
                  )
                )
              ),
              128
            )),
          ]),
          n.hideLabeling
            ? t("", !0)
            : (e(!0),
              l(
                g,
                { key: 0 },
                h(
                  n.labelingInformationWithText,
                  (a, d) => (
                    e(),
                    l(
                      "div",
                      {
                        class: "brandhub-co2-labeling__text",
                        key: "text-" + d,
                        innerHTML: a.labelingText,
                      },
                      null,
                      8,
                      Y
                    )
                  )
                ),
                128
              )),
        ],
        2
      ))
    : t("", !0);
}
const bn = V(M, [
  ["render", Z],
  ["styles", [R]],
]);
export { bn as default };
