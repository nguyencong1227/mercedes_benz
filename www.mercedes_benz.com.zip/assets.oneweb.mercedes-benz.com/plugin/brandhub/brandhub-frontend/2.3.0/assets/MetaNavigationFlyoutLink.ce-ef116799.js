import { T as e } from "./TrackingPushService-374dd83c.js";
import {
  d as r,
  o as i,
  c as a,
  h as l,
  t as s,
  e as u,
  n as b,
} from "./index.js";
import { _ as m } from "./_plugin-vue_export-helper-c27b6911.js";
const d = r({
    name: "MetaNavigationFlyoutLink",
    props: {
      linkUrl: String,
      linkText: String,
      linkTarget: String,
      linkIcon: { type: String, default: "arrow-external" },
      isFirstItem: Boolean,
      editMode: Boolean,
    },
    computed: {
      rootClass() {
        return {
          "brandhub-meta-navigation-flyout-link--first": this.isFirstItem,
        };
      },
    },
    methods: {
      onItemClick() {
        this.linkUrl &&
          this.linkText &&
          e.pushTrackingAttributes(
            "link",
            "Login Flyout",
            this.linkText,
            this.linkUrl
          );
      },
    },
  }),
  h = `.brandhub-meta-navigation-flyout-link{align-items:center;cursor:pointer;display:flex;justify-content:center;padding:1.1428571429rem 1.1428571429rem 1.1428571429rem 1.7142857143rem;text-decoration:none}@media (min-width: 1024px){.brandhub-meta-navigation-flyout-link{justify-content:space-between}}.brandhub-meta-navigation-flyout-link:hover,.brandhub-meta-navigation-flyout-link:focus-visible{background-color:#014880}.brandhub-meta-navigation-flyout-link:hover .brandhub-meta-navigation-flyout-link__text,.brandhub-meta-navigation-flyout-link:hover .brandhub-meta-navigation-flyout-link__icon,.brandhub-meta-navigation-flyout-link:focus-visible .brandhub-meta-navigation-flyout-link__text,.brandhub-meta-navigation-flyout-link:focus-visible .brandhub-meta-navigation-flyout-link__icon{color:var(--wb-white)}@media (min-width: 1024px){.brandhub-meta-navigation-flyout-link--first:before{background-color:var(--wb-white);content:"";height:1.0714285714rem;position:absolute;right:1.4285714286rem;top:-.3571428571rem;transform:rotate(45deg);width:1.0714285714rem}}.brandhub-meta-navigation-flyout-link--first:hover:before,.brandhub-meta-navigation-flyout-link--first:focus-visible:before{background-color:#014880}.brandhub-meta-navigation-flyout-link__text,.brandhub-meta-navigation-flyout-link__icon{color:var(--wb-white);transition:color .2s}@media (min-width: 1024px){.brandhub-meta-navigation-flyout-link__text,.brandhub-meta-navigation-flyout-link__icon{color:var(--wb-black)}}.brandhub-meta-navigation-flyout-link__icon{height:1.1428571429rem;margin-left:.6428571429rem;width:1.1428571429rem}@media (min-width: 1024px){.brandhub-meta-navigation-flyout-link__icon{margin-left:3.5714285714rem}}
`,
  c = ["href", "target"],
  f = ["textContent"],
  k = ["icon"];
function g(n, t, v, y, _, p) {
  return (
    i(),
    a(
      "a",
      {
        class: b(["brandhub-meta-navigation-flyout-link", n.rootClass]),
        href: n.linkUrl,
        target: n.linkTarget,
        onClick:
          t[0] || (t[0] = (...o) => n.onItemClick && n.onItemClick(...o)),
      },
      [
        l(
          "span",
          {
            class: "brandhub-meta-navigation-flyout-link__text",
            textContent: s(n.linkText),
          },
          null,
          8,
          f
        ),
        n.linkIcon !== "none"
          ? (i(),
            a(
              "brandhub-icon",
              {
                key: 0,
                class: "brandhub-meta-navigation-flyout-link__icon",
                icon: n.linkIcon,
                "original-size": "",
              },
              null,
              8,
              k
            ))
          : u("", !0),
      ],
      10,
      c
    )
  );
}
const T = m(d, [
  ["render", g],
  ["styles", [h]],
]);
export { T as default };
