import { _ as r } from "./LayeredGallery.ce.vue_vue_type_script_lang-5e3a1314.js";
import { L as E } from "./LayeredGallery.ce.vue_vue_type_script_lang-5e3a1314.js";
import { _ as a } from "./_plugin-vue_export-helper-c27b6911.js";
import { o as l, c as o, h as t, B as d, n as s, g as i } from "./index.js";
const n = `.brandhub-layered-gallery{background-color:var(--wb-black);color:var(--wb-white);height:var(--module-height, 100vh)}.brandhub-layered-gallery--background-white{background-color:var(--wb-white)}.brandhub-layered-gallery--edit-mode{height:auto}.brandhub-layered-gallery--edit-mode .new{background:#a0a0a0;border-radius:4px;height:2.875rem;min-width:8rem}.brandhub-layered-gallery--edit-mode .brandhub-layered-gallery__sticky{height:auto;position:relative}.brandhub-layered-gallery__sticky{height:100vh;left:0;position:sticky;top:0}
`,
  h = { class: "brandhub-layered-gallery__sticky" };
function y(e, b, c, u, _, g) {
  return (
    l(),
    o(
      "div",
      {
        class: s(["brandhub-layered-gallery", e.rootClass]),
        style: i(e.rootStyle),
      },
      [t("div", h, [d(e.$slots, "default")])],
      6
    )
  );
}
const k = a(r, [
  ["render", y],
  ["styles", [n]],
]);
export { E as LAYERED_GALLERY_ITEM_MOUNTED, k as default };
