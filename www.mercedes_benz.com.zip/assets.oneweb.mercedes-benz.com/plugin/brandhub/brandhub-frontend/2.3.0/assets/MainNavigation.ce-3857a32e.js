import { d as n, o as i, c as e, h as t, B as o, n as r } from "./index.js";
import { _ as s } from "./_plugin-vue_export-helper-c27b6911.js";
const d = n({
    name: "MainNavigation",
    props: { editMode: Boolean },
    computed: {
      rootClass() {
        return { "brandhub-main-navigation--edit-mode": this.editMode };
      },
    },
  }),
  l = `.brandhub-main-navigation--edit-mode .new{background:#a0a0a0;border-radius:4px;height:2.875rem;min-width:8rem}.brandhub-main-navigation__list{--link-color: var(--header-link-color);color:var(--wb-white);display:flex;font-size:inherit;height:var(--main-menu-height);justify-content:center;list-style:none;margin:0 auto;padding:0;width:max-content}@media (min-width: 1024px){.brandhub-main-navigation__list:hover{--link-color: var(--wb-grey-45)}}@media (max-width: 1023px){.brandhub-main-navigation__list{align-items:center;flex-flow:column;margin:0;min-height:100%;padding:15.6428571429rem 0;width:100%}}
`,
  m = { class: "brandhub-main-navigation__list" };
function c(a, h, g, u, _, p) {
  return (
    i(),
    e(
      "div",
      { class: r(["brandhub-main-navigation", a.rootClass]) },
      [t("nav", m, [o(a.$slots, "default")])],
      2
    )
  );
}
const f = s(d, [
  ["render", c],
  ["styles", [l]],
]);
export { f as default };
