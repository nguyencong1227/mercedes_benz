import { d as a, i as n } from "./index.js";
const o = "textMaskCompatibleModuleMounted",
  s = 100,
  l = 160,
  r = a({
    name: "TextMask",
    props: {
      editMode: Boolean,
      outlinedText: String,
      transparentText: String,
      transparentPath: String,
      focusPosition: { type: String, default: "50" },
      fillColor: String,
      surfaceColor: String,
      dataAnalyticsContentMilestone: String,
      useGraphic: Boolean,
    },
    data() {
      return {
        fadeInReady: !0,
        fadingIn: !1,
        scale: 0,
        outerHeight: 0,
        innerHeight: 0,
        childModule: null,
        childModuleHeight: null,
        fontLoaded: !1,
      };
    },
    setup() {
      const e = n(),
        t = n();
      return { outerMask: e, screenDiv: t };
    },
    computed: {
      rootCssClass() {
        const e = [
          "brandhub-text-mask",
          `brandhub-text-mask--${this.surfaceColor}`,
        ];
        return (
          this.editMode && e.push("brandhub-text-mask--edit-mode"), e.join(" ")
        );
      },
      filledTextStyle() {
        return `transform: scale(${this.scale ** 2 + 1});`;
      },
      maskTextStyle() {
        return `transform: scale(${this.scale ** 3 * l + 1});`;
      },
      rootStyle() {
        let e = `--desktop-focus-point: ${this.focusPosition}%;`;
        return (
          this.fillColor && (e += `--fill-color: ${this.fillColor};`),
          this.childModuleHeight &&
            (e += `--module-height: ${100 + s + this.childModuleHeight}vh`),
          e
        );
      },
      backgroundOverlayOpacity() {
        return this.useGraphic
          ? 0
          : Math.min(Math.max(0.98 - this.scale, 0), 0.98);
      },
      svgCssClass() {
        const e = ["brandhub-text-mask__mask"];
        return (
          this.fadeInReady && e.push("brandhub-text-mask__mask--fade-in-ready"),
          this.fadingIn && e.push("brandhub-text-mask__mask--fading-in"),
          e.join(" ")
        );
      },
      clipPathId() {
        return this.dataAnalyticsContentMilestone
          ? `clip-${this.dataAnalyticsContentMilestone}`
          : "clip";
      },
    },
    methods: {
      calculateScale() {
        const { outerMask: e } = this.$refs,
          t = e ? e.getBoundingClientRect().top : 0,
          { innerHeight: i } = window;
        this.childModule &&
          this.childModule.handleScrolling({
            wrapperTop: t,
            contentTop: t + (i * (s / 100) + 1),
            browserHeight: i,
          }),
          t > 0
            ? (this.scale = 0)
            : t < i * -1
            ? (this.scale = 1)
            : (this.scale = (t / i / (s / 100)) * -1);
      },
      initialFade(e = "in") {
        e === "in"
          ? ((this.fadingIn = !0),
            setTimeout(() => {
              (this.fadeInReady = !1), (this.fadingIn = !1);
            }, 1050))
          : ((this.fadeInReady = !0),
            (this.fadingIn = !0),
            requestAnimationFrame(() => {
              this.fadingIn = !1;
            }));
      },
      handleMountedChildModule(e) {
        e instanceof CustomEvent &&
          typeof e.detail.itemHeight == "number" &&
          ((this.childModule = e.detail.item),
          (this.childModuleHeight = e.detail.itemHeight),
          this.childModule !== null && this.childModule.setIsTextMaskChild(!0));
      },
    },
    mounted() {
      document.fonts && document.fonts.ready
        ? document.fonts.ready.then(() => {
            this.fontLoaded = !0;
          })
        : document.readyState === "complete"
        ? (this.fontLoaded = !0)
        : window.addEventListener(
            "load",
            () => {
              this.fontLoaded = !0;
            },
            { passive: !0 }
          ),
        this.editMode
          ? this.initialFade("in")
          : (this.$el.addEventListener(o, this.handleMountedChildModule),
            window.addEventListener("scroll", this.calculateScale, {
              passive: !0,
            }),
            new IntersectionObserver(
              (t) => {
                t.forEach((i) => {
                  i.target === this.$refs.screenDiv &&
                    (i.isIntersecting
                      ? (this.initialFade("in"), this.calculateScale())
                      : i.boundingClientRect.top > 0
                      ? this.initialFade("out")
                      : this.initialFade("in"));
                });
              },
              { threshold: 0.75 }
            ).observe(this.$refs.screenDiv));
    },
  });
export { o as T, r as _ };
