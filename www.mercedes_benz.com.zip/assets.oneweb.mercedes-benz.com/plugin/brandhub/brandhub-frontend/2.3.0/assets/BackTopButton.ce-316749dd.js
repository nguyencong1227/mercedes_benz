import {
  d as r,
  a,
  _ as s,
  r as c,
  o as i,
  c as p,
  f as d,
  g as b,
  h as m,
} from "./index.js";
import { B as l } from "./BackgroundColorMixin-87cd4cac.js";
import { _ as u } from "./_plugin-vue_export-helper-c27b6911.js";
const _ = a(() =>
    s(
      () => import("./arrow-right-9ff753e0.js"),
      ["./arrow-right-9ff753e0.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  h = r({
    components: { BackTopIcon: _ },
    mixins: [l],
    methods: {
      scrollTop() {
        window.scrollTo({ top: 0, behavior: "smooth" });
      },
    },
  }),
  k = `.brandhub-back-top-button{align-items:center;background-color:var(--background-color);border:none;color:var(--wb-white);cursor:pointer;display:flex;flex-flow:column;font-family:MBCorpo Text,sans-serif;padding-bottom:2rem;padding-top:4.6428571429rem;width:100%}@media (min-width: 768px){.brandhub-back-top-button{padding-top:4.6428571429rem}}@media (min-width: 1024px){.brandhub-back-top-button{padding-bottom:4.5rem;padding-top:6.7857142857rem}}@media (min-width: 1440px){.brandhub-back-top-button{padding-top:7.1428571429rem}}.brandhub-back-top-button__icon{height:2.1428571429rem;margin-bottom:-.4285714286rem;transform:rotate(-90deg);width:2.1428571429rem}.brandhub-back-top-button__text{font-size:1rem}
`,
  f = m("span", { class: "brandhub-back-top-button__text" }, "Top", -1);
function g(o, t, w, x, B, T) {
  const n = c("back-top-icon");
  return (
    i(),
    p(
      "button",
      {
        class: "brandhub-back-top-button",
        style: b(o.getBackgroundColorStyle),
        onClick: t[0] || (t[0] = (...e) => o.scrollTop && o.scrollTop(...e)),
      },
      [d(n, { class: "brandhub-back-top-button__icon" }), f],
      4
    )
  );
}
const $ = u(h, [
  ["render", g],
  ["styles", [k]],
]);
export { $ as default };
