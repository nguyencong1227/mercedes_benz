import { d as s, o as i, c as t, h as a, B as n } from "./index.js";
import { _ as r } from "./_plugin-vue_export-helper-c27b6911.js";
const l = s({ name: "SearchLinkList" }),
  d = `.brandhub-search-link-list__items{display:flex;flex-flow:column;margin:0;padding:0;row-gap:2.1875rem}@media (min-width: 480px){.brandhub-search-link-list__items{column-gap:2.75rem;display:grid;grid-template:"list1 list2 list3" auto/1fr 1fr 1fr}}@media (min-width: 1024px){.brandhub-search-link-list__items{column-gap:7.5625rem}}@media (min-width: 1280px){.brandhub-search-link-list__items{column-gap:10.6875rem}}::slotted(brandhub-search-link-list-item:first-child){justify-self:end}
`,
  o = { class: "brandhub-search-link-list" },
  c = { class: "brandhub-search-link-list__items" };
function m(e, _, h, p, f, u) {
  return i(), t("div", o, [a("div", c, [n(e.$slots, "default")])]);
}
const g = r(l, [
  ["render", m],
  ["styles", [d]],
]);
export { g as default };
