import { _ as d } from "./TextMask.ce.vue_vue_type_script_lang-065fa87d.js";
import { T as I } from "./TextMask.ce.vue_vue_type_script_lang-065fa87d.js";
import {
  o as e,
  c as s,
  h as a,
  n as r,
  e as o,
  w as l,
  v as h,
  t as n,
  g as i,
  B as m,
  l as b,
} from "./index.js";
import { _ as c } from "./_plugin-vue_export-helper-c27b6911.js";
const _ = `.brandhub-text-mask{--surface-color: var(--wb-black);--text-mask-height: 100vh;min-height:var(--module-height, 140vh)}.brandhub-text-mask--white{--surface-color: var(--wb-white)}.brandhub-text-mask--theme{--surface-color: var(--campaign-primary)}.brandhub-text-mask--edit-mode{--module-height: 800px}.brandhub-text-mask--edit-mode .brandhub-text-mask__screen{height:800px}.brandhub-text-mask__screen{display:grid;grid-template:"content" 100%/100%;height:100vh;overflow:hidden;position:sticky;top:0;width:100%}.brandhub-text-mask__mask{display:block;grid-area:content;height:100%;opacity:1;overflow:hidden;width:100%;z-index:5}@media (max-width: 767px){.brandhub-text-mask__mask{transform:scale(1.5)}}.brandhub-text-mask__mask--black{background:var(--wb-black)}.brandhub-text-mask__mask--white{background:var(--wb-white)}.brandhub-text-mask__mask--fade-in-ready .brandhub-text-mask__transparent-text{transform:translateY(4rem);transition:transform 1s}.brandhub-text-mask__mask--fade-in-ready .brandhub-text-mask__see-through-surface{fill:var(--surface-color, var(--wb-black));transition:fill 1s}.brandhub-text-mask__mask--fade-in-ready .brandhub-text-mask__surface-text{opacity:0;transform:translateY(1rem);transition:opacity 1s,transform 1s}.brandhub-text-mask__mask--fading-in .brandhub-text-mask__transparent-text{transform:translateY(0)}.brandhub-text-mask__mask--fading-in .brandhub-text-mask__see-through-surface{fill:var(--fill-color, var(--wb-white))}.brandhub-text-mask__mask--fading-in .brandhub-text-mask__surface-text{opacity:.7;transform:translateY(0)}.brandhub-text-mask__mask text{font-family:MBCorpo Title,sans-serif;line-height:1em}.brandhub-text-mask__clip-path,.brandhub-text-mask__svg-group{transform-origin:var(--desktop-focus-point, 50%) 51%}.brandhub-text-mask__mask-text{font-size:4.25rem}.brandhub-text-mask__surface{fill:var(--surface-color)}.brandhub-text-mask__surface-text{font-size:11.25rem;opacity:.7;stroke:var(--fill-color, var(--wb-white));stroke-width:.002em;z-index:2}@media (max-width: 1023px){.brandhub-text-mask__surface-text{font-size:clamp(6rem,12vw,11.25rem)}}.brandhub-text-mask__content{grid-area:content;min-height:100vh;width:100%}.brandhub-text-mask__content--mask{mask:url(#mask)}.brandhub-text-mask__background-overlay{background:var(--fill-color);grid-area:content;height:100%;width:100%;z-index:1}
`,
  k = { class: "brandhub-text-mask__screen", ref: "screenDiv" },
  u = { id: "svg-mask-title" },
  f = ["id"],
  x = ["d"],
  p = ["fill", "opacity"],
  g = ["clip-path"],
  v = a(
    "rect",
    {
      class: "brandhub-text-mask__surface",
      fill: "black",
      height: "960",
      width: "480",
      x: "0",
      y: "0",
    },
    null,
    -1
  ),
  w = {
    class: "brandhub-text-mask__surface-text",
    fill: "transparent",
    "stroke-width": "0.02rem",
    stroke: "white",
    "text-anchor": "middle",
    x: "240",
    y: "530",
  },
  y = { class: "brandhub-text-mask__content" };
function T(t, C, z, S, M, B) {
  return (
    e(),
    s(
      "div",
      { class: r(t.rootCssClass), ref: "outerMask", style: i(t.rootStyle) },
      [
        a(
          "div",
          k,
          [
            t.fontLoaded
              ? o("", !0)
              : (e(),
                s(
                  "div",
                  {
                    key: 0,
                    class: r([
                      "brandhub-text-mask__mask brandhub-text-mask__mask--initial",
                      t.surfaceColor === "black"
                        ? "brandhub-text-mask__mask--black"
                        : "brandhub-text-mask__mask--white",
                    ]),
                  },
                  null,
                  2
                )),
            t.fontLoaded
              ? l(
                  (e(),
                  s(
                    "svg",
                    {
                      key: 1,
                      class: r(t.svgCssClass),
                      role: "img",
                      "aria-labelledby": "svg-mask-title",
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 480 960",
                      width: "100%",
                      height: "100%",
                      preserveAspectRatio: "xMidYMid slice",
                    },
                    [
                      a(
                        "title",
                        u,
                        n(t.outlinedText) + " " + n(t.transparentText),
                        1
                      ),
                      a("defs", null, [
                        a(
                          "clipPath",
                          {
                            id: t.clipPathId,
                            class: "brandhub-text-mask__clip-path",
                            style: i(t.maskTextStyle),
                          },
                          [
                            a(
                              "path",
                              {
                                class: "brandhub-text-mask__transparent-text",
                                d: t.transparentPath,
                                "fill-rule": "nonzero",
                              },
                              null,
                              8,
                              x
                            ),
                          ],
                          12,
                          f
                        ),
                      ]),
                      a(
                        "rect",
                        {
                          fill: t.fillColor,
                          opacity: t.backgroundOverlayOpacity,
                          class: "brandhub-text-mask__see-through-surface",
                          height: "960",
                          width: "480",
                          x: "0",
                          y: "0",
                        },
                        null,
                        8,
                        p
                      ),
                      a(
                        "g",
                        {
                          class: "brandhub-text-mask__svg-group",
                          style: i(t.filledTextStyle),
                          "clip-path": `url(#${t.clipPathId})`,
                        },
                        [v, a("text", w, n(t.outlinedText), 1)],
                        12,
                        g
                      ),
                    ],
                    2
                  )),
                  [[h, t.scale < 1]]
                )
              : o("", !0),
            a("div", y, [
              m(t.$slots, "default", {}, () => [
                b(" Please add a child component here "),
              ]),
            ]),
          ],
          512
        ),
      ],
      6
    )
  );
}
const Y = c(d, [
  ["render", T],
  ["styles", [_]],
]);
export { I as TEXT_MASK_CHILD_MOUNTED, Y as default };
