import { o as e, c as o, h as t } from "./index.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "fill-rule": "evenodd",
    "stroke-linejoin": "round",
    "stroke-miterlimit": "2",
    "clip-rule": "evenodd",
    viewBox: "0 0 40 40",
  },
  n = t(
    "path",
    {
      fill: "currentColor",
      d: "M20 0c11.038 0 20 8.962 20 20s-8.962 20-20 20S0 31.038 0 20 8.962 0 20 0zm-7 28a1 1 0 0 1-1-1v-4.667a1 1 0 0 1 2 0L14.001 26h3.666a1 1 0 0 1 0 2H13zm14-16a1 1 0 0 1 1 1v4.667a1 1 0 0 1-2 0L25.999 14h-3.666a1 1 0 0 1 0-2H27z",
    },
    null,
    -1
  ),
  s = [n];
function a(l, c) {
  return e(), o("svg", r, [...s]);
}
const i = { render: a };
export { i as default, a as render };
