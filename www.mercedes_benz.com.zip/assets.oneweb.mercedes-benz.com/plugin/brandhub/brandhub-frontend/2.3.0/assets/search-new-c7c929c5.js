import { o, c as r, h as e } from "./index.js";
const t = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 16 16" },
  c = e(
    "g",
    { fill: "none", "fill-rule": "evenodd", transform: "translate(2 2)" },
    [
      e("circle", { cx: "7.121", cy: "4.5", r: "4.5", stroke: "currentColor" }),
      e("path", {
        fill: "currentColor",
        d: "M0 10.914 3.535 7.38l.707.707-3.535 3.536z",
      }),
    ],
    -1
  ),
  n = [c];
function s(l, a) {
  return o(), r("svg", t, [...n]);
}
const i = { render: s };
export { i as default, s as render };
