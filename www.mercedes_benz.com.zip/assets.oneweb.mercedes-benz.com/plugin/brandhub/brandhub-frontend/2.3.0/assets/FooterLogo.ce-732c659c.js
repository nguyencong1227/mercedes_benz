import { B as e } from "./BackgroundColorMixin-87cd4cac.js";
import { d as t, o as r, c as a, h as i, g as l } from "./index.js";
import { _ as n } from "./_plugin-vue_export-helper-c27b6911.js";
const s = t({ props: { logoPath: String, logoAlt: String }, mixins: [e] }),
  g = `.footer-logo{background-color:var(--background-color);display:flex;justify-content:center;margin-left:auto;margin-right:auto;width:100%}.footer-logo__image{height:8.8571428571rem}@media (min-width: 768px){.footer-logo__image{height:10.7142857143rem}}@media (min-width: 1440px){.footer-logo__image{height:13.0714285714rem}}
`,
  c = ["src", "alt"];
function m(o, d, _, f, p, h) {
  return (
    r(),
    a(
      "div",
      { class: "footer-logo", style: l(o.getBackgroundColorStyle) },
      [
        i(
          "img",
          { class: "footer-logo__image", src: o.logoPath, alt: o.logoAlt },
          null,
          8,
          c
        ),
      ],
      4
    )
  );
}
const B = n(s, [
  ["render", m],
  ["styles", [g]],
]);
export { B as default };
