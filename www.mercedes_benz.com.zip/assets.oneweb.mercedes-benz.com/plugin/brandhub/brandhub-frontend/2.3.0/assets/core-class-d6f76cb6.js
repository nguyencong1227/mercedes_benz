function Me(e) {
  return (
    e !== null &&
    typeof e == "object" &&
    "constructor" in e &&
    e.constructor === Object
  );
}
function ge(e, t) {
  e === void 0 && (e = {}),
    t === void 0 && (t = {}),
    Object.keys(t).forEach(function (i) {
      typeof e[i] > "u"
        ? (e[i] = t[i])
        : Me(t[i]) &&
          Me(e[i]) &&
          Object.keys(t[i]).length > 0 &&
          ge(e[i], t[i]);
    });
}
var Ie = {
  body: {},
  addEventListener: function () {},
  removeEventListener: function () {},
  activeElement: { blur: function () {}, nodeName: "" },
  querySelector: function () {
    return null;
  },
  querySelectorAll: function () {
    return [];
  },
  getElementById: function () {
    return null;
  },
  createEvent: function () {
    return { initEvent: function () {} };
  },
  createElement: function () {
    return {
      children: [],
      childNodes: [],
      style: {},
      setAttribute: function () {},
      getElementsByTagName: function () {
        return [];
      },
    };
  },
  createElementNS: function () {
    return {};
  },
  importNode: function () {
    return null;
  },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: "",
  },
};
function D() {
  var e = typeof document < "u" ? document : {};
  return ge(e, Ie), e;
}
var Ve = {
  document: Ie,
  navigator: { userAgent: "" },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: "",
  },
  history: {
    replaceState: function () {},
    pushState: function () {},
    go: function () {},
    back: function () {},
  },
  CustomEvent: function () {
    return this;
  },
  addEventListener: function () {},
  removeEventListener: function () {},
  getComputedStyle: function () {
    return {
      getPropertyValue: function () {
        return "";
      },
    };
  },
  Image: function () {},
  Date: function () {},
  screen: {},
  setTimeout: function () {},
  clearTimeout: function () {},
  matchMedia: function () {
    return {};
  },
  requestAnimationFrame: function (e) {
    return typeof setTimeout > "u" ? (e(), null) : setTimeout(e, 0);
  },
  cancelAnimationFrame: function (e) {
    typeof setTimeout > "u" || clearTimeout(e);
  },
};
function L() {
  var e = typeof window < "u" ? window : {};
  return ge(e, Ve), e;
}
function Ne(e, t) {
  (e.prototype = Object.create(t.prototype)),
    (e.prototype.constructor = e),
    (e.__proto__ = t);
}
function pe(e) {
  return (
    (pe = Object.setPrototypeOf
      ? Object.getPrototypeOf
      : function (i) {
          return i.__proto__ || Object.getPrototypeOf(i);
        }),
    pe(e)
  );
}
function _(e, t) {
  return (
    (_ =
      Object.setPrototypeOf ||
      function (r, s) {
        return (r.__proto__ = s), r;
      }),
    _(e, t)
  );
}
function We() {
  if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
    return !1;
  if (typeof Proxy == "function") return !0;
  try {
    return (
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {})),
      !0
    );
  } catch {
    return !1;
  }
}
function Z(e, t, i) {
  return (
    We()
      ? (Z = Reflect.construct)
      : (Z = function (s, n, l) {
          var o = [null];
          o.push.apply(o, n);
          var a = Function.bind.apply(s, o),
            f = new a();
          return l && _(f, l.prototype), f;
        }),
    Z.apply(null, arguments)
  );
}
function $e(e) {
  return Function.toString.call(e).indexOf("[native code]") !== -1;
}
function ce(e) {
  var t = typeof Map == "function" ? new Map() : void 0;
  return (
    (ce = function (r) {
      if (r === null || !$e(r)) return r;
      if (typeof r != "function")
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      if (typeof t < "u") {
        if (t.has(r)) return t.get(r);
        t.set(r, s);
      }
      function s() {
        return Z(r, arguments, pe(this).constructor);
      }
      return (
        (s.prototype = Object.create(r.prototype, {
          constructor: {
            value: s,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
        _(s, r)
      );
    }),
    ce(e)
  );
}
function Fe(e) {
  if (e === void 0)
    throw new ReferenceError(
      "this hasn't been initialised - super() hasn't been called"
    );
  return e;
}
function je(e) {
  var t = e.__proto__;
  Object.defineProperty(e, "__proto__", {
    get: function () {
      return t;
    },
    set: function (r) {
      t.__proto__ = r;
    },
  });
}
var H = (function (e) {
  Ne(t, e);
  function t(i) {
    var r;
    return (r = e.call.apply(e, [this].concat(i)) || this), je(Fe(r)), r;
  }
  return t;
})(ce(Array));
function X(e) {
  e === void 0 && (e = []);
  var t = [];
  return (
    e.forEach(function (i) {
      Array.isArray(i) ? t.push.apply(t, X(i)) : t.push(i);
    }),
    t
  );
}
function Ae(e, t) {
  return Array.prototype.filter.call(e, t);
}
function qe(e) {
  for (var t = [], i = 0; i < e.length; i += 1)
    t.indexOf(e[i]) === -1 && t.push(e[i]);
  return t;
}
function Xe(e, t) {
  if (typeof e != "string") return [e];
  for (var i = [], r = t.querySelectorAll(e), s = 0; s < r.length; s += 1)
    i.push(r[s]);
  return i;
}
function v(e, t) {
  var i = L(),
    r = D(),
    s = [];
  if (!t && e instanceof H) return e;
  if (!e) return new H(s);
  if (typeof e == "string") {
    var n = e.trim();
    if (n.indexOf("<") >= 0 && n.indexOf(">") >= 0) {
      var l = "div";
      n.indexOf("<li") === 0 && (l = "ul"),
        n.indexOf("<tr") === 0 && (l = "tbody"),
        (n.indexOf("<td") === 0 || n.indexOf("<th") === 0) && (l = "tr"),
        n.indexOf("<tbody") === 0 && (l = "table"),
        n.indexOf("<option") === 0 && (l = "select");
      var o = r.createElement(l);
      o.innerHTML = n;
      for (var a = 0; a < o.childNodes.length; a += 1) s.push(o.childNodes[a]);
    } else s = Xe(e.trim(), t || r);
  } else if (e.nodeType || e === i || e === r) s.push(e);
  else if (Array.isArray(e)) {
    if (e instanceof H) return e;
    s = e;
  }
  return new H(qe(s));
}
v.fn = H.prototype;
function Ye() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = X(
    t.map(function (s) {
      return s.split(" ");
    })
  );
  return (
    this.forEach(function (s) {
      var n;
      (n = s.classList).add.apply(n, r);
    }),
    this
  );
}
function Ue() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = X(
    t.map(function (s) {
      return s.split(" ");
    })
  );
  return (
    this.forEach(function (s) {
      var n;
      (n = s.classList).remove.apply(n, r);
    }),
    this
  );
}
function Je() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = X(
    t.map(function (s) {
      return s.split(" ");
    })
  );
  this.forEach(function (s) {
    r.forEach(function (n) {
      s.classList.toggle(n);
    });
  });
}
function Qe() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = X(
    t.map(function (s) {
      return s.split(" ");
    })
  );
  return (
    Ae(this, function (s) {
      return (
        r.filter(function (n) {
          return s.classList.contains(n);
        }).length > 0
      );
    }).length > 0
  );
}
function Ze(e, t) {
  if (arguments.length === 1 && typeof e == "string")
    return this[0] ? this[0].getAttribute(e) : void 0;
  for (var i = 0; i < this.length; i += 1)
    if (arguments.length === 2) this[i].setAttribute(e, t);
    else for (var r in e) (this[i][r] = e[r]), this[i].setAttribute(r, e[r]);
  return this;
}
function _e(e) {
  for (var t = 0; t < this.length; t += 1) this[t].removeAttribute(e);
  return this;
}
function Ke(e) {
  for (var t = 0; t < this.length; t += 1) this[t].style.transform = e;
  return this;
}
function et(e) {
  for (var t = 0; t < this.length; t += 1)
    this[t].style.transitionDuration = typeof e != "string" ? e + "ms" : e;
  return this;
}
function tt() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = t[0],
    s = t[1],
    n = t[2],
    l = t[3];
  typeof t[1] == "function" &&
    ((r = t[0]), (n = t[1]), (l = t[2]), (s = void 0)),
    l || (l = !1);
  function o(g) {
    var w = g.target;
    if (w) {
      var E = g.target.dom7EventData || [];
      if ((E.indexOf(g) < 0 && E.unshift(g), v(w).is(s))) n.apply(w, E);
      else
        for (var y = v(w).parents(), T = 0; T < y.length; T += 1)
          v(y[T]).is(s) && n.apply(y[T], E);
    }
  }
  function a(g) {
    var w = g && g.target ? g.target.dom7EventData || [] : [];
    w.indexOf(g) < 0 && w.unshift(g), n.apply(this, w);
  }
  for (var f = r.split(" "), d, p = 0; p < this.length; p += 1) {
    var u = this[p];
    if (s)
      for (d = 0; d < f.length; d += 1) {
        var m = f[d];
        u.dom7LiveListeners || (u.dom7LiveListeners = {}),
          u.dom7LiveListeners[m] || (u.dom7LiveListeners[m] = []),
          u.dom7LiveListeners[m].push({ listener: n, proxyListener: o }),
          u.addEventListener(m, o, l);
      }
    else
      for (d = 0; d < f.length; d += 1) {
        var c = f[d];
        u.dom7Listeners || (u.dom7Listeners = {}),
          u.dom7Listeners[c] || (u.dom7Listeners[c] = []),
          u.dom7Listeners[c].push({ listener: n, proxyListener: a }),
          u.addEventListener(c, a, l);
      }
  }
  return this;
}
function rt() {
  for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
    t[i] = arguments[i];
  var r = t[0],
    s = t[1],
    n = t[2],
    l = t[3];
  typeof t[1] == "function" &&
    ((r = t[0]), (n = t[1]), (l = t[2]), (s = void 0)),
    l || (l = !1);
  for (var o = r.split(" "), a = 0; a < o.length; a += 1)
    for (var f = o[a], d = 0; d < this.length; d += 1) {
      var p = this[d],
        u = void 0;
      if (
        (!s && p.dom7Listeners
          ? (u = p.dom7Listeners[f])
          : s && p.dom7LiveListeners && (u = p.dom7LiveListeners[f]),
        u && u.length)
      )
        for (var c = u.length - 1; c >= 0; c -= 1) {
          var m = u[c];
          (n && m.listener === n) ||
          (n &&
            m.listener &&
            m.listener.dom7proxy &&
            m.listener.dom7proxy === n)
            ? (p.removeEventListener(f, m.proxyListener, l), u.splice(c, 1))
            : n ||
              (p.removeEventListener(f, m.proxyListener, l), u.splice(c, 1));
        }
    }
  return this;
}
function it() {
  for (var e = L(), t = arguments.length, i = new Array(t), r = 0; r < t; r++)
    i[r] = arguments[r];
  for (var s = i[0].split(" "), n = i[1], l = 0; l < s.length; l += 1)
    for (var o = s[l], a = 0; a < this.length; a += 1) {
      var f = this[a];
      if (e.CustomEvent) {
        var d = new e.CustomEvent(o, {
          detail: n,
          bubbles: !0,
          cancelable: !0,
        });
        (f.dom7EventData = i.filter(function (p, u) {
          return u > 0;
        })),
          f.dispatchEvent(d),
          (f.dom7EventData = []),
          delete f.dom7EventData;
      }
    }
  return this;
}
function st(e) {
  var t = this;
  function i(r) {
    r.target === this && (e.call(this, r), t.off("transitionend", i));
  }
  return e && t.on("transitionend", i), this;
}
function nt(e) {
  if (this.length > 0) {
    if (e) {
      var t = this.styles();
      return (
        this[0].offsetWidth +
        parseFloat(t.getPropertyValue("margin-right")) +
        parseFloat(t.getPropertyValue("margin-left"))
      );
    }
    return this[0].offsetWidth;
  }
  return null;
}
function at(e) {
  if (this.length > 0) {
    if (e) {
      var t = this.styles();
      return (
        this[0].offsetHeight +
        parseFloat(t.getPropertyValue("margin-top")) +
        parseFloat(t.getPropertyValue("margin-bottom"))
      );
    }
    return this[0].offsetHeight;
  }
  return null;
}
function ot() {
  if (this.length > 0) {
    var e = L(),
      t = D(),
      i = this[0],
      r = i.getBoundingClientRect(),
      s = t.body,
      n = i.clientTop || s.clientTop || 0,
      l = i.clientLeft || s.clientLeft || 0,
      o = i === e ? e.scrollY : i.scrollTop,
      a = i === e ? e.scrollX : i.scrollLeft;
    return { top: r.top + o - n, left: r.left + a - l };
  }
  return null;
}
function lt() {
  var e = L();
  return this[0] ? e.getComputedStyle(this[0], null) : {};
}
function ft(e, t) {
  var i = L(),
    r;
  if (arguments.length === 1)
    if (typeof e == "string") {
      if (this[0]) return i.getComputedStyle(this[0], null).getPropertyValue(e);
    } else {
      for (r = 0; r < this.length; r += 1)
        for (var s in e) this[r].style[s] = e[s];
      return this;
    }
  if (arguments.length === 2 && typeof e == "string") {
    for (r = 0; r < this.length; r += 1) this[r].style[e] = t;
    return this;
  }
  return this;
}
function dt(e) {
  return e
    ? (this.forEach(function (t, i) {
        e.apply(t, [t, i]);
      }),
      this)
    : this;
}
function ut(e) {
  var t = Ae(this, e);
  return v(t);
}
function pt(e) {
  if (typeof e > "u") return this[0] ? this[0].innerHTML : null;
  for (var t = 0; t < this.length; t += 1) this[t].innerHTML = e;
  return this;
}
function ct(e) {
  if (typeof e > "u") return this[0] ? this[0].textContent.trim() : null;
  for (var t = 0; t < this.length; t += 1) this[t].textContent = e;
  return this;
}
function vt(e) {
  var t = L(),
    i = D(),
    r = this[0],
    s,
    n;
  if (!r || typeof e > "u") return !1;
  if (typeof e == "string") {
    if (r.matches) return r.matches(e);
    if (r.webkitMatchesSelector) return r.webkitMatchesSelector(e);
    if (r.msMatchesSelector) return r.msMatchesSelector(e);
    for (s = v(e), n = 0; n < s.length; n += 1) if (s[n] === r) return !0;
    return !1;
  }
  if (e === i) return r === i;
  if (e === t) return r === t;
  if (e.nodeType || e instanceof H) {
    for (s = e.nodeType ? [e] : e, n = 0; n < s.length; n += 1)
      if (s[n] === r) return !0;
    return !1;
  }
  return !1;
}
function ht() {
  var e = this[0],
    t;
  if (e) {
    for (t = 0; (e = e.previousSibling) !== null; )
      e.nodeType === 1 && (t += 1);
    return t;
  }
}
function mt(e) {
  if (typeof e > "u") return this;
  var t = this.length;
  if (e > t - 1) return v([]);
  if (e < 0) {
    var i = t + e;
    return i < 0 ? v([]) : v([this[i]]);
  }
  return v([this[e]]);
}
function gt() {
  for (var e, t = D(), i = 0; i < arguments.length; i += 1) {
    e = i < 0 || arguments.length <= i ? void 0 : arguments[i];
    for (var r = 0; r < this.length; r += 1)
      if (typeof e == "string") {
        var s = t.createElement("div");
        for (s.innerHTML = e; s.firstChild; ) this[r].appendChild(s.firstChild);
      } else if (e instanceof H)
        for (var n = 0; n < e.length; n += 1) this[r].appendChild(e[n]);
      else this[r].appendChild(e);
  }
  return this;
}
function wt(e) {
  var t = D(),
    i,
    r;
  for (i = 0; i < this.length; i += 1)
    if (typeof e == "string") {
      var s = t.createElement("div");
      for (s.innerHTML = e, r = s.childNodes.length - 1; r >= 0; r -= 1)
        this[i].insertBefore(s.childNodes[r], this[i].childNodes[0]);
    } else if (e instanceof H)
      for (r = 0; r < e.length; r += 1)
        this[i].insertBefore(e[r], this[i].childNodes[0]);
    else this[i].insertBefore(e, this[i].childNodes[0]);
  return this;
}
function Tt(e) {
  return this.length > 0
    ? e
      ? this[0].nextElementSibling && v(this[0].nextElementSibling).is(e)
        ? v([this[0].nextElementSibling])
        : v([])
      : this[0].nextElementSibling
      ? v([this[0].nextElementSibling])
      : v([])
    : v([]);
}
function St(e) {
  var t = [],
    i = this[0];
  if (!i) return v([]);
  for (; i.nextElementSibling; ) {
    var r = i.nextElementSibling;
    e ? v(r).is(e) && t.push(r) : t.push(r), (i = r);
  }
  return v(t);
}
function bt(e) {
  if (this.length > 0) {
    var t = this[0];
    return e
      ? t.previousElementSibling && v(t.previousElementSibling).is(e)
        ? v([t.previousElementSibling])
        : v([])
      : t.previousElementSibling
      ? v([t.previousElementSibling])
      : v([]);
  }
  return v([]);
}
function Et(e) {
  var t = [],
    i = this[0];
  if (!i) return v([]);
  for (; i.previousElementSibling; ) {
    var r = i.previousElementSibling;
    e ? v(r).is(e) && t.push(r) : t.push(r), (i = r);
  }
  return v(t);
}
function yt(e) {
  for (var t = [], i = 0; i < this.length; i += 1)
    this[i].parentNode !== null &&
      (e
        ? v(this[i].parentNode).is(e) && t.push(this[i].parentNode)
        : t.push(this[i].parentNode));
  return v(t);
}
function Ct(e) {
  for (var t = [], i = 0; i < this.length; i += 1)
    for (var r = this[i].parentNode; r; )
      e ? v(r).is(e) && t.push(r) : t.push(r), (r = r.parentNode);
  return v(t);
}
function xt(e) {
  var t = this;
  return typeof e > "u" ? v([]) : (t.is(e) || (t = t.parents(e).eq(0)), t);
}
function Mt(e) {
  for (var t = [], i = 0; i < this.length; i += 1)
    for (var r = this[i].querySelectorAll(e), s = 0; s < r.length; s += 1)
      t.push(r[s]);
  return v(t);
}
function Lt(e) {
  for (var t = [], i = 0; i < this.length; i += 1)
    for (var r = this[i].children, s = 0; s < r.length; s += 1)
      (!e || v(r[s]).is(e)) && t.push(r[s]);
  return v(t);
}
function Pt() {
  for (var e = 0; e < this.length; e += 1)
    this[e].parentNode && this[e].parentNode.removeChild(this[e]);
  return this;
}
var Le = {
  addClass: Ye,
  removeClass: Ue,
  hasClass: Qe,
  toggleClass: Je,
  attr: Ze,
  removeAttr: _e,
  transform: Ke,
  transition: et,
  on: tt,
  off: rt,
  trigger: it,
  transitionEnd: st,
  outerWidth: nt,
  outerHeight: at,
  styles: lt,
  offset: ot,
  css: ft,
  each: dt,
  html: pt,
  text: ct,
  is: vt,
  index: ht,
  eq: mt,
  append: gt,
  prepend: wt,
  next: Tt,
  nextAll: St,
  prev: bt,
  prevAll: Et,
  parent: yt,
  parents: Ct,
  closest: xt,
  find: Mt,
  children: Lt,
  filter: ut,
  remove: Pt,
};
Object.keys(Le).forEach(function (e) {
  Object.defineProperty(v.fn, e, { value: Le[e], writable: !0 });
});
function Ot(e) {
  var t = e;
  Object.keys(t).forEach(function (i) {
    try {
      t[i] = null;
    } catch {}
    try {
      delete t[i];
    } catch {}
  });
}
function ve(e, t) {
  return t === void 0 && (t = 0), setTimeout(e, t);
}
function V() {
  return Date.now();
}
function zt(e) {
  var t = L(),
    i;
  return (
    t.getComputedStyle && (i = t.getComputedStyle(e, null)),
    !i && e.currentStyle && (i = e.currentStyle),
    i || (i = e.style),
    i
  );
}
function It(e, t) {
  t === void 0 && (t = "x");
  var i = L(),
    r,
    s,
    n,
    l = zt(e);
  return (
    i.WebKitCSSMatrix
      ? ((s = l.transform || l.webkitTransform),
        s.split(",").length > 6 &&
          (s = s
            .split(", ")
            .map(function (o) {
              return o.replace(",", ".");
            })
            .join(", ")),
        (n = new i.WebKitCSSMatrix(s === "none" ? "" : s)))
      : ((n =
          l.MozTransform ||
          l.OTransform ||
          l.MsTransform ||
          l.msTransform ||
          l.transform ||
          l
            .getPropertyValue("transform")
            .replace("translate(", "matrix(1, 0, 0, 1,")),
        (r = n.toString().split(","))),
    t === "x" &&
      (i.WebKitCSSMatrix
        ? (s = n.m41)
        : r.length === 16
        ? (s = parseFloat(r[12]))
        : (s = parseFloat(r[4]))),
    t === "y" &&
      (i.WebKitCSSMatrix
        ? (s = n.m42)
        : r.length === 16
        ? (s = parseFloat(r[13]))
        : (s = parseFloat(r[5]))),
    s || 0
  );
}
function q(e) {
  return (
    typeof e == "object" &&
    e !== null &&
    e.constructor &&
    Object.prototype.toString.call(e).slice(8, -1) === "Object"
  );
}
function At(e) {
  return typeof window < "u" && typeof window.HTMLElement < "u"
    ? e instanceof HTMLElement
    : e && (e.nodeType === 1 || e.nodeType === 11);
}
function x() {
  for (
    var e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
      t = ["__proto__", "constructor", "prototype"],
      i = 1;
    i < arguments.length;
    i += 1
  ) {
    var r = i < 0 || arguments.length <= i ? void 0 : arguments[i];
    if (r != null && !At(r))
      for (
        var s = Object.keys(Object(r)).filter(function (f) {
            return t.indexOf(f) < 0;
          }),
          n = 0,
          l = s.length;
        n < l;
        n += 1
      ) {
        var o = s[n],
          a = Object.getOwnPropertyDescriptor(r, o);
        a !== void 0 &&
          a.enumerable &&
          (q(e[o]) && q(r[o])
            ? r[o].__swiper__
              ? (e[o] = r[o])
              : x(e[o], r[o])
            : !q(e[o]) && q(r[o])
            ? ((e[o] = {}), r[o].__swiper__ ? (e[o] = r[o]) : x(e[o], r[o]))
            : (e[o] = r[o]));
      }
  }
  return e;
}
function Dt(e, t) {
  Object.keys(t).forEach(function (i) {
    q(t[i]) &&
      Object.keys(t[i]).forEach(function (r) {
        typeof t[i][r] == "function" && (t[i][r] = t[i][r].bind(e));
      }),
      (e[i] = t[i]);
  });
}
function ti(e) {
  return (
    e === void 0 && (e = ""),
    "." +
      e
        .trim()
        .replace(/([\.:!\/])/g, "\\$1")
        .replace(/ /g, ".")
  );
}
function ri(e, t, i, r) {
  var s = D();
  return (
    i &&
      Object.keys(r).forEach(function (n) {
        if (!t[n] && t.auto === !0) {
          var l = s.createElement("div");
          (l.className = r[n]), e.append(l), (t[n] = l);
        }
      }),
    t
  );
}
var oe;
function Gt() {
  var e = L(),
    t = D();
  return {
    touch: !!(
      "ontouchstart" in e ||
      (e.DocumentTouch && t instanceof e.DocumentTouch)
    ),
    pointerEvents:
      !!e.PointerEvent &&
      "maxTouchPoints" in e.navigator &&
      e.navigator.maxTouchPoints >= 0,
    observer: (function () {
      return "MutationObserver" in e || "WebkitMutationObserver" in e;
    })(),
    passiveListener: (function () {
      var r = !1;
      try {
        var s = Object.defineProperty({}, "passive", {
          get: function () {
            r = !0;
          },
        });
        e.addEventListener("testPassiveListener", null, s);
      } catch {}
      return r;
    })(),
    gestures: (function () {
      return "ongesturestart" in e;
    })(),
  };
}
function De() {
  return oe || (oe = Gt()), oe;
}
var le;
function kt(e) {
  var t = e === void 0 ? {} : e,
    i = t.userAgent,
    r = De(),
    s = L(),
    n = s.navigator.platform,
    l = i || s.navigator.userAgent,
    o = { ios: !1, android: !1 },
    a = s.screen.width,
    f = s.screen.height,
    d = l.match(/(Android);?[\s\/]+([\d.]+)?/),
    p = l.match(/(iPad).*OS\s([\d_]+)/),
    u = l.match(/(iPod)(.*OS\s([\d_]+))?/),
    c = !p && l.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
    m = n === "Win32",
    g = n === "MacIntel",
    w = [
      "1024x1366",
      "1366x1024",
      "834x1194",
      "1194x834",
      "834x1112",
      "1112x834",
      "768x1024",
      "1024x768",
      "820x1180",
      "1180x820",
      "810x1080",
      "1080x810",
    ];
  return (
    !p &&
      g &&
      r.touch &&
      w.indexOf(a + "x" + f) >= 0 &&
      ((p = l.match(/(Version)\/([\d.]+)/)),
      p || (p = [0, 1, "13_0_0"]),
      (g = !1)),
    d && !m && ((o.os = "android"), (o.android = !0)),
    (p || c || u) && ((o.os = "ios"), (o.ios = !0)),
    o
  );
}
function Bt(e) {
  return e === void 0 && (e = {}), le || (le = kt(e)), le;
}
var fe;
function Rt() {
  var e = L();
  function t() {
    var i = e.navigator.userAgent.toLowerCase();
    return (
      i.indexOf("safari") >= 0 &&
      i.indexOf("chrome") < 0 &&
      i.indexOf("android") < 0
    );
  }
  return {
    isEdge: !!e.navigator.userAgent.match(/Edge/g),
    isSafari: t(),
    isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(
      e.navigator.userAgent
    ),
  };
}
function Ht() {
  return fe || (fe = Rt()), fe;
}
var Vt = function () {
  var t = L();
  return typeof t.ResizeObserver < "u";
};
const Nt = {
  name: "resize",
  create: function () {
    var t = this;
    x(t, {
      resize: {
        observer: null,
        createObserver: function () {
          !t ||
            t.destroyed ||
            !t.initialized ||
            ((t.resize.observer = new ResizeObserver(function (r) {
              var s = t.width,
                n = t.height,
                l = s,
                o = n;
              r.forEach(function (a) {
                var f = a.contentBoxSize,
                  d = a.contentRect,
                  p = a.target;
                (p && p !== t.el) ||
                  ((l = d ? d.width : (f[0] || f).inlineSize),
                  (o = d ? d.height : (f[0] || f).blockSize));
              }),
                (l !== s || o !== n) && t.resize.resizeHandler();
            })),
            t.resize.observer.observe(t.el));
        },
        removeObserver: function () {
          t.resize.observer &&
            t.resize.observer.unobserve &&
            t.el &&
            (t.resize.observer.unobserve(t.el), (t.resize.observer = null));
        },
        resizeHandler: function () {
          !t ||
            t.destroyed ||
            !t.initialized ||
            (t.emit("beforeResize"), t.emit("resize"));
        },
        orientationChangeHandler: function () {
          !t || t.destroyed || !t.initialized || t.emit("orientationchange");
        },
      },
    });
  },
  on: {
    init: function (t) {
      var i = L();
      if (t.params.resizeObserver && Vt()) {
        t.resize.createObserver();
        return;
      }
      i.addEventListener("resize", t.resize.resizeHandler),
        i.addEventListener(
          "orientationchange",
          t.resize.orientationChangeHandler
        );
    },
    destroy: function (t) {
      var i = L();
      t.resize.removeObserver(),
        i.removeEventListener("resize", t.resize.resizeHandler),
        i.removeEventListener(
          "orientationchange",
          t.resize.orientationChangeHandler
        );
    },
  },
};
function he() {
  return (
    (he =
      Object.assign ||
      function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];
          for (var r in i)
            Object.prototype.hasOwnProperty.call(i, r) && (e[r] = i[r]);
        }
        return e;
      }),
    he.apply(this, arguments)
  );
}
var Wt = {
  attach: function (t, i) {
    i === void 0 && (i = {});
    var r = L(),
      s = this,
      n = r.MutationObserver || r.WebkitMutationObserver,
      l = new n(function (o) {
        if (o.length === 1) {
          s.emit("observerUpdate", o[0]);
          return;
        }
        var a = function () {
          s.emit("observerUpdate", o[0]);
        };
        r.requestAnimationFrame
          ? r.requestAnimationFrame(a)
          : r.setTimeout(a, 0);
      });
    l.observe(t, {
      attributes: typeof i.attributes > "u" ? !0 : i.attributes,
      childList: typeof i.childList > "u" ? !0 : i.childList,
      characterData: typeof i.characterData > "u" ? !0 : i.characterData,
    }),
      s.observer.observers.push(l);
  },
  init: function () {
    var t = this;
    if (!(!t.support.observer || !t.params.observer)) {
      if (t.params.observeParents)
        for (var i = t.$el.parents(), r = 0; r < i.length; r += 1)
          t.observer.attach(i[r]);
      t.observer.attach(t.$el[0], { childList: t.params.observeSlideChildren }),
        t.observer.attach(t.$wrapperEl[0], { attributes: !1 });
    }
  },
  destroy: function () {
    var t = this;
    t.observer.observers.forEach(function (i) {
      i.disconnect();
    }),
      (t.observer.observers = []);
  },
};
const $t = {
    name: "observer",
    params: { observer: !1, observeParents: !1, observeSlideChildren: !1 },
    create: function () {
      var t = this;
      Dt(t, { observer: he({}, Wt, { observers: [] }) });
    },
    on: {
      init: function (t) {
        t.observer.init();
      },
      destroy: function (t) {
        t.observer.destroy();
      },
    },
  },
  Ft = {
    useParams: function (t) {
      var i = this;
      i.modules &&
        Object.keys(i.modules).forEach(function (r) {
          var s = i.modules[r];
          s.params && x(t, s.params);
        });
    },
    useModules: function (t) {
      t === void 0 && (t = {});
      var i = this;
      i.modules &&
        Object.keys(i.modules).forEach(function (r) {
          var s = i.modules[r],
            n = t[r] || {};
          s.on &&
            i.on &&
            Object.keys(s.on).forEach(function (l) {
              i.on(l, s.on[l]);
            }),
            s.create && s.create.bind(i)(n);
        });
    },
  },
  jt = {
    on: function (t, i, r) {
      var s = this;
      if (typeof i != "function") return s;
      var n = r ? "unshift" : "push";
      return (
        t.split(" ").forEach(function (l) {
          s.eventsListeners[l] || (s.eventsListeners[l] = []),
            s.eventsListeners[l][n](i);
        }),
        s
      );
    },
    once: function (t, i, r) {
      var s = this;
      if (typeof i != "function") return s;
      function n() {
        s.off(t, n), n.__emitterProxy && delete n.__emitterProxy;
        for (var l = arguments.length, o = new Array(l), a = 0; a < l; a++)
          o[a] = arguments[a];
        i.apply(s, o);
      }
      return (n.__emitterProxy = i), s.on(t, n, r);
    },
    onAny: function (t, i) {
      var r = this;
      if (typeof t != "function") return r;
      var s = i ? "unshift" : "push";
      return (
        r.eventsAnyListeners.indexOf(t) < 0 && r.eventsAnyListeners[s](t), r
      );
    },
    offAny: function (t) {
      var i = this;
      if (!i.eventsAnyListeners) return i;
      var r = i.eventsAnyListeners.indexOf(t);
      return r >= 0 && i.eventsAnyListeners.splice(r, 1), i;
    },
    off: function (t, i) {
      var r = this;
      return (
        r.eventsListeners &&
          t.split(" ").forEach(function (s) {
            typeof i > "u"
              ? (r.eventsListeners[s] = [])
              : r.eventsListeners[s] &&
                r.eventsListeners[s].forEach(function (n, l) {
                  (n === i || (n.__emitterProxy && n.__emitterProxy === i)) &&
                    r.eventsListeners[s].splice(l, 1);
                });
          }),
        r
      );
    },
    emit: function () {
      var t = this;
      if (!t.eventsListeners) return t;
      for (
        var i, r, s, n = arguments.length, l = new Array(n), o = 0;
        o < n;
        o++
      )
        l[o] = arguments[o];
      typeof l[0] == "string" || Array.isArray(l[0])
        ? ((i = l[0]), (r = l.slice(1, l.length)), (s = t))
        : ((i = l[0].events), (r = l[0].data), (s = l[0].context || t)),
        r.unshift(s);
      var a = Array.isArray(i) ? i : i.split(" ");
      return (
        a.forEach(function (f) {
          t.eventsAnyListeners &&
            t.eventsAnyListeners.length &&
            t.eventsAnyListeners.forEach(function (d) {
              d.apply(s, [f].concat(r));
            }),
            t.eventsListeners &&
              t.eventsListeners[f] &&
              t.eventsListeners[f].forEach(function (d) {
                d.apply(s, r);
              });
        }),
        t
      );
    },
  };
function qt() {
  var e = this,
    t,
    i,
    r = e.$el;
  typeof e.params.width < "u" && e.params.width !== null
    ? (t = e.params.width)
    : (t = r[0].clientWidth),
    typeof e.params.height < "u" && e.params.height !== null
      ? (i = e.params.height)
      : (i = r[0].clientHeight),
    !((t === 0 && e.isHorizontal()) || (i === 0 && e.isVertical())) &&
      ((t =
        t -
        parseInt(r.css("padding-left") || 0, 10) -
        parseInt(r.css("padding-right") || 0, 10)),
      (i =
        i -
        parseInt(r.css("padding-top") || 0, 10) -
        parseInt(r.css("padding-bottom") || 0, 10)),
      Number.isNaN(t) && (t = 0),
      Number.isNaN(i) && (i = 0),
      x(e, { width: t, height: i, size: e.isHorizontal() ? t : i }));
}
function Xt() {
  var e = this;
  function t(O) {
    return e.isHorizontal()
      ? O
      : {
          width: "height",
          "margin-top": "margin-left",
          "margin-bottom ": "margin-right",
          "margin-left": "margin-top",
          "margin-right": "margin-bottom",
          "padding-left": "padding-top",
          "padding-right": "padding-bottom",
          marginRight: "marginBottom",
        }[O];
  }
  function i(O, $) {
    return parseFloat(O.getPropertyValue(t($)) || 0);
  }
  var r = e.params,
    s = e.$wrapperEl,
    n = e.size,
    l = e.rtlTranslate,
    o = e.wrongRTL,
    a = e.virtual && r.virtual.enabled,
    f = a ? e.virtual.slides.length : e.slides.length,
    d = s.children("." + e.params.slideClass),
    p = a ? e.virtual.slides.length : d.length,
    u = [],
    c = [],
    m = [],
    g = r.slidesOffsetBefore;
  typeof g == "function" && (g = r.slidesOffsetBefore.call(e));
  var w = r.slidesOffsetAfter;
  typeof w == "function" && (w = r.slidesOffsetAfter.call(e));
  var E = e.snapGrid.length,
    y = e.slidesGrid.length,
    T = r.spaceBetween,
    h = -g,
    G = 0,
    A = 0;
  if (!(typeof n > "u")) {
    typeof T == "string" &&
      T.indexOf("%") >= 0 &&
      (T = (parseFloat(T.replace("%", "")) / 100) * n),
      (e.virtualSize = -T),
      l
        ? d.css({ marginLeft: "", marginBottom: "", marginTop: "" })
        : d.css({ marginRight: "", marginBottom: "", marginTop: "" });
    var z;
    r.slidesPerColumn > 1 &&
      (Math.floor(p / r.slidesPerColumn) === p / e.params.slidesPerColumn
        ? (z = p)
        : (z = Math.ceil(p / r.slidesPerColumn) * r.slidesPerColumn),
      r.slidesPerView !== "auto" &&
        r.slidesPerColumnFill === "row" &&
        (z = Math.max(z, r.slidesPerView * r.slidesPerColumn)));
    for (
      var S,
        P = r.slidesPerColumn,
        k = z / P,
        B = Math.floor(p / r.slidesPerColumn),
        M = 0;
      M < p;
      M += 1
    ) {
      S = 0;
      var b = d.eq(M);
      if (r.slidesPerColumn > 1) {
        var R = void 0,
          C = void 0,
          I = void 0;
        if (r.slidesPerColumnFill === "row" && r.slidesPerGroup > 1) {
          var N = Math.floor(M / (r.slidesPerGroup * r.slidesPerColumn)),
            W = M - r.slidesPerColumn * r.slidesPerGroup * N,
            Y =
              N === 0
                ? r.slidesPerGroup
                : Math.min(
                    Math.ceil((p - N * P * r.slidesPerGroup) / P),
                    r.slidesPerGroup
                  );
          (I = Math.floor(W / Y)),
            (C = W - I * Y + N * r.slidesPerGroup),
            (R = C + (I * z) / P),
            b.css({
              "-webkit-box-ordinal-group": R,
              "-moz-box-ordinal-group": R,
              "-ms-flex-order": R,
              "-webkit-order": R,
              order: R,
            });
        } else
          r.slidesPerColumnFill === "column"
            ? ((C = Math.floor(M / P)),
              (I = M - C * P),
              (C > B || (C === B && I === P - 1)) &&
                ((I += 1), I >= P && ((I = 0), (C += 1))))
            : ((I = Math.floor(M / k)), (C = M - I * k));
        b.css(
          t("margin-top"),
          I !== 0 ? r.spaceBetween && r.spaceBetween + "px" : ""
        );
      }
      if (b.css("display") !== "none") {
        if (r.slidesPerView === "auto") {
          var F = getComputedStyle(b[0]),
            K = b[0].style.transform,
            ee = b[0].style.webkitTransform;
          if (
            (K && (b[0].style.transform = "none"),
            ee && (b[0].style.webkitTransform = "none"),
            r.roundLengths)
          )
            S = e.isHorizontal() ? b.outerWidth(!0) : b.outerHeight(!0);
          else {
            var Te = i(F, "width"),
              Ge = i(F, "padding-left"),
              ke = i(F, "padding-right"),
              Se = i(F, "margin-left"),
              be = i(F, "margin-right"),
              Ee = F.getPropertyValue("box-sizing");
            if (Ee && Ee === "border-box") S = Te + Se + be;
            else {
              var ye = b[0],
                Be = ye.clientWidth,
                Re = ye.offsetWidth;
              S = Te + Ge + ke + Se + be + (Re - Be);
            }
          }
          K && (b[0].style.transform = K),
            ee && (b[0].style.webkitTransform = ee),
            r.roundLengths && (S = Math.floor(S));
        } else
          (S = (n - (r.slidesPerView - 1) * T) / r.slidesPerView),
            r.roundLengths && (S = Math.floor(S)),
            d[M] && (d[M].style[t("width")] = S + "px");
        d[M] && (d[M].swiperSlideSize = S),
          m.push(S),
          r.centeredSlides
            ? ((h = h + S / 2 + G / 2 + T),
              G === 0 && M !== 0 && (h = h - n / 2 - T),
              M === 0 && (h = h - n / 2 - T),
              Math.abs(h) < 1 / 1e3 && (h = 0),
              r.roundLengths && (h = Math.floor(h)),
              A % r.slidesPerGroup === 0 && u.push(h),
              c.push(h))
            : (r.roundLengths && (h = Math.floor(h)),
              (A - Math.min(e.params.slidesPerGroupSkip, A)) %
                e.params.slidesPerGroup ===
                0 && u.push(h),
              c.push(h),
              (h = h + S + T)),
          (e.virtualSize += S + T),
          (G = S),
          (A += 1);
      }
    }
    e.virtualSize = Math.max(e.virtualSize, n) + w;
    var j;
    if (
      (l &&
        o &&
        (r.effect === "slide" || r.effect === "coverflow") &&
        s.css({ width: e.virtualSize + r.spaceBetween + "px" }),
      r.setWrapperSize)
    ) {
      var te;
      s.css(
        ((te = {}),
        (te[t("width")] = e.virtualSize + r.spaceBetween + "px"),
        te)
      );
    }
    if (r.slidesPerColumn > 1) {
      var re;
      if (
        ((e.virtualSize = (S + r.spaceBetween) * z),
        (e.virtualSize =
          Math.ceil(e.virtualSize / r.slidesPerColumn) - r.spaceBetween),
        s.css(
          ((re = {}),
          (re[t("width")] = e.virtualSize + r.spaceBetween + "px"),
          re)
        ),
        r.centeredSlides)
      ) {
        j = [];
        for (var U = 0; U < u.length; U += 1) {
          var ie = u[U];
          r.roundLengths && (ie = Math.floor(ie)),
            u[U] < e.virtualSize + u[0] && j.push(ie);
        }
        u = j;
      }
    }
    if (!r.centeredSlides) {
      j = [];
      for (var J = 0; J < u.length; J += 1) {
        var se = u[J];
        r.roundLengths && (se = Math.floor(se)),
          u[J] <= e.virtualSize - n && j.push(se);
      }
      (u = j),
        Math.floor(e.virtualSize - n) - Math.floor(u[u.length - 1]) > 1 &&
          u.push(e.virtualSize - n);
    }
    if ((u.length === 0 && (u = [0]), r.spaceBetween !== 0)) {
      var ne,
        He = e.isHorizontal() && l ? "marginLeft" : t("marginRight");
      d.filter(function (O, $) {
        return r.cssMode ? $ !== d.length - 1 : !0;
      }).css(((ne = {}), (ne[He] = T + "px"), ne));
    }
    if (r.centeredSlides && r.centeredSlidesBounds) {
      var ae = 0;
      m.forEach(function (O) {
        ae += O + (r.spaceBetween ? r.spaceBetween : 0);
      }),
        (ae -= r.spaceBetween);
      var Ce = ae - n;
      u = u.map(function (O) {
        return O < 0 ? -g : O > Ce ? Ce + w : O;
      });
    }
    if (r.centerInsufficientSlides) {
      var Q = 0;
      if (
        (m.forEach(function (O) {
          Q += O + (r.spaceBetween ? r.spaceBetween : 0);
        }),
        (Q -= r.spaceBetween),
        Q < n)
      ) {
        var xe = (n - Q) / 2;
        u.forEach(function (O, $) {
          u[$] = O - xe;
        }),
          c.forEach(function (O, $) {
            c[$] = O + xe;
          });
      }
    }
    x(e, { slides: d, snapGrid: u, slidesGrid: c, slidesSizesGrid: m }),
      p !== f && e.emit("slidesLengthChange"),
      u.length !== E &&
        (e.params.watchOverflow && e.checkOverflow(),
        e.emit("snapGridLengthChange")),
      c.length !== y && e.emit("slidesGridLengthChange"),
      (r.watchSlidesProgress || r.watchSlidesVisibility) &&
        e.updateSlidesOffset();
  }
}
function Yt(e) {
  var t = this,
    i = [],
    r = t.virtual && t.params.virtual.enabled,
    s = 0,
    n;
  typeof e == "number"
    ? t.setTransition(e)
    : e === !0 && t.setTransition(t.params.speed);
  var l = function (d) {
    return r
      ? t.slides.filter(function (p) {
          return parseInt(p.getAttribute("data-swiper-slide-index"), 10) === d;
        })[0]
      : t.slides.eq(d)[0];
  };
  if (t.params.slidesPerView !== "auto" && t.params.slidesPerView > 1)
    if (t.params.centeredSlides)
      t.visibleSlides.each(function (f) {
        i.push(f);
      });
    else
      for (n = 0; n < Math.ceil(t.params.slidesPerView); n += 1) {
        var o = t.activeIndex + n;
        if (o > t.slides.length && !r) break;
        i.push(l(o));
      }
  else i.push(l(t.activeIndex));
  for (n = 0; n < i.length; n += 1)
    if (typeof i[n] < "u") {
      var a = i[n].offsetHeight;
      s = a > s ? a : s;
    }
  s && t.$wrapperEl.css("height", s + "px");
}
function Ut() {
  for (var e = this, t = e.slides, i = 0; i < t.length; i += 1)
    t[i].swiperSlideOffset = e.isHorizontal()
      ? t[i].offsetLeft
      : t[i].offsetTop;
}
function Jt(e) {
  e === void 0 && (e = (this && this.translate) || 0);
  var t = this,
    i = t.params,
    r = t.slides,
    s = t.rtlTranslate;
  if (r.length !== 0) {
    typeof r[0].swiperSlideOffset > "u" && t.updateSlidesOffset();
    var n = -e;
    s && (n = e),
      r.removeClass(i.slideVisibleClass),
      (t.visibleSlidesIndexes = []),
      (t.visibleSlides = []);
    for (var l = 0; l < r.length; l += 1) {
      var o = r[l],
        a =
          (n +
            (i.centeredSlides ? t.minTranslate() : 0) -
            o.swiperSlideOffset) /
          (o.swiperSlideSize + i.spaceBetween);
      if (i.watchSlidesVisibility || (i.centeredSlides && i.autoHeight)) {
        var f = -(n - o.swiperSlideOffset),
          d = f + t.slidesSizesGrid[l],
          p =
            (f >= 0 && f < t.size - 1) ||
            (d > 1 && d <= t.size) ||
            (f <= 0 && d >= t.size);
        p &&
          (t.visibleSlides.push(o),
          t.visibleSlidesIndexes.push(l),
          r.eq(l).addClass(i.slideVisibleClass));
      }
      o.progress = s ? -a : a;
    }
    t.visibleSlides = v(t.visibleSlides);
  }
}
function Qt(e) {
  var t = this;
  if (typeof e > "u") {
    var i = t.rtlTranslate ? -1 : 1;
    e = (t && t.translate && t.translate * i) || 0;
  }
  var r = t.params,
    s = t.maxTranslate() - t.minTranslate(),
    n = t.progress,
    l = t.isBeginning,
    o = t.isEnd,
    a = l,
    f = o;
  s === 0
    ? ((n = 0), (l = !0), (o = !0))
    : ((n = (e - t.minTranslate()) / s), (l = n <= 0), (o = n >= 1)),
    x(t, { progress: n, isBeginning: l, isEnd: o }),
    (r.watchSlidesProgress ||
      r.watchSlidesVisibility ||
      (r.centeredSlides && r.autoHeight)) &&
      t.updateSlidesProgress(e),
    l && !a && t.emit("reachBeginning toEdge"),
    o && !f && t.emit("reachEnd toEdge"),
    ((a && !l) || (f && !o)) && t.emit("fromEdge"),
    t.emit("progress", n);
}
function Zt() {
  var e = this,
    t = e.slides,
    i = e.params,
    r = e.$wrapperEl,
    s = e.activeIndex,
    n = e.realIndex,
    l = e.virtual && i.virtual.enabled;
  t.removeClass(
    i.slideActiveClass +
      " " +
      i.slideNextClass +
      " " +
      i.slidePrevClass +
      " " +
      i.slideDuplicateActiveClass +
      " " +
      i.slideDuplicateNextClass +
      " " +
      i.slideDuplicatePrevClass
  );
  var o;
  l
    ? (o = e.$wrapperEl.find(
        "." + i.slideClass + '[data-swiper-slide-index="' + s + '"]'
      ))
    : (o = t.eq(s)),
    o.addClass(i.slideActiveClass),
    i.loop &&
      (o.hasClass(i.slideDuplicateClass)
        ? r
            .children(
              "." +
                i.slideClass +
                ":not(." +
                i.slideDuplicateClass +
                ')[data-swiper-slide-index="' +
                n +
                '"]'
            )
            .addClass(i.slideDuplicateActiveClass)
        : r
            .children(
              "." +
                i.slideClass +
                "." +
                i.slideDuplicateClass +
                '[data-swiper-slide-index="' +
                n +
                '"]'
            )
            .addClass(i.slideDuplicateActiveClass));
  var a = o
    .nextAll("." + i.slideClass)
    .eq(0)
    .addClass(i.slideNextClass);
  i.loop && a.length === 0 && ((a = t.eq(0)), a.addClass(i.slideNextClass));
  var f = o
    .prevAll("." + i.slideClass)
    .eq(0)
    .addClass(i.slidePrevClass);
  i.loop && f.length === 0 && ((f = t.eq(-1)), f.addClass(i.slidePrevClass)),
    i.loop &&
      (a.hasClass(i.slideDuplicateClass)
        ? r
            .children(
              "." +
                i.slideClass +
                ":not(." +
                i.slideDuplicateClass +
                ')[data-swiper-slide-index="' +
                a.attr("data-swiper-slide-index") +
                '"]'
            )
            .addClass(i.slideDuplicateNextClass)
        : r
            .children(
              "." +
                i.slideClass +
                "." +
                i.slideDuplicateClass +
                '[data-swiper-slide-index="' +
                a.attr("data-swiper-slide-index") +
                '"]'
            )
            .addClass(i.slideDuplicateNextClass),
      f.hasClass(i.slideDuplicateClass)
        ? r
            .children(
              "." +
                i.slideClass +
                ":not(." +
                i.slideDuplicateClass +
                ')[data-swiper-slide-index="' +
                f.attr("data-swiper-slide-index") +
                '"]'
            )
            .addClass(i.slideDuplicatePrevClass)
        : r
            .children(
              "." +
                i.slideClass +
                "." +
                i.slideDuplicateClass +
                '[data-swiper-slide-index="' +
                f.attr("data-swiper-slide-index") +
                '"]'
            )
            .addClass(i.slideDuplicatePrevClass)),
    e.emitSlidesClasses();
}
function _t(e) {
  var t = this,
    i = t.rtlTranslate ? t.translate : -t.translate,
    r = t.slidesGrid,
    s = t.snapGrid,
    n = t.params,
    l = t.activeIndex,
    o = t.realIndex,
    a = t.snapIndex,
    f = e,
    d;
  if (typeof f > "u") {
    for (var p = 0; p < r.length; p += 1)
      typeof r[p + 1] < "u"
        ? i >= r[p] && i < r[p + 1] - (r[p + 1] - r[p]) / 2
          ? (f = p)
          : i >= r[p] && i < r[p + 1] && (f = p + 1)
        : i >= r[p] && (f = p);
    n.normalizeSlideIndex && (f < 0 || typeof f > "u") && (f = 0);
  }
  if (s.indexOf(i) >= 0) d = s.indexOf(i);
  else {
    var u = Math.min(n.slidesPerGroupSkip, f);
    d = u + Math.floor((f - u) / n.slidesPerGroup);
  }
  if ((d >= s.length && (d = s.length - 1), f === l)) {
    d !== a && ((t.snapIndex = d), t.emit("snapIndexChange"));
    return;
  }
  var c = parseInt(t.slides.eq(f).attr("data-swiper-slide-index") || f, 10);
  x(t, { snapIndex: d, realIndex: c, previousIndex: l, activeIndex: f }),
    t.emit("activeIndexChange"),
    t.emit("snapIndexChange"),
    o !== c && t.emit("realIndexChange"),
    (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange");
}
function Kt(e) {
  var t = this,
    i = t.params,
    r = v(e.target).closest("." + i.slideClass)[0],
    s = !1,
    n;
  if (r) {
    for (var l = 0; l < t.slides.length; l += 1)
      if (t.slides[l] === r) {
        (s = !0), (n = l);
        break;
      }
  }
  if (r && s)
    (t.clickedSlide = r),
      t.virtual && t.params.virtual.enabled
        ? (t.clickedIndex = parseInt(v(r).attr("data-swiper-slide-index"), 10))
        : (t.clickedIndex = n);
  else {
    (t.clickedSlide = void 0), (t.clickedIndex = void 0);
    return;
  }
  i.slideToClickedSlide &&
    t.clickedIndex !== void 0 &&
    t.clickedIndex !== t.activeIndex &&
    t.slideToClickedSlide();
}
const er = {
  updateSize: qt,
  updateSlides: Xt,
  updateAutoHeight: Yt,
  updateSlidesOffset: Ut,
  updateSlidesProgress: Jt,
  updateProgress: Qt,
  updateSlidesClasses: Zt,
  updateActiveIndex: _t,
  updateClickedSlide: Kt,
};
function tr(e) {
  e === void 0 && (e = this.isHorizontal() ? "x" : "y");
  var t = this,
    i = t.params,
    r = t.rtlTranslate,
    s = t.translate,
    n = t.$wrapperEl;
  if (i.virtualTranslate) return r ? -s : s;
  if (i.cssMode) return s;
  var l = It(n[0], e);
  return r && (l = -l), l || 0;
}
function rr(e, t) {
  var i = this,
    r = i.rtlTranslate,
    s = i.params,
    n = i.$wrapperEl,
    l = i.wrapperEl,
    o = i.progress,
    a = 0,
    f = 0,
    d = 0;
  i.isHorizontal() ? (a = r ? -e : e) : (f = e),
    s.roundLengths && ((a = Math.floor(a)), (f = Math.floor(f))),
    s.cssMode
      ? (l[i.isHorizontal() ? "scrollLeft" : "scrollTop"] = i.isHorizontal()
          ? -a
          : -f)
      : s.virtualTranslate ||
        n.transform("translate3d(" + a + "px, " + f + "px, " + d + "px)"),
    (i.previousTranslate = i.translate),
    (i.translate = i.isHorizontal() ? a : f);
  var p,
    u = i.maxTranslate() - i.minTranslate();
  u === 0 ? (p = 0) : (p = (e - i.minTranslate()) / u),
    p !== o && i.updateProgress(e),
    i.emit("setTranslate", i.translate, t);
}
function ir() {
  return -this.snapGrid[0];
}
function sr() {
  return -this.snapGrid[this.snapGrid.length - 1];
}
function nr(e, t, i, r, s) {
  e === void 0 && (e = 0),
    t === void 0 && (t = this.params.speed),
    i === void 0 && (i = !0),
    r === void 0 && (r = !0);
  var n = this,
    l = n.params,
    o = n.wrapperEl;
  if (n.animating && l.preventInteractionOnTransition) return !1;
  var a = n.minTranslate(),
    f = n.maxTranslate(),
    d;
  if (
    (r && e > a ? (d = a) : r && e < f ? (d = f) : (d = e),
    n.updateProgress(d),
    l.cssMode)
  ) {
    var p = n.isHorizontal();
    if (t === 0) o[p ? "scrollLeft" : "scrollTop"] = -d;
    else if (o.scrollTo) {
      var u;
      o.scrollTo(
        ((u = {}), (u[p ? "left" : "top"] = -d), (u.behavior = "smooth"), u)
      );
    } else o[p ? "scrollLeft" : "scrollTop"] = -d;
    return !0;
  }
  return (
    t === 0
      ? (n.setTransition(0),
        n.setTranslate(d),
        i && (n.emit("beforeTransitionStart", t, s), n.emit("transitionEnd")))
      : (n.setTransition(t),
        n.setTranslate(d),
        i && (n.emit("beforeTransitionStart", t, s), n.emit("transitionStart")),
        n.animating ||
          ((n.animating = !0),
          n.onTranslateToWrapperTransitionEnd ||
            (n.onTranslateToWrapperTransitionEnd = function (m) {
              !n ||
                n.destroyed ||
                (m.target === this &&
                  (n.$wrapperEl[0].removeEventListener(
                    "transitionend",
                    n.onTranslateToWrapperTransitionEnd
                  ),
                  n.$wrapperEl[0].removeEventListener(
                    "webkitTransitionEnd",
                    n.onTranslateToWrapperTransitionEnd
                  ),
                  (n.onTranslateToWrapperTransitionEnd = null),
                  delete n.onTranslateToWrapperTransitionEnd,
                  i && n.emit("transitionEnd")));
            }),
          n.$wrapperEl[0].addEventListener(
            "transitionend",
            n.onTranslateToWrapperTransitionEnd
          ),
          n.$wrapperEl[0].addEventListener(
            "webkitTransitionEnd",
            n.onTranslateToWrapperTransitionEnd
          ))),
    !0
  );
}
const ar = {
  getTranslate: tr,
  setTranslate: rr,
  minTranslate: ir,
  maxTranslate: sr,
  translateTo: nr,
};
function or(e, t) {
  var i = this;
  i.params.cssMode || i.$wrapperEl.transition(e), i.emit("setTransition", e, t);
}
function lr(e, t) {
  e === void 0 && (e = !0);
  var i = this,
    r = i.activeIndex,
    s = i.params,
    n = i.previousIndex;
  if (!s.cssMode) {
    s.autoHeight && i.updateAutoHeight();
    var l = t;
    if (
      (l || (r > n ? (l = "next") : r < n ? (l = "prev") : (l = "reset")),
      i.emit("transitionStart"),
      e && r !== n)
    ) {
      if (l === "reset") {
        i.emit("slideResetTransitionStart");
        return;
      }
      i.emit("slideChangeTransitionStart"),
        l === "next"
          ? i.emit("slideNextTransitionStart")
          : i.emit("slidePrevTransitionStart");
    }
  }
}
function fr(e, t) {
  e === void 0 && (e = !0);
  var i = this,
    r = i.activeIndex,
    s = i.previousIndex,
    n = i.params;
  if (((i.animating = !1), !n.cssMode)) {
    i.setTransition(0);
    var l = t;
    if (
      (l || (r > s ? (l = "next") : r < s ? (l = "prev") : (l = "reset")),
      i.emit("transitionEnd"),
      e && r !== s)
    ) {
      if (l === "reset") {
        i.emit("slideResetTransitionEnd");
        return;
      }
      i.emit("slideChangeTransitionEnd"),
        l === "next"
          ? i.emit("slideNextTransitionEnd")
          : i.emit("slidePrevTransitionEnd");
    }
  }
}
const dr = { setTransition: or, transitionStart: lr, transitionEnd: fr };
function ur(e, t, i, r, s) {
  if (
    (e === void 0 && (e = 0),
    t === void 0 && (t = this.params.speed),
    i === void 0 && (i = !0),
    typeof e != "number" && typeof e != "string")
  )
    throw new Error(
      "The 'index' argument cannot have type other than 'number' or 'string'. [" +
        typeof e +
        "] given."
    );
  if (typeof e == "string") {
    var n = parseInt(e, 10),
      l = isFinite(n);
    if (!l)
      throw new Error(
        "The passed-in 'index' (string) couldn't be converted to 'number'. [" +
          e +
          "] given."
      );
    e = n;
  }
  var o = this,
    a = e;
  a < 0 && (a = 0);
  var f = o.params,
    d = o.snapGrid,
    p = o.slidesGrid,
    u = o.previousIndex,
    c = o.activeIndex,
    m = o.rtlTranslate,
    g = o.wrapperEl,
    w = o.enabled;
  if ((o.animating && f.preventInteractionOnTransition) || (!w && !r && !s))
    return !1;
  var E = Math.min(o.params.slidesPerGroupSkip, a),
    y = E + Math.floor((a - E) / o.params.slidesPerGroup);
  y >= d.length && (y = d.length - 1),
    (c || f.initialSlide || 0) === (u || 0) &&
      i &&
      o.emit("beforeSlideChangeStart");
  var T = -d[y];
  if ((o.updateProgress(T), f.normalizeSlideIndex))
    for (var h = 0; h < p.length; h += 1) {
      var G = -Math.floor(T * 100),
        A = Math.floor(p[h] * 100),
        z = Math.floor(p[h + 1] * 100);
      typeof p[h + 1] < "u"
        ? G >= A && G < z - (z - A) / 2
          ? (a = h)
          : G >= A && G < z && (a = h + 1)
        : G >= A && (a = h);
    }
  if (
    o.initialized &&
    a !== c &&
    ((!o.allowSlideNext && T < o.translate && T < o.minTranslate()) ||
      (!o.allowSlidePrev &&
        T > o.translate &&
        T > o.maxTranslate() &&
        (c || 0) !== a))
  )
    return !1;
  var S;
  if (
    (a > c ? (S = "next") : a < c ? (S = "prev") : (S = "reset"),
    (m && -T === o.translate) || (!m && T === o.translate))
  )
    return (
      o.updateActiveIndex(a),
      f.autoHeight && o.updateAutoHeight(),
      o.updateSlidesClasses(),
      f.effect !== "slide" && o.setTranslate(T),
      S !== "reset" && (o.transitionStart(i, S), o.transitionEnd(i, S)),
      !1
    );
  if (f.cssMode) {
    var P = o.isHorizontal(),
      k = -T;
    if ((m && (k = g.scrollWidth - g.offsetWidth - k), t === 0))
      g[P ? "scrollLeft" : "scrollTop"] = k;
    else if (g.scrollTo) {
      var B;
      g.scrollTo(
        ((B = {}), (B[P ? "left" : "top"] = k), (B.behavior = "smooth"), B)
      );
    } else g[P ? "scrollLeft" : "scrollTop"] = k;
    return !0;
  }
  return (
    t === 0
      ? (o.setTransition(0),
        o.setTranslate(T),
        o.updateActiveIndex(a),
        o.updateSlidesClasses(),
        o.emit("beforeTransitionStart", t, r),
        o.transitionStart(i, S),
        o.transitionEnd(i, S))
      : (o.setTransition(t),
        o.setTranslate(T),
        o.updateActiveIndex(a),
        o.updateSlidesClasses(),
        o.emit("beforeTransitionStart", t, r),
        o.transitionStart(i, S),
        o.animating ||
          ((o.animating = !0),
          o.onSlideToWrapperTransitionEnd ||
            (o.onSlideToWrapperTransitionEnd = function (b) {
              !o ||
                o.destroyed ||
                (b.target === this &&
                  (o.$wrapperEl[0].removeEventListener(
                    "transitionend",
                    o.onSlideToWrapperTransitionEnd
                  ),
                  o.$wrapperEl[0].removeEventListener(
                    "webkitTransitionEnd",
                    o.onSlideToWrapperTransitionEnd
                  ),
                  (o.onSlideToWrapperTransitionEnd = null),
                  delete o.onSlideToWrapperTransitionEnd,
                  o.transitionEnd(i, S)));
            }),
          o.$wrapperEl[0].addEventListener(
            "transitionend",
            o.onSlideToWrapperTransitionEnd
          ),
          o.$wrapperEl[0].addEventListener(
            "webkitTransitionEnd",
            o.onSlideToWrapperTransitionEnd
          ))),
    !0
  );
}
function pr(e, t, i, r) {
  e === void 0 && (e = 0),
    t === void 0 && (t = this.params.speed),
    i === void 0 && (i = !0);
  var s = this,
    n = e;
  return s.params.loop && (n += s.loopedSlides), s.slideTo(n, t, i, r);
}
function cr(e, t, i) {
  e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
  var r = this,
    s = r.params,
    n = r.animating,
    l = r.enabled;
  if (!l) return r;
  var o = r.activeIndex < s.slidesPerGroupSkip ? 1 : s.slidesPerGroup;
  if (s.loop) {
    if (n && s.loopPreventsSlide) return !1;
    r.loopFix(), (r._clientLeft = r.$wrapperEl[0].clientLeft);
  }
  return r.slideTo(r.activeIndex + o, e, t, i);
}
function vr(e, t, i) {
  e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
  var r = this,
    s = r.params,
    n = r.animating,
    l = r.snapGrid,
    o = r.slidesGrid,
    a = r.rtlTranslate,
    f = r.enabled;
  if (!f) return r;
  if (s.loop) {
    if (n && s.loopPreventsSlide) return !1;
    r.loopFix(), (r._clientLeft = r.$wrapperEl[0].clientLeft);
  }
  var d = a ? r.translate : -r.translate;
  function p(w) {
    return w < 0 ? -Math.floor(Math.abs(w)) : Math.floor(w);
  }
  var u = p(d),
    c = l.map(function (w) {
      return p(w);
    }),
    m = l[c.indexOf(u) - 1];
  typeof m > "u" &&
    s.cssMode &&
    l.forEach(function (w) {
      !m && u >= w && (m = w);
    });
  var g;
  return (
    typeof m < "u" && ((g = o.indexOf(m)), g < 0 && (g = r.activeIndex - 1)),
    r.slideTo(g, e, t, i)
  );
}
function hr(e, t, i) {
  e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
  var r = this;
  return r.slideTo(r.activeIndex, e, t, i);
}
function mr(e, t, i, r) {
  e === void 0 && (e = this.params.speed),
    t === void 0 && (t = !0),
    r === void 0 && (r = 0.5);
  var s = this,
    n = s.activeIndex,
    l = Math.min(s.params.slidesPerGroupSkip, n),
    o = l + Math.floor((n - l) / s.params.slidesPerGroup),
    a = s.rtlTranslate ? s.translate : -s.translate;
  if (a >= s.snapGrid[o]) {
    var f = s.snapGrid[o],
      d = s.snapGrid[o + 1];
    a - f > (d - f) * r && (n += s.params.slidesPerGroup);
  } else {
    var p = s.snapGrid[o - 1],
      u = s.snapGrid[o];
    a - p <= (u - p) * r && (n -= s.params.slidesPerGroup);
  }
  return (
    (n = Math.max(n, 0)),
    (n = Math.min(n, s.slidesGrid.length - 1)),
    s.slideTo(n, e, t, i)
  );
}
function gr() {
  var e = this,
    t = e.params,
    i = e.$wrapperEl,
    r = t.slidesPerView === "auto" ? e.slidesPerViewDynamic() : t.slidesPerView,
    s = e.clickedIndex,
    n;
  if (t.loop) {
    if (e.animating) return;
    (n = parseInt(v(e.clickedSlide).attr("data-swiper-slide-index"), 10)),
      t.centeredSlides
        ? s < e.loopedSlides - r / 2 ||
          s > e.slides.length - e.loopedSlides + r / 2
          ? (e.loopFix(),
            (s = i
              .children(
                "." +
                  t.slideClass +
                  '[data-swiper-slide-index="' +
                  n +
                  '"]:not(.' +
                  t.slideDuplicateClass +
                  ")"
              )
              .eq(0)
              .index()),
            ve(function () {
              e.slideTo(s);
            }))
          : e.slideTo(s)
        : s > e.slides.length - r
        ? (e.loopFix(),
          (s = i
            .children(
              "." +
                t.slideClass +
                '[data-swiper-slide-index="' +
                n +
                '"]:not(.' +
                t.slideDuplicateClass +
                ")"
            )
            .eq(0)
            .index()),
          ve(function () {
            e.slideTo(s);
          }))
        : e.slideTo(s);
  } else e.slideTo(s);
}
const wr = {
  slideTo: ur,
  slideToLoop: pr,
  slideNext: cr,
  slidePrev: vr,
  slideReset: hr,
  slideToClosest: mr,
  slideToClickedSlide: gr,
};
function Tr() {
  var e = this,
    t = D(),
    i = e.params,
    r = e.$wrapperEl;
  r.children("." + i.slideClass + "." + i.slideDuplicateClass).remove();
  var s = r.children("." + i.slideClass);
  if (i.loopFillGroupWithBlank) {
    var n = i.slidesPerGroup - (s.length % i.slidesPerGroup);
    if (n !== i.slidesPerGroup) {
      for (var l = 0; l < n; l += 1) {
        var o = v(t.createElement("div")).addClass(
          i.slideClass + " " + i.slideBlankClass
        );
        r.append(o);
      }
      s = r.children("." + i.slideClass);
    }
  }
  i.slidesPerView === "auto" && !i.loopedSlides && (i.loopedSlides = s.length),
    (e.loopedSlides = Math.ceil(
      parseFloat(i.loopedSlides || i.slidesPerView, 10)
    )),
    (e.loopedSlides += i.loopAdditionalSlides),
    e.loopedSlides > s.length && (e.loopedSlides = s.length);
  var a = [],
    f = [];
  s.each(function (u, c) {
    var m = v(u);
    c < e.loopedSlides && f.push(u),
      c < s.length && c >= s.length - e.loopedSlides && a.push(u),
      m.attr("data-swiper-slide-index", c);
  });
  for (var d = 0; d < f.length; d += 1)
    r.append(v(f[d].cloneNode(!0)).addClass(i.slideDuplicateClass));
  for (var p = a.length - 1; p >= 0; p -= 1)
    r.prepend(v(a[p].cloneNode(!0)).addClass(i.slideDuplicateClass));
}
function Sr() {
  var e = this;
  e.emit("beforeLoopFix");
  var t = e.activeIndex,
    i = e.slides,
    r = e.loopedSlides,
    s = e.allowSlidePrev,
    n = e.allowSlideNext,
    l = e.snapGrid,
    o = e.rtlTranslate,
    a;
  (e.allowSlidePrev = !0), (e.allowSlideNext = !0);
  var f = -l[t],
    d = f - e.getTranslate();
  if (t < r) {
    (a = i.length - r * 3 + t), (a += r);
    var p = e.slideTo(a, 0, !1, !0);
    p && d !== 0 && e.setTranslate((o ? -e.translate : e.translate) - d);
  } else if (t >= i.length - r) {
    (a = -i.length + t + r), (a += r);
    var u = e.slideTo(a, 0, !1, !0);
    u && d !== 0 && e.setTranslate((o ? -e.translate : e.translate) - d);
  }
  (e.allowSlidePrev = s), (e.allowSlideNext = n), e.emit("loopFix");
}
function br() {
  var e = this,
    t = e.$wrapperEl,
    i = e.params,
    r = e.slides;
  t
    .children(
      "." +
        i.slideClass +
        "." +
        i.slideDuplicateClass +
        ",." +
        i.slideClass +
        "." +
        i.slideBlankClass
    )
    .remove(),
    r.removeAttr("data-swiper-slide-index");
}
const Er = { loopCreate: Tr, loopFix: Sr, loopDestroy: br };
function yr(e) {
  var t = this;
  if (
    !(
      t.support.touch ||
      !t.params.simulateTouch ||
      (t.params.watchOverflow && t.isLocked) ||
      t.params.cssMode
    )
  ) {
    var i = t.el;
    (i.style.cursor = "move"),
      (i.style.cursor = e ? "-webkit-grabbing" : "-webkit-grab"),
      (i.style.cursor = e ? "-moz-grabbin" : "-moz-grab"),
      (i.style.cursor = e ? "grabbing" : "grab");
  }
}
function Cr() {
  var e = this;
  e.support.touch ||
    (e.params.watchOverflow && e.isLocked) ||
    e.params.cssMode ||
    (e.el.style.cursor = "");
}
const xr = { setGrabCursor: yr, unsetGrabCursor: Cr };
function Mr(e) {
  var t = this,
    i = t.$wrapperEl,
    r = t.params;
  if ((r.loop && t.loopDestroy(), typeof e == "object" && "length" in e))
    for (var s = 0; s < e.length; s += 1) e[s] && i.append(e[s]);
  else i.append(e);
  r.loop && t.loopCreate(), (r.observer && t.support.observer) || t.update();
}
function Lr(e) {
  var t = this,
    i = t.params,
    r = t.$wrapperEl,
    s = t.activeIndex;
  i.loop && t.loopDestroy();
  var n = s + 1;
  if (typeof e == "object" && "length" in e) {
    for (var l = 0; l < e.length; l += 1) e[l] && r.prepend(e[l]);
    n = s + e.length;
  } else r.prepend(e);
  i.loop && t.loopCreate(),
    (i.observer && t.support.observer) || t.update(),
    t.slideTo(n, 0, !1);
}
function Pr(e, t) {
  var i = this,
    r = i.$wrapperEl,
    s = i.params,
    n = i.activeIndex,
    l = n;
  s.loop &&
    ((l -= i.loopedSlides),
    i.loopDestroy(),
    (i.slides = r.children("." + s.slideClass)));
  var o = i.slides.length;
  if (e <= 0) {
    i.prependSlide(t);
    return;
  }
  if (e >= o) {
    i.appendSlide(t);
    return;
  }
  for (var a = l > e ? l + 1 : l, f = [], d = o - 1; d >= e; d -= 1) {
    var p = i.slides.eq(d);
    p.remove(), f.unshift(p);
  }
  if (typeof t == "object" && "length" in t) {
    for (var u = 0; u < t.length; u += 1) t[u] && r.append(t[u]);
    a = l > e ? l + t.length : l;
  } else r.append(t);
  for (var c = 0; c < f.length; c += 1) r.append(f[c]);
  s.loop && i.loopCreate(),
    (s.observer && i.support.observer) || i.update(),
    s.loop ? i.slideTo(a + i.loopedSlides, 0, !1) : i.slideTo(a, 0, !1);
}
function Or(e) {
  var t = this,
    i = t.params,
    r = t.$wrapperEl,
    s = t.activeIndex,
    n = s;
  i.loop &&
    ((n -= t.loopedSlides),
    t.loopDestroy(),
    (t.slides = r.children("." + i.slideClass)));
  var l = n,
    o;
  if (typeof e == "object" && "length" in e) {
    for (var a = 0; a < e.length; a += 1)
      (o = e[a]), t.slides[o] && t.slides.eq(o).remove(), o < l && (l -= 1);
    l = Math.max(l, 0);
  } else
    (o = e),
      t.slides[o] && t.slides.eq(o).remove(),
      o < l && (l -= 1),
      (l = Math.max(l, 0));
  i.loop && t.loopCreate(),
    (i.observer && t.support.observer) || t.update(),
    i.loop ? t.slideTo(l + t.loopedSlides, 0, !1) : t.slideTo(l, 0, !1);
}
function zr() {
  for (var e = this, t = [], i = 0; i < e.slides.length; i += 1) t.push(i);
  e.removeSlide(t);
}
const Ir = {
  appendSlide: Mr,
  prependSlide: Lr,
  addSlide: Pr,
  removeSlide: Or,
  removeAllSlides: zr,
};
function Ar(e, t) {
  t === void 0 && (t = this);
  function i(r) {
    if (!r || r === D() || r === L()) return null;
    r.assignedSlot && (r = r.assignedSlot);
    var s = r.closest(e);
    return s || i(r.getRootNode().host);
  }
  return i(t);
}
function Dr(e) {
  var t = this,
    i = D(),
    r = L(),
    s = t.touchEventsData,
    n = t.params,
    l = t.touches,
    o = t.enabled;
  if (o && !(t.animating && n.preventInteractionOnTransition)) {
    var a = e;
    a.originalEvent && (a = a.originalEvent);
    var f = v(a.target);
    if (
      !(n.touchEventsTarget === "wrapper" && !f.closest(t.wrapperEl).length) &&
      ((s.isTouchEvent = a.type === "touchstart"),
      !(!s.isTouchEvent && "which" in a && a.which === 3) &&
        !(!s.isTouchEvent && "button" in a && a.button > 0) &&
        !(s.isTouched && s.isMoved))
    ) {
      var d = !!n.noSwipingClass && n.noSwipingClass !== "";
      d &&
        a.target &&
        a.target.shadowRoot &&
        e.path &&
        e.path[0] &&
        (f = v(e.path[0]));
      var p = n.noSwipingSelector
          ? n.noSwipingSelector
          : "." + n.noSwipingClass,
        u = !!(a.target && a.target.shadowRoot);
      if (n.noSwiping && (u ? Ar(p, a.target) : f.closest(p)[0])) {
        t.allowClick = !0;
        return;
      }
      if (!(n.swipeHandler && !f.closest(n.swipeHandler)[0])) {
        (l.currentX =
          a.type === "touchstart" ? a.targetTouches[0].pageX : a.pageX),
          (l.currentY =
            a.type === "touchstart" ? a.targetTouches[0].pageY : a.pageY);
        var c = l.currentX,
          m = l.currentY,
          g = n.edgeSwipeDetection || n.iOSEdgeSwipeDetection,
          w = n.edgeSwipeThreshold || n.iOSEdgeSwipeThreshold;
        if (g && (c <= w || c >= r.innerWidth - w))
          if (g === "prevent") e.preventDefault();
          else return;
        if (
          (x(s, {
            isTouched: !0,
            isMoved: !1,
            allowTouchCallbacks: !0,
            isScrolling: void 0,
            startMoving: void 0,
          }),
          (l.startX = c),
          (l.startY = m),
          (s.touchStartTime = V()),
          (t.allowClick = !0),
          t.updateSize(),
          (t.swipeDirection = void 0),
          n.threshold > 0 && (s.allowThresholdMove = !1),
          a.type !== "touchstart")
        ) {
          var E = !0;
          f.is(s.focusableElements) && (E = !1),
            i.activeElement &&
              v(i.activeElement).is(s.focusableElements) &&
              i.activeElement !== f[0] &&
              i.activeElement.blur();
          var y = E && t.allowTouchMove && n.touchStartPreventDefault;
          (n.touchStartForcePreventDefault || y) &&
            !f[0].isContentEditable &&
            a.preventDefault();
        }
        t.emit("touchStart", a);
      }
    }
  }
}
function Gr(e) {
  var t = D(),
    i = this,
    r = i.touchEventsData,
    s = i.params,
    n = i.touches,
    l = i.rtlTranslate,
    o = i.enabled;
  if (o) {
    var a = e;
    if ((a.originalEvent && (a = a.originalEvent), !r.isTouched)) {
      r.startMoving && r.isScrolling && i.emit("touchMoveOpposite", a);
      return;
    }
    if (!(r.isTouchEvent && a.type !== "touchmove")) {
      var f =
          a.type === "touchmove" &&
          a.targetTouches &&
          (a.targetTouches[0] || a.changedTouches[0]),
        d = a.type === "touchmove" ? f.pageX : a.pageX,
        p = a.type === "touchmove" ? f.pageY : a.pageY;
      if (a.preventedByNestedSwiper) {
        (n.startX = d), (n.startY = p);
        return;
      }
      if (!i.allowTouchMove) {
        (i.allowClick = !1),
          r.isTouched &&
            (x(n, { startX: d, startY: p, currentX: d, currentY: p }),
            (r.touchStartTime = V()));
        return;
      }
      if (r.isTouchEvent && s.touchReleaseOnEdges && !s.loop) {
        if (i.isVertical()) {
          if (
            (p < n.startY && i.translate <= i.maxTranslate()) ||
            (p > n.startY && i.translate >= i.minTranslate())
          ) {
            (r.isTouched = !1), (r.isMoved = !1);
            return;
          }
        } else if (
          (d < n.startX && i.translate <= i.maxTranslate()) ||
          (d > n.startX && i.translate >= i.minTranslate())
        )
          return;
      }
      if (
        r.isTouchEvent &&
        t.activeElement &&
        a.target === t.activeElement &&
        v(a.target).is(r.focusableElements)
      ) {
        (r.isMoved = !0), (i.allowClick = !1);
        return;
      }
      if (
        (r.allowTouchCallbacks && i.emit("touchMove", a),
        !(a.targetTouches && a.targetTouches.length > 1))
      ) {
        (n.currentX = d), (n.currentY = p);
        var u = n.currentX - n.startX,
          c = n.currentY - n.startY;
        if (
          !(
            i.params.threshold &&
            Math.sqrt(Math.pow(u, 2) + Math.pow(c, 2)) < i.params.threshold
          )
        ) {
          if (typeof r.isScrolling > "u") {
            var m;
            (i.isHorizontal() && n.currentY === n.startY) ||
            (i.isVertical() && n.currentX === n.startX)
              ? (r.isScrolling = !1)
              : u * u + c * c >= 25 &&
                ((m = (Math.atan2(Math.abs(c), Math.abs(u)) * 180) / Math.PI),
                (r.isScrolling = i.isHorizontal()
                  ? m > s.touchAngle
                  : 90 - m > s.touchAngle));
          }
          if (
            (r.isScrolling && i.emit("touchMoveOpposite", a),
            typeof r.startMoving > "u" &&
              (n.currentX !== n.startX || n.currentY !== n.startY) &&
              (r.startMoving = !0),
            r.isScrolling)
          ) {
            r.isTouched = !1;
            return;
          }
          if (r.startMoving) {
            (i.allowClick = !1),
              !s.cssMode && a.cancelable && a.preventDefault(),
              s.touchMoveStopPropagation && !s.nested && a.stopPropagation(),
              r.isMoved ||
                (s.loop && i.loopFix(),
                (r.startTranslate = i.getTranslate()),
                i.setTransition(0),
                i.animating &&
                  i.$wrapperEl.trigger("webkitTransitionEnd transitionend"),
                (r.allowMomentumBounce = !1),
                s.grabCursor &&
                  (i.allowSlideNext === !0 || i.allowSlidePrev === !0) &&
                  i.setGrabCursor(!0),
                i.emit("sliderFirstMove", a)),
              i.emit("sliderMove", a),
              (r.isMoved = !0);
            var g = i.isHorizontal() ? u : c;
            (n.diff = g),
              (g *= s.touchRatio),
              l && (g = -g),
              (i.swipeDirection = g > 0 ? "prev" : "next"),
              (r.currentTranslate = g + r.startTranslate);
            var w = !0,
              E = s.resistanceRatio;
            if (
              (s.touchReleaseOnEdges && (E = 0),
              g > 0 && r.currentTranslate > i.minTranslate()
                ? ((w = !1),
                  s.resistance &&
                    (r.currentTranslate =
                      i.minTranslate() -
                      1 +
                      Math.pow(-i.minTranslate() + r.startTranslate + g, E)))
                : g < 0 &&
                  r.currentTranslate < i.maxTranslate() &&
                  ((w = !1),
                  s.resistance &&
                    (r.currentTranslate =
                      i.maxTranslate() +
                      1 -
                      Math.pow(i.maxTranslate() - r.startTranslate - g, E))),
              w && (a.preventedByNestedSwiper = !0),
              !i.allowSlideNext &&
                i.swipeDirection === "next" &&
                r.currentTranslate < r.startTranslate &&
                (r.currentTranslate = r.startTranslate),
              !i.allowSlidePrev &&
                i.swipeDirection === "prev" &&
                r.currentTranslate > r.startTranslate &&
                (r.currentTranslate = r.startTranslate),
              !i.allowSlidePrev &&
                !i.allowSlideNext &&
                (r.currentTranslate = r.startTranslate),
              s.threshold > 0)
            )
              if (Math.abs(g) > s.threshold || r.allowThresholdMove) {
                if (!r.allowThresholdMove) {
                  (r.allowThresholdMove = !0),
                    (n.startX = n.currentX),
                    (n.startY = n.currentY),
                    (r.currentTranslate = r.startTranslate),
                    (n.diff = i.isHorizontal()
                      ? n.currentX - n.startX
                      : n.currentY - n.startY);
                  return;
                }
              } else {
                r.currentTranslate = r.startTranslate;
                return;
              }
            !s.followFinger ||
              s.cssMode ||
              ((s.freeMode ||
                s.watchSlidesProgress ||
                s.watchSlidesVisibility) &&
                (i.updateActiveIndex(), i.updateSlidesClasses()),
              s.freeMode &&
                (r.velocities.length === 0 &&
                  r.velocities.push({
                    position: n[i.isHorizontal() ? "startX" : "startY"],
                    time: r.touchStartTime,
                  }),
                r.velocities.push({
                  position: n[i.isHorizontal() ? "currentX" : "currentY"],
                  time: V(),
                })),
              i.updateProgress(r.currentTranslate),
              i.setTranslate(r.currentTranslate));
          }
        }
      }
    }
  }
}
function kr(e) {
  var t = this,
    i = t.touchEventsData,
    r = t.params,
    s = t.touches,
    n = t.rtlTranslate,
    l = t.$wrapperEl,
    o = t.slidesGrid,
    a = t.snapGrid,
    f = t.enabled;
  if (f) {
    var d = e;
    if (
      (d.originalEvent && (d = d.originalEvent),
      i.allowTouchCallbacks && t.emit("touchEnd", d),
      (i.allowTouchCallbacks = !1),
      !i.isTouched)
    ) {
      i.isMoved && r.grabCursor && t.setGrabCursor(!1),
        (i.isMoved = !1),
        (i.startMoving = !1);
      return;
    }
    r.grabCursor &&
      i.isMoved &&
      i.isTouched &&
      (t.allowSlideNext === !0 || t.allowSlidePrev === !0) &&
      t.setGrabCursor(!1);
    var p = V(),
      u = p - i.touchStartTime;
    if (
      (t.allowClick &&
        (t.updateClickedSlide(d),
        t.emit("tap click", d),
        u < 300 &&
          p - i.lastClickTime < 300 &&
          t.emit("doubleTap doubleClick", d)),
      (i.lastClickTime = V()),
      ve(function () {
        t.destroyed || (t.allowClick = !0);
      }),
      !i.isTouched ||
        !i.isMoved ||
        !t.swipeDirection ||
        s.diff === 0 ||
        i.currentTranslate === i.startTranslate)
    ) {
      (i.isTouched = !1), (i.isMoved = !1), (i.startMoving = !1);
      return;
    }
    (i.isTouched = !1), (i.isMoved = !1), (i.startMoving = !1);
    var c;
    if (
      (r.followFinger
        ? (c = n ? t.translate : -t.translate)
        : (c = -i.currentTranslate),
      !r.cssMode)
    ) {
      if (r.freeMode) {
        if (c < -t.minTranslate()) {
          t.slideTo(t.activeIndex);
          return;
        }
        if (c > -t.maxTranslate()) {
          t.slides.length < a.length
            ? t.slideTo(a.length - 1)
            : t.slideTo(t.slides.length - 1);
          return;
        }
        if (r.freeModeMomentum) {
          if (i.velocities.length > 1) {
            var m = i.velocities.pop(),
              g = i.velocities.pop(),
              w = m.position - g.position,
              E = m.time - g.time;
            (t.velocity = w / E),
              (t.velocity /= 2),
              Math.abs(t.velocity) < r.freeModeMinimumVelocity &&
                (t.velocity = 0),
              (E > 150 || V() - m.time > 300) && (t.velocity = 0);
          } else t.velocity = 0;
          (t.velocity *= r.freeModeMomentumVelocityRatio),
            (i.velocities.length = 0);
          var y = 1e3 * r.freeModeMomentumRatio,
            T = t.velocity * y,
            h = t.translate + T;
          n && (h = -h);
          var G = !1,
            A,
            z = Math.abs(t.velocity) * 20 * r.freeModeMomentumBounceRatio,
            S;
          if (h < t.maxTranslate())
            r.freeModeMomentumBounce
              ? (h + t.maxTranslate() < -z && (h = t.maxTranslate() - z),
                (A = t.maxTranslate()),
                (G = !0),
                (i.allowMomentumBounce = !0))
              : (h = t.maxTranslate()),
              r.loop && r.centeredSlides && (S = !0);
          else if (h > t.minTranslate())
            r.freeModeMomentumBounce
              ? (h - t.minTranslate() > z && (h = t.minTranslate() + z),
                (A = t.minTranslate()),
                (G = !0),
                (i.allowMomentumBounce = !0))
              : (h = t.minTranslate()),
              r.loop && r.centeredSlides && (S = !0);
          else if (r.freeModeSticky) {
            for (var P, k = 0; k < a.length; k += 1)
              if (a[k] > -h) {
                P = k;
                break;
              }
            Math.abs(a[P] - h) < Math.abs(a[P - 1] - h) ||
            t.swipeDirection === "next"
              ? (h = a[P])
              : (h = a[P - 1]),
              (h = -h);
          }
          if (
            (S &&
              t.once("transitionEnd", function () {
                t.loopFix();
              }),
            t.velocity !== 0)
          ) {
            if (
              (n
                ? (y = Math.abs((-h - t.translate) / t.velocity))
                : (y = Math.abs((h - t.translate) / t.velocity)),
              r.freeModeSticky)
            ) {
              var B = Math.abs((n ? -h : h) - t.translate),
                M = t.slidesSizesGrid[t.activeIndex];
              B < M
                ? (y = r.speed)
                : B < 2 * M
                ? (y = r.speed * 1.5)
                : (y = r.speed * 2.5);
            }
          } else if (r.freeModeSticky) {
            t.slideToClosest();
            return;
          }
          r.freeModeMomentumBounce && G
            ? (t.updateProgress(A),
              t.setTransition(y),
              t.setTranslate(h),
              t.transitionStart(!0, t.swipeDirection),
              (t.animating = !0),
              l.transitionEnd(function () {
                !t ||
                  t.destroyed ||
                  !i.allowMomentumBounce ||
                  (t.emit("momentumBounce"),
                  t.setTransition(r.speed),
                  setTimeout(function () {
                    t.setTranslate(A),
                      l.transitionEnd(function () {
                        !t || t.destroyed || t.transitionEnd();
                      });
                  }, 0));
              }))
            : t.velocity
            ? (t.updateProgress(h),
              t.setTransition(y),
              t.setTranslate(h),
              t.transitionStart(!0, t.swipeDirection),
              t.animating ||
                ((t.animating = !0),
                l.transitionEnd(function () {
                  !t || t.destroyed || t.transitionEnd();
                })))
            : (t.emit("_freeModeNoMomentumRelease"), t.updateProgress(h)),
            t.updateActiveIndex(),
            t.updateSlidesClasses();
        } else if (r.freeModeSticky) {
          t.slideToClosest();
          return;
        } else r.freeMode && t.emit("_freeModeNoMomentumRelease");
        (!r.freeModeMomentum || u >= r.longSwipesMs) &&
          (t.updateProgress(), t.updateActiveIndex(), t.updateSlidesClasses());
        return;
      }
      for (
        var b = 0, R = t.slidesSizesGrid[0], C = 0;
        C < o.length;
        C += C < r.slidesPerGroupSkip ? 1 : r.slidesPerGroup
      ) {
        var I = C < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
        typeof o[C + I] < "u"
          ? c >= o[C] && c < o[C + I] && ((b = C), (R = o[C + I] - o[C]))
          : c >= o[C] && ((b = C), (R = o[o.length - 1] - o[o.length - 2]));
      }
      var N = (c - o[b]) / R,
        W = b < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
      if (u > r.longSwipesMs) {
        if (!r.longSwipes) {
          t.slideTo(t.activeIndex);
          return;
        }
        t.swipeDirection === "next" &&
          (N >= r.longSwipesRatio ? t.slideTo(b + W) : t.slideTo(b)),
          t.swipeDirection === "prev" &&
            (N > 1 - r.longSwipesRatio ? t.slideTo(b + W) : t.slideTo(b));
      } else {
        if (!r.shortSwipes) {
          t.slideTo(t.activeIndex);
          return;
        }
        var Y =
          t.navigation &&
          (d.target === t.navigation.nextEl ||
            d.target === t.navigation.prevEl);
        Y
          ? d.target === t.navigation.nextEl
            ? t.slideTo(b + W)
            : t.slideTo(b)
          : (t.swipeDirection === "next" && t.slideTo(b + W),
            t.swipeDirection === "prev" && t.slideTo(b));
      }
    }
  }
}
function me() {
  var e = this,
    t = e.params,
    i = e.el;
  if (!(i && i.offsetWidth === 0)) {
    t.breakpoints && e.setBreakpoint();
    var r = e.allowSlideNext,
      s = e.allowSlidePrev,
      n = e.snapGrid;
    (e.allowSlideNext = !0),
      (e.allowSlidePrev = !0),
      e.updateSize(),
      e.updateSlides(),
      e.updateSlidesClasses(),
      (t.slidesPerView === "auto" || t.slidesPerView > 1) &&
      e.isEnd &&
      !e.isBeginning &&
      !e.params.centeredSlides
        ? e.slideTo(e.slides.length - 1, 0, !1, !0)
        : e.slideTo(e.activeIndex, 0, !1, !0),
      e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.run(),
      (e.allowSlidePrev = s),
      (e.allowSlideNext = r),
      e.params.watchOverflow && n !== e.snapGrid && e.checkOverflow();
  }
}
function Br(e) {
  var t = this;
  t.enabled &&
    (t.allowClick ||
      (t.params.preventClicks && e.preventDefault(),
      t.params.preventClicksPropagation &&
        t.animating &&
        (e.stopPropagation(), e.stopImmediatePropagation())));
}
function Rr() {
  var e = this,
    t = e.wrapperEl,
    i = e.rtlTranslate,
    r = e.enabled;
  if (r) {
    (e.previousTranslate = e.translate),
      e.isHorizontal()
        ? i
          ? (e.translate = t.scrollWidth - t.offsetWidth - t.scrollLeft)
          : (e.translate = -t.scrollLeft)
        : (e.translate = -t.scrollTop),
      e.translate === -0 && (e.translate = 0),
      e.updateActiveIndex(),
      e.updateSlidesClasses();
    var s,
      n = e.maxTranslate() - e.minTranslate();
    n === 0 ? (s = 0) : (s = (e.translate - e.minTranslate()) / n),
      s !== e.progress && e.updateProgress(i ? -e.translate : e.translate),
      e.emit("setTranslate", e.translate, !1);
  }
}
var Pe = !1;
function Hr() {}
function Vr() {
  var e = this,
    t = D(),
    i = e.params,
    r = e.touchEvents,
    s = e.el,
    n = e.wrapperEl,
    l = e.device,
    o = e.support;
  (e.onTouchStart = Dr.bind(e)),
    (e.onTouchMove = Gr.bind(e)),
    (e.onTouchEnd = kr.bind(e)),
    i.cssMode && (e.onScroll = Rr.bind(e)),
    (e.onClick = Br.bind(e));
  var a = !!i.nested;
  if (!o.touch && o.pointerEvents)
    s.addEventListener(r.start, e.onTouchStart, !1),
      t.addEventListener(r.move, e.onTouchMove, a),
      t.addEventListener(r.end, e.onTouchEnd, !1);
  else {
    if (o.touch) {
      var f =
        r.start === "touchstart" && o.passiveListener && i.passiveListeners
          ? { passive: !0, capture: !1 }
          : !1;
      s.addEventListener(r.start, e.onTouchStart, f),
        s.addEventListener(
          r.move,
          e.onTouchMove,
          o.passiveListener ? { passive: !1, capture: a } : a
        ),
        s.addEventListener(r.end, e.onTouchEnd, f),
        r.cancel && s.addEventListener(r.cancel, e.onTouchEnd, f),
        Pe || (t.addEventListener("touchstart", Hr), (Pe = !0));
    }
    ((i.simulateTouch && !l.ios && !l.android) ||
      (i.simulateTouch && !o.touch && l.ios)) &&
      (s.addEventListener("mousedown", e.onTouchStart, !1),
      t.addEventListener("mousemove", e.onTouchMove, a),
      t.addEventListener("mouseup", e.onTouchEnd, !1));
  }
  (i.preventClicks || i.preventClicksPropagation) &&
    s.addEventListener("click", e.onClick, !0),
    i.cssMode && n.addEventListener("scroll", e.onScroll),
    i.updateOnWindowResize
      ? e.on(
          l.ios || l.android
            ? "resize orientationchange observerUpdate"
            : "resize observerUpdate",
          me,
          !0
        )
      : e.on("observerUpdate", me, !0);
}
function Nr() {
  var e = this,
    t = D(),
    i = e.params,
    r = e.touchEvents,
    s = e.el,
    n = e.wrapperEl,
    l = e.device,
    o = e.support,
    a = !!i.nested;
  if (!o.touch && o.pointerEvents)
    s.removeEventListener(r.start, e.onTouchStart, !1),
      t.removeEventListener(r.move, e.onTouchMove, a),
      t.removeEventListener(r.end, e.onTouchEnd, !1);
  else {
    if (o.touch) {
      var f =
        r.start === "onTouchStart" && o.passiveListener && i.passiveListeners
          ? { passive: !0, capture: !1 }
          : !1;
      s.removeEventListener(r.start, e.onTouchStart, f),
        s.removeEventListener(r.move, e.onTouchMove, a),
        s.removeEventListener(r.end, e.onTouchEnd, f),
        r.cancel && s.removeEventListener(r.cancel, e.onTouchEnd, f);
    }
    ((i.simulateTouch && !l.ios && !l.android) ||
      (i.simulateTouch && !o.touch && l.ios)) &&
      (s.removeEventListener("mousedown", e.onTouchStart, !1),
      t.removeEventListener("mousemove", e.onTouchMove, a),
      t.removeEventListener("mouseup", e.onTouchEnd, !1));
  }
  (i.preventClicks || i.preventClicksPropagation) &&
    s.removeEventListener("click", e.onClick, !0),
    i.cssMode && n.removeEventListener("scroll", e.onScroll),
    e.off(
      l.ios || l.android
        ? "resize orientationchange observerUpdate"
        : "resize observerUpdate",
      me
    );
}
const Wr = { attachEvents: Vr, detachEvents: Nr };
function $r() {
  var e = this,
    t = e.activeIndex,
    i = e.initialized,
    r = e.loopedSlides,
    s = r === void 0 ? 0 : r,
    n = e.params,
    l = e.$el,
    o = n.breakpoints;
  if (!(!o || (o && Object.keys(o).length === 0))) {
    var a = e.getBreakpoint(o, e.params.breakpointsBase, e.el);
    if (!(!a || e.currentBreakpoint === a)) {
      var f = a in o ? o[a] : void 0;
      f &&
        [
          "slidesPerView",
          "spaceBetween",
          "slidesPerGroup",
          "slidesPerGroupSkip",
          "slidesPerColumn",
        ].forEach(function (E) {
          var y = f[E];
          typeof y > "u" ||
            (E === "slidesPerView" && (y === "AUTO" || y === "auto")
              ? (f[E] = "auto")
              : E === "slidesPerView"
              ? (f[E] = parseFloat(y))
              : (f[E] = parseInt(y, 10)));
        });
      var d = f || e.originalParams,
        p = n.slidesPerColumn > 1,
        u = d.slidesPerColumn > 1,
        c = n.enabled;
      p && !u
        ? (l.removeClass(
            n.containerModifierClass +
              "multirow " +
              n.containerModifierClass +
              "multirow-column"
          ),
          e.emitContainerClasses())
        : !p &&
          u &&
          (l.addClass(n.containerModifierClass + "multirow"),
          ((d.slidesPerColumnFill && d.slidesPerColumnFill === "column") ||
            (!d.slidesPerColumnFill && n.slidesPerColumnFill === "column")) &&
            l.addClass(n.containerModifierClass + "multirow-column"),
          e.emitContainerClasses());
      var m = d.direction && d.direction !== n.direction,
        g = n.loop && (d.slidesPerView !== n.slidesPerView || m);
      m && i && e.changeDirection(), x(e.params, d);
      var w = e.params.enabled;
      x(e, {
        allowTouchMove: e.params.allowTouchMove,
        allowSlideNext: e.params.allowSlideNext,
        allowSlidePrev: e.params.allowSlidePrev,
      }),
        c && !w ? e.disable() : !c && w && e.enable(),
        (e.currentBreakpoint = a),
        e.emit("_beforeBreakpoint", d),
        g &&
          i &&
          (e.loopDestroy(),
          e.loopCreate(),
          e.updateSlides(),
          e.slideTo(t - s + e.loopedSlides, 0, !1)),
        e.emit("breakpoint", d);
    }
  }
}
function Fr(e, t, i) {
  if ((t === void 0 && (t = "window"), !(!e || (t === "container" && !i)))) {
    var r = !1,
      s = L(),
      n = t === "window" ? s.innerHeight : i.clientHeight,
      l = Object.keys(e).map(function (p) {
        if (typeof p == "string" && p.indexOf("@") === 0) {
          var u = parseFloat(p.substr(1)),
            c = n * u;
          return { value: c, point: p };
        }
        return { value: p, point: p };
      });
    l.sort(function (p, u) {
      return parseInt(p.value, 10) - parseInt(u.value, 10);
    });
    for (var o = 0; o < l.length; o += 1) {
      var a = l[o],
        f = a.point,
        d = a.value;
      t === "window"
        ? s.matchMedia("(min-width: " + d + "px)").matches && (r = f)
        : d <= i.clientWidth && (r = f);
    }
    return r || "max";
  }
}
const jr = { setBreakpoint: $r, getBreakpoint: Fr };
function qr(e, t) {
  var i = [];
  return (
    e.forEach(function (r) {
      typeof r == "object"
        ? Object.keys(r).forEach(function (s) {
            r[s] && i.push(t + s);
          })
        : typeof r == "string" && i.push(t + r);
    }),
    i
  );
}
function Xr() {
  var e = this,
    t = e.classNames,
    i = e.params,
    r = e.rtl,
    s = e.$el,
    n = e.device,
    l = e.support,
    o = qr(
      [
        "initialized",
        i.direction,
        { "pointer-events": l.pointerEvents && !l.touch },
        { "free-mode": i.freeMode },
        { autoheight: i.autoHeight },
        { rtl: r },
        { multirow: i.slidesPerColumn > 1 },
        {
          "multirow-column":
            i.slidesPerColumn > 1 && i.slidesPerColumnFill === "column",
        },
        { android: n.android },
        { ios: n.ios },
        { "css-mode": i.cssMode },
      ],
      i.containerModifierClass
    );
  t.push.apply(t, o),
    s.addClass([].concat(t).join(" ")),
    e.emitContainerClasses();
}
function Yr() {
  var e = this,
    t = e.$el,
    i = e.classNames;
  t.removeClass(i.join(" ")), e.emitContainerClasses();
}
const Ur = { addClasses: Xr, removeClasses: Yr };
function Jr(e, t, i, r, s, n) {
  var l = L(),
    o;
  function a() {
    n && n();
  }
  var f = v(e).parent("picture")[0];
  !f && (!e.complete || !s) && t
    ? ((o = new l.Image()),
      (o.onload = a),
      (o.onerror = a),
      r && (o.sizes = r),
      i && (o.srcset = i),
      t && (o.src = t))
    : a();
}
function Qr() {
  var e = this;
  e.imagesToLoad = e.$el.find("img");
  function t() {
    typeof e > "u" ||
      e === null ||
      !e ||
      e.destroyed ||
      (e.imagesLoaded !== void 0 && (e.imagesLoaded += 1),
      e.imagesLoaded === e.imagesToLoad.length &&
        (e.params.updateOnImagesReady && e.update(), e.emit("imagesReady")));
  }
  for (var i = 0; i < e.imagesToLoad.length; i += 1) {
    var r = e.imagesToLoad[i];
    e.loadImage(
      r,
      r.currentSrc || r.getAttribute("src"),
      r.srcset || r.getAttribute("srcset"),
      r.sizes || r.getAttribute("sizes"),
      !0,
      t
    );
  }
}
const Zr = { loadImage: Jr, preloadImages: Qr };
function _r() {
  var e = this,
    t = e.params,
    i = e.isLocked,
    r =
      e.slides.length > 0 &&
      t.slidesOffsetBefore +
        t.spaceBetween * (e.slides.length - 1) +
        e.slides[0].offsetWidth * e.slides.length;
  t.slidesOffsetBefore && t.slidesOffsetAfter && r
    ? (e.isLocked = r <= e.size)
    : (e.isLocked = e.snapGrid.length === 1),
    (e.allowSlideNext = !e.isLocked),
    (e.allowSlidePrev = !e.isLocked),
    i !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock"),
    i &&
      i !== e.isLocked &&
      ((e.isEnd = !1), e.navigation && e.navigation.update());
}
const Kr = { checkOverflow: _r },
  Oe = {
    init: !0,
    direction: "horizontal",
    touchEventsTarget: "container",
    initialSlide: 0,
    speed: 300,
    cssMode: !1,
    updateOnWindowResize: !0,
    resizeObserver: !1,
    nested: !1,
    createElements: !1,
    enabled: !0,
    focusableElements: "input, select, option, textarea, button, video, label",
    width: null,
    height: null,
    preventInteractionOnTransition: !1,
    userAgent: null,
    url: null,
    edgeSwipeDetection: !1,
    edgeSwipeThreshold: 20,
    freeMode: !1,
    freeModeMomentum: !0,
    freeModeMomentumRatio: 1,
    freeModeMomentumBounce: !0,
    freeModeMomentumBounceRatio: 1,
    freeModeMomentumVelocityRatio: 1,
    freeModeSticky: !1,
    freeModeMinimumVelocity: 0.02,
    autoHeight: !1,
    setWrapperSize: !1,
    virtualTranslate: !1,
    effect: "slide",
    breakpoints: void 0,
    breakpointsBase: "window",
    spaceBetween: 0,
    slidesPerView: 1,
    slidesPerColumn: 1,
    slidesPerColumnFill: "column",
    slidesPerGroup: 1,
    slidesPerGroupSkip: 0,
    centeredSlides: !1,
    centeredSlidesBounds: !1,
    slidesOffsetBefore: 0,
    slidesOffsetAfter: 0,
    normalizeSlideIndex: !0,
    centerInsufficientSlides: !1,
    watchOverflow: !1,
    roundLengths: !1,
    touchRatio: 1,
    touchAngle: 45,
    simulateTouch: !0,
    shortSwipes: !0,
    longSwipes: !0,
    longSwipesRatio: 0.5,
    longSwipesMs: 300,
    followFinger: !0,
    allowTouchMove: !0,
    threshold: 0,
    touchMoveStopPropagation: !1,
    touchStartPreventDefault: !0,
    touchStartForcePreventDefault: !1,
    touchReleaseOnEdges: !1,
    uniqueNavElements: !0,
    resistance: !0,
    resistanceRatio: 0.85,
    watchSlidesProgress: !1,
    watchSlidesVisibility: !1,
    grabCursor: !1,
    preventClicks: !0,
    preventClicksPropagation: !0,
    slideToClickedSlide: !1,
    preloadImages: !0,
    updateOnImagesReady: !0,
    loop: !1,
    loopAdditionalSlides: 0,
    loopedSlides: null,
    loopFillGroupWithBlank: !1,
    loopPreventsSlide: !0,
    allowSlidePrev: !0,
    allowSlideNext: !0,
    swipeHandler: null,
    noSwiping: !0,
    noSwipingClass: "swiper-no-swiping",
    noSwipingSelector: null,
    passiveListeners: !0,
    containerModifierClass: "swiper-container-",
    slideClass: "swiper-slide",
    slideBlankClass: "swiper-slide-invisible-blank",
    slideActiveClass: "swiper-slide-active",
    slideDuplicateActiveClass: "swiper-slide-duplicate-active",
    slideVisibleClass: "swiper-slide-visible",
    slideDuplicateClass: "swiper-slide-duplicate",
    slideNextClass: "swiper-slide-next",
    slideDuplicateNextClass: "swiper-slide-duplicate-next",
    slidePrevClass: "swiper-slide-prev",
    slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
    wrapperClass: "swiper-wrapper",
    runCallbacksOnInit: !0,
    _emitClasses: !1,
  };
function ze(e, t) {
  for (var i = 0; i < t.length; i++) {
    var r = t[i];
    (r.enumerable = r.enumerable || !1),
      (r.configurable = !0),
      "value" in r && (r.writable = !0),
      Object.defineProperty(e, r.key, r);
  }
}
function ei(e, t, i) {
  return t && ze(e.prototype, t), i && ze(e, i), e;
}
var de = {
    modular: Ft,
    eventsEmitter: jt,
    update: er,
    translate: ar,
    transition: dr,
    slide: wr,
    loop: Er,
    grabCursor: xr,
    manipulation: Ir,
    events: Wr,
    breakpoints: jr,
    checkOverflow: Kr,
    classes: Ur,
    images: Zr,
  },
  ue = {},
  we = (function () {
    function e() {
      for (var i, r, s = arguments.length, n = new Array(s), l = 0; l < s; l++)
        n[l] = arguments[l];
      if (
        (n.length === 1 &&
        n[0].constructor &&
        Object.prototype.toString.call(n[0]).slice(8, -1) === "Object"
          ? (r = n[0])
          : ((i = n[0]), (r = n[1])),
        r || (r = {}),
        (r = x({}, r)),
        i && !r.el && (r.el = i),
        r.el && v(r.el).length > 1)
      ) {
        var o = [];
        return (
          v(r.el).each(function (d) {
            var p = x({}, r, { el: d });
            o.push(new e(p));
          }),
          o
        );
      }
      var a = this;
      (a.__swiper__ = !0),
        (a.support = De()),
        (a.device = Bt({ userAgent: r.userAgent })),
        (a.browser = Ht()),
        (a.eventsListeners = {}),
        (a.eventsAnyListeners = []),
        typeof a.modules > "u" && (a.modules = {}),
        Object.keys(a.modules).forEach(function (d) {
          var p = a.modules[d];
          if (p.params) {
            var u = Object.keys(p.params)[0],
              c = p.params[u];
            if (
              typeof c != "object" ||
              c === null ||
              (["navigation", "pagination", "scrollbar"].indexOf(u) >= 0 &&
                r[u] === !0 &&
                (r[u] = { auto: !0 }),
              !(u in r && "enabled" in c))
            )
              return;
            r[u] === !0 && (r[u] = { enabled: !0 }),
              typeof r[u] == "object" &&
                !("enabled" in r[u]) &&
                (r[u].enabled = !0),
              r[u] || (r[u] = { enabled: !1 });
          }
        });
      var f = x({}, Oe);
      return (
        a.useParams(f),
        (a.params = x({}, f, ue, r)),
        (a.originalParams = x({}, a.params)),
        (a.passedParams = x({}, r)),
        a.params &&
          a.params.on &&
          Object.keys(a.params.on).forEach(function (d) {
            a.on(d, a.params.on[d]);
          }),
        a.params && a.params.onAny && a.onAny(a.params.onAny),
        (a.$ = v),
        x(a, {
          enabled: a.params.enabled,
          el: i,
          classNames: [],
          slides: v(),
          slidesGrid: [],
          snapGrid: [],
          slidesSizesGrid: [],
          isHorizontal: function () {
            return a.params.direction === "horizontal";
          },
          isVertical: function () {
            return a.params.direction === "vertical";
          },
          activeIndex: 0,
          realIndex: 0,
          isBeginning: !0,
          isEnd: !1,
          translate: 0,
          previousTranslate: 0,
          progress: 0,
          velocity: 0,
          animating: !1,
          allowSlideNext: a.params.allowSlideNext,
          allowSlidePrev: a.params.allowSlidePrev,
          touchEvents: (function () {
            var p = ["touchstart", "touchmove", "touchend", "touchcancel"],
              u = ["mousedown", "mousemove", "mouseup"];
            return (
              a.support.pointerEvents &&
                (u = ["pointerdown", "pointermove", "pointerup"]),
              (a.touchEventsTouch = {
                start: p[0],
                move: p[1],
                end: p[2],
                cancel: p[3],
              }),
              (a.touchEventsDesktop = { start: u[0], move: u[1], end: u[2] }),
              a.support.touch || !a.params.simulateTouch
                ? a.touchEventsTouch
                : a.touchEventsDesktop
            );
          })(),
          touchEventsData: {
            isTouched: void 0,
            isMoved: void 0,
            allowTouchCallbacks: void 0,
            touchStartTime: void 0,
            isScrolling: void 0,
            currentTranslate: void 0,
            startTranslate: void 0,
            allowThresholdMove: void 0,
            focusableElements: a.params.focusableElements,
            lastClickTime: V(),
            clickTimeout: void 0,
            velocities: [],
            allowMomentumBounce: void 0,
            isTouchEvent: void 0,
            startMoving: void 0,
          },
          allowClick: !0,
          allowTouchMove: a.params.allowTouchMove,
          touches: { startX: 0, startY: 0, currentX: 0, currentY: 0, diff: 0 },
          imagesToLoad: [],
          imagesLoaded: 0,
        }),
        a.useModules(),
        a.emit("_swiper"),
        a.params.init && a.init(),
        a
      );
    }
    var t = e.prototype;
    return (
      (t.enable = function () {
        var r = this;
        r.enabled ||
          ((r.enabled = !0),
          r.params.grabCursor && r.setGrabCursor(),
          r.emit("enable"));
      }),
      (t.disable = function () {
        var r = this;
        r.enabled &&
          ((r.enabled = !1),
          r.params.grabCursor && r.unsetGrabCursor(),
          r.emit("disable"));
      }),
      (t.setProgress = function (r, s) {
        var n = this;
        r = Math.min(Math.max(r, 0), 1);
        var l = n.minTranslate(),
          o = n.maxTranslate(),
          a = (o - l) * r + l;
        n.translateTo(a, typeof s > "u" ? 0 : s),
          n.updateActiveIndex(),
          n.updateSlidesClasses();
      }),
      (t.emitContainerClasses = function () {
        var r = this;
        if (!(!r.params._emitClasses || !r.el)) {
          var s = r.el.className.split(" ").filter(function (n) {
            return (
              n.indexOf("swiper-container") === 0 ||
              n.indexOf(r.params.containerModifierClass) === 0
            );
          });
          r.emit("_containerClasses", s.join(" "));
        }
      }),
      (t.getSlideClasses = function (r) {
        var s = this;
        return r.className
          .split(" ")
          .filter(function (n) {
            return (
              n.indexOf("swiper-slide") === 0 ||
              n.indexOf(s.params.slideClass) === 0
            );
          })
          .join(" ");
      }),
      (t.emitSlidesClasses = function () {
        var r = this;
        if (!(!r.params._emitClasses || !r.el)) {
          var s = [];
          r.slides.each(function (n) {
            var l = r.getSlideClasses(n);
            s.push({ slideEl: n, classNames: l }), r.emit("_slideClass", n, l);
          }),
            r.emit("_slideClasses", s);
        }
      }),
      (t.slidesPerViewDynamic = function () {
        var r = this,
          s = r.params,
          n = r.slides,
          l = r.slidesGrid,
          o = r.size,
          a = r.activeIndex,
          f = 1;
        if (s.centeredSlides) {
          for (var d = n[a].swiperSlideSize, p, u = a + 1; u < n.length; u += 1)
            n[u] &&
              !p &&
              ((d += n[u].swiperSlideSize), (f += 1), d > o && (p = !0));
          for (var c = a - 1; c >= 0; c -= 1)
            n[c] &&
              !p &&
              ((d += n[c].swiperSlideSize), (f += 1), d > o && (p = !0));
        } else
          for (var m = a + 1; m < n.length; m += 1) l[m] - l[a] < o && (f += 1);
        return f;
      }),
      (t.update = function () {
        var r = this;
        if (!r || r.destroyed) return;
        var s = r.snapGrid,
          n = r.params;
        n.breakpoints && r.setBreakpoint(),
          r.updateSize(),
          r.updateSlides(),
          r.updateProgress(),
          r.updateSlidesClasses();
        function l() {
          var a = r.rtlTranslate ? r.translate * -1 : r.translate,
            f = Math.min(Math.max(a, r.maxTranslate()), r.minTranslate());
          r.setTranslate(f), r.updateActiveIndex(), r.updateSlidesClasses();
        }
        var o;
        r.params.freeMode
          ? (l(), r.params.autoHeight && r.updateAutoHeight())
          : ((r.params.slidesPerView === "auto" ||
              r.params.slidesPerView > 1) &&
            r.isEnd &&
            !r.params.centeredSlides
              ? (o = r.slideTo(r.slides.length - 1, 0, !1, !0))
              : (o = r.slideTo(r.activeIndex, 0, !1, !0)),
            o || l()),
          n.watchOverflow && s !== r.snapGrid && r.checkOverflow(),
          r.emit("update");
      }),
      (t.changeDirection = function (r, s) {
        s === void 0 && (s = !0);
        var n = this,
          l = n.params.direction;
        return (
          r || (r = l === "horizontal" ? "vertical" : "horizontal"),
          r === l ||
            (r !== "horizontal" && r !== "vertical") ||
            (n.$el
              .removeClass("" + n.params.containerModifierClass + l)
              .addClass("" + n.params.containerModifierClass + r),
            n.emitContainerClasses(),
            (n.params.direction = r),
            n.slides.each(function (o) {
              r === "vertical" ? (o.style.width = "") : (o.style.height = "");
            }),
            n.emit("changeDirection"),
            s && n.update()),
          n
        );
      }),
      (t.mount = function (r) {
        var s = this;
        if (s.mounted) return !0;
        var n = v(r || s.params.el);
        if (((r = n[0]), !r)) return !1;
        r.swiper = s;
        var l = function () {
            return (
              "." + (s.params.wrapperClass || "").trim().split(" ").join(".")
            );
          },
          o = function () {
            if (r && r.shadowRoot && r.shadowRoot.querySelector) {
              var u = v(r.shadowRoot.querySelector(l()));
              return (
                (u.children = function (c) {
                  return n.children(c);
                }),
                u
              );
            }
            return n.children(l());
          },
          a = o();
        if (a.length === 0 && s.params.createElements) {
          var f = D(),
            d = f.createElement("div");
          (a = v(d)),
            (d.className = s.params.wrapperClass),
            n.append(d),
            n.children("." + s.params.slideClass).each(function (p) {
              a.append(p);
            });
        }
        return (
          x(s, {
            $el: n,
            el: r,
            $wrapperEl: a,
            wrapperEl: a[0],
            mounted: !0,
            rtl: r.dir.toLowerCase() === "rtl" || n.css("direction") === "rtl",
            rtlTranslate:
              s.params.direction === "horizontal" &&
              (r.dir.toLowerCase() === "rtl" || n.css("direction") === "rtl"),
            wrongRTL: a.css("display") === "-webkit-box",
          }),
          !0
        );
      }),
      (t.init = function (r) {
        var s = this;
        if (s.initialized) return s;
        var n = s.mount(r);
        return (
          n === !1 ||
            (s.emit("beforeInit"),
            s.params.breakpoints && s.setBreakpoint(),
            s.addClasses(),
            s.params.loop && s.loopCreate(),
            s.updateSize(),
            s.updateSlides(),
            s.params.watchOverflow && s.checkOverflow(),
            s.params.grabCursor && s.enabled && s.setGrabCursor(),
            s.params.preloadImages && s.preloadImages(),
            s.params.loop
              ? s.slideTo(
                  s.params.initialSlide + s.loopedSlides,
                  0,
                  s.params.runCallbacksOnInit,
                  !1,
                  !0
                )
              : s.slideTo(
                  s.params.initialSlide,
                  0,
                  s.params.runCallbacksOnInit,
                  !1,
                  !0
                ),
            s.attachEvents(),
            (s.initialized = !0),
            s.emit("init"),
            s.emit("afterInit")),
          s
        );
      }),
      (t.destroy = function (r, s) {
        r === void 0 && (r = !0), s === void 0 && (s = !0);
        var n = this,
          l = n.params,
          o = n.$el,
          a = n.$wrapperEl,
          f = n.slides;
        return (
          typeof n.params > "u" ||
            n.destroyed ||
            (n.emit("beforeDestroy"),
            (n.initialized = !1),
            n.detachEvents(),
            l.loop && n.loopDestroy(),
            s &&
              (n.removeClasses(),
              o.removeAttr("style"),
              a.removeAttr("style"),
              f &&
                f.length &&
                f
                  .removeClass(
                    [
                      l.slideVisibleClass,
                      l.slideActiveClass,
                      l.slideNextClass,
                      l.slidePrevClass,
                    ].join(" ")
                  )
                  .removeAttr("style")
                  .removeAttr("data-swiper-slide-index")),
            n.emit("destroy"),
            Object.keys(n.eventsListeners).forEach(function (d) {
              n.off(d);
            }),
            r !== !1 && ((n.$el[0].swiper = null), Ot(n)),
            (n.destroyed = !0)),
          null
        );
      }),
      (e.extendDefaults = function (r) {
        x(ue, r);
      }),
      (e.installModule = function (r) {
        e.prototype.modules || (e.prototype.modules = {});
        var s = r.name || Object.keys(e.prototype.modules).length + "_" + V();
        e.prototype.modules[s] = r;
      }),
      (e.use = function (r) {
        return Array.isArray(r)
          ? (r.forEach(function (s) {
              return e.installModule(s);
            }),
            e)
          : (e.installModule(r), e);
      }),
      ei(e, null, [
        {
          key: "extendedDefaults",
          get: function () {
            return ue;
          },
        },
        {
          key: "defaults",
          get: function () {
            return Oe;
          },
        },
      ]),
      e
    );
  })();
Object.keys(de).forEach(function (e) {
  Object.keys(de[e]).forEach(function (t) {
    we.prototype[t] = de[e][t];
  });
});
we.use([Nt, $t]);
const ii = we;
export {
  v as $,
  ii as S,
  D as a,
  Dt as b,
  ve as c,
  ri as d,
  x as e,
  ti as f,
  L as g,
  It as h,
  q as i,
  V as n,
};
