var l = Object.defineProperty;
var c = (n, e, s) =>
  e in n
    ? l(n, e, { enumerable: !0, configurable: !0, writable: !0, value: s })
    : (n[e] = s);
var a = (n, e, s) => (c(n, typeof e != "symbol" ? e + "" : e, s), s);
import { S as t } from "./ShadowDom-bc0a555e.js";
const i = class i {
  constructor() {
    a(this, "allVideosOnPage", []);
    a(this, "pausedVideos", []);
  }
  static getInstance() {
    return i.instance || (i.instance = new i()), i.instance;
  }
  addNewVideo(e) {
    this.allVideosOnPage.push(e), this.removeVideosNotInDocument();
  }
  removeVideosNotInDocument() {
    this.allVideosOnPage.forEach((e) => {
      if (e instanceof HTMLVideoElement) {
        if (!t.isInDocument(e)) {
          const s = this.allVideosOnPage.indexOf(e, 0);
          s > -1 && this.allVideosOnPage.splice(s, 1);
        }
      } else if (
        window.YT &&
        e instanceof YT.Player &&
        !t.isInDocument(e.getIframe())
      ) {
        const s = this.allVideosOnPage.indexOf(e, 0);
        s > -1 && this.allVideosOnPage.splice(s, 1);
      }
    });
  }
  pauseAllVideos() {
    this.removeVideosNotInDocument(),
      this.allVideosOnPage.forEach((e) => {
        e instanceof HTMLVideoElement
          ? e.paused || (this.pausedVideos.push(e), e.pause())
          : window.YT &&
            e instanceof YT.Player &&
            (this.pausedVideos.push(e), e.pauseVideo());
      });
  }
  playPausedVideos() {
    this.pausedVideos.forEach((e) => {
      e instanceof HTMLVideoElement
        ? e.play()
        : e instanceof YT.Player && e.playVideo();
    }),
      (this.pausedVideos = []);
  }
};
a(i, "instance");
let o = i;
export { o as V };
