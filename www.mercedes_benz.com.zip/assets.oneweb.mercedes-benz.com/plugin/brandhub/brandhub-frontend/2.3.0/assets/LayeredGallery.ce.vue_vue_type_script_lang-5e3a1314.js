import { d as n, i as l, a as h, _ as c } from "./index.js";
const u = h(() =>
    c(
      () => import("./ResponsiveImage-0ce28426.js"),
      [
        "./ResponsiveImage-0ce28426.js",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  y = n({
    name: "LayeredGalleryItem",
    props: {
      dataAnalyticsContentMilestone: String,
      editMode: Boolean,
      mainPicture: String,
      secondaryPicture: String,
      secondaryHeadline: String,
      smallPicture: String,
      smallCopy: String,
    },
    data() {
      return {
        textsNeeded: 3,
        secondaryTitleWidth: 100,
        showMainPictures: !1,
        showHeadline: !1,
        showSmallPicture: !1,
        showCopy: !1,
        inverseDir: !1,
      };
    },
    setup() {
      return { secondaryHeadlineNode: l() };
    },
    components: { ResponsiveImage: u },
    methods: {
      dispatchItemMountedEvent() {
        const e = new CustomEvent(a, {
          bubbles: !0,
          composed: !0,
          detail: { item: this },
        });
        this.$nextTick(() => {
          this.$el.dispatchEvent(e);
        });
      },
      calculate() {
        this.secondaryHeadline &&
          this.$nextTick(() => {
            if (this.secondaryHeadlineNode) {
              const { width: e } = this.secondaryHeadlineNode.getBBox();
              this.secondaryTitleWidth = e;
              const i = (e * 1.11 - 33) / 33;
              (this.textsNeeded = Math.floor(i) + 2),
                i % 1 > 0.5 && (this.textsNeeded += 1);
            }
          });
      },
    },
    computed: {
      rootClass() {
        return {
          "brandhub-layered-gallery-item--edit-mode": this.editMode,
          "brandhub-layered-gallery-item--show-main-picture":
            this.showMainPictures || this.editMode,
          "brandhub-layered-gallery-item--show-headline":
            this.showHeadline || this.editMode,
          "brandhub-layered-gallery-item--show-small-picture":
            this.showSmallPicture || this.editMode,
          "brandhub-layered-gallery-item--show-copy":
            this.showCopy || this.editMode,
          "brandhub-layered-gallery-item--inverse-transition-dir":
            this.inverseDir,
        };
      },
      viewBox() {
        let e = 0;
        return (
          this.svgTextNodes.length > 0 &&
            (e =
              Number(this.svgTextNodes[this.svgTextNodes.length - 1].y) / 2 -
              this.secondaryTitleWidth / 2 -
              0.75),
          `0 ${e} ${this.secondaryTitleWidth} ${this.secondaryTitleWidth}`
        );
      },
      svgTextNodes() {
        const e = [];
        for (let t = 0; t < this.textsNeeded; t += 1) {
          const i = `--fade-in-transition-delay: ${
              (this.textsNeeded - t - 1) * 150
            }ms`,
            s = `--fade-out-transition-delay: ${t * 100 + 100}ms`,
            o = `--text-opacity: ${t % 2 === 0 ? "0.5" : "1"}`,
            d = (t + 1) * (this.secondaryTitleWidth * 0.12 + 12) + 1.2;
          e.push({ index: t, y: d.toString(), elementStyle: `${i};${s};${o}` });
        }
        return e;
      },
    },
    mounted() {
      var e;
      this.dispatchItemMountedEvent(),
        (e = document.fonts) != null && e.ready
          ? document.fonts.ready.then(() => {
              this.calculate();
            })
          : document.readyState === "complete"
          ? this.calculate()
          : window.addEventListener(
              "load",
              () => {
                this.calculate();
              },
              { passive: !0 }
            );
    },
  }),
  a = "layeredGalleryItemMounted",
  r = 1,
  m = n({
    name: "LayeredGallery",
    props: { backgroundColor: String, editMode: Boolean },
    data() {
      return { layeredGalleryItems: [] };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-layered-gallery--edit-mode": this.editMode,
          "brandhub-layered-gallery--background-white":
            this.backgroundColor === "white",
          "brandhub-layered-gallery--background-black":
            this.backgroundColor === "black",
        };
      },
      rootStyle() {
        return `--module-height: ${this.wrapperHeight.height}vh`;
      },
      wrapperHeight() {
        const { innerHeight: e } = window,
          t = [];
        let i = e * 0.5;
        return (
          this.layeredGalleryItems.forEach((s) => {
            t.push({ trigger: i, gallery: s, switch: "showMainPictures" }),
              (i -= e * r),
              s.secondaryHeadline &&
                (t.push({ trigger: i, gallery: s, switch: "showHeadline" }),
                (i -= e * r)),
              s.smallPicture &&
                (t.push({ trigger: i, gallery: s, switch: "showSmallPicture" }),
                (i -= e * r)),
              s.smallCopy &&
                (t.push({ trigger: i, gallery: s, switch: "showCopy" }),
                (i -= e * r));
          }),
          { triggers: t, height: t.length * r * 100 + 100 }
        );
      },
    },
    methods: {
      handleLayeredGalleryMount(e) {
        e instanceof CustomEvent &&
          e.detail.item &&
          (this.layeredGalleryItems.push(e.detail.item),
          this.layeredGalleryItems.length % 2 === 0 &&
            (e.detail.item.inverseDir = !0));
      },
      handleScroll() {
        const { top: e } = this.$el.getBoundingClientRect();
        for (const t of this.wrapperHeight.triggers)
          t.gallery[t.switch] = t.trigger > e;
      },
    },
    mounted() {
      this.editMode ||
        (this.$el.addEventListener(a, this.handleLayeredGalleryMount, {
          passive: !0,
        }),
        window.addEventListener("scroll", this.handleScroll, { passive: !0 }),
        this.handleScroll());
    },
    unmounted() {
      window.removeEventListener("scroll", this.handleScroll);
    },
  });
export { a as L, m as _, y as a };
