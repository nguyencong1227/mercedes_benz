import { d as ft, i as $e, a as Ue, _ as Se } from "./index.js";
import { c as yt } from "./can-autoplay.es-4e207aef.js";
import bt from "./ResponsiveImage-0ce28426.js";
import { V as vt } from "./VideoPauseHandler-61c3b0c3.js";
import { R as wt, M as Tt } from "./ResizeUpdateMixin-a56b9b41.js";
import { I as kt } from "./index-12214b95.js";
function d(e, i, t) {
  return (
    i in e
      ? Object.defineProperty(e, i, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[i] = t),
    e
  );
}
function Ct(e, i) {
  if (!(e instanceof i))
    throw new TypeError("Cannot call a class as a function");
}
function _e(e, i) {
  for (var t = 0; t < i.length; t++) {
    var s = i[t];
    (s.enumerable = s.enumerable || !1),
      (s.configurable = !0),
      "value" in s && (s.writable = !0),
      Object.defineProperty(e, s.key, s);
  }
}
function Et(e, i, t) {
  return i && _e(e.prototype, i), t && _e(e, t), e;
}
function Pt(e, i, t) {
  return (
    i in e
      ? Object.defineProperty(e, i, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[i] = t),
    e
  );
}
function Re(e, i) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(e);
    i &&
      (s = s.filter(function (n) {
        return Object.getOwnPropertyDescriptor(e, n).enumerable;
      })),
      t.push.apply(t, s);
  }
  return t;
}
function Ve(e) {
  for (var i = 1; i < arguments.length; i++) {
    var t = arguments[i] != null ? arguments[i] : {};
    i % 2
      ? Re(Object(t), !0).forEach(function (s) {
          Pt(e, s, t[s]);
        })
      : Object.getOwnPropertyDescriptors
      ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
      : Re(Object(t)).forEach(function (s) {
          Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(t, s));
        });
  }
  return e;
}
var je = { addCSS: !0, thumbWidth: 15, watch: !0 };
function At(e, i) {
  return function () {
    return Array.from(document.querySelectorAll(i)).includes(this);
  }.call(e, i);
}
function St(e, i) {
  if (e && i) {
    var t = new Event(i, { bubbles: !0 });
    e.dispatchEvent(t);
  }
}
var se = function (e) {
    return e != null ? e.constructor : null;
  },
  Ne = function (e, i) {
    return !!(e && i && e instanceof i);
  },
  We = function (e) {
    return e == null;
  },
  ze = function (e) {
    return se(e) === Object;
  },
  Nt = function (e) {
    return se(e) === Number && !Number.isNaN(e);
  },
  Ke = function (e) {
    return se(e) === String;
  },
  Mt = function (e) {
    return se(e) === Boolean;
  },
  It = function (e) {
    return se(e) === Function;
  },
  Ye = function (e) {
    return Array.isArray(e);
  },
  Qe = function (e) {
    return Ne(e, NodeList);
  },
  xt = function (e) {
    return Ne(e, Element);
  },
  Lt = function (e) {
    return Ne(e, Event);
  },
  Ot = function (e) {
    return (
      We(e) ||
      ((Ke(e) || Ye(e) || Qe(e)) && !e.length) ||
      (ze(e) && !Object.keys(e).length)
    );
  },
  _ = {
    nullOrUndefined: We,
    object: ze,
    number: Nt,
    string: Ke,
    boolean: Mt,
    function: It,
    array: Ye,
    nodeList: Qe,
    element: xt,
    event: Lt,
    empty: Ot,
  };
function $t(e) {
  var i = "".concat(e).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
  return i ? Math.max(0, (i[1] ? i[1].length : 0) - (i[2] ? +i[2] : 0)) : 0;
}
function _t(e, i) {
  if (1 > i) {
    var t = $t(i);
    return parseFloat(e.toFixed(t));
  }
  return Math.round(e / i) * i;
}
var Rt = (function () {
  function e(i, t) {
    Ct(this, e),
      _.element(i)
        ? (this.element = i)
        : _.string(i) && (this.element = document.querySelector(i)),
      _.element(this.element) &&
        _.empty(this.element.rangeTouch) &&
        ((this.config = Ve({}, je, {}, t)), this.init());
  }
  return (
    Et(
      e,
      [
        {
          key: "init",
          value: function () {
            e.enabled &&
              (this.config.addCSS &&
                ((this.element.style.userSelect = "none"),
                (this.element.style.webKitUserSelect = "none"),
                (this.element.style.touchAction = "manipulation")),
              this.listeners(!0),
              (this.element.rangeTouch = this));
          },
        },
        {
          key: "destroy",
          value: function () {
            e.enabled &&
              (this.config.addCSS &&
                ((this.element.style.userSelect = ""),
                (this.element.style.webKitUserSelect = ""),
                (this.element.style.touchAction = "")),
              this.listeners(!1),
              (this.element.rangeTouch = null));
          },
        },
        {
          key: "listeners",
          value: function (i) {
            var t = this,
              s = i ? "addEventListener" : "removeEventListener";
            ["touchstart", "touchmove", "touchend"].forEach(function (n) {
              t.element[s](
                n,
                function (a) {
                  return t.set(a);
                },
                !1
              );
            });
          },
        },
        {
          key: "get",
          value: function (i) {
            if (!e.enabled || !_.event(i)) return null;
            var t,
              s = i.target,
              n = i.changedTouches[0],
              a = parseFloat(s.getAttribute("min")) || 0,
              l = parseFloat(s.getAttribute("max")) || 100,
              r = parseFloat(s.getAttribute("step")) || 1,
              c = s.getBoundingClientRect(),
              h = ((100 / c.width) * (this.config.thumbWidth / 2)) / 100;
            return (
              0 > (t = (100 / c.width) * (n.clientX - c.left))
                ? (t = 0)
                : 100 < t && (t = 100),
              50 > t
                ? (t -= (100 - 2 * t) * h)
                : 50 < t && (t += 2 * (t - 50) * h),
              a + _t((t / 100) * (l - a), r)
            );
          },
        },
        {
          key: "set",
          value: function (i) {
            e.enabled &&
              _.event(i) &&
              !i.target.disabled &&
              (i.preventDefault(),
              (i.target.value = this.get(i)),
              St(i.target, i.type === "touchend" ? "change" : "input"));
          },
        },
      ],
      [
        {
          key: "setup",
          value: function (i) {
            var t =
                1 < arguments.length && arguments[1] !== void 0
                  ? arguments[1]
                  : {},
              s = null;
            if (
              (_.empty(i) || _.string(i)
                ? (s = Array.from(
                    document.querySelectorAll(
                      _.string(i) ? i : 'input[type="range"]'
                    )
                  ))
                : _.element(i)
                ? (s = [i])
                : _.nodeList(i)
                ? (s = Array.from(i))
                : _.array(i) && (s = i.filter(_.element)),
              _.empty(s))
            )
              return null;
            var n = Ve({}, je, {}, t);
            if (_.string(i) && n.watch) {
              var a = new MutationObserver(function (l) {
                Array.from(l).forEach(function (r) {
                  Array.from(r.addedNodes).forEach(function (c) {
                    _.element(c) && At(c, i) && new e(c, n);
                  });
                });
              });
              a.observe(document.body, { childList: !0, subtree: !0 });
            }
            return s.map(function (l) {
              return new e(l, t);
            });
          },
        },
        {
          key: "enabled",
          get: function () {
            return "ontouchstart" in document.documentElement;
          },
        },
      ]
    ),
    e
  );
})();
const J = (e) => (e != null ? e.constructor : null),
  B = (e, i) => !!(e && i && e instanceof i),
  Me = (e) => e == null,
  Xe = (e) => J(e) === Object,
  Vt = (e) => J(e) === Number && !Number.isNaN(e),
  me = (e) => J(e) === String,
  jt = (e) => J(e) === Boolean,
  Je = (e) => J(e) === Function,
  Ge = (e) => Array.isArray(e),
  Dt = (e) => B(e, WeakMap),
  Ze = (e) => B(e, NodeList),
  Ht = (e) => J(e) === Text,
  qt = (e) => B(e, Event),
  Ft = (e) => B(e, KeyboardEvent),
  Bt = (e) => B(e, window.TextTrackCue) || B(e, window.VTTCue),
  Ut = (e) => B(e, TextTrack) || (!Me(e) && me(e.kind)),
  Wt = (e) => B(e, Promise) && Je(e.then),
  zt = (e) =>
    e !== null &&
    typeof e == "object" &&
    e.nodeType === 1 &&
    typeof e.style == "object" &&
    typeof e.ownerDocument == "object",
  et = (e) =>
    Me(e) ||
    ((me(e) || Ge(e) || Ze(e)) && !e.length) ||
    (Xe(e) && !Object.keys(e).length),
  Kt = (e) => {
    if (B(e, window.URL)) return !0;
    if (!me(e)) return !1;
    let i = e;
    (e.startsWith("http://") && e.startsWith("https://")) ||
      (i = `http://${e}`);
    try {
      return !et(new URL(i).hostname);
    } catch {
      return !1;
    }
  };
var o = {
  nullOrUndefined: Me,
  object: Xe,
  number: Vt,
  string: me,
  boolean: jt,
  function: Je,
  array: Ge,
  weakMap: Dt,
  nodeList: Ze,
  element: zt,
  textNode: Ht,
  event: qt,
  keyboardEvent: Ft,
  cue: Bt,
  track: Ut,
  promise: Wt,
  url: Kt,
  empty: et,
};
const we = (() => {
  const e = document.createElement("span"),
    i = {
      WebkitTransition: "webkitTransitionEnd",
      MozTransition: "transitionend",
      OTransition: "oTransitionEnd otransitionend",
      transition: "transitionend",
    },
    t = Object.keys(i).find((s) => e.style[s] !== void 0);
  return !!o.string(t) && i[t];
})();
function tt(e, i) {
  setTimeout(() => {
    try {
      (e.hidden = !0), e.offsetHeight, (e.hidden = !1);
    } catch {}
  }, i);
}
const $ = {
  isIE: !!window.document.documentMode,
  isEdge: window.navigator.userAgent.includes("Edge"),
  isWebkit:
    "WebkitAppearance" in document.documentElement.style &&
    !/Edge/.test(navigator.userAgent),
  isIPhone: /(iPhone|iPod)/gi.test(navigator.platform),
  isIos:
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) ||
    /(iPad|iPhone|iPod)/gi.test(navigator.platform),
};
function Yt(e) {
  return JSON.parse(JSON.stringify(e));
}
function it(e, i) {
  return i.split(".").reduce((t, s) => t && t[s], e);
}
function I(e = {}, ...i) {
  if (!i.length) return e;
  const t = i.shift();
  return o.object(t)
    ? (Object.keys(t).forEach((s) => {
        o.object(t[s])
          ? (Object.keys(e).includes(s) || Object.assign(e, { [s]: {} }),
            I(e[s], t[s]))
          : Object.assign(e, { [s]: t[s] });
      }),
      I(e, ...i))
    : e;
}
function st(e, i) {
  const t = e.length ? e : [e];
  Array.from(t)
    .reverse()
    .forEach((s, n) => {
      const a = n > 0 ? i.cloneNode(!0) : i,
        l = s.parentNode,
        r = s.nextSibling;
      a.appendChild(s), r ? l.insertBefore(a, r) : l.appendChild(a);
    });
}
function Te(e, i) {
  o.element(e) &&
    !o.empty(i) &&
    Object.entries(i)
      .filter(([, t]) => !o.nullOrUndefined(t))
      .forEach(([t, s]) => e.setAttribute(t, s));
}
function b(e, i, t) {
  const s = document.createElement(e);
  return o.object(i) && Te(s, i), o.string(t) && (s.innerText = t), s;
}
function Qt(e, i) {
  o.element(e) && o.element(i) && i.parentNode.insertBefore(e, i.nextSibling);
}
function De(e, i, t, s) {
  o.element(i) && i.appendChild(b(e, t, s));
}
function F(e) {
  o.nodeList(e) || o.array(e)
    ? Array.from(e).forEach(F)
    : o.element(e) && o.element(e.parentNode) && e.parentNode.removeChild(e);
}
function le(e) {
  if (!o.element(e)) return;
  let { length: i } = e.childNodes;
  for (; i > 0; ) e.removeChild(e.lastChild), (i -= 1);
}
function he(e, i) {
  return o.element(i) && o.element(i.parentNode) && o.element(e)
    ? (i.parentNode.replaceChild(e, i), e)
    : null;
}
function D(e, i) {
  if (!o.string(e) || o.empty(e)) return {};
  const t = {},
    s = I({}, i);
  return (
    e.split(",").forEach((n) => {
      const a = n.trim(),
        l = a.replace(".", ""),
        r = a.replace(/[[\]]/g, "").split("="),
        [c] = r,
        h = r.length > 1 ? r[1].replace(/["']/g, "") : "";
      switch (a.charAt(0)) {
        case ".":
          o.string(s.class) ? (t.class = `${s.class} ${l}`) : (t.class = l);
          break;
        case "#":
          t.id = a.replace("#", "");
          break;
        case "[":
          t[c] = h;
      }
    }),
    I(s, t)
  );
}
function z(e, i) {
  if (!o.element(e)) return;
  let t = i;
  o.boolean(t) || (t = !e.hidden), (e.hidden = t);
}
function k(e, i, t) {
  if (o.nodeList(e)) return Array.from(e).map((s) => k(s, i, t));
  if (o.element(e)) {
    let s = "toggle";
    return (
      t !== void 0 && (s = t ? "add" : "remove"),
      e.classList[s](i),
      e.classList.contains(i)
    );
  }
  return !1;
}
function ue(e, i) {
  return o.element(e) && e.classList.contains(i);
}
function K(e, i) {
  const { prototype: t } = Element;
  return (
    t.matches ||
    t.webkitMatchesSelector ||
    t.mozMatchesSelector ||
    t.msMatchesSelector ||
    function () {
      return Array.from(document.querySelectorAll(i)).includes(this);
    }
  ).call(e, i);
}
function Xt(e, i) {
  const { prototype: t } = Element;
  return (
    t.closest ||
    function () {
      let s = this;
      do {
        if (K.matches(s, i)) return s;
        s = s.parentElement || s.parentNode;
      } while (s !== null && s.nodeType === 1);
      return null;
    }
  ).call(e, i);
}
function Y(e) {
  return this.elements.container.querySelectorAll(e);
}
function L(e) {
  return this.elements.container.querySelector(e);
}
function fe(e = null, i = !1) {
  o.element(e) &&
    (e.focus({ preventScroll: !0 }),
    i && k(e, this.config.classNames.tabFocus));
}
const He = {
    "audio/ogg": "vorbis",
    "audio/wav": "1",
    "video/webm": "vp8, vorbis",
    "video/mp4": "avc1.42E01E, mp4a.40.2",
    "video/ogg": "theora",
  },
  M = {
    audio: "canPlayType" in document.createElement("audio"),
    video: "canPlayType" in document.createElement("video"),
    check(e, i, t) {
      const s = $.isIPhone && t && M.playsinline,
        n = M[e] || i !== "html5";
      return {
        api: n,
        ui: n && M.rangeInput && (e !== "video" || !$.isIPhone || s),
      };
    },
    pip: !(
      $.isIPhone ||
      (!o.function(b("video").webkitSetPresentationMode) &&
        (!document.pictureInPictureEnabled ||
          b("video").disablePictureInPicture))
    ),
    airplay: o.function(window.WebKitPlaybackTargetAvailabilityEvent),
    playsinline: "playsInline" in document.createElement("video"),
    mime(e) {
      if (o.empty(e)) return !1;
      const [i] = e.split("/");
      let t = e;
      if (!this.isHTML5 || i !== this.type) return !1;
      Object.keys(He).includes(t) && (t += `; codecs="${He[e]}"`);
      try {
        return !!(t && this.media.canPlayType(t).replace(/no/, ""));
      } catch {
        return !1;
      }
    },
    textTracks: "textTracks" in document.createElement("video"),
    rangeInput: (() => {
      const e = document.createElement("input");
      return (e.type = "range"), e.type === "range";
    })(),
    touch: "ontouchstart" in document.documentElement,
    transitions: we !== !1,
    reducedMotion:
      "matchMedia" in window &&
      window.matchMedia("(prefers-reduced-motion)").matches,
  },
  Jt = (() => {
    let e = !1;
    try {
      const i = Object.defineProperty({}, "passive", {
        get: () => ((e = !0), null),
      });
      window.addEventListener("test", null, i),
        window.removeEventListener("test", null, i);
    } catch {}
    return e;
  })();
function Q(e, i, t, s = !1, n = !0, a = !1) {
  if (!e || !("addEventListener" in e) || o.empty(i) || !o.function(t)) return;
  const l = i.split(" ");
  let r = a;
  Jt && (r = { passive: n, capture: a }),
    l.forEach((c) => {
      this &&
        this.eventListeners &&
        s &&
        this.eventListeners.push({
          element: e,
          type: c,
          callback: t,
          options: r,
        }),
        e[s ? "addEventListener" : "removeEventListener"](c, t, r);
    });
}
function T(e, i = "", t, s = !0, n = !1) {
  Q.call(this, e, i, t, !0, s, n);
}
function pe(e, i = "", t, s = !0, n = !1) {
  Q.call(this, e, i, t, !1, s, n);
}
function Ie(e, i = "", t, s = !0, n = !1) {
  const a = (...l) => {
    pe(e, i, a, s, n), t.apply(this, l);
  };
  Q.call(this, e, i, a, !0, s, n);
}
function y(e, i = "", t = !1, s = {}) {
  if (!o.element(e) || o.empty(i)) return;
  const n = new CustomEvent(i, { bubbles: t, detail: { ...s, plyr: this } });
  e.dispatchEvent(n);
}
function Gt() {
  this &&
    this.eventListeners &&
    (this.eventListeners.forEach((e) => {
      const { element: i, type: t, callback: s, options: n } = e;
      i.removeEventListener(t, s, n);
    }),
    (this.eventListeners = []));
}
function Zt() {
  return new Promise((e) =>
    this.ready
      ? setTimeout(e, 0)
      : T.call(this, this.elements.container, "ready", e)
  ).then(() => {});
}
function q(e) {
  o.promise(e) && e.then(null, () => {});
}
function ke(e) {
  return o.array(e) ? e.filter((i, t) => e.indexOf(i) === t) : e;
}
function nt(e, i) {
  return o.array(e) && e.length
    ? e.reduce((t, s) => (Math.abs(s - i) < Math.abs(t - i) ? s : t))
    : null;
}
function at(e) {
  return !(!window || !window.CSS) && window.CSS.supports(e);
}
const qe = [
  [1, 1],
  [4, 3],
  [3, 4],
  [5, 4],
  [4, 5],
  [3, 2],
  [2, 3],
  [16, 10],
  [10, 16],
  [16, 9],
  [9, 16],
  [21, 9],
  [9, 21],
  [32, 9],
  [9, 32],
].reduce((e, [i, t]) => ({ ...e, [i / t]: [i, t] }), {});
function ot(e) {
  return o.array(e) || (o.string(e) && e.includes(":"))
    ? (o.array(e) ? e : e.split(":")).map(Number).every(o.number)
    : !1;
}
function de(e) {
  if (!o.array(e) || !e.every(o.number)) return null;
  const [i, t] = e,
    s = (a, l) => (l === 0 ? a : s(l, a % l)),
    n = s(i, t);
  return [i / n, t / n];
}
function xe(e) {
  const i = (s) => (ot(s) ? s.split(":").map(Number) : null);
  let t = i(e);
  if (
    (t === null && (t = i(this.config.ratio)),
    t === null &&
      !o.empty(this.embed) &&
      o.array(this.embed.ratio) &&
      ({ ratio: t } = this.embed),
    t === null && this.isHTML5)
  ) {
    const { videoWidth: s, videoHeight: n } = this.media;
    t = [s, n];
  }
  return de(t);
}
function X(e) {
  if (!this.isVideo) return {};
  const { wrapper: i } = this.elements,
    t = xe.call(this, e);
  if (!o.array(t)) return {};
  const [s, n] = de(t),
    a = (100 / s) * n;
  if (
    (at(`aspect-ratio: ${s}/${n}`)
      ? (i.style.aspectRatio = `${s}/${n}`)
      : (i.style.paddingBottom = `${a}%`),
    this.isVimeo && !this.config.vimeo.premium && this.supported.ui)
  ) {
    const l =
        (100 / this.media.offsetWidth) *
        parseInt(window.getComputedStyle(this.media).paddingBottom, 10),
      r = (l - a) / (l / 50);
    this.fullscreen.active
      ? (i.style.paddingBottom = null)
      : (this.media.style.transform = `translateY(-${r}%)`);
  } else
    this.isHTML5 && i.classList.add(this.config.classNames.videoFixedRatio);
  return { padding: a, ratio: t };
}
function lt(e, i, t = 0.05) {
  const s = e / i,
    n = nt(Object.keys(qe), s);
  return Math.abs(n - s) <= t ? qe[n] : [e, i];
}
function ei() {
  return [
    Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
    Math.max(
      document.documentElement.clientHeight || 0,
      window.innerHeight || 0
    ),
  ];
}
const W = {
  getSources() {
    return this.isHTML5
      ? Array.from(this.media.querySelectorAll("source")).filter((e) => {
          const i = e.getAttribute("type");
          return !!o.empty(i) || M.mime.call(this, i);
        })
      : [];
  },
  getQualityOptions() {
    return this.config.quality.forced
      ? this.config.quality.options
      : W.getSources
          .call(this)
          .map((e) => Number(e.getAttribute("size")))
          .filter(Boolean);
  },
  setup() {
    if (!this.isHTML5) return;
    const e = this;
    (e.options.speed = e.config.speed.options),
      o.empty(this.config.ratio) || X.call(e),
      Object.defineProperty(e.media, "quality", {
        get() {
          const i = W.getSources
            .call(e)
            .find((t) => t.getAttribute("src") === e.source);
          return i && Number(i.getAttribute("size"));
        },
        set(i) {
          if (e.quality !== i) {
            if (
              e.config.quality.forced &&
              o.function(e.config.quality.onChange)
            )
              e.config.quality.onChange(i);
            else {
              const t = W.getSources
                .call(e)
                .find((c) => Number(c.getAttribute("size")) === i);
              if (!t) return;
              const {
                currentTime: s,
                paused: n,
                preload: a,
                readyState: l,
                playbackRate: r,
              } = e.media;
              (e.media.src = t.getAttribute("src")),
                (a !== "none" || l) &&
                  (e.once("loadedmetadata", () => {
                    (e.speed = r), (e.currentTime = s), n || q(e.play());
                  }),
                  e.media.load());
            }
            y.call(e, e.media, "qualitychange", !1, { quality: i });
          }
        },
      });
  },
  cancelRequests() {
    this.isHTML5 &&
      (F(W.getSources.call(this)),
      this.media.setAttribute("src", this.config.blankVideo),
      this.media.load(),
      this.debug.log("Cancelled network requests"));
  },
};
function ti(e) {
  return `${e}-${Math.floor(1e4 * Math.random())}`;
}
function Ce(e, ...i) {
  return o.empty(e)
    ? e
    : e.toString().replace(/{(\d+)}/g, (t, s) => i[s].toString());
}
function ii(e, i) {
  return e === 0 || i === 0 || Number.isNaN(e) || Number.isNaN(i)
    ? 0
    : ((e / i) * 100).toFixed(2);
}
const ee = (e = "", i = "", t = "") =>
    e.replace(
      new RegExp(
        i.toString().replace(/([.*+?^=!:${}()|[\]/\\])/g, "\\$1"),
        "g"
      ),
      t.toString()
    ),
  rt = (e = "") =>
    e
      .toString()
      .replace(
        /\w\S*/g,
        (i) => i.charAt(0).toUpperCase() + i.substr(1).toLowerCase()
      );
function si(e = "") {
  let i = e.toString();
  return (
    (i = ee(i, "-", " ")), (i = ee(i, "_", " ")), (i = rt(i)), ee(i, " ", "")
  );
}
function ni(e = "") {
  let i = e.toString();
  return (i = si(i)), i.charAt(0).toLowerCase() + i.slice(1);
}
function ai(e) {
  const i = document.createDocumentFragment(),
    t = document.createElement("div");
  return i.appendChild(t), (t.innerHTML = e), i.firstChild.innerText;
}
function oi(e) {
  const i = document.createElement("div");
  return i.appendChild(e), i.innerHTML;
}
const Fe = {
    pip: "PIP",
    airplay: "AirPlay",
    html5: "HTML5",
    vimeo: "Vimeo",
    youtube: "YouTube",
  },
  O = {
    get(e = "", i = {}) {
      if (o.empty(e) || o.empty(i)) return "";
      let t = it(i.i18n, e);
      if (o.empty(t)) return Object.keys(Fe).includes(e) ? Fe[e] : "";
      const s = { "{seektime}": i.seekTime, "{title}": i.title };
      return (
        Object.entries(s).forEach(([n, a]) => {
          t = ee(t, n, a);
        }),
        t
      );
    },
  };
class te {
  constructor(i) {
    d(this, "get", (t) => {
      if (!te.supported || !this.enabled) return null;
      const s = window.localStorage.getItem(this.key);
      if (o.empty(s)) return null;
      const n = JSON.parse(s);
      return o.string(t) && t.length ? n[t] : n;
    }),
      d(this, "set", (t) => {
        if (!te.supported || !this.enabled || !o.object(t)) return;
        let s = this.get();
        o.empty(s) && (s = {}), I(s, t);
        try {
          window.localStorage.setItem(this.key, JSON.stringify(s));
        } catch {}
      }),
      (this.enabled = i.config.storage.enabled),
      (this.key = i.config.storage.key);
  }
  static get supported() {
    try {
      if (!("localStorage" in window)) return !1;
      const i = "___test";
      return (
        window.localStorage.setItem(i, i), window.localStorage.removeItem(i), !0
      );
    } catch {
      return !1;
    }
  }
}
function ne(e, i = "text") {
  return new Promise((t, s) => {
    try {
      const n = new XMLHttpRequest();
      if (!("withCredentials" in n)) return;
      n.addEventListener("load", () => {
        if (i === "text")
          try {
            t(JSON.parse(n.responseText));
          } catch {
            t(n.responseText);
          }
        else t(n.response);
      }),
        n.addEventListener("error", () => {
          throw new Error(n.status);
        }),
        n.open("GET", e, !0),
        (n.responseType = i),
        n.send();
    } catch (n) {
      s(n);
    }
  });
}
function ct(e, i) {
  if (!o.string(e)) return;
  const t = o.string(i);
  let s = !1;
  const n = () => document.getElementById(i) !== null,
    a = (l, r) => {
      (l.innerHTML = r),
        (t && n()) || document.body.insertAdjacentElement("afterbegin", l);
    };
  if (!t || !n()) {
    const l = te.supported,
      r = document.createElement("div");
    if ((r.setAttribute("hidden", ""), t && r.setAttribute("id", i), l)) {
      const c = window.localStorage.getItem(`cache-${i}`);
      if (((s = c !== null), s)) {
        const h = JSON.parse(c);
        a(r, h.content);
      }
    }
    ne(e)
      .then((c) => {
        if (!o.empty(c)) {
          if (l)
            try {
              window.localStorage.setItem(
                `cache-${i}`,
                JSON.stringify({ content: c })
              );
            } catch {}
          a(r, c);
        }
      })
      .catch(() => {});
  }
}
const ht = (e) => Math.trunc((e / 60 / 60) % 60, 10),
  li = (e) => Math.trunc(e % 60, 10);
function ge(e = 0, i = !1, t = !1) {
  if (!o.number(e)) return ge(void 0, i, t);
  const s = (c) => `0${c}`.slice(-2);
  let n = ht(e);
  const a = ((l = e), Math.trunc((l / 60) % 60, 10));
  var l;
  const r = li(e);
  return (
    (n = i || n > 0 ? `${n}:` : ""),
    `${t && e > 0 ? "-" : ""}${n}${s(a)}:${s(r)}`
  );
}
const u = {
  getIconUrl() {
    const e = new URL(this.config.iconUrl, window.location),
      i = window.location.host
        ? window.location.host
        : window.top.location.host,
      t = e.host !== i || ($.isIE && !window.svg4everybody);
    return { url: this.config.iconUrl, cors: t };
  },
  findElements() {
    try {
      return (
        (this.elements.controls = L.call(
          this,
          this.config.selectors.controls.wrapper
        )),
        (this.elements.buttons = {
          play: Y.call(this, this.config.selectors.buttons.play),
          pause: L.call(this, this.config.selectors.buttons.pause),
          restart: L.call(this, this.config.selectors.buttons.restart),
          rewind: L.call(this, this.config.selectors.buttons.rewind),
          fastForward: L.call(this, this.config.selectors.buttons.fastForward),
          mute: L.call(this, this.config.selectors.buttons.mute),
          pip: L.call(this, this.config.selectors.buttons.pip),
          airplay: L.call(this, this.config.selectors.buttons.airplay),
          settings: L.call(this, this.config.selectors.buttons.settings),
          captions: L.call(this, this.config.selectors.buttons.captions),
          fullscreen: L.call(this, this.config.selectors.buttons.fullscreen),
        }),
        (this.elements.progress = L.call(this, this.config.selectors.progress)),
        (this.elements.inputs = {
          seek: L.call(this, this.config.selectors.inputs.seek),
          volume: L.call(this, this.config.selectors.inputs.volume),
        }),
        (this.elements.display = {
          buffer: L.call(this, this.config.selectors.display.buffer),
          currentTime: L.call(this, this.config.selectors.display.currentTime),
          duration: L.call(this, this.config.selectors.display.duration),
        }),
        o.element(this.elements.progress) &&
          (this.elements.display.seekTooltip =
            this.elements.progress.querySelector(
              `.${this.config.classNames.tooltip}`
            )),
        !0
      );
    } catch (e) {
      return (
        this.debug.warn(
          "It looks like there is a problem with your custom controls HTML",
          e
        ),
        this.toggleNativeControls(!0),
        !1
      );
    }
  },
  createIcon(e, i) {
    const t = "http://www.w3.org/2000/svg",
      s = u.getIconUrl.call(this),
      n = `${s.cors ? "" : s.url}#${this.config.iconPrefix}`,
      a = document.createElementNS(t, "svg");
    Te(a, I(i, { "aria-hidden": "true", focusable: "false" }));
    const l = document.createElementNS(t, "use"),
      r = `${n}-${e}`;
    return (
      "href" in l &&
        l.setAttributeNS("http://www.w3.org/1999/xlink", "href", r),
      l.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", r),
      a.appendChild(l),
      a
    );
  },
  createLabel(e, i = {}) {
    const t = O.get(e, this.config);
    return b(
      "span",
      {
        ...i,
        class: [i.class, this.config.classNames.hidden]
          .filter(Boolean)
          .join(" "),
      },
      t
    );
  },
  createBadge(e) {
    if (o.empty(e)) return null;
    const i = b("span", { class: this.config.classNames.menu.value });
    return (
      i.appendChild(b("span", { class: this.config.classNames.menu.badge }, e)),
      i
    );
  },
  createButton(e, i) {
    const t = I({}, i);
    let s = ni(e);
    const n = {
      element: "button",
      toggle: !1,
      label: null,
      icon: null,
      labelPressed: null,
      iconPressed: null,
    };
    switch (
      (["element", "icon", "label"].forEach((l) => {
        Object.keys(t).includes(l) && ((n[l] = t[l]), delete t[l]);
      }),
      n.element !== "button" ||
        Object.keys(t).includes("type") ||
        (t.type = "button"),
      Object.keys(t).includes("class")
        ? t.class
            .split(" ")
            .some((l) => l === this.config.classNames.control) ||
          I(t, { class: `${t.class} ${this.config.classNames.control}` })
        : (t.class = this.config.classNames.control),
      e)
    ) {
      case "play":
        (n.toggle = !0),
          (n.label = "play"),
          (n.labelPressed = "pause"),
          (n.icon = "play"),
          (n.iconPressed = "pause");
        break;
      case "mute":
        (n.toggle = !0),
          (n.label = "mute"),
          (n.labelPressed = "unmute"),
          (n.icon = "volume"),
          (n.iconPressed = "muted");
        break;
      case "captions":
        (n.toggle = !0),
          (n.label = "enableCaptions"),
          (n.labelPressed = "disableCaptions"),
          (n.icon = "captions-off"),
          (n.iconPressed = "captions-on");
        break;
      case "fullscreen":
        (n.toggle = !0),
          (n.label = "enterFullscreen"),
          (n.labelPressed = "exitFullscreen"),
          (n.icon = "enter-fullscreen"),
          (n.iconPressed = "exit-fullscreen");
        break;
      case "play-large":
        (t.class += ` ${this.config.classNames.control}--overlaid`),
          (s = "play"),
          (n.label = "play"),
          (n.icon = "play");
        break;
      default:
        o.empty(n.label) && (n.label = s), o.empty(n.icon) && (n.icon = e);
    }
    const a = b(n.element);
    return (
      n.toggle
        ? (a.appendChild(
            u.createIcon.call(this, n.iconPressed, { class: "icon--pressed" })
          ),
          a.appendChild(
            u.createIcon.call(this, n.icon, { class: "icon--not-pressed" })
          ),
          a.appendChild(
            u.createLabel.call(this, n.labelPressed, {
              class: "label--pressed",
            })
          ),
          a.appendChild(
            u.createLabel.call(this, n.label, { class: "label--not-pressed" })
          ))
        : (a.appendChild(u.createIcon.call(this, n.icon)),
          a.appendChild(u.createLabel.call(this, n.label))),
      I(t, D(this.config.selectors.buttons[s], t)),
      Te(a, t),
      s === "play"
        ? (o.array(this.elements.buttons[s]) || (this.elements.buttons[s] = []),
          this.elements.buttons[s].push(a))
        : (this.elements.buttons[s] = a),
      a
    );
  },
  createRange(e, i) {
    const t = b(
      "input",
      I(
        D(this.config.selectors.inputs[e]),
        {
          type: "range",
          min: 0,
          max: 100,
          step: 0.01,
          value: 0,
          autocomplete: "off",
          role: "slider",
          "aria-label": O.get(e, this.config),
          "aria-valuemin": 0,
          "aria-valuemax": 100,
          "aria-valuenow": 0,
        },
        i
      )
    );
    return (
      (this.elements.inputs[e] = t),
      u.updateRangeFill.call(this, t),
      Rt.setup(t),
      t
    );
  },
  createProgress(e, i) {
    const t = b(
      "progress",
      I(
        D(this.config.selectors.display[e]),
        { min: 0, max: 100, value: 0, role: "progressbar", "aria-hidden": !0 },
        i
      )
    );
    if (e !== "volume") {
      t.appendChild(b("span", null, "0"));
      const s = { played: "played", buffer: "buffered" }[e],
        n = s ? O.get(s, this.config) : "";
      t.innerText = `% ${n.toLowerCase()}`;
    }
    return (this.elements.display[e] = t), t;
  },
  createTime(e, i) {
    const t = D(this.config.selectors.display[e], i),
      s = b(
        "div",
        I(t, {
          class: `${t.class ? t.class : ""} ${
            this.config.classNames.display.time
          } `.trim(),
          "aria-label": O.get(e, this.config),
        }),
        "00:00"
      );
    return (this.elements.display[e] = s), s;
  },
  bindMenuItemShortcuts(e, i) {
    T.call(
      this,
      e,
      "keydown keyup",
      (t) => {
        if (
          ![32, 38, 39, 40].includes(t.which) ||
          (t.preventDefault(), t.stopPropagation(), t.type === "keydown")
        )
          return;
        const s = K(e, '[role="menuitemradio"]');
        if (!s && [32, 39].includes(t.which)) u.showMenuPanel.call(this, i, !0);
        else {
          let n;
          t.which !== 32 &&
            (t.which === 40 || (s && t.which === 39)
              ? ((n = e.nextElementSibling),
                o.element(n) || (n = e.parentNode.firstElementChild))
              : ((n = e.previousElementSibling),
                o.element(n) || (n = e.parentNode.lastElementChild)),
            fe.call(this, n, !0));
        }
      },
      !1
    ),
      T.call(this, e, "keyup", (t) => {
        t.which === 13 && u.focusFirstMenuItem.call(this, null, !0);
      });
  },
  createMenuItem({
    value: e,
    list: i,
    type: t,
    title: s,
    badge: n = null,
    checked: a = !1,
  }) {
    const l = D(this.config.selectors.inputs[t]),
      r = b(
        "button",
        I(l, {
          type: "button",
          role: "menuitemradio",
          class: `${this.config.classNames.control} ${
            l.class ? l.class : ""
          }`.trim(),
          "aria-checked": a,
          value: e,
        })
      ),
      c = b("span");
    (c.innerHTML = s),
      o.element(n) && c.appendChild(n),
      r.appendChild(c),
      Object.defineProperty(r, "checked", {
        enumerable: !0,
        get: () => r.getAttribute("aria-checked") === "true",
        set(h) {
          h &&
            Array.from(r.parentNode.children)
              .filter((g) => K(g, '[role="menuitemradio"]'))
              .forEach((g) => g.setAttribute("aria-checked", "false")),
            r.setAttribute("aria-checked", h ? "true" : "false");
        },
      }),
      this.listeners.bind(
        r,
        "click keyup",
        (h) => {
          if (!o.keyboardEvent(h) || h.which === 32) {
            switch (
              (h.preventDefault(), h.stopPropagation(), (r.checked = !0), t)
            ) {
              case "language":
                this.currentTrack = Number(e);
                break;
              case "quality":
                this.quality = e;
                break;
              case "speed":
                this.speed = parseFloat(e);
            }
            u.showMenuPanel.call(this, "home", o.keyboardEvent(h));
          }
        },
        t,
        !1
      ),
      u.bindMenuItemShortcuts.call(this, r, t),
      i.appendChild(r);
  },
  formatTime(e = 0, i = !1) {
    return o.number(e) ? ge(e, ht(this.duration) > 0, i) : e;
  },
  updateTimeDisplay(e = null, i = 0, t = !1) {
    o.element(e) && o.number(i) && (e.innerText = u.formatTime(i, t));
  },
  updateVolume() {
    this.supported.ui &&
      (o.element(this.elements.inputs.volume) &&
        u.setRange.call(
          this,
          this.elements.inputs.volume,
          this.muted ? 0 : this.volume
        ),
      o.element(this.elements.buttons.mute) &&
        (this.elements.buttons.mute.pressed = this.muted || this.volume === 0));
  },
  setRange(e, i = 0) {
    o.element(e) && ((e.value = i), u.updateRangeFill.call(this, e));
  },
  updateProgress(e) {
    if (!this.supported.ui || !o.event(e)) return;
    let i = 0;
    const t = (s, n) => {
      const a = o.number(n) ? n : 0,
        l = o.element(s) ? s : this.elements.display.buffer;
      if (o.element(l)) {
        l.value = a;
        const r = l.getElementsByTagName("span")[0];
        o.element(r) && (r.childNodes[0].nodeValue = a);
      }
    };
    if (e)
      switch (e.type) {
        case "timeupdate":
        case "seeking":
        case "seeked":
          (i = ii(this.currentTime, this.duration)),
            e.type === "timeupdate" &&
              u.setRange.call(this, this.elements.inputs.seek, i);
          break;
        case "playing":
        case "progress":
          t(this.elements.display.buffer, 100 * this.buffered);
      }
  },
  updateRangeFill(e) {
    const i = o.event(e) ? e.target : e;
    if (o.element(i) && i.getAttribute("type") === "range") {
      if (K(i, this.config.selectors.inputs.seek)) {
        i.setAttribute("aria-valuenow", this.currentTime);
        const t = u.formatTime(this.currentTime),
          s = u.formatTime(this.duration),
          n = O.get("seekLabel", this.config);
        i.setAttribute(
          "aria-valuetext",
          n.replace("{currentTime}", t).replace("{duration}", s)
        );
      } else if (K(i, this.config.selectors.inputs.volume)) {
        const t = 100 * i.value;
        i.setAttribute("aria-valuenow", t),
          i.setAttribute("aria-valuetext", `${t.toFixed(1)}%`);
      } else i.setAttribute("aria-valuenow", i.value);
      $.isWebkit &&
        i.style.setProperty("--value", (i.value / i.max) * 100 + "%");
    }
  },
  updateSeekTooltip(e) {
    if (
      !this.config.tooltips.seek ||
      !o.element(this.elements.inputs.seek) ||
      !o.element(this.elements.display.seekTooltip) ||
      this.duration === 0
    )
      return;
    const i = `${this.config.classNames.tooltip}--visible`,
      t = (a) => k(this.elements.display.seekTooltip, i, a);
    if (this.touch) return void t(!1);
    let s = 0;
    const n = this.elements.progress.getBoundingClientRect();
    if (o.event(e)) s = (100 / n.width) * (e.pageX - n.left);
    else {
      if (!ue(this.elements.display.seekTooltip, i)) return;
      s = parseFloat(this.elements.display.seekTooltip.style.left, 10);
    }
    s < 0 ? (s = 0) : s > 100 && (s = 100),
      u.updateTimeDisplay.call(
        this,
        this.elements.display.seekTooltip,
        (this.duration / 100) * s
      ),
      (this.elements.display.seekTooltip.style.left = `${s}%`),
      o.event(e) &&
        ["mouseenter", "mouseleave"].includes(e.type) &&
        t(e.type === "mouseenter");
  },
  timeUpdate(e) {
    const i =
      !o.element(this.elements.display.duration) && this.config.invertTime;
    u.updateTimeDisplay.call(
      this,
      this.elements.display.currentTime,
      i ? this.duration - this.currentTime : this.currentTime,
      i
    ),
      (e && e.type === "timeupdate" && this.media.seeking) ||
        u.updateProgress.call(this, e);
  },
  durationUpdate() {
    if (!this.supported.ui || (!this.config.invertTime && this.currentTime))
      return;
    if (this.duration >= 2 ** 32)
      return (
        z(this.elements.display.currentTime, !0),
        void z(this.elements.progress, !0)
      );
    o.element(this.elements.inputs.seek) &&
      this.elements.inputs.seek.setAttribute("aria-valuemax", this.duration);
    const e = o.element(this.elements.display.duration);
    !e &&
      this.config.displayDuration &&
      this.paused &&
      u.updateTimeDisplay.call(
        this,
        this.elements.display.currentTime,
        this.duration
      ),
      e &&
        u.updateTimeDisplay.call(
          this,
          this.elements.display.duration,
          this.duration
        ),
      u.updateSeekTooltip.call(this);
  },
  toggleMenuButton(e, i) {
    z(this.elements.settings.buttons[e], !i);
  },
  updateSetting(e, i, t) {
    const s = this.elements.settings.panels[e];
    let n = null,
      a = i;
    if (e === "captions") n = this.currentTrack;
    else {
      if (
        ((n = o.empty(t) ? this[e] : t),
        o.empty(n) && (n = this.config[e].default),
        !o.empty(this.options[e]) && !this.options[e].includes(n))
      )
        return void this.debug.warn(`Unsupported value of '${n}' for ${e}`);
      if (!this.config[e].options.includes(n))
        return void this.debug.warn(`Disabled value of '${n}' for ${e}`);
    }
    if (
      (o.element(a) || (a = s && s.querySelector('[role="menu"]')),
      !o.element(a))
    )
      return;
    this.elements.settings.buttons[e].querySelector(
      `.${this.config.classNames.menu.value}`
    ).innerHTML = u.getLabel.call(this, e, n);
    const l = a && a.querySelector(`[value="${n}"]`);
    o.element(l) && (l.checked = !0);
  },
  getLabel(e, i) {
    switch (e) {
      case "speed":
        return i === 1 ? O.get("normal", this.config) : `${i}&times;`;
      case "quality":
        if (o.number(i)) {
          const t = O.get(`qualityLabel.${i}`, this.config);
          return t.length ? t : `${i}p`;
        }
        return rt(i);
      case "captions":
        return A.getLabel.call(this);
      default:
        return null;
    }
  },
  setQualityMenu(e) {
    if (!o.element(this.elements.settings.panels.quality)) return;
    const i = "quality",
      t = this.elements.settings.panels.quality.querySelector('[role="menu"]');
    o.array(e) &&
      (this.options.quality = ke(e).filter((a) =>
        this.config.quality.options.includes(a)
      ));
    const s = !o.empty(this.options.quality) && this.options.quality.length > 1;
    if (
      (u.toggleMenuButton.call(this, i, s), le(t), u.checkMenu.call(this), !s)
    )
      return;
    const n = (a) => {
      const l = O.get(`qualityBadge.${a}`, this.config);
      return l.length ? u.createBadge.call(this, l) : null;
    };
    this.options.quality
      .sort((a, l) => {
        const r = this.config.quality.options;
        return r.indexOf(a) > r.indexOf(l) ? 1 : -1;
      })
      .forEach((a) => {
        u.createMenuItem.call(this, {
          value: a,
          list: t,
          type: i,
          title: u.getLabel.call(this, "quality", a),
          badge: n(a),
        });
      }),
      u.updateSetting.call(this, i, t);
  },
  setCaptionsMenu() {
    if (!o.element(this.elements.settings.panels.captions)) return;
    const e = "captions",
      i = this.elements.settings.panels.captions.querySelector('[role="menu"]'),
      t = A.getTracks.call(this),
      s = !!t.length;
    if (
      (u.toggleMenuButton.call(this, e, s), le(i), u.checkMenu.call(this), !s)
    )
      return;
    const n = t.map((a, l) => ({
      value: l,
      checked: this.captions.toggled && this.currentTrack === l,
      title: A.getLabel.call(this, a),
      badge: a.language && u.createBadge.call(this, a.language.toUpperCase()),
      list: i,
      type: "language",
    }));
    n.unshift({
      value: -1,
      checked: !this.captions.toggled,
      title: O.get("disabled", this.config),
      list: i,
      type: "language",
    }),
      n.forEach(u.createMenuItem.bind(this)),
      u.updateSetting.call(this, e, i);
  },
  setSpeedMenu() {
    if (!o.element(this.elements.settings.panels.speed)) return;
    const e = "speed",
      i = this.elements.settings.panels.speed.querySelector('[role="menu"]');
    this.options.speed = this.options.speed.filter(
      (s) => s >= this.minimumSpeed && s <= this.maximumSpeed
    );
    const t = !o.empty(this.options.speed) && this.options.speed.length > 1;
    u.toggleMenuButton.call(this, e, t),
      le(i),
      u.checkMenu.call(this),
      t &&
        (this.options.speed.forEach((s) => {
          u.createMenuItem.call(this, {
            value: s,
            list: i,
            type: e,
            title: u.getLabel.call(this, "speed", s),
          });
        }),
        u.updateSetting.call(this, e, i));
  },
  checkMenu() {
    const { buttons: e } = this.elements.settings,
      i = !o.empty(e) && Object.values(e).some((t) => !t.hidden);
    z(this.elements.settings.menu, !i);
  },
  focusFirstMenuItem(e, i = !1) {
    if (this.elements.settings.popup.hidden) return;
    let t = e;
    o.element(t) ||
      (t = Object.values(this.elements.settings.panels).find((n) => !n.hidden));
    const s = t.querySelector('[role^="menuitem"]');
    fe.call(this, s, i);
  },
  toggleMenu(e) {
    const { popup: i } = this.elements.settings,
      t = this.elements.buttons.settings;
    if (!o.element(i) || !o.element(t)) return;
    const { hidden: s } = i;
    let n = s;
    if (o.boolean(e)) n = e;
    else if (o.keyboardEvent(e) && e.which === 27) n = !1;
    else if (o.event(e)) {
      const a = o.function(e.composedPath) ? e.composedPath()[0] : e.target,
        l = i.contains(a);
      if (l || (!l && e.target !== t && n)) return;
    }
    t.setAttribute("aria-expanded", n),
      z(i, !n),
      k(this.elements.container, this.config.classNames.menu.open, n),
      n && o.keyboardEvent(e)
        ? u.focusFirstMenuItem.call(this, null, !0)
        : n || s || fe.call(this, t, o.keyboardEvent(e));
  },
  getMenuSize(e) {
    const i = e.cloneNode(!0);
    (i.style.position = "absolute"),
      (i.style.opacity = 0),
      i.removeAttribute("hidden"),
      e.parentNode.appendChild(i);
    const t = i.scrollWidth,
      s = i.scrollHeight;
    return F(i), { width: t, height: s };
  },
  showMenuPanel(e = "", i = !1) {
    const t = this.elements.container.querySelector(
      `#plyr-settings-${this.id}-${e}`
    );
    if (!o.element(t)) return;
    const s = t.parentNode,
      n = Array.from(s.children).find((a) => !a.hidden);
    if (M.transitions && !M.reducedMotion) {
      (s.style.width = `${n.scrollWidth}px`),
        (s.style.height = `${n.scrollHeight}px`);
      const a = u.getMenuSize.call(this, t),
        l = (r) => {
          r.target === s &&
            ["width", "height"].includes(r.propertyName) &&
            ((s.style.width = ""),
            (s.style.height = ""),
            pe.call(this, s, we, l));
        };
      T.call(this, s, we, l),
        (s.style.width = `${a.width}px`),
        (s.style.height = `${a.height}px`);
    }
    z(n, !0), z(t, !1), u.focusFirstMenuItem.call(this, t, i);
  },
  setDownloadUrl() {
    const e = this.elements.buttons.download;
    o.element(e) && e.setAttribute("href", this.download);
  },
  create(e) {
    const {
      bindMenuItemShortcuts: i,
      createButton: t,
      createProgress: s,
      createRange: n,
      createTime: a,
      setQualityMenu: l,
      setSpeedMenu: r,
      showMenuPanel: c,
    } = u;
    (this.elements.controls = null),
      o.array(this.config.controls) &&
        this.config.controls.includes("play-large") &&
        this.elements.container.appendChild(t.call(this, "play-large"));
    const h = b("div", D(this.config.selectors.controls.wrapper));
    this.elements.controls = h;
    const g = { class: "plyr__controls__item" };
    return (
      ke(o.array(this.config.controls) ? this.config.controls : []).forEach(
        (f) => {
          if (
            (f === "restart" && h.appendChild(t.call(this, "restart", g)),
            f === "rewind" && h.appendChild(t.call(this, "rewind", g)),
            f === "play" && h.appendChild(t.call(this, "play", g)),
            f === "fast-forward" &&
              h.appendChild(t.call(this, "fast-forward", g)),
            f === "progress")
          ) {
            const m = b("div", {
                class: `${g.class} plyr__progress__container`,
              }),
              w = b("div", D(this.config.selectors.progress));
            if (
              (w.appendChild(n.call(this, "seek", { id: `plyr-seek-${e.id}` })),
              w.appendChild(s.call(this, "buffer")),
              this.config.tooltips.seek)
            ) {
              const C = b(
                "span",
                { class: this.config.classNames.tooltip },
                "00:00"
              );
              w.appendChild(C), (this.elements.display.seekTooltip = C);
            }
            (this.elements.progress = w),
              m.appendChild(this.elements.progress),
              h.appendChild(m);
          }
          if (
            (f === "current-time" &&
              h.appendChild(a.call(this, "currentTime", g)),
            f === "duration" && h.appendChild(a.call(this, "duration", g)),
            f === "mute" || f === "volume")
          ) {
            let { volume: m } = this.elements;
            if (
              ((o.element(m) && h.contains(m)) ||
                ((m = b(
                  "div",
                  I({}, g, { class: `${g.class} plyr__volume`.trim() })
                )),
                (this.elements.volume = m),
                h.appendChild(m)),
              f === "mute" && m.appendChild(t.call(this, "mute")),
              f === "volume" && !$.isIos)
            ) {
              const w = { max: 1, step: 0.05, value: this.config.volume };
              m.appendChild(
                n.call(this, "volume", I(w, { id: `plyr-volume-${e.id}` }))
              );
            }
          }
          if (
            (f === "captions" && h.appendChild(t.call(this, "captions", g)),
            f === "settings" && !o.empty(this.config.settings))
          ) {
            const m = b(
              "div",
              I({}, g, { class: `${g.class} plyr__menu`.trim(), hidden: "" })
            );
            m.appendChild(
              t.call(this, "settings", {
                "aria-haspopup": !0,
                "aria-controls": `plyr-settings-${e.id}`,
                "aria-expanded": !1,
              })
            );
            const w = b("div", {
                class: "plyr__menu__container",
                id: `plyr-settings-${e.id}`,
                hidden: "",
              }),
              C = b("div"),
              E = b("div", { id: `plyr-settings-${e.id}-home` }),
              N = b("div", { role: "menu" });
            E.appendChild(N),
              C.appendChild(E),
              (this.elements.settings.panels.home = E),
              this.config.settings.forEach((v) => {
                const p = b(
                  "button",
                  I(D(this.config.selectors.buttons.settings), {
                    type: "button",
                    class: `${this.config.classNames.control} ${this.config.classNames.control}--forward`,
                    role: "menuitem",
                    "aria-haspopup": !0,
                    hidden: "",
                  })
                );
                i.call(this, p, v),
                  T.call(this, p, "click", () => {
                    c.call(this, v, !1);
                  });
                const P = b("span", null, O.get(v, this.config)),
                  x = b("span", { class: this.config.classNames.menu.value });
                (x.innerHTML = e[v]),
                  P.appendChild(x),
                  p.appendChild(P),
                  N.appendChild(p);
                const R = b("div", {
                    id: `plyr-settings-${e.id}-${v}`,
                    hidden: "",
                  }),
                  V = b("button", {
                    type: "button",
                    class: `${this.config.classNames.control} ${this.config.classNames.control}--back`,
                  });
                V.appendChild(
                  b("span", { "aria-hidden": !0 }, O.get(v, this.config))
                ),
                  V.appendChild(
                    b(
                      "span",
                      { class: this.config.classNames.hidden },
                      O.get("menuBack", this.config)
                    )
                  ),
                  T.call(
                    this,
                    R,
                    "keydown",
                    (j) => {
                      j.which === 37 &&
                        (j.preventDefault(),
                        j.stopPropagation(),
                        c.call(this, "home", !0));
                    },
                    !1
                  ),
                  T.call(this, V, "click", () => {
                    c.call(this, "home", !1);
                  }),
                  R.appendChild(V),
                  R.appendChild(b("div", { role: "menu" })),
                  C.appendChild(R),
                  (this.elements.settings.buttons[v] = p),
                  (this.elements.settings.panels[v] = R);
              }),
              w.appendChild(C),
              m.appendChild(w),
              h.appendChild(m),
              (this.elements.settings.popup = w),
              (this.elements.settings.menu = m);
          }
          if (
            (f === "pip" && M.pip && h.appendChild(t.call(this, "pip", g)),
            f === "airplay" &&
              M.airplay &&
              h.appendChild(t.call(this, "airplay", g)),
            f === "download")
          ) {
            const m = I({}, g, {
              element: "a",
              href: this.download,
              target: "_blank",
            });
            this.isHTML5 && (m.download = "");
            const { download: w } = this.config.urls;
            !o.url(w) &&
              this.isEmbed &&
              I(m, { icon: `logo-${this.provider}`, label: this.provider }),
              h.appendChild(t.call(this, "download", m));
          }
          f === "fullscreen" && h.appendChild(t.call(this, "fullscreen", g));
        }
      ),
      this.isHTML5 && l.call(this, W.getQualityOptions.call(this)),
      r.call(this),
      h
    );
  },
  inject() {
    if (this.config.loadSprite) {
      const n = u.getIconUrl.call(this);
      n.cors && ct(n.url, "sprite-plyr");
    }
    this.id = Math.floor(1e4 * Math.random());
    let e = null;
    this.elements.controls = null;
    const i = {
      id: this.id,
      seektime: this.config.seekTime,
      title: this.config.title,
    };
    let t = !0;
    o.function(this.config.controls) &&
      (this.config.controls = this.config.controls.call(this, i)),
      this.config.controls || (this.config.controls = []),
      o.element(this.config.controls) || o.string(this.config.controls)
        ? (e = this.config.controls)
        : ((e = u.create.call(this, {
            id: this.id,
            seektime: this.config.seekTime,
            speed: this.speed,
            quality: this.quality,
            captions: A.getLabel.call(this),
          })),
          (t = !1));
    let s;
    if (
      (t &&
        o.string(this.config.controls) &&
        (e = ((n) => {
          let a = n;
          return (
            Object.entries(i).forEach(([l, r]) => {
              a = ee(a, `{${l}}`, r);
            }),
            a
          );
        })(e)),
      o.string(this.config.selectors.controls.container) &&
        (s = document.querySelector(this.config.selectors.controls.container)),
      o.element(s) || (s = this.elements.container),
      s[o.element(e) ? "insertAdjacentElement" : "insertAdjacentHTML"](
        "afterbegin",
        e
      ),
      o.element(this.elements.controls) || u.findElements.call(this),
      !o.empty(this.elements.buttons))
    ) {
      const n = (a) => {
        const l = this.config.classNames.controlPressed;
        Object.defineProperty(a, "pressed", {
          enumerable: !0,
          get: () => ue(a, l),
          set(r = !1) {
            k(a, l, r);
          },
        });
      };
      Object.values(this.elements.buttons)
        .filter(Boolean)
        .forEach((a) => {
          o.array(a) || o.nodeList(a)
            ? Array.from(a).filter(Boolean).forEach(n)
            : n(a);
        });
    }
    if (($.isEdge && tt(s), this.config.tooltips.controls)) {
      const { classNames: n, selectors: a } = this.config,
        l = `${a.controls.wrapper} ${a.labels} .${n.hidden}`,
        r = Y.call(this, l);
      Array.from(r).forEach((c) => {
        k(c, this.config.classNames.hidden, !1),
          k(c, this.config.classNames.tooltip, !0);
      });
    }
  },
};
function ut(e, i = !0) {
  let t = e;
  if (i) {
    const s = document.createElement("a");
    (s.href = t), (t = s.href);
  }
  try {
    return new URL(t);
  } catch {
    return null;
  }
}
function dt(e) {
  const i = new URLSearchParams();
  return (
    o.object(e) &&
      Object.entries(e).forEach(([t, s]) => {
        i.set(t, s);
      }),
    i
  );
}
const A = {
    setup() {
      if (!this.supported.ui) return;
      if (!this.isVideo || this.isYouTube || (this.isHTML5 && !M.textTracks))
        return void (
          o.array(this.config.controls) &&
          this.config.controls.includes("settings") &&
          this.config.settings.includes("captions") &&
          u.setCaptionsMenu.call(this)
        );
      if (
        (o.element(this.elements.captions) ||
          ((this.elements.captions = b(
            "div",
            D(this.config.selectors.captions)
          )),
          Qt(this.elements.captions, this.elements.wrapper)),
        $.isIE && window.URL)
      ) {
        const s = this.media.querySelectorAll("track");
        Array.from(s).forEach((n) => {
          const a = n.getAttribute("src"),
            l = ut(a);
          l !== null &&
            l.hostname !== window.location.href.hostname &&
            ["http:", "https:"].includes(l.protocol) &&
            ne(a, "blob")
              .then((r) => {
                n.setAttribute("src", window.URL.createObjectURL(r));
              })
              .catch(() => {
                F(n);
              });
        });
      }
      const e = ke(
        (
          navigator.languages || [
            navigator.language || navigator.userLanguage || "en",
          ]
        ).map((s) => s.split("-")[0])
      );
      let i = (
        this.storage.get("language") ||
        this.config.captions.language ||
        "auto"
      ).toLowerCase();
      i === "auto" && ([i] = e);
      let t = this.storage.get("captions");
      if (
        (o.boolean(t) || ({ active: t } = this.config.captions),
        Object.assign(this.captions, {
          toggled: !1,
          active: t,
          language: i,
          languages: e,
        }),
        this.isHTML5)
      ) {
        const s = this.config.captions.update
          ? "addtrack removetrack"
          : "removetrack";
        T.call(this, this.media.textTracks, s, A.update.bind(this));
      }
      setTimeout(A.update.bind(this), 0);
    },
    update() {
      const e = A.getTracks.call(this, !0),
        {
          active: i,
          language: t,
          meta: s,
          currentTrackNode: n,
        } = this.captions,
        a = !!e.find((l) => l.language === t);
      this.isHTML5 &&
        this.isVideo &&
        e
          .filter((l) => !s.get(l))
          .forEach((l) => {
            this.debug.log("Track added", l),
              s.set(l, { default: l.mode === "showing" }),
              l.mode === "showing" && (l.mode = "hidden"),
              T.call(this, l, "cuechange", () => A.updateCues.call(this));
          }),
        ((a && this.language !== t) || !e.includes(n)) &&
          (A.setLanguage.call(this, t), A.toggle.call(this, i && a)),
        this.elements &&
          k(
            this.elements.container,
            this.config.classNames.captions.enabled,
            !o.empty(e)
          ),
        o.array(this.config.controls) &&
          this.config.controls.includes("settings") &&
          this.config.settings.includes("captions") &&
          u.setCaptionsMenu.call(this);
    },
    toggle(e, i = !0) {
      if (!this.supported.ui) return;
      const { toggled: t } = this.captions,
        s = this.config.classNames.captions.active,
        n = o.nullOrUndefined(e) ? !t : e;
      if (n !== t) {
        if (
          (i || ((this.captions.active = n), this.storage.set({ captions: n })),
          !this.language && n && !i)
        ) {
          const a = A.getTracks.call(this),
            l = A.findTrack.call(
              this,
              [this.captions.language, ...this.captions.languages],
              !0
            );
          return (
            (this.captions.language = l.language),
            void A.set.call(this, a.indexOf(l))
          );
        }
        this.elements.buttons.captions &&
          (this.elements.buttons.captions.pressed = n),
          k(this.elements.container, s, n),
          (this.captions.toggled = n),
          u.updateSetting.call(this, "captions"),
          y.call(this, this.media, n ? "captionsenabled" : "captionsdisabled");
      }
      setTimeout(() => {
        n &&
          this.captions.toggled &&
          (this.captions.currentTrackNode.mode = "hidden");
      });
    },
    set(e, i = !0) {
      const t = A.getTracks.call(this);
      if (e !== -1)
        if (o.number(e))
          if (e in t) {
            if (this.captions.currentTrack !== e) {
              this.captions.currentTrack = e;
              const s = t[e],
                { language: n } = s || {};
              (this.captions.currentTrackNode = s),
                u.updateSetting.call(this, "captions"),
                i ||
                  ((this.captions.language = n),
                  this.storage.set({ language: n })),
                this.isVimeo && this.embed.enableTextTrack(n),
                y.call(this, this.media, "languagechange");
            }
            A.toggle.call(this, !0, i),
              this.isHTML5 && this.isVideo && A.updateCues.call(this);
          } else this.debug.warn("Track not found", e);
        else this.debug.warn("Invalid caption argument", e);
      else A.toggle.call(this, !1, i);
    },
    setLanguage(e, i = !0) {
      if (!o.string(e))
        return void this.debug.warn("Invalid language argument", e);
      const t = e.toLowerCase();
      this.captions.language = t;
      const s = A.getTracks.call(this),
        n = A.findTrack.call(this, [t]);
      A.set.call(this, s.indexOf(n), i);
    },
    getTracks(e = !1) {
      return Array.from((this.media || {}).textTracks || [])
        .filter((i) => !this.isHTML5 || e || this.captions.meta.has(i))
        .filter((i) => ["captions", "subtitles"].includes(i.kind));
    },
    findTrack(e, i = !1) {
      const t = A.getTracks.call(this),
        s = (l) => Number((this.captions.meta.get(l) || {}).default),
        n = Array.from(t).sort((l, r) => s(r) - s(l));
      let a;
      return (
        e.every((l) => ((a = n.find((r) => r.language === l)), !a)),
        a || (i ? n[0] : void 0)
      );
    },
    getCurrentTrack() {
      return A.getTracks.call(this)[this.currentTrack];
    },
    getLabel(e) {
      let i = e;
      return (
        !o.track(i) &&
          M.textTracks &&
          this.captions.toggled &&
          (i = A.getCurrentTrack.call(this)),
        o.track(i)
          ? o.empty(i.label)
            ? o.empty(i.language)
              ? O.get("enabled", this.config)
              : e.language.toUpperCase()
            : i.label
          : O.get("disabled", this.config)
      );
    },
    updateCues(e) {
      if (!this.supported.ui) return;
      if (!o.element(this.elements.captions))
        return void this.debug.warn("No captions element to render to");
      if (!o.nullOrUndefined(e) && !Array.isArray(e))
        return void this.debug.warn("updateCues: Invalid input", e);
      let i = e;
      if (!i) {
        const s = A.getCurrentTrack.call(this);
        i = Array.from((s || {}).activeCues || [])
          .map((n) => n.getCueAsHTML())
          .map(oi);
      }
      const t = i.map((s) => s.trim()).join(`
`);
      if (t !== this.elements.captions.innerHTML) {
        le(this.elements.captions);
        const s = b("span", D(this.config.selectors.caption));
        (s.innerHTML = t),
          this.elements.captions.appendChild(s),
          y.call(this, this.media, "cuechange");
      }
    },
  },
  mt = {
    enabled: !0,
    title: "",
    debug: !1,
    autoplay: !1,
    autopause: !0,
    playsinline: !0,
    seekTime: 10,
    volume: 1,
    muted: !1,
    duration: null,
    displayDuration: !0,
    invertTime: !0,
    toggleInvert: !0,
    ratio: null,
    clickToPlay: !0,
    hideControls: !0,
    resetOnEnd: !1,
    disableContextMenu: !0,
    loadSprite: !0,
    iconPrefix: "plyr",
    iconUrl: "https://cdn.plyr.io/3.6.12/plyr.svg",
    blankVideo: "https://cdn.plyr.io/static/blank.mp4",
    quality: {
      default: 576,
      options: [4320, 2880, 2160, 1440, 1080, 720, 576, 480, 360, 240],
      forced: !1,
      onChange: null,
    },
    loop: { active: !1 },
    speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 4] },
    keyboard: { focused: !0, global: !1 },
    tooltips: { controls: !1, seek: !0 },
    captions: { active: !1, language: "auto", update: !1 },
    fullscreen: { enabled: !0, fallback: !0, iosNative: !1 },
    storage: { enabled: !0, key: "plyr" },
    controls: [
      "play-large",
      "play",
      "progress",
      "current-time",
      "mute",
      "volume",
      "captions",
      "settings",
      "pip",
      "airplay",
      "fullscreen",
    ],
    settings: ["captions", "quality", "speed"],
    i18n: {
      restart: "Restart",
      rewind: "Rewind {seektime}s",
      play: "Play",
      pause: "Pause",
      fastForward: "Forward {seektime}s",
      seek: "Seek",
      seekLabel: "{currentTime} of {duration}",
      played: "Played",
      buffered: "Buffered",
      currentTime: "Current time",
      duration: "Duration",
      volume: "Volume",
      mute: "Mute",
      unmute: "Unmute",
      enableCaptions: "Enable captions",
      disableCaptions: "Disable captions",
      download: "Download",
      enterFullscreen: "Enter fullscreen",
      exitFullscreen: "Exit fullscreen",
      frameTitle: "Player for {title}",
      captions: "Captions",
      settings: "Settings",
      pip: "PIP",
      menuBack: "Go back to previous menu",
      speed: "Speed",
      normal: "Normal",
      quality: "Quality",
      loop: "Loop",
      start: "Start",
      end: "End",
      all: "All",
      reset: "Reset",
      disabled: "Disabled",
      enabled: "Enabled",
      advertisement: "Ad",
      qualityBadge: {
        2160: "4K",
        1440: "HD",
        1080: "HD",
        720: "HD",
        576: "SD",
        480: "SD",
      },
    },
    urls: {
      download: null,
      vimeo: {
        sdk: "https://player.vimeo.com/api/player.js",
        iframe: "https://player.vimeo.com/video/{0}?{1}",
        api: "https://vimeo.com/api/oembed.json?url={0}",
      },
      youtube: {
        sdk: "https://www.youtube.com/iframe_api",
        api: "https://noembed.com/embed?url=https://www.youtube.com/watch?v={0}",
      },
      googleIMA: { sdk: "https://imasdk.googleapis.com/js/sdkloader/ima3.js" },
    },
    listeners: {
      seek: null,
      play: null,
      pause: null,
      restart: null,
      rewind: null,
      fastForward: null,
      mute: null,
      volume: null,
      captions: null,
      download: null,
      fullscreen: null,
      pip: null,
      airplay: null,
      speed: null,
      quality: null,
      loop: null,
      language: null,
    },
    events: [
      "ended",
      "progress",
      "stalled",
      "playing",
      "waiting",
      "canplay",
      "canplaythrough",
      "loadstart",
      "loadeddata",
      "loadedmetadata",
      "timeupdate",
      "volumechange",
      "play",
      "pause",
      "error",
      "seeking",
      "seeked",
      "emptied",
      "ratechange",
      "cuechange",
      "download",
      "enterfullscreen",
      "exitfullscreen",
      "captionsenabled",
      "captionsdisabled",
      "languagechange",
      "controlshidden",
      "controlsshown",
      "ready",
      "statechange",
      "qualitychange",
      "adsloaded",
      "adscontentpause",
      "adscontentresume",
      "adstarted",
      "adsmidpoint",
      "adscomplete",
      "adsallcomplete",
      "adsimpression",
      "adsclick",
    ],
    selectors: {
      editable: "input, textarea, select, [contenteditable]",
      container: ".plyr",
      controls: { container: null, wrapper: ".plyr__controls" },
      labels: "[data-plyr]",
      buttons: {
        play: '[data-plyr="play"]',
        pause: '[data-plyr="pause"]',
        restart: '[data-plyr="restart"]',
        rewind: '[data-plyr="rewind"]',
        fastForward: '[data-plyr="fast-forward"]',
        mute: '[data-plyr="mute"]',
        captions: '[data-plyr="captions"]',
        download: '[data-plyr="download"]',
        fullscreen: '[data-plyr="fullscreen"]',
        pip: '[data-plyr="pip"]',
        airplay: '[data-plyr="airplay"]',
        settings: '[data-plyr="settings"]',
        loop: '[data-plyr="loop"]',
      },
      inputs: {
        seek: '[data-plyr="seek"]',
        volume: '[data-plyr="volume"]',
        speed: '[data-plyr="speed"]',
        language: '[data-plyr="language"]',
        quality: '[data-plyr="quality"]',
      },
      display: {
        currentTime: ".plyr__time--current",
        duration: ".plyr__time--duration",
        buffer: ".plyr__progress__buffer",
        loop: ".plyr__progress__loop",
        volume: ".plyr__volume--display",
      },
      progress: ".plyr__progress",
      captions: ".plyr__captions",
      caption: ".plyr__caption",
    },
    classNames: {
      type: "plyr--{0}",
      provider: "plyr--{0}",
      video: "plyr__video-wrapper",
      embed: "plyr__video-embed",
      videoFixedRatio: "plyr__video-wrapper--fixed-ratio",
      embedContainer: "plyr__video-embed__container",
      poster: "plyr__poster",
      posterEnabled: "plyr__poster-enabled",
      ads: "plyr__ads",
      control: "plyr__control",
      controlPressed: "plyr__control--pressed",
      playing: "plyr--playing",
      paused: "plyr--paused",
      stopped: "plyr--stopped",
      loading: "plyr--loading",
      hover: "plyr--hover",
      tooltip: "plyr__tooltip",
      cues: "plyr__cues",
      hidden: "plyr__sr-only",
      hideControls: "plyr--hide-controls",
      isIos: "plyr--is-ios",
      isTouch: "plyr--is-touch",
      uiSupported: "plyr--full-ui",
      noTransition: "plyr--no-transition",
      display: { time: "plyr__time" },
      menu: {
        value: "plyr__menu__value",
        badge: "plyr__badge",
        open: "plyr--menu-open",
      },
      captions: {
        enabled: "plyr--captions-enabled",
        active: "plyr--captions-active",
      },
      fullscreen: {
        enabled: "plyr--fullscreen-enabled",
        fallback: "plyr--fullscreen-fallback",
      },
      pip: { supported: "plyr--pip-supported", active: "plyr--pip-active" },
      airplay: {
        supported: "plyr--airplay-supported",
        active: "plyr--airplay-active",
      },
      tabFocus: "plyr__tab-focus",
      previewThumbnails: {
        thumbContainer: "plyr__preview-thumb",
        thumbContainerShown: "plyr__preview-thumb--is-shown",
        imageContainer: "plyr__preview-thumb__image-container",
        timeContainer: "plyr__preview-thumb__time-container",
        scrubbingContainer: "plyr__preview-scrubbing",
        scrubbingContainerShown: "plyr__preview-scrubbing--is-shown",
      },
    },
    attributes: {
      embed: {
        provider: "data-plyr-provider",
        id: "data-plyr-embed-id",
        hash: "data-plyr-embed-hash",
      },
    },
    ads: { enabled: !1, publisherId: "", tagUrl: "" },
    previewThumbnails: { enabled: !1, src: "" },
    vimeo: {
      byline: !1,
      portrait: !1,
      title: !1,
      speed: !0,
      transparent: !1,
      customControls: !0,
      referrerPolicy: null,
      premium: !1,
    },
    youtube: {
      rel: 0,
      showinfo: 0,
      iv_load_policy: 3,
      modestbranding: 1,
      customControls: !0,
      noCookie: !1,
    },
  },
  ye = { active: "picture-in-picture", inactive: "inline" },
  U = { html5: "html5", youtube: "youtube", vimeo: "vimeo" },
  be = { audio: "audio", video: "video" };
function ri(e) {
  return /^(https?:\/\/)?(www\.)?(youtube\.com|youtube-nocookie\.com|youtu\.?be)\/.+$/.test(
    e
  )
    ? U.youtube
    : /^https?:\/\/player.vimeo.com\/video\/\d{0,9}(?=\b|\/)/.test(e)
    ? U.vimeo
    : null;
}
const ve = () => {};
class ci {
  constructor(i = !1) {
    (this.enabled = window.console && i),
      this.enabled && this.log("Debugging enabled");
  }
  get log() {
    return this.enabled
      ? Function.prototype.bind.call(console.log, console)
      : ve;
  }
  get warn() {
    return this.enabled
      ? Function.prototype.bind.call(console.warn, console)
      : ve;
  }
  get error() {
    return this.enabled
      ? Function.prototype.bind.call(console.error, console)
      : ve;
  }
}
class H {
  constructor(i) {
    d(this, "onChange", () => {
      if (!this.enabled) return;
      const t = this.player.elements.buttons.fullscreen;
      o.element(t) && (t.pressed = this.active);
      const s =
        this.target === this.player.media
          ? this.target
          : this.player.elements.container;
      y.call(
        this.player,
        s,
        this.active ? "enterfullscreen" : "exitfullscreen",
        !0
      );
    }),
      d(this, "toggleFallback", (t = !1) => {
        if (
          (t
            ? (this.scrollPosition = {
                x: window.scrollX || 0,
                y: window.scrollY || 0,
              })
            : window.scrollTo(this.scrollPosition.x, this.scrollPosition.y),
          (document.body.style.overflow = t ? "hidden" : ""),
          k(this.target, this.player.config.classNames.fullscreen.fallback, t),
          $.isIos)
        ) {
          let s = document.head.querySelector('meta[name="viewport"]');
          const n = "viewport-fit=cover";
          s ||
            ((s = document.createElement("meta")),
            s.setAttribute("name", "viewport"));
          const a = o.string(s.content) && s.content.includes(n);
          t
            ? ((this.cleanupViewport = !a), a || (s.content += `,${n}`))
            : this.cleanupViewport &&
              (s.content = s.content
                .split(",")
                .filter((l) => l.trim() !== n)
                .join(","));
        }
        this.onChange();
      }),
      d(this, "trapFocus", (t) => {
        if ($.isIos || !this.active || t.key !== "Tab" || t.keyCode !== 9)
          return;
        const s = document.activeElement,
          n = Y.call(
            this.player,
            "a[href], button:not(:disabled), input:not(:disabled), [tabindex]"
          ),
          [a] = n,
          l = n[n.length - 1];
        s !== l || t.shiftKey
          ? s === a && t.shiftKey && (l.focus(), t.preventDefault())
          : (a.focus(), t.preventDefault());
      }),
      d(this, "update", () => {
        if (this.enabled) {
          let t;
          (t = this.forceFallback
            ? "Fallback (forced)"
            : H.native
            ? "Native"
            : "Fallback"),
            this.player.debug.log(`${t} fullscreen enabled`);
        } else
          this.player.debug.log(
            "Fullscreen not supported and fallback disabled"
          );
        k(
          this.player.elements.container,
          this.player.config.classNames.fullscreen.enabled,
          this.enabled
        );
      }),
      d(this, "enter", () => {
        this.enabled &&
          ($.isIos && this.player.config.fullscreen.iosNative
            ? this.player.isVimeo
              ? this.player.embed.requestFullscreen()
              : this.target.webkitEnterFullscreen()
            : !H.native || this.forceFallback
            ? this.toggleFallback(!0)
            : this.prefix
            ? o.empty(this.prefix) ||
              this.target[`${this.prefix}Request${this.property}`]()
            : this.target.requestFullscreen({ navigationUI: "hide" }));
      }),
      d(this, "exit", () => {
        if (this.enabled)
          if ($.isIos && this.player.config.fullscreen.iosNative)
            this.target.webkitExitFullscreen(), q(this.player.play());
          else if (!H.native || this.forceFallback) this.toggleFallback(!1);
          else if (this.prefix) {
            if (!o.empty(this.prefix)) {
              const t = this.prefix === "moz" ? "Cancel" : "Exit";
              document[`${this.prefix}${t}${this.property}`]();
            }
          } else
            (document.cancelFullScreen || document.exitFullscreen).call(
              document
            );
      }),
      d(this, "toggle", () => {
        this.active ? this.exit() : this.enter();
      }),
      (this.player = i),
      (this.prefix = H.prefix),
      (this.property = H.property),
      (this.scrollPosition = { x: 0, y: 0 }),
      (this.forceFallback = i.config.fullscreen.fallback === "force"),
      (this.player.elements.fullscreen =
        i.config.fullscreen.container &&
        Xt(this.player.elements.container, i.config.fullscreen.container)),
      T.call(
        this.player,
        document,
        this.prefix === "ms"
          ? "MSFullscreenChange"
          : `${this.prefix}fullscreenchange`,
        () => {
          this.onChange();
        }
      ),
      T.call(this.player, this.player.elements.container, "dblclick", (t) => {
        (o.element(this.player.elements.controls) &&
          this.player.elements.controls.contains(t.target)) ||
          this.player.listeners.proxy(t, this.toggle, "fullscreen");
      }),
      T.call(this, this.player.elements.container, "keydown", (t) =>
        this.trapFocus(t)
      ),
      this.update();
  }
  static get native() {
    return !!(
      document.fullscreenEnabled ||
      document.webkitFullscreenEnabled ||
      document.mozFullScreenEnabled ||
      document.msFullscreenEnabled
    );
  }
  get usingNative() {
    return H.native && !this.forceFallback;
  }
  static get prefix() {
    if (o.function(document.exitFullscreen)) return "";
    let i = "";
    return (
      ["webkit", "moz", "ms"].some(
        (t) =>
          !(
            !o.function(document[`${t}ExitFullscreen`]) &&
            !o.function(document[`${t}CancelFullScreen`])
          ) && ((i = t), !0)
      ),
      i
    );
  }
  static get property() {
    return this.prefix === "moz" ? "FullScreen" : "Fullscreen";
  }
  get enabled() {
    return (
      (H.native || this.player.config.fullscreen.fallback) &&
      this.player.config.fullscreen.enabled &&
      this.player.supported.ui &&
      this.player.isVideo
    );
  }
  get active() {
    if (!this.enabled) return !1;
    if (!H.native || this.forceFallback)
      return ue(this.target, this.player.config.classNames.fullscreen.fallback);
    const i = this.prefix
      ? this.target.getRootNode()[`${this.prefix}${this.property}Element`]
      : this.target.getRootNode().fullscreenElement;
    return i && i.shadowRoot
      ? i === this.target.getRootNode().host
      : i === this.target;
  }
  get target() {
    return $.isIos && this.player.config.fullscreen.iosNative
      ? this.player.media
      : this.player.elements.fullscreen || this.player.elements.container;
  }
}
function re(e, i = 1) {
  return new Promise((t, s) => {
    const n = new Image(),
      a = () => {
        delete n.onload, delete n.onerror, (n.naturalWidth >= i ? t : s)(n);
      };
    Object.assign(n, { onload: a, onerror: a, src: e });
  });
}
const S = {
  addStyleHook() {
    k(
      this.elements.container,
      this.config.selectors.container.replace(".", ""),
      !0
    ),
      k(
        this.elements.container,
        this.config.classNames.uiSupported,
        this.supported.ui
      );
  },
  toggleNativeControls(e = !1) {
    e && this.isHTML5
      ? this.media.setAttribute("controls", "")
      : this.media.removeAttribute("controls");
  },
  build() {
    if ((this.listeners.media(), !this.supported.ui))
      return (
        this.debug.warn(`Basic support only for ${this.provider} ${this.type}`),
        void S.toggleNativeControls.call(this, !0)
      );
    o.element(this.elements.controls) ||
      (u.inject.call(this), this.listeners.controls()),
      S.toggleNativeControls.call(this),
      this.isHTML5 && A.setup.call(this),
      (this.volume = null),
      (this.muted = null),
      (this.loop = null),
      (this.quality = null),
      (this.speed = null),
      u.updateVolume.call(this),
      u.timeUpdate.call(this),
      u.durationUpdate.call(this),
      S.checkPlaying.call(this),
      k(
        this.elements.container,
        this.config.classNames.pip.supported,
        M.pip && this.isHTML5 && this.isVideo
      ),
      k(
        this.elements.container,
        this.config.classNames.airplay.supported,
        M.airplay && this.isHTML5
      ),
      k(this.elements.container, this.config.classNames.isIos, $.isIos),
      k(this.elements.container, this.config.classNames.isTouch, this.touch),
      (this.ready = !0),
      setTimeout(() => {
        y.call(this, this.media, "ready");
      }, 0),
      S.setTitle.call(this),
      this.poster && S.setPoster.call(this, this.poster, !1).catch(() => {}),
      this.config.duration && u.durationUpdate.call(this);
  },
  setTitle() {
    let e = O.get("play", this.config);
    if (
      (o.string(this.config.title) &&
        !o.empty(this.config.title) &&
        (e += `, ${this.config.title}`),
      Array.from(this.elements.buttons.play || []).forEach((i) => {
        i.setAttribute("aria-label", e);
      }),
      this.isEmbed)
    ) {
      const i = L.call(this, "iframe");
      if (!o.element(i)) return;
      const t = o.empty(this.config.title) ? "video" : this.config.title,
        s = O.get("frameTitle", this.config);
      i.setAttribute("title", s.replace("{title}", t));
    }
  },
  togglePoster(e) {
    k(this.elements.container, this.config.classNames.posterEnabled, e);
  },
  setPoster(e, i = !0) {
    return i && this.poster
      ? Promise.reject(new Error("Poster already set"))
      : (this.media.setAttribute("data-poster", e),
        this.elements.poster.removeAttribute("hidden"),
        Zt.call(this)
          .then(() => re(e))
          .catch((t) => {
            throw (e === this.poster && S.togglePoster.call(this, !1), t);
          })
          .then(() => {
            if (e !== this.poster)
              throw new Error("setPoster cancelled by later call to setPoster");
          })
          .then(
            () => (
              Object.assign(this.elements.poster.style, {
                backgroundImage: `url('${e}')`,
                backgroundSize: "",
              }),
              S.togglePoster.call(this, !0),
              e
            )
          ));
  },
  checkPlaying(e) {
    k(this.elements.container, this.config.classNames.playing, this.playing),
      k(this.elements.container, this.config.classNames.paused, this.paused),
      k(this.elements.container, this.config.classNames.stopped, this.stopped),
      Array.from(this.elements.buttons.play || []).forEach((i) => {
        Object.assign(i, { pressed: this.playing }),
          i.setAttribute(
            "aria-label",
            O.get(this.playing ? "pause" : "play", this.config)
          );
      }),
      (o.event(e) && e.type === "timeupdate") || S.toggleControls.call(this);
  },
  checkLoading(e) {
    (this.loading = ["stalled", "waiting"].includes(e.type)),
      clearTimeout(this.timers.loading),
      (this.timers.loading = setTimeout(
        () => {
          k(
            this.elements.container,
            this.config.classNames.loading,
            this.loading
          ),
            S.toggleControls.call(this);
        },
        this.loading ? 250 : 0
      ));
  },
  toggleControls(e) {
    const { controls: i } = this.elements;
    if (i && this.config.hideControls) {
      const t = this.touch && this.lastSeekTime + 2e3 > Date.now();
      this.toggleControls(
        !!(e || this.loading || this.paused || i.pressed || i.hover || t)
      );
    }
  },
  migrateStyles() {
    Object.values({ ...this.media.style })
      .filter((e) => !o.empty(e) && o.string(e) && e.startsWith("--plyr"))
      .forEach((e) => {
        this.elements.container.style.setProperty(
          e,
          this.media.style.getPropertyValue(e)
        ),
          this.media.style.removeProperty(e);
      }),
      o.empty(this.media.style) && this.media.removeAttribute("style");
  },
};
class hi {
  constructor(i) {
    d(this, "firstTouch", () => {
      const { player: t } = this,
        { elements: s } = t;
      (t.touch = !0), k(s.container, t.config.classNames.isTouch, !0);
    }),
      d(this, "setTabFocus", (t) => {
        const { player: s } = this,
          { elements: n } = s;
        if (
          (clearTimeout(this.focusTimer), t.type === "keydown" && t.which !== 9)
        )
          return;
        t.type === "keydown" && (this.lastKeyDown = t.timeStamp);
        const a = t.timeStamp - this.lastKeyDown <= 20;
        (t.type !== "focus" || a) &&
          ((() => {
            const l = s.config.classNames.tabFocus;
            k(Y.call(s, `.${l}`), l, !1);
          })(),
          t.type !== "focusout" &&
            (this.focusTimer = setTimeout(() => {
              const l = document.activeElement;
              n.container.contains(l) &&
                k(document.activeElement, s.config.classNames.tabFocus, !0);
            }, 10)));
      }),
      d(this, "global", (t = !0) => {
        const { player: s } = this;
        s.config.keyboard.global &&
          Q.call(s, window, "keydown keyup", this.handleKey, t, !1),
          Q.call(s, document.body, "click", this.toggleMenu, t),
          Ie.call(s, document.body, "touchstart", this.firstTouch),
          Q.call(
            s,
            document.body,
            "keydown focus blur focusout",
            this.setTabFocus,
            t,
            !1,
            !0
          );
      }),
      d(this, "container", () => {
        const { player: t } = this,
          { config: s, elements: n, timers: a } = t;
        !s.keyboard.global &&
          s.keyboard.focused &&
          T.call(t, n.container, "keydown keyup", this.handleKey, !1),
          T.call(
            t,
            n.container,
            "mousemove mouseleave touchstart touchmove enterfullscreen exitfullscreen",
            (c) => {
              const { controls: h } = n;
              h &&
                c.type === "enterfullscreen" &&
                ((h.pressed = !1), (h.hover = !1));
              let g = 0;
              ["touchstart", "touchmove", "mousemove"].includes(c.type) &&
                (S.toggleControls.call(t, !0), (g = t.touch ? 3e3 : 2e3)),
                clearTimeout(a.controls),
                (a.controls = setTimeout(
                  () => S.toggleControls.call(t, !1),
                  g
                ));
            }
          );
        const l = () => {
            if (!t.isVimeo || t.config.vimeo.premium) return;
            const c = n.wrapper,
              { active: h } = t.fullscreen,
              [g, f] = xe.call(t),
              m = at(`aspect-ratio: ${g} / ${f}`);
            if (!h)
              return void (m
                ? ((c.style.width = null), (c.style.height = null))
                : ((c.style.maxWidth = null), (c.style.margin = null)));
            const [w, C] = ei(),
              E = w / C > g / f;
            m
              ? ((c.style.width = E ? "auto" : "100%"),
                (c.style.height = E ? "100%" : "auto"))
              : ((c.style.maxWidth = E ? (C / f) * g + "px" : null),
                (c.style.margin = E ? "0 auto" : null));
          },
          r = () => {
            clearTimeout(a.resized), (a.resized = setTimeout(l, 50));
          };
        T.call(t, n.container, "enterfullscreen exitfullscreen", (c) => {
          const { target: h } = t.fullscreen;
          h === n.container &&
            ((!t.isEmbed && o.empty(t.config.ratio)) ||
              (l(),
              (c.type === "enterfullscreen" ? T : pe).call(
                t,
                window,
                "resize",
                r
              )));
        });
      }),
      d(this, "media", () => {
        const { player: t } = this,
          { elements: s } = t;
        if (
          (T.call(t, t.media, "timeupdate seeking seeked", (a) =>
            u.timeUpdate.call(t, a)
          ),
          T.call(t, t.media, "durationchange loadeddata loadedmetadata", (a) =>
            u.durationUpdate.call(t, a)
          ),
          T.call(t, t.media, "ended", () => {
            t.isHTML5 &&
              t.isVideo &&
              t.config.resetOnEnd &&
              (t.restart(), t.pause());
          }),
          T.call(t, t.media, "progress playing seeking seeked", (a) =>
            u.updateProgress.call(t, a)
          ),
          T.call(t, t.media, "volumechange", (a) => u.updateVolume.call(t, a)),
          T.call(
            t,
            t.media,
            "playing play pause ended emptied timeupdate",
            (a) => S.checkPlaying.call(t, a)
          ),
          T.call(t, t.media, "waiting canplay seeked playing", (a) =>
            S.checkLoading.call(t, a)
          ),
          t.supported.ui && t.config.clickToPlay && !t.isAudio)
        ) {
          const a = L.call(t, `.${t.config.classNames.video}`);
          if (!o.element(a)) return;
          T.call(t, s.container, "click", (l) => {
            ([s.container, a].includes(l.target) || a.contains(l.target)) &&
              ((t.touch && t.config.hideControls) ||
                (t.ended
                  ? (this.proxy(l, t.restart, "restart"),
                    this.proxy(
                      l,
                      () => {
                        q(t.play());
                      },
                      "play"
                    ))
                  : this.proxy(
                      l,
                      () => {
                        q(t.togglePlay());
                      },
                      "play"
                    )));
          });
        }
        t.supported.ui &&
          t.config.disableContextMenu &&
          T.call(
            t,
            s.wrapper,
            "contextmenu",
            (a) => {
              a.preventDefault();
            },
            !1
          ),
          T.call(t, t.media, "volumechange", () => {
            t.storage.set({ volume: t.volume, muted: t.muted });
          }),
          T.call(t, t.media, "ratechange", () => {
            u.updateSetting.call(t, "speed"), t.storage.set({ speed: t.speed });
          }),
          T.call(t, t.media, "qualitychange", (a) => {
            u.updateSetting.call(t, "quality", null, a.detail.quality);
          }),
          T.call(t, t.media, "ready qualitychange", () => {
            u.setDownloadUrl.call(t);
          });
        const n = t.config.events.concat(["keyup", "keydown"]).join(" ");
        T.call(t, t.media, n, (a) => {
          let { detail: l = {} } = a;
          a.type === "error" && (l = t.media.error),
            y.call(t, s.container, a.type, !0, l);
        });
      }),
      d(this, "proxy", (t, s, n) => {
        const { player: a } = this,
          l = a.config.listeners[n];
        let r = !0;
        o.function(l) && (r = l.call(a, t)),
          r !== !1 && o.function(s) && s.call(a, t);
      }),
      d(this, "bind", (t, s, n, a, l = !0) => {
        const { player: r } = this,
          c = r.config.listeners[a],
          h = o.function(c);
        T.call(r, t, s, (g) => this.proxy(g, n, a), l && !h);
      }),
      d(this, "controls", () => {
        const { player: t } = this,
          { elements: s } = t,
          n = $.isIE ? "change" : "input";
        if (
          (s.buttons.play &&
            Array.from(s.buttons.play).forEach((a) => {
              this.bind(
                a,
                "click",
                () => {
                  q(t.togglePlay());
                },
                "play"
              );
            }),
          this.bind(s.buttons.restart, "click", t.restart, "restart"),
          this.bind(
            s.buttons.rewind,
            "click",
            () => {
              (t.lastSeekTime = Date.now()), t.rewind();
            },
            "rewind"
          ),
          this.bind(
            s.buttons.fastForward,
            "click",
            () => {
              (t.lastSeekTime = Date.now()), t.forward();
            },
            "fastForward"
          ),
          this.bind(
            s.buttons.mute,
            "click",
            () => {
              t.muted = !t.muted;
            },
            "mute"
          ),
          this.bind(s.buttons.captions, "click", () => t.toggleCaptions()),
          this.bind(
            s.buttons.download,
            "click",
            () => {
              y.call(t, t.media, "download");
            },
            "download"
          ),
          this.bind(
            s.buttons.fullscreen,
            "click",
            () => {
              t.fullscreen.toggle();
            },
            "fullscreen"
          ),
          this.bind(
            s.buttons.pip,
            "click",
            () => {
              t.pip = "toggle";
            },
            "pip"
          ),
          this.bind(s.buttons.airplay, "click", t.airplay, "airplay"),
          this.bind(
            s.buttons.settings,
            "click",
            (a) => {
              a.stopPropagation(), a.preventDefault(), u.toggleMenu.call(t, a);
            },
            null,
            !1
          ),
          this.bind(
            s.buttons.settings,
            "keyup",
            (a) => {
              const l = a.which;
              [13, 32].includes(l) &&
                (l !== 13
                  ? (a.preventDefault(),
                    a.stopPropagation(),
                    u.toggleMenu.call(t, a))
                  : u.focusFirstMenuItem.call(t, null, !0));
            },
            null,
            !1
          ),
          this.bind(s.settings.menu, "keydown", (a) => {
            a.which === 27 && u.toggleMenu.call(t, a);
          }),
          this.bind(s.inputs.seek, "mousedown mousemove", (a) => {
            const l = s.progress.getBoundingClientRect(),
              r = (100 / l.width) * (a.pageX - l.left);
            a.currentTarget.setAttribute("seek-value", r);
          }),
          this.bind(
            s.inputs.seek,
            "mousedown mouseup keydown keyup touchstart touchend",
            (a) => {
              const l = a.currentTarget,
                r = a.keyCode ? a.keyCode : a.which,
                c = "play-on-seeked";
              if (o.keyboardEvent(a) && r !== 39 && r !== 37) return;
              t.lastSeekTime = Date.now();
              const h = l.hasAttribute(c),
                g = ["mouseup", "touchend", "keyup"].includes(a.type);
              h && g
                ? (l.removeAttribute(c), q(t.play()))
                : !g && t.playing && (l.setAttribute(c, ""), t.pause());
            }
          ),
          $.isIos)
        ) {
          const a = Y.call(t, 'input[type="range"]');
          Array.from(a).forEach((l) => this.bind(l, n, (r) => tt(r.target)));
        }
        this.bind(
          s.inputs.seek,
          n,
          (a) => {
            const l = a.currentTarget;
            let r = l.getAttribute("seek-value");
            o.empty(r) && (r = l.value),
              l.removeAttribute("seek-value"),
              (t.currentTime = (r / l.max) * t.duration);
          },
          "seek"
        ),
          this.bind(s.progress, "mouseenter mouseleave mousemove", (a) =>
            u.updateSeekTooltip.call(t, a)
          ),
          this.bind(s.progress, "mousemove touchmove", (a) => {
            const { previewThumbnails: l } = t;
            l && l.loaded && l.startMove(a);
          }),
          this.bind(s.progress, "mouseleave touchend click", () => {
            const { previewThumbnails: a } = t;
            a && a.loaded && a.endMove(!1, !0);
          }),
          this.bind(s.progress, "mousedown touchstart", (a) => {
            const { previewThumbnails: l } = t;
            l && l.loaded && l.startScrubbing(a);
          }),
          this.bind(s.progress, "mouseup touchend", (a) => {
            const { previewThumbnails: l } = t;
            l && l.loaded && l.endScrubbing(a);
          }),
          $.isWebkit &&
            Array.from(Y.call(t, 'input[type="range"]')).forEach((a) => {
              this.bind(a, "input", (l) => u.updateRangeFill.call(t, l.target));
            }),
          t.config.toggleInvert &&
            !o.element(s.display.duration) &&
            this.bind(s.display.currentTime, "click", () => {
              t.currentTime !== 0 &&
                ((t.config.invertTime = !t.config.invertTime),
                u.timeUpdate.call(t));
            }),
          this.bind(
            s.inputs.volume,
            n,
            (a) => {
              t.volume = a.target.value;
            },
            "volume"
          ),
          this.bind(s.controls, "mouseenter mouseleave", (a) => {
            s.controls.hover = !t.touch && a.type === "mouseenter";
          }),
          s.fullscreen &&
            Array.from(s.fullscreen.children)
              .filter((a) => !a.contains(s.container))
              .forEach((a) => {
                this.bind(a, "mouseenter mouseleave", (l) => {
                  s.controls &&
                    (s.controls.hover = !t.touch && l.type === "mouseenter");
                });
              }),
          this.bind(
            s.controls,
            "mousedown mouseup touchstart touchend touchcancel",
            (a) => {
              s.controls.pressed = ["mousedown", "touchstart"].includes(a.type);
            }
          ),
          this.bind(s.controls, "focusin", () => {
            const { config: a, timers: l } = t;
            k(s.controls, a.classNames.noTransition, !0),
              S.toggleControls.call(t, !0),
              setTimeout(() => {
                k(s.controls, a.classNames.noTransition, !1);
              }, 0);
            const r = this.touch ? 3e3 : 4e3;
            clearTimeout(l.controls),
              (l.controls = setTimeout(() => S.toggleControls.call(t, !1), r));
          }),
          this.bind(
            s.inputs.volume,
            "wheel",
            (a) => {
              const l = a.webkitDirectionInvertedFromDevice,
                [r, c] = [a.deltaX, -a.deltaY].map((f) => (l ? -f : f)),
                h = Math.sign(Math.abs(r) > Math.abs(c) ? r : c);
              t.increaseVolume(h / 50);
              const { volume: g } = t.media;
              ((h === 1 && g < 1) || (h === -1 && g > 0)) && a.preventDefault();
            },
            "volume",
            !1
          );
      }),
      (this.player = i),
      (this.lastKey = null),
      (this.focusTimer = null),
      (this.lastKeyDown = null),
      (this.handleKey = this.handleKey.bind(this)),
      (this.toggleMenu = this.toggleMenu.bind(this)),
      (this.setTabFocus = this.setTabFocus.bind(this)),
      (this.firstTouch = this.firstTouch.bind(this));
  }
  handleKey(i) {
    const { player: t } = this,
      { elements: s } = t,
      n = i.keyCode ? i.keyCode : i.which,
      a = i.type === "keydown",
      l = a && n === this.lastKey;
    if (!(i.altKey || i.ctrlKey || i.metaKey || i.shiftKey) && o.number(n))
      if (a) {
        const r = document.activeElement;
        if (o.element(r)) {
          const { editable: c } = t.config.selectors,
            { seek: h } = s.inputs;
          if (
            (r !== h && K(r, c)) ||
            (i.which === 32 && K(r, 'button, [role^="menuitem"]'))
          )
            return;
        }
        switch (
          ([
            32, 37, 38, 39, 40, 48, 49, 50, 51, 52, 53, 54, 56, 57, 67, 70, 73,
            75, 76, 77, 79,
          ].includes(n) && (i.preventDefault(), i.stopPropagation()),
          n)
        ) {
          case 48:
          case 49:
          case 50:
          case 51:
          case 52:
          case 53:
          case 54:
          case 55:
          case 56:
          case 57:
            l || (t.currentTime = (t.duration / 10) * (n - 48));
            break;
          case 32:
          case 75:
            l || q(t.togglePlay());
            break;
          case 38:
            t.increaseVolume(0.1);
            break;
          case 40:
            t.decreaseVolume(0.1);
            break;
          case 77:
            l || (t.muted = !t.muted);
            break;
          case 39:
            t.forward();
            break;
          case 37:
            t.rewind();
            break;
          case 70:
            t.fullscreen.toggle();
            break;
          case 67:
            l || t.toggleCaptions();
            break;
          case 76:
            t.loop = !t.loop;
        }
        n === 27 &&
          !t.fullscreen.usingNative &&
          t.fullscreen.active &&
          t.fullscreen.toggle(),
          (this.lastKey = n);
      } else this.lastKey = null;
  }
  toggleMenu(i) {
    u.toggleMenu.call(this.player, i);
  }
}
function ui(e, i) {
  return e((i = { exports: {} }), i.exports), i.exports;
}
var di = ui(function (e, i) {
  e.exports = (function () {
    var t = function () {},
      s = {},
      n = {},
      a = {};
    function l(m, w) {
      m = m.push ? m : [m];
      var C,
        E,
        N,
        v = [],
        p = m.length,
        P = p;
      for (
        C = function (x, R) {
          R.length && v.push(x), --P || w(v);
        };
        p--;

      )
        (E = m[p]), (N = n[E]) ? C(E, N) : (a[E] = a[E] || []).push(C);
    }
    function r(m, w) {
      if (m) {
        var C = a[m];
        if (((n[m] = w), C)) for (; C.length; ) C[0](m, w), C.splice(0, 1);
      }
    }
    function c(m, w) {
      m.call && (m = { success: m }),
        w.length ? (m.error || t)(w) : (m.success || t)(m);
    }
    function h(m, w, C, E) {
      var N,
        v,
        p = document,
        P = C.async,
        x = (C.numRetries || 0) + 1,
        R = C.before || t,
        V = m.replace(/[\?|#].*$/, ""),
        j = m.replace(/^(css|img)!/, "");
      (E = E || 0),
        /(^css!|\.css$)/.test(V)
          ? (((v = p.createElement("link")).rel = "stylesheet"),
            (v.href = j),
            (N = "hideFocus" in v) &&
              v.relList &&
              ((N = 0), (v.rel = "preload"), (v.as = "style")))
          : /(^img!|\.(png|gif|jpg|svg|webp)$)/.test(V)
          ? ((v = p.createElement("img")).src = j)
          : (((v = p.createElement("script")).src = m),
            (v.async = P === void 0 || P)),
        (v.onload =
          v.onerror =
          v.onbeforeload =
            function (Oe) {
              var ae = Oe.type[0];
              if (N)
                try {
                  v.sheet.cssText.length || (ae = "e");
                } catch (gt) {
                  gt.code != 18 && (ae = "e");
                }
              if (ae == "e") {
                if ((E += 1) < x) return h(m, w, C, E);
              } else if (v.rel == "preload" && v.as == "style")
                return (v.rel = "stylesheet");
              w(m, ae, Oe.defaultPrevented);
            }),
        R(m, v) !== !1 && p.head.appendChild(v);
    }
    function g(m, w, C) {
      var E,
        N,
        v = (m = m.push ? m : [m]).length,
        p = v,
        P = [];
      for (
        E = function (x, R, V) {
          if ((R == "e" && P.push(x), R == "b")) {
            if (!V) return;
            P.push(x);
          }
          --v || w(P);
        },
          N = 0;
        N < p;
        N++
      )
        h(m[N], E, C);
    }
    function f(m, w, C) {
      var E, N;
      if ((w && w.trim && (E = w), (N = (E ? C : w) || {}), E)) {
        if (E in s) throw "LoadJS";
        s[E] = !0;
      }
      function v(p, P) {
        g(
          m,
          function (x) {
            c(N, x), p && c({ success: p, error: P }, x), r(E, x);
          },
          N
        );
      }
      if (N.returnPromise) return new Promise(v);
      v();
    }
    return (
      (f.ready = function (m, w) {
        return (
          l(m, function (C) {
            c(w, C);
          }),
          f
        );
      }),
      (f.done = function (m) {
        r(m, []);
      }),
      (f.reset = function () {
        (s = {}), (n = {}), (a = {});
      }),
      (f.isDefined = function (m) {
        return m in s;
      }),
      f
    );
  })();
});
function Le(e) {
  return new Promise((i, t) => {
    di(e, { success: i, error: t });
  });
}
function mi(e) {
  return o.empty(e)
    ? null
    : o.number(Number(e))
    ? e
    : e.match(/^.*(vimeo.com\/|video\/)(\d+).*/)
    ? RegExp.$2
    : e;
}
function pi(e) {
  const i = e.match(
    /^.*(?:vimeo.com\/|video\/)(?:\d+)(?:\?.*&*h=|\/)+(?<hash>[\d,a-f]+)/
  );
  return i ? i.groups.hash : null;
}
function G(e) {
  e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0),
    this.media.paused === e &&
      ((this.media.paused = !e),
      y.call(this, this.media, e ? "play" : "pause"));
}
const Ee = {
  setup() {
    const e = this;
    k(e.elements.wrapper, e.config.classNames.embed, !0),
      (e.options.speed = e.config.speed.options),
      X.call(e),
      o.object(window.Vimeo)
        ? Ee.ready.call(e)
        : Le(e.config.urls.vimeo.sdk)
            .then(() => {
              Ee.ready.call(e);
            })
            .catch((i) => {
              e.debug.warn("Vimeo SDK (player.js) failed to load", i);
            });
  },
  ready() {
    const e = this,
      i = e.config.vimeo,
      { premium: t, referrerPolicy: s, ...n } = i;
    let a = e.media.getAttribute("src"),
      l = "";
    o.empty(a)
      ? ((a = e.media.getAttribute(e.config.attributes.embed.id)),
        (l = e.media.getAttribute(e.config.attributes.embed.hash)))
      : (l = pi(a));
    const r = l ? { h: l } : {};
    t && Object.assign(n, { controls: !1, sidedock: !1 });
    const c = dt({
        loop: e.config.loop.active,
        autoplay: e.autoplay,
        muted: e.muted,
        gesture: "media",
        playsinline: !this.config.fullscreen.iosNative,
        ...r,
        ...n,
      }),
      h = mi(a),
      g = b("iframe"),
      f = Ce(e.config.urls.vimeo.iframe, h, c);
    if (
      (g.setAttribute("src", f),
      g.setAttribute("allowfullscreen", ""),
      g.setAttribute(
        "allow",
        [
          "autoplay",
          "fullscreen",
          "picture-in-picture",
          "encrypted-media",
          "accelerometer",
          "gyroscope",
        ].join("; ")
      ),
      o.empty(s) || g.setAttribute("referrerPolicy", s),
      t || !i.customControls)
    )
      g.setAttribute("data-poster", e.poster), (e.media = he(g, e.media));
    else {
      const p = b("div", {
        class: e.config.classNames.embedContainer,
        "data-poster": e.poster,
      });
      p.appendChild(g), (e.media = he(p, e.media));
    }
    i.customControls ||
      ne(Ce(e.config.urls.vimeo.api, f)).then((p) => {
        !o.empty(p) &&
          p.thumbnail_url &&
          S.setPoster.call(e, p.thumbnail_url).catch(() => {});
      }),
      (e.embed = new window.Vimeo.Player(g, {
        autopause: e.config.autopause,
        muted: e.muted,
      })),
      (e.media.paused = !0),
      (e.media.currentTime = 0),
      e.supported.ui && e.embed.disableTextTrack(),
      (e.media.play = () => (G.call(e, !0), e.embed.play())),
      (e.media.pause = () => (G.call(e, !1), e.embed.pause())),
      (e.media.stop = () => {
        e.pause(), (e.currentTime = 0);
      });
    let { currentTime: m } = e.media;
    Object.defineProperty(e.media, "currentTime", {
      get: () => m,
      set(p) {
        const { embed: P, media: x, paused: R, volume: V } = e,
          j = R && !P.hasPlayed;
        (x.seeking = !0),
          y.call(e, x, "seeking"),
          Promise.resolve(j && P.setVolume(0))
            .then(() => P.setCurrentTime(p))
            .then(() => j && P.pause())
            .then(() => j && P.setVolume(V))
            .catch(() => {});
      },
    });
    let w = e.config.speed.selected;
    Object.defineProperty(e.media, "playbackRate", {
      get: () => w,
      set(p) {
        e.embed
          .setPlaybackRate(p)
          .then(() => {
            (w = p), y.call(e, e.media, "ratechange");
          })
          .catch(() => {
            e.options.speed = [1];
          });
      },
    });
    let { volume: C } = e.config;
    Object.defineProperty(e.media, "volume", {
      get: () => C,
      set(p) {
        e.embed.setVolume(p).then(() => {
          (C = p), y.call(e, e.media, "volumechange");
        });
      },
    });
    let { muted: E } = e.config;
    Object.defineProperty(e.media, "muted", {
      get: () => E,
      set(p) {
        const P = !!o.boolean(p) && p;
        e.embed.setVolume(P ? 0 : e.config.volume).then(() => {
          (E = P), y.call(e, e.media, "volumechange");
        });
      },
    });
    let N,
      { loop: v } = e.config;
    Object.defineProperty(e.media, "loop", {
      get: () => v,
      set(p) {
        const P = o.boolean(p) ? p : e.config.loop.active;
        e.embed.setLoop(P).then(() => {
          v = P;
        });
      },
    }),
      e.embed
        .getVideoUrl()
        .then((p) => {
          (N = p), u.setDownloadUrl.call(e);
        })
        .catch((p) => {
          this.debug.warn(p);
        }),
      Object.defineProperty(e.media, "currentSrc", { get: () => N }),
      Object.defineProperty(e.media, "ended", {
        get: () => e.currentTime === e.duration,
      }),
      Promise.all([e.embed.getVideoWidth(), e.embed.getVideoHeight()]).then(
        (p) => {
          const [P, x] = p;
          (e.embed.ratio = lt(P, x)), X.call(this);
        }
      ),
      e.embed.setAutopause(e.config.autopause).then((p) => {
        e.config.autopause = p;
      }),
      e.embed.getVideoTitle().then((p) => {
        (e.config.title = p), S.setTitle.call(this);
      }),
      e.embed.getCurrentTime().then((p) => {
        (m = p), y.call(e, e.media, "timeupdate");
      }),
      e.embed.getDuration().then((p) => {
        (e.media.duration = p), y.call(e, e.media, "durationchange");
      }),
      e.embed.getTextTracks().then((p) => {
        (e.media.textTracks = p), A.setup.call(e);
      }),
      e.embed.on("cuechange", ({ cues: p = [] }) => {
        const P = p.map((x) => ai(x.text));
        A.updateCues.call(e, P);
      }),
      e.embed.on("loaded", () => {
        e.embed.getPaused().then((p) => {
          G.call(e, !p), p || y.call(e, e.media, "playing");
        }),
          o.element(e.embed.element) &&
            e.supported.ui &&
            e.embed.element.setAttribute("tabindex", -1);
      }),
      e.embed.on("bufferstart", () => {
        y.call(e, e.media, "waiting");
      }),
      e.embed.on("bufferend", () => {
        y.call(e, e.media, "playing");
      }),
      e.embed.on("play", () => {
        G.call(e, !0), y.call(e, e.media, "playing");
      }),
      e.embed.on("pause", () => {
        G.call(e, !1);
      }),
      e.embed.on("timeupdate", (p) => {
        (e.media.seeking = !1),
          (m = p.seconds),
          y.call(e, e.media, "timeupdate");
      }),
      e.embed.on("progress", (p) => {
        (e.media.buffered = p.percent),
          y.call(e, e.media, "progress"),
          parseInt(p.percent, 10) === 1 && y.call(e, e.media, "canplaythrough"),
          e.embed.getDuration().then((P) => {
            P !== e.media.duration &&
              ((e.media.duration = P), y.call(e, e.media, "durationchange"));
          });
      }),
      e.embed.on("seeked", () => {
        (e.media.seeking = !1), y.call(e, e.media, "seeked");
      }),
      e.embed.on("ended", () => {
        (e.media.paused = !0), y.call(e, e.media, "ended");
      }),
      e.embed.on("error", (p) => {
        (e.media.error = p), y.call(e, e.media, "error");
      }),
      i.customControls && setTimeout(() => S.build.call(e), 0);
  },
};
function gi(e) {
  return o.empty(e)
    ? null
    : e.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/)
    ? RegExp.$2
    : e;
}
function Z(e) {
  e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0),
    this.media.paused === e &&
      ((this.media.paused = !e),
      y.call(this, this.media, e ? "play" : "pause"));
}
function fi(e) {
  return e.noCookie
    ? "https://www.youtube-nocookie.com"
    : window.location.protocol === "http:"
    ? "http://www.youtube.com"
    : void 0;
}
const ce = {
    setup() {
      if (
        (k(this.elements.wrapper, this.config.classNames.embed, !0),
        o.object(window.YT) && o.function(window.YT.Player))
      )
        ce.ready.call(this);
      else {
        const e = window.onYouTubeIframeAPIReady;
        (window.onYouTubeIframeAPIReady = () => {
          o.function(e) && e(), ce.ready.call(this);
        }),
          Le(this.config.urls.youtube.sdk).catch((i) => {
            this.debug.warn("YouTube API failed to load", i);
          });
      }
    },
    getTitle(e) {
      ne(Ce(this.config.urls.youtube.api, e))
        .then((i) => {
          if (o.object(i)) {
            const { title: t, height: s, width: n } = i;
            (this.config.title = t),
              S.setTitle.call(this),
              (this.embed.ratio = lt(n, s));
          }
          X.call(this);
        })
        .catch(() => {
          X.call(this);
        });
    },
    ready() {
      const e = this,
        i = e.config.youtube,
        t = e.media && e.media.getAttribute("id");
      if (!o.empty(t) && t.startsWith("youtube-")) return;
      let s = e.media.getAttribute("src");
      o.empty(s) && (s = e.media.getAttribute(this.config.attributes.embed.id));
      const n = gi(s),
        a = b("div", {
          id: ti(e.provider),
          "data-poster": i.customControls ? e.poster : void 0,
        });
      if (((e.media = he(a, e.media)), i.customControls)) {
        const l = (r) => `https://i.ytimg.com/vi/${n}/${r}default.jpg`;
        re(l("maxres"), 121)
          .catch(() => re(l("sd"), 121))
          .catch(() => re(l("hq")))
          .then((r) => S.setPoster.call(e, r.src))
          .then((r) => {
            r.includes("maxres") ||
              (e.elements.poster.style.backgroundSize = "cover");
          })
          .catch(() => {});
      }
      e.embed = new window.YT.Player(e.media, {
        videoId: n,
        host: fi(i),
        playerVars: I(
          {},
          {
            autoplay: e.config.autoplay ? 1 : 0,
            hl: e.config.hl,
            controls: e.supported.ui && i.customControls ? 0 : 1,
            disablekb: 1,
            playsinline: e.config.fullscreen.iosNative ? 0 : 1,
            cc_load_policy: e.captions.active ? 1 : 0,
            cc_lang_pref: e.config.captions.language,
            widget_referrer: window ? window.location.href : null,
          },
          i
        ),
        events: {
          onError(l) {
            if (!e.media.error) {
              const r = l.data,
                c =
                  {
                    2: "The request contains an invalid parameter value. For example, this error occurs if you specify a video ID that does not have 11 characters, or if the video ID contains invalid characters, such as exclamation points or asterisks.",
                    5: "The requested content cannot be played in an HTML5 player or another error related to the HTML5 player has occurred.",
                    100: "The video requested was not found. This error occurs when a video has been removed (for any reason) or has been marked as private.",
                    101: "The owner of the requested video does not allow it to be played in embedded players.",
                    150: "The owner of the requested video does not allow it to be played in embedded players.",
                  }[r] || "An unknown error occured";
              (e.media.error = { code: r, message: c }),
                y.call(e, e.media, "error");
            }
          },
          onPlaybackRateChange(l) {
            const r = l.target;
            (e.media.playbackRate = r.getPlaybackRate()),
              y.call(e, e.media, "ratechange");
          },
          onReady(l) {
            if (o.function(e.media.play)) return;
            const r = l.target;
            ce.getTitle.call(e, n),
              (e.media.play = () => {
                Z.call(e, !0), r.playVideo();
              }),
              (e.media.pause = () => {
                Z.call(e, !1), r.pauseVideo();
              }),
              (e.media.stop = () => {
                r.stopVideo();
              }),
              (e.media.duration = r.getDuration()),
              (e.media.paused = !0),
              (e.media.currentTime = 0),
              Object.defineProperty(e.media, "currentTime", {
                get: () => Number(r.getCurrentTime()),
                set(f) {
                  e.paused && !e.embed.hasPlayed && e.embed.mute(),
                    (e.media.seeking = !0),
                    y.call(e, e.media, "seeking"),
                    r.seekTo(f);
                },
              }),
              Object.defineProperty(e.media, "playbackRate", {
                get: () => r.getPlaybackRate(),
                set(f) {
                  r.setPlaybackRate(f);
                },
              });
            let { volume: c } = e.config;
            Object.defineProperty(e.media, "volume", {
              get: () => c,
              set(f) {
                (c = f),
                  r.setVolume(100 * c),
                  y.call(e, e.media, "volumechange");
              },
            });
            let { muted: h } = e.config;
            Object.defineProperty(e.media, "muted", {
              get: () => h,
              set(f) {
                const m = o.boolean(f) ? f : h;
                (h = m),
                  r[m ? "mute" : "unMute"](),
                  r.setVolume(100 * c),
                  y.call(e, e.media, "volumechange");
              },
            }),
              Object.defineProperty(e.media, "currentSrc", {
                get: () => r.getVideoUrl(),
              }),
              Object.defineProperty(e.media, "ended", {
                get: () => e.currentTime === e.duration,
              });
            const g = r.getAvailablePlaybackRates();
            (e.options.speed = g.filter((f) =>
              e.config.speed.options.includes(f)
            )),
              e.supported.ui &&
                i.customControls &&
                e.media.setAttribute("tabindex", -1),
              y.call(e, e.media, "timeupdate"),
              y.call(e, e.media, "durationchange"),
              clearInterval(e.timers.buffering),
              (e.timers.buffering = setInterval(() => {
                (e.media.buffered = r.getVideoLoadedFraction()),
                  (e.media.lastBuffered === null ||
                    e.media.lastBuffered < e.media.buffered) &&
                    y.call(e, e.media, "progress"),
                  (e.media.lastBuffered = e.media.buffered),
                  e.media.buffered === 1 &&
                    (clearInterval(e.timers.buffering),
                    y.call(e, e.media, "canplaythrough"));
              }, 200)),
              i.customControls && setTimeout(() => S.build.call(e), 50);
          },
          onStateChange(l) {
            const r = l.target;
            switch (
              (clearInterval(e.timers.playing),
              e.media.seeking &&
                [1, 2].includes(l.data) &&
                ((e.media.seeking = !1), y.call(e, e.media, "seeked")),
              l.data)
            ) {
              case -1:
                y.call(e, e.media, "timeupdate"),
                  (e.media.buffered = r.getVideoLoadedFraction()),
                  y.call(e, e.media, "progress");
                break;
              case 0:
                Z.call(e, !1),
                  e.media.loop
                    ? (r.stopVideo(), r.playVideo())
                    : y.call(e, e.media, "ended");
                break;
              case 1:
                i.customControls &&
                !e.config.autoplay &&
                e.media.paused &&
                !e.embed.hasPlayed
                  ? e.media.pause()
                  : (Z.call(e, !0),
                    y.call(e, e.media, "playing"),
                    (e.timers.playing = setInterval(() => {
                      y.call(e, e.media, "timeupdate");
                    }, 50)),
                    e.media.duration !== r.getDuration() &&
                      ((e.media.duration = r.getDuration()),
                      y.call(e, e.media, "durationchange")));
                break;
              case 2:
                e.muted || e.embed.unMute(), Z.call(e, !1);
                break;
              case 3:
                y.call(e, e.media, "waiting");
            }
            y.call(e, e.elements.container, "statechange", !1, {
              code: l.data,
            });
          },
        },
      });
    },
  },
  pt = {
    setup() {
      this.media
        ? (k(
            this.elements.container,
            this.config.classNames.type.replace("{0}", this.type),
            !0
          ),
          k(
            this.elements.container,
            this.config.classNames.provider.replace("{0}", this.provider),
            !0
          ),
          this.isEmbed &&
            k(
              this.elements.container,
              this.config.classNames.type.replace("{0}", "video"),
              !0
            ),
          this.isVideo &&
            ((this.elements.wrapper = b("div", {
              class: this.config.classNames.video,
            })),
            st(this.media, this.elements.wrapper),
            (this.elements.poster = b("div", {
              class: this.config.classNames.poster,
            })),
            this.elements.wrapper.appendChild(this.elements.poster)),
          this.isHTML5
            ? W.setup.call(this)
            : this.isYouTube
            ? ce.setup.call(this)
            : this.isVimeo && Ee.setup.call(this))
        : this.debug.warn("No media element found!");
    },
  };
class yi {
  constructor(i) {
    d(this, "load", () => {
      this.enabled &&
        (o.object(window.google) && o.object(window.google.ima)
          ? this.ready()
          : Le(this.player.config.urls.googleIMA.sdk)
              .then(() => {
                this.ready();
              })
              .catch(() => {
                this.trigger(
                  "error",
                  new Error("Google IMA SDK failed to load")
                );
              }));
    }),
      d(this, "ready", () => {
        var t;
        this.enabled ||
          ((t = this).manager && t.manager.destroy(),
          t.elements.displayContainer && t.elements.displayContainer.destroy(),
          t.elements.container.remove()),
          this.startSafetyTimer(12e3, "ready()"),
          this.managerPromise.then(() => {
            this.clearSafetyTimer("onAdsManagerLoaded()");
          }),
          this.listeners(),
          this.setupIMA();
      }),
      d(this, "setupIMA", () => {
        (this.elements.container = b("div", {
          class: this.player.config.classNames.ads,
        })),
          this.player.elements.container.appendChild(this.elements.container),
          google.ima.settings.setVpaidMode(
            google.ima.ImaSdkSettings.VpaidMode.ENABLED
          ),
          google.ima.settings.setLocale(this.player.config.ads.language),
          google.ima.settings.setDisableCustomPlaybackForIOS10Plus(
            this.player.config.playsinline
          ),
          (this.elements.displayContainer = new google.ima.AdDisplayContainer(
            this.elements.container,
            this.player.media
          )),
          (this.loader = new google.ima.AdsLoader(
            this.elements.displayContainer
          )),
          this.loader.addEventListener(
            google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
            (t) => this.onAdsManagerLoaded(t),
            !1
          ),
          this.loader.addEventListener(
            google.ima.AdErrorEvent.Type.AD_ERROR,
            (t) => this.onAdError(t),
            !1
          ),
          this.requestAds();
      }),
      d(this, "requestAds", () => {
        const { container: t } = this.player.elements;
        try {
          const s = new google.ima.AdsRequest();
          (s.adTagUrl = this.tagUrl),
            (s.linearAdSlotWidth = t.offsetWidth),
            (s.linearAdSlotHeight = t.offsetHeight),
            (s.nonLinearAdSlotWidth = t.offsetWidth),
            (s.nonLinearAdSlotHeight = t.offsetHeight),
            (s.forceNonLinearFullSlot = !1),
            s.setAdWillPlayMuted(!this.player.muted),
            this.loader.requestAds(s);
        } catch (s) {
          this.onAdError(s);
        }
      }),
      d(this, "pollCountdown", (t = !1) => {
        if (!t)
          return (
            clearInterval(this.countdownTimer),
            void this.elements.container.removeAttribute("data-badge-text")
          );
        this.countdownTimer = setInterval(() => {
          const s = ge(Math.max(this.manager.getRemainingTime(), 0)),
            n = `${O.get("advertisement", this.player.config)} - ${s}`;
          this.elements.container.setAttribute("data-badge-text", n);
        }, 100);
      }),
      d(this, "onAdsManagerLoaded", (t) => {
        if (!this.enabled) return;
        const s = new google.ima.AdsRenderingSettings();
        (s.restoreCustomPlaybackStateOnAdBreakComplete = !0),
          (s.enablePreloading = !0),
          (this.manager = t.getAdsManager(this.player, s)),
          (this.cuePoints = this.manager.getCuePoints()),
          this.manager.addEventListener(
            google.ima.AdErrorEvent.Type.AD_ERROR,
            (n) => this.onAdError(n)
          ),
          Object.keys(google.ima.AdEvent.Type).forEach((n) => {
            this.manager.addEventListener(google.ima.AdEvent.Type[n], (a) =>
              this.onAdEvent(a)
            );
          }),
          this.trigger("loaded");
      }),
      d(this, "addCuePoints", () => {
        o.empty(this.cuePoints) ||
          this.cuePoints.forEach((t) => {
            if (t !== 0 && t !== -1 && t < this.player.duration) {
              const s = this.player.elements.progress;
              if (o.element(s)) {
                const n = (100 / this.player.duration) * t,
                  a = b("span", { class: this.player.config.classNames.cues });
                (a.style.left = `${n.toString()}%`), s.appendChild(a);
              }
            }
          });
      }),
      d(this, "onAdEvent", (t) => {
        const { container: s } = this.player.elements,
          n = t.getAd(),
          a = t.getAdData();
        switch (
          (((l) => {
            y.call(
              this.player,
              this.player.media,
              `ads${l.replace(/_/g, "").toLowerCase()}`
            );
          })(t.type),
          t.type)
        ) {
          case google.ima.AdEvent.Type.LOADED:
            this.trigger("loaded"),
              this.pollCountdown(!0),
              n.isLinear() ||
                ((n.width = s.offsetWidth), (n.height = s.offsetHeight));
            break;
          case google.ima.AdEvent.Type.STARTED:
            this.manager.setVolume(this.player.volume);
            break;
          case google.ima.AdEvent.Type.ALL_ADS_COMPLETED:
            this.player.ended ? this.loadAds() : this.loader.contentComplete();
            break;
          case google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED:
            this.pauseContent();
            break;
          case google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED:
            this.pollCountdown(), this.resumeContent();
            break;
          case google.ima.AdEvent.Type.LOG:
            a.adError &&
              this.player.debug.warn(
                `Non-fatal ad error: ${a.adError.getMessage()}`
              );
        }
      }),
      d(this, "onAdError", (t) => {
        this.cancel(), this.player.debug.warn("Ads error", t);
      }),
      d(this, "listeners", () => {
        const { container: t } = this.player.elements;
        let s;
        this.player.on("canplay", () => {
          this.addCuePoints();
        }),
          this.player.on("ended", () => {
            this.loader.contentComplete();
          }),
          this.player.on("timeupdate", () => {
            s = this.player.currentTime;
          }),
          this.player.on("seeked", () => {
            const n = this.player.currentTime;
            o.empty(this.cuePoints) ||
              this.cuePoints.forEach((a, l) => {
                s < a &&
                  a < n &&
                  (this.manager.discardAdBreak(), this.cuePoints.splice(l, 1));
              });
          }),
          window.addEventListener("resize", () => {
            this.manager &&
              this.manager.resize(
                t.offsetWidth,
                t.offsetHeight,
                google.ima.ViewMode.NORMAL
              );
          });
      }),
      d(this, "play", () => {
        const { container: t } = this.player.elements;
        this.managerPromise || this.resumeContent(),
          this.managerPromise
            .then(() => {
              this.manager.setVolume(this.player.volume),
                this.elements.displayContainer.initialize();
              try {
                this.initialized ||
                  (this.manager.init(
                    t.offsetWidth,
                    t.offsetHeight,
                    google.ima.ViewMode.NORMAL
                  ),
                  this.manager.start()),
                  (this.initialized = !0);
              } catch (s) {
                this.onAdError(s);
              }
            })
            .catch(() => {});
      }),
      d(this, "resumeContent", () => {
        (this.elements.container.style.zIndex = ""),
          (this.playing = !1),
          q(this.player.media.play());
      }),
      d(this, "pauseContent", () => {
        (this.elements.container.style.zIndex = 3),
          (this.playing = !0),
          this.player.media.pause();
      }),
      d(this, "cancel", () => {
        this.initialized && this.resumeContent(),
          this.trigger("error"),
          this.loadAds();
      }),
      d(this, "loadAds", () => {
        this.managerPromise
          .then(() => {
            this.manager && this.manager.destroy(),
              (this.managerPromise = new Promise((t) => {
                this.on("loaded", t), this.player.debug.log(this.manager);
              })),
              (this.initialized = !1),
              this.requestAds();
          })
          .catch(() => {});
      }),
      d(this, "trigger", (t, ...s) => {
        const n = this.events[t];
        o.array(n) &&
          n.forEach((a) => {
            o.function(a) && a.apply(this, s);
          });
      }),
      d(
        this,
        "on",
        (t, s) => (
          o.array(this.events[t]) || (this.events[t] = []),
          this.events[t].push(s),
          this
        )
      ),
      d(this, "startSafetyTimer", (t, s) => {
        this.player.debug.log(`Safety timer invoked from: ${s}`),
          (this.safetyTimer = setTimeout(() => {
            this.cancel(), this.clearSafetyTimer("startSafetyTimer()");
          }, t));
      }),
      d(this, "clearSafetyTimer", (t) => {
        o.nullOrUndefined(this.safetyTimer) ||
          (this.player.debug.log(`Safety timer cleared from: ${t}`),
          clearTimeout(this.safetyTimer),
          (this.safetyTimer = null));
      }),
      (this.player = i),
      (this.config = i.config.ads),
      (this.playing = !1),
      (this.initialized = !1),
      (this.elements = { container: null, displayContainer: null }),
      (this.manager = null),
      (this.loader = null),
      (this.cuePoints = null),
      (this.events = {}),
      (this.safetyTimer = null),
      (this.countdownTimer = null),
      (this.managerPromise = new Promise((t, s) => {
        this.on("loaded", t), this.on("error", s);
      })),
      this.load();
  }
  get enabled() {
    const { config: i } = this;
    return (
      this.player.isHTML5 &&
      this.player.isVideo &&
      i.enabled &&
      (!o.empty(i.publisherId) || o.url(i.tagUrl))
    );
  }
  get tagUrl() {
    const { config: i } = this;
    return o.url(i.tagUrl)
      ? i.tagUrl
      : `https://go.aniview.com/api/adserver6/vast/?${dt({
          AV_PUBLISHERID: "58c25bb0073ef448b1087ad6",
          AV_CHANNELID: "5a0458dc28a06145e4519d21",
          AV_URL: window.location.hostname,
          cb: Date.now(),
          AV_WIDTH: 640,
          AV_HEIGHT: 480,
          AV_CDIM2: i.publisherId,
        })}`;
  }
}
const bi = (e) => {
    const i = [];
    return (
      e.split(/\r\n\r\n|\n\n|\r\r/).forEach((t) => {
        const s = {};
        t.split(/\r\n|\n|\r/).forEach((n) => {
          if (o.number(s.startTime)) {
            if (!o.empty(n.trim()) && o.empty(s.text)) {
              const a = n.trim().split("#xywh=");
              ([s.text] = a), a[1] && ([s.x, s.y, s.w, s.h] = a[1].split(","));
            }
          } else {
            const a = n.match(
              /([0-9]{2})?:?([0-9]{2}):([0-9]{2}).([0-9]{2,3})( ?--> ?)([0-9]{2})?:?([0-9]{2}):([0-9]{2}).([0-9]{2,3})/
            );
            a &&
              ((s.startTime =
                60 * Number(a[1] || 0) * 60 +
                60 * Number(a[2]) +
                Number(a[3]) +
                +`0.${a[4]}`),
              (s.endTime =
                60 * Number(a[6] || 0) * 60 +
                60 * Number(a[7]) +
                Number(a[8]) +
                +`0.${a[9]}`));
          }
        }),
          s.text && i.push(s);
      }),
      i
    );
  },
  Be = (e, i) => {
    const t = {};
    return (
      e > i.width / i.height
        ? ((t.width = i.width), (t.height = (1 / e) * i.width))
        : ((t.height = i.height), (t.width = e * i.height)),
      t
    );
  };
class Pe {
  constructor(i) {
    d(this, "load", () => {
      this.player.elements.display.seekTooltip &&
        (this.player.elements.display.seekTooltip.hidden = this.enabled),
        this.enabled &&
          this.getThumbnails().then(() => {
            this.enabled &&
              (this.render(),
              this.determineContainerAutoSizing(),
              (this.loaded = !0));
          });
    }),
      d(
        this,
        "getThumbnails",
        () =>
          new Promise((t) => {
            const { src: s } = this.player.config.previewThumbnails;
            if (o.empty(s))
              throw new Error("Missing previewThumbnails.src config attribute");
            const n = () => {
              this.thumbnails.sort((a, l) => a.height - l.height),
                this.player.debug.log("Preview thumbnails", this.thumbnails),
                t();
            };
            if (o.function(s))
              s((a) => {
                (this.thumbnails = a), n();
              });
            else {
              const a = (o.string(s) ? [s] : s).map((l) =>
                this.getThumbnail(l)
              );
              Promise.all(a).then(n);
            }
          })
      ),
      d(
        this,
        "getThumbnail",
        (t) =>
          new Promise((s) => {
            ne(t).then((n) => {
              const a = { frames: bi(n), height: null, urlPrefix: "" };
              a.frames[0].text.startsWith("/") ||
                a.frames[0].text.startsWith("http://") ||
                a.frames[0].text.startsWith("https://") ||
                (a.urlPrefix = t.substring(0, t.lastIndexOf("/") + 1));
              const l = new Image();
              (l.onload = () => {
                (a.height = l.naturalHeight),
                  (a.width = l.naturalWidth),
                  this.thumbnails.push(a),
                  s();
              }),
                (l.src = a.urlPrefix + a.frames[0].text);
            });
          })
      ),
      d(this, "startMove", (t) => {
        if (
          this.loaded &&
          o.event(t) &&
          ["touchmove", "mousemove"].includes(t.type) &&
          this.player.media.duration
        ) {
          if (t.type === "touchmove")
            this.seekTime =
              this.player.media.duration *
              (this.player.elements.inputs.seek.value / 100);
          else {
            const s = this.player.elements.progress.getBoundingClientRect(),
              n = (100 / s.width) * (t.pageX - s.left);
            (this.seekTime = this.player.media.duration * (n / 100)),
              this.seekTime < 0 && (this.seekTime = 0),
              this.seekTime > this.player.media.duration - 1 &&
                (this.seekTime = this.player.media.duration - 1),
              (this.mousePosX = t.pageX),
              (this.elements.thumb.time.innerText = ge(this.seekTime));
          }
          this.showImageAtCurrentTime();
        }
      }),
      d(this, "endMove", () => {
        this.toggleThumbContainer(!1, !0);
      }),
      d(this, "startScrubbing", (t) => {
        (o.nullOrUndefined(t.button) || t.button === !1 || t.button === 0) &&
          ((this.mouseDown = !0),
          this.player.media.duration &&
            (this.toggleScrubbingContainer(!0),
            this.toggleThumbContainer(!1, !0),
            this.showImageAtCurrentTime()));
      }),
      d(this, "endScrubbing", () => {
        (this.mouseDown = !1),
          Math.ceil(this.lastTime) === Math.ceil(this.player.media.currentTime)
            ? this.toggleScrubbingContainer(!1)
            : Ie.call(this.player, this.player.media, "timeupdate", () => {
                this.mouseDown || this.toggleScrubbingContainer(!1);
              });
      }),
      d(this, "listeners", () => {
        this.player.on("play", () => {
          this.toggleThumbContainer(!1, !0);
        }),
          this.player.on("seeked", () => {
            this.toggleThumbContainer(!1);
          }),
          this.player.on("timeupdate", () => {
            this.lastTime = this.player.media.currentTime;
          });
      }),
      d(this, "render", () => {
        (this.elements.thumb.container = b("div", {
          class: this.player.config.classNames.previewThumbnails.thumbContainer,
        })),
          (this.elements.thumb.imageContainer = b("div", {
            class:
              this.player.config.classNames.previewThumbnails.imageContainer,
          })),
          this.elements.thumb.container.appendChild(
            this.elements.thumb.imageContainer
          );
        const t = b("div", {
          class: this.player.config.classNames.previewThumbnails.timeContainer,
        });
        (this.elements.thumb.time = b("span", {}, "00:00")),
          t.appendChild(this.elements.thumb.time),
          this.elements.thumb.container.appendChild(t),
          o.element(this.player.elements.progress) &&
            this.player.elements.progress.appendChild(
              this.elements.thumb.container
            ),
          (this.elements.scrubbing.container = b("div", {
            class:
              this.player.config.classNames.previewThumbnails
                .scrubbingContainer,
          })),
          this.player.elements.wrapper.appendChild(
            this.elements.scrubbing.container
          );
      }),
      d(this, "destroy", () => {
        this.elements.thumb.container && this.elements.thumb.container.remove(),
          this.elements.scrubbing.container &&
            this.elements.scrubbing.container.remove();
      }),
      d(this, "showImageAtCurrentTime", () => {
        this.mouseDown
          ? this.setScrubbingContainerSize()
          : this.setThumbContainerSizeAndPos();
        const t = this.thumbnails[0].frames.findIndex(
            (a) => this.seekTime >= a.startTime && this.seekTime <= a.endTime
          ),
          s = t >= 0;
        let n = 0;
        this.mouseDown || this.toggleThumbContainer(s),
          s &&
            (this.thumbnails.forEach((a, l) => {
              this.loadedImages.includes(a.frames[t].text) && (n = l);
            }),
            t !== this.showingThumb &&
              ((this.showingThumb = t), this.loadImage(n)));
      }),
      d(this, "loadImage", (t = 0) => {
        const s = this.showingThumb,
          n = this.thumbnails[t],
          { urlPrefix: a } = n,
          l = n.frames[s],
          r = n.frames[s].text,
          c = a + r;
        if (
          this.currentImageElement &&
          this.currentImageElement.dataset.filename === r
        )
          this.showImage(this.currentImageElement, l, t, s, r, !1),
            (this.currentImageElement.dataset.index = s),
            this.removeOldImages(this.currentImageElement);
        else {
          this.loadingImage &&
            this.usingSprites &&
            (this.loadingImage.onload = null);
          const h = new Image();
          (h.src = c),
            (h.dataset.index = s),
            (h.dataset.filename = r),
            (this.showingThumbFilename = r),
            this.player.debug.log(`Loading image: ${c}`),
            (h.onload = () => this.showImage(h, l, t, s, r, !0)),
            (this.loadingImage = h),
            this.removeOldImages(h);
        }
      }),
      d(this, "showImage", (t, s, n, a, l, r = !0) => {
        this.player.debug.log(
          `Showing thumb: ${l}. num: ${a}. qual: ${n}. newimg: ${r}`
        ),
          this.setImageSizeAndOffset(t, s),
          r &&
            (this.currentImageContainer.appendChild(t),
            (this.currentImageElement = t),
            this.loadedImages.includes(l) || this.loadedImages.push(l)),
          this.preloadNearby(a, !0)
            .then(this.preloadNearby(a, !1))
            .then(this.getHigherQuality(n, t, s, l));
      }),
      d(this, "removeOldImages", (t) => {
        Array.from(this.currentImageContainer.children).forEach((s) => {
          if (s.tagName.toLowerCase() !== "img") return;
          const n = this.usingSprites ? 500 : 1e3;
          if (s.dataset.index !== t.dataset.index && !s.dataset.deleting) {
            s.dataset.deleting = !0;
            const { currentImageContainer: a } = this;
            setTimeout(() => {
              a.removeChild(s),
                this.player.debug.log(`Removing thumb: ${s.dataset.filename}`);
            }, n);
          }
        });
      }),
      d(
        this,
        "preloadNearby",
        (t, s = !0) =>
          new Promise((n) => {
            setTimeout(() => {
              const a = this.thumbnails[0].frames[t].text;
              if (this.showingThumbFilename === a) {
                let l;
                l = s
                  ? this.thumbnails[0].frames.slice(t)
                  : this.thumbnails[0].frames.slice(0, t).reverse();
                let r = !1;
                l.forEach((c) => {
                  const h = c.text;
                  if (h !== a && !this.loadedImages.includes(h)) {
                    (r = !0),
                      this.player.debug.log(`Preloading thumb filename: ${h}`);
                    const { urlPrefix: g } = this.thumbnails[0],
                      f = g + h,
                      m = new Image();
                    (m.src = f),
                      (m.onload = () => {
                        this.player.debug.log(`Preloaded thumb filename: ${h}`),
                          this.loadedImages.includes(h) ||
                            this.loadedImages.push(h),
                          n();
                      });
                  }
                }),
                  r || n();
              }
            }, 300);
          })
      ),
      d(this, "getHigherQuality", (t, s, n, a) => {
        if (t < this.thumbnails.length - 1) {
          let l = s.naturalHeight;
          this.usingSprites && (l = n.h),
            l < this.thumbContainerHeight &&
              setTimeout(() => {
                this.showingThumbFilename === a &&
                  (this.player.debug.log(
                    `Showing higher quality thumb for: ${a}`
                  ),
                  this.loadImage(t + 1));
              }, 300);
        }
      }),
      d(this, "toggleThumbContainer", (t = !1, s = !1) => {
        const n =
          this.player.config.classNames.previewThumbnails.thumbContainerShown;
        this.elements.thumb.container.classList.toggle(n, t),
          !t &&
            s &&
            ((this.showingThumb = null), (this.showingThumbFilename = null));
      }),
      d(this, "toggleScrubbingContainer", (t = !1) => {
        const s =
          this.player.config.classNames.previewThumbnails
            .scrubbingContainerShown;
        this.elements.scrubbing.container.classList.toggle(s, t),
          t || ((this.showingThumb = null), (this.showingThumbFilename = null));
      }),
      d(this, "determineContainerAutoSizing", () => {
        (this.elements.thumb.imageContainer.clientHeight > 20 ||
          this.elements.thumb.imageContainer.clientWidth > 20) &&
          (this.sizeSpecifiedInCSS = !0);
      }),
      d(this, "setThumbContainerSizeAndPos", () => {
        if (this.sizeSpecifiedInCSS) {
          if (
            this.elements.thumb.imageContainer.clientHeight > 20 &&
            this.elements.thumb.imageContainer.clientWidth < 20
          ) {
            const t = Math.floor(
              this.elements.thumb.imageContainer.clientHeight *
                this.thumbAspectRatio
            );
            this.elements.thumb.imageContainer.style.width = `${t}px`;
          } else if (
            this.elements.thumb.imageContainer.clientHeight < 20 &&
            this.elements.thumb.imageContainer.clientWidth > 20
          ) {
            const t = Math.floor(
              this.elements.thumb.imageContainer.clientWidth /
                this.thumbAspectRatio
            );
            this.elements.thumb.imageContainer.style.height = `${t}px`;
          }
        } else {
          const t = Math.floor(
            this.thumbContainerHeight * this.thumbAspectRatio
          );
          (this.elements.thumb.imageContainer.style.height = `${this.thumbContainerHeight}px`),
            (this.elements.thumb.imageContainer.style.width = `${t}px`);
        }
        this.setThumbContainerPos();
      }),
      d(this, "setThumbContainerPos", () => {
        const t = this.player.elements.progress.getBoundingClientRect(),
          s = this.player.elements.container.getBoundingClientRect(),
          { container: n } = this.elements.thumb,
          a = s.left - t.left + 10,
          l = s.right - t.left - n.clientWidth - 10;
        let r = this.mousePosX - t.left - n.clientWidth / 2;
        r < a && (r = a), r > l && (r = l), (n.style.left = `${r}px`);
      }),
      d(this, "setScrubbingContainerSize", () => {
        const { width: t, height: s } = Be(this.thumbAspectRatio, {
          width: this.player.media.clientWidth,
          height: this.player.media.clientHeight,
        });
        (this.elements.scrubbing.container.style.width = `${t}px`),
          (this.elements.scrubbing.container.style.height = `${s}px`);
      }),
      d(this, "setImageSizeAndOffset", (t, s) => {
        if (!this.usingSprites) return;
        const n = this.thumbContainerHeight / s.h;
        (t.style.height = t.naturalHeight * n + "px"),
          (t.style.width = t.naturalWidth * n + "px"),
          (t.style.left = `-${s.x * n}px`),
          (t.style.top = `-${s.y * n}px`);
      }),
      (this.player = i),
      (this.thumbnails = []),
      (this.loaded = !1),
      (this.lastMouseMoveTime = Date.now()),
      (this.mouseDown = !1),
      (this.loadedImages = []),
      (this.elements = { thumb: {}, scrubbing: {} }),
      this.load();
  }
  get enabled() {
    return (
      this.player.isHTML5 &&
      this.player.isVideo &&
      this.player.config.previewThumbnails.enabled
    );
  }
  get currentImageContainer() {
    return this.mouseDown
      ? this.elements.scrubbing.container
      : this.elements.thumb.imageContainer;
  }
  get usingSprites() {
    return Object.keys(this.thumbnails[0].frames[0]).includes("w");
  }
  get thumbAspectRatio() {
    return this.usingSprites
      ? this.thumbnails[0].frames[0].w / this.thumbnails[0].frames[0].h
      : this.thumbnails[0].width / this.thumbnails[0].height;
  }
  get thumbContainerHeight() {
    if (this.mouseDown) {
      const { height: i } = Be(this.thumbAspectRatio, {
        width: this.player.media.clientWidth,
        height: this.player.media.clientHeight,
      });
      return i;
    }
    return this.sizeSpecifiedInCSS
      ? this.elements.thumb.imageContainer.clientHeight
      : Math.floor(this.player.media.clientWidth / this.thumbAspectRatio / 4);
  }
  get currentImageElement() {
    return this.mouseDown
      ? this.currentScrubbingImageElement
      : this.currentThumbnailImageElement;
  }
  set currentImageElement(i) {
    this.mouseDown
      ? (this.currentScrubbingImageElement = i)
      : (this.currentThumbnailImageElement = i);
  }
}
const Ae = {
  insertElements(e, i) {
    o.string(i)
      ? De(e, this.media, { src: i })
      : o.array(i) &&
        i.forEach((t) => {
          De(e, this.media, t);
        });
  },
  change(e) {
    it(e, "sources.length")
      ? (W.cancelRequests.call(this),
        this.destroy.call(
          this,
          () => {
            (this.options.quality = []),
              F(this.media),
              (this.media = null),
              o.element(this.elements.container) &&
                this.elements.container.removeAttribute("class");
            const { sources: i, type: t } = e,
              [{ provider: s = U.html5, src: n }] = i,
              a = s === "html5" ? t : "div",
              l = s === "html5" ? {} : { src: n };
            Object.assign(this, {
              provider: s,
              type: t,
              supported: M.check(t, s, this.config.playsinline),
              media: b(a, l),
            }),
              this.elements.container.appendChild(this.media),
              o.boolean(e.autoplay) && (this.config.autoplay = e.autoplay),
              this.isHTML5 &&
                (this.config.crossorigin &&
                  this.media.setAttribute("crossorigin", ""),
                this.config.autoplay && this.media.setAttribute("autoplay", ""),
                o.empty(e.poster) || (this.poster = e.poster),
                this.config.loop.active && this.media.setAttribute("loop", ""),
                this.config.muted && this.media.setAttribute("muted", ""),
                this.config.playsinline &&
                  this.media.setAttribute("playsinline", "")),
              S.addStyleHook.call(this),
              this.isHTML5 && Ae.insertElements.call(this, "source", i),
              (this.config.title = e.title),
              pt.setup.call(this),
              this.isHTML5 &&
                Object.keys(e).includes("tracks") &&
                Ae.insertElements.call(this, "track", e.tracks),
              (this.isHTML5 || (this.isEmbed && !this.supported.ui)) &&
                S.build.call(this),
              this.isHTML5 && this.media.load(),
              o.empty(e.previewThumbnails) ||
                (Object.assign(
                  this.config.previewThumbnails,
                  e.previewThumbnails
                ),
                this.previewThumbnails &&
                  this.previewThumbnails.loaded &&
                  (this.previewThumbnails.destroy(),
                  (this.previewThumbnails = null)),
                this.config.previewThumbnails.enabled &&
                  (this.previewThumbnails = new Pe(this))),
              this.fullscreen.update();
          },
          !0
        ))
      : this.debug.warn("Invalid source format");
  },
};
function vi(e = 0, i = 0, t = 255) {
  return Math.min(Math.max(e, i), t);
}
class ie {
  constructor(i, t) {
    if (
      (d(this, "play", () =>
        o.function(this.media.play)
          ? (this.ads &&
              this.ads.enabled &&
              this.ads.managerPromise
                .then(() => this.ads.play())
                .catch(() => q(this.media.play())),
            this.media.play())
          : null
      ),
      d(this, "pause", () =>
        this.playing && o.function(this.media.pause) ? this.media.pause() : null
      ),
      d(this, "togglePlay", (r) =>
        (o.boolean(r) ? r : !this.playing) ? this.play() : this.pause()
      ),
      d(this, "stop", () => {
        this.isHTML5
          ? (this.pause(), this.restart())
          : o.function(this.media.stop) && this.media.stop();
      }),
      d(this, "restart", () => {
        this.currentTime = 0;
      }),
      d(this, "rewind", (r) => {
        this.currentTime -= o.number(r) ? r : this.config.seekTime;
      }),
      d(this, "forward", (r) => {
        this.currentTime += o.number(r) ? r : this.config.seekTime;
      }),
      d(this, "increaseVolume", (r) => {
        const c = this.media.muted ? 0 : this.volume;
        this.volume = c + (o.number(r) ? r : 0);
      }),
      d(this, "decreaseVolume", (r) => {
        this.increaseVolume(-r);
      }),
      d(this, "airplay", () => {
        M.airplay && this.media.webkitShowPlaybackTargetPicker();
      }),
      d(this, "toggleControls", (r) => {
        if (this.supported.ui && !this.isAudio) {
          const c = ue(
              this.elements.container,
              this.config.classNames.hideControls
            ),
            h = r === void 0 ? void 0 : !r,
            g = k(
              this.elements.container,
              this.config.classNames.hideControls,
              h
            );
          if (
            (g &&
              o.array(this.config.controls) &&
              this.config.controls.includes("settings") &&
              !o.empty(this.config.settings) &&
              u.toggleMenu.call(this, !1),
            g !== c)
          ) {
            const f = g ? "controlshidden" : "controlsshown";
            y.call(this, this.media, f);
          }
          return !g;
        }
        return !1;
      }),
      d(this, "on", (r, c) => {
        T.call(this, this.elements.container, r, c);
      }),
      d(this, "once", (r, c) => {
        Ie.call(this, this.elements.container, r, c);
      }),
      d(this, "off", (r, c) => {
        pe(this.elements.container, r, c);
      }),
      d(this, "destroy", (r, c = !1) => {
        if (!this.ready) return;
        const h = () => {
          (document.body.style.overflow = ""),
            (this.embed = null),
            c
              ? (Object.keys(this.elements).length &&
                  (F(this.elements.buttons.play),
                  F(this.elements.captions),
                  F(this.elements.controls),
                  F(this.elements.wrapper),
                  (this.elements.buttons.play = null),
                  (this.elements.captions = null),
                  (this.elements.controls = null),
                  (this.elements.wrapper = null)),
                o.function(r) && r())
              : (Gt.call(this),
                W.cancelRequests.call(this),
                he(this.elements.original, this.elements.container),
                y.call(this, this.elements.original, "destroyed", !0),
                o.function(r) && r.call(this.elements.original),
                (this.ready = !1),
                setTimeout(() => {
                  (this.elements = null), (this.media = null);
                }, 200));
        };
        this.stop(),
          clearTimeout(this.timers.loading),
          clearTimeout(this.timers.controls),
          clearTimeout(this.timers.resized),
          this.isHTML5
            ? (S.toggleNativeControls.call(this, !0), h())
            : this.isYouTube
            ? (clearInterval(this.timers.buffering),
              clearInterval(this.timers.playing),
              this.embed !== null &&
                o.function(this.embed.destroy) &&
                this.embed.destroy(),
              h())
            : this.isVimeo &&
              (this.embed !== null && this.embed.unload().then(h),
              setTimeout(h, 200));
      }),
      d(this, "supports", (r) => M.mime.call(this, r)),
      (this.timers = {}),
      (this.ready = !1),
      (this.loading = !1),
      (this.failed = !1),
      (this.touch = M.touch),
      (this.media = i),
      o.string(this.media) &&
        (this.media = document.querySelectorAll(this.media)),
      ((window.jQuery && this.media instanceof jQuery) ||
        o.nodeList(this.media) ||
        o.array(this.media)) &&
        (this.media = this.media[0]),
      (this.config = I(
        {},
        mt,
        ie.defaults,
        t || {},
        (() => {
          try {
            return JSON.parse(this.media.getAttribute("data-plyr-config"));
          } catch {
            return {};
          }
        })()
      )),
      (this.elements = {
        container: null,
        fullscreen: null,
        captions: null,
        buttons: {},
        display: {},
        progress: {},
        inputs: {},
        settings: { popup: null, menu: null, panels: {}, buttons: {} },
      }),
      (this.captions = { active: null, currentTrack: -1, meta: new WeakMap() }),
      (this.fullscreen = { active: !1 }),
      (this.options = { speed: [], quality: [] }),
      (this.debug = new ci(this.config.debug)),
      this.debug.log("Config", this.config),
      this.debug.log("Support", M),
      o.nullOrUndefined(this.media) || !o.element(this.media))
    )
      return void this.debug.error("Setup failed: no suitable element passed");
    if (this.media.plyr) return void this.debug.warn("Target already setup");
    if (!this.config.enabled)
      return void this.debug.error("Setup failed: disabled by config");
    if (!M.check().api)
      return void this.debug.error("Setup failed: no support");
    const s = this.media.cloneNode(!0);
    (s.autoplay = !1), (this.elements.original = s);
    const n = this.media.tagName.toLowerCase();
    let a = null,
      l = null;
    switch (n) {
      case "div":
        if (((a = this.media.querySelector("iframe")), o.element(a))) {
          if (
            ((l = ut(a.getAttribute("src"))),
            (this.provider = ri(l.toString())),
            (this.elements.container = this.media),
            (this.media = a),
            (this.elements.container.className = ""),
            l.search.length)
          ) {
            const r = ["1", "true"];
            r.includes(l.searchParams.get("autoplay")) &&
              (this.config.autoplay = !0),
              r.includes(l.searchParams.get("loop")) &&
                (this.config.loop.active = !0),
              this.isYouTube
                ? ((this.config.playsinline = r.includes(
                    l.searchParams.get("playsinline")
                  )),
                  (this.config.youtube.hl = l.searchParams.get("hl")))
                : (this.config.playsinline = !0);
          }
        } else
          (this.provider = this.media.getAttribute(
            this.config.attributes.embed.provider
          )),
            this.media.removeAttribute(this.config.attributes.embed.provider);
        if (o.empty(this.provider) || !Object.values(U).includes(this.provider))
          return void this.debug.error("Setup failed: Invalid provider");
        this.type = be.video;
        break;
      case "video":
      case "audio":
        (this.type = n),
          (this.provider = U.html5),
          this.media.hasAttribute("crossorigin") &&
            (this.config.crossorigin = !0),
          this.media.hasAttribute("autoplay") && (this.config.autoplay = !0),
          (this.media.hasAttribute("playsinline") ||
            this.media.hasAttribute("webkit-playsinline")) &&
            (this.config.playsinline = !0),
          this.media.hasAttribute("muted") && (this.config.muted = !0),
          this.media.hasAttribute("loop") && (this.config.loop.active = !0);
        break;
      default:
        return void this.debug.error("Setup failed: unsupported type");
    }
    (this.supported = M.check(
      this.type,
      this.provider,
      this.config.playsinline
    )),
      this.supported.api
        ? ((this.eventListeners = []),
          (this.listeners = new hi(this)),
          (this.storage = new te(this)),
          (this.media.plyr = this),
          o.element(this.elements.container) ||
            ((this.elements.container = b("div", { tabindex: 0 })),
            st(this.media, this.elements.container)),
          S.migrateStyles.call(this),
          S.addStyleHook.call(this),
          pt.setup.call(this),
          this.config.debug &&
            T.call(
              this,
              this.elements.container,
              this.config.events.join(" "),
              (r) => {
                this.debug.log(`event: ${r.type}`);
              }
            ),
          (this.fullscreen = new H(this)),
          (this.isHTML5 || (this.isEmbed && !this.supported.ui)) &&
            S.build.call(this),
          this.listeners.container(),
          this.listeners.global(),
          this.config.ads.enabled && (this.ads = new yi(this)),
          this.isHTML5 &&
            this.config.autoplay &&
            this.once("canplay", () => q(this.play())),
          (this.lastSeekTime = 0),
          this.config.previewThumbnails.enabled &&
            (this.previewThumbnails = new Pe(this)))
        : this.debug.error("Setup failed: no support");
  }
  get isHTML5() {
    return this.provider === U.html5;
  }
  get isEmbed() {
    return this.isYouTube || this.isVimeo;
  }
  get isYouTube() {
    return this.provider === U.youtube;
  }
  get isVimeo() {
    return this.provider === U.vimeo;
  }
  get isVideo() {
    return this.type === be.video;
  }
  get isAudio() {
    return this.type === be.audio;
  }
  get playing() {
    return !!(this.ready && !this.paused && !this.ended);
  }
  get paused() {
    return !!this.media.paused;
  }
  get stopped() {
    return !!(this.paused && this.currentTime === 0);
  }
  get ended() {
    return !!this.media.ended;
  }
  set currentTime(i) {
    if (!this.duration) return;
    const t = o.number(i) && i > 0;
    (this.media.currentTime = t ? Math.min(i, this.duration) : 0),
      this.debug.log(`Seeking to ${this.currentTime} seconds`);
  }
  get currentTime() {
    return Number(this.media.currentTime);
  }
  get buffered() {
    const { buffered: i } = this.media;
    return o.number(i)
      ? i
      : i && i.length && this.duration > 0
      ? i.end(0) / this.duration
      : 0;
  }
  get seeking() {
    return !!this.media.seeking;
  }
  get duration() {
    const i = parseFloat(this.config.duration),
      t = (this.media || {}).duration,
      s = o.number(t) && t !== 1 / 0 ? t : 0;
    return i || s;
  }
  set volume(i) {
    let t = i;
    o.string(t) && (t = Number(t)),
      o.number(t) || (t = this.storage.get("volume")),
      o.number(t) || ({ volume: t } = this.config),
      t > 1 && (t = 1),
      t < 0 && (t = 0),
      (this.config.volume = t),
      (this.media.volume = t),
      !o.empty(i) && this.muted && t > 0 && (this.muted = !1);
  }
  get volume() {
    return Number(this.media.volume);
  }
  set muted(i) {
    let t = i;
    o.boolean(t) || (t = this.storage.get("muted")),
      o.boolean(t) || (t = this.config.muted),
      (this.config.muted = t),
      (this.media.muted = t);
  }
  get muted() {
    return !!this.media.muted;
  }
  get hasAudio() {
    return (
      !this.isHTML5 ||
      !!this.isAudio ||
      !!this.media.mozHasAudio ||
      !!this.media.webkitAudioDecodedByteCount ||
      !!(this.media.audioTracks && this.media.audioTracks.length)
    );
  }
  set speed(i) {
    let t = null;
    o.number(i) && (t = i),
      o.number(t) || (t = this.storage.get("speed")),
      o.number(t) || (t = this.config.speed.selected);
    const { minimumSpeed: s, maximumSpeed: n } = this;
    (t = vi(t, s, n)),
      (this.config.speed.selected = t),
      setTimeout(() => {
        this.media && (this.media.playbackRate = t);
      }, 0);
  }
  get speed() {
    return Number(this.media.playbackRate);
  }
  get minimumSpeed() {
    return this.isYouTube
      ? Math.min(...this.options.speed)
      : this.isVimeo
      ? 0.5
      : 0.0625;
  }
  get maximumSpeed() {
    return this.isYouTube
      ? Math.max(...this.options.speed)
      : this.isVimeo
      ? 2
      : 16;
  }
  set quality(i) {
    const t = this.config.quality,
      s = this.options.quality;
    if (!s.length) return;
    let n = [
        !o.empty(i) && Number(i),
        this.storage.get("quality"),
        t.selected,
        t.default,
      ].find(o.number),
      a = !0;
    if (!s.includes(n)) {
      const l = nt(s, n);
      this.debug.warn(`Unsupported quality option: ${n}, using ${l} instead`),
        (n = l),
        (a = !1);
    }
    (t.selected = n),
      (this.media.quality = n),
      a && this.storage.set({ quality: n });
  }
  get quality() {
    return this.media.quality;
  }
  set loop(i) {
    const t = o.boolean(i) ? i : this.config.loop.active;
    (this.config.loop.active = t), (this.media.loop = t);
  }
  get loop() {
    return !!this.media.loop;
  }
  set source(i) {
    Ae.change.call(this, i);
  }
  get source() {
    return this.media.currentSrc;
  }
  get download() {
    const { download: i } = this.config.urls;
    return o.url(i) ? i : this.source;
  }
  set download(i) {
    o.url(i) && ((this.config.urls.download = i), u.setDownloadUrl.call(this));
  }
  set poster(i) {
    this.isVideo
      ? S.setPoster.call(this, i, !1).catch(() => {})
      : this.debug.warn("Poster can only be set for video");
  }
  get poster() {
    return this.isVideo
      ? this.media.getAttribute("poster") ||
          this.media.getAttribute("data-poster")
      : null;
  }
  get ratio() {
    if (!this.isVideo) return null;
    const i = de(xe.call(this));
    return o.array(i) ? i.join(":") : i;
  }
  set ratio(i) {
    this.isVideo
      ? o.string(i) && ot(i)
        ? ((this.config.ratio = de(i)), X.call(this))
        : this.debug.error(`Invalid aspect ratio specified (${i})`)
      : this.debug.warn("Aspect ratio can only be set for video");
  }
  set autoplay(i) {
    const t = o.boolean(i) ? i : this.config.autoplay;
    this.config.autoplay = t;
  }
  get autoplay() {
    return !!this.config.autoplay;
  }
  toggleCaptions(i) {
    A.toggle.call(this, i, !1);
  }
  set currentTrack(i) {
    A.set.call(this, i, !1), A.setup();
  }
  get currentTrack() {
    const { toggled: i, currentTrack: t } = this.captions;
    return i ? t : -1;
  }
  set language(i) {
    A.setLanguage.call(this, i, !1);
  }
  get language() {
    return (A.getCurrentTrack.call(this) || {}).language;
  }
  set pip(i) {
    if (!M.pip) return;
    const t = o.boolean(i) ? i : !this.pip;
    o.function(this.media.webkitSetPresentationMode) &&
      this.media.webkitSetPresentationMode(t ? ye.active : ye.inactive),
      o.function(this.media.requestPictureInPicture) &&
        (!this.pip && t
          ? this.media.requestPictureInPicture()
          : this.pip && !t && document.exitPictureInPicture());
  }
  get pip() {
    return M.pip
      ? o.empty(this.media.webkitPresentationMode)
        ? this.media === document.pictureInPictureElement
        : this.media.webkitPresentationMode === ye.active
      : null;
  }
  setPreviewThumbnails(i) {
    this.previewThumbnails &&
      this.previewThumbnails.loaded &&
      (this.previewThumbnails.destroy(), (this.previewThumbnails = null)),
      Object.assign(this.config.previewThumbnails, i),
      this.config.previewThumbnails.enabled &&
        (this.previewThumbnails = new Pe(this));
  }
  static supported(i, t, s) {
    return M.check(i, t, s);
  }
  static loadSprite(i, t) {
    return ct(i, t);
  }
  static setup(i, t = {}) {
    let s = null;
    return (
      o.string(i)
        ? (s = Array.from(document.querySelectorAll(i)))
        : o.nodeList(i)
        ? (s = Array.from(i))
        : o.array(i) && (s = i.filter(o.element)),
      o.empty(s) ? null : s.map((n) => new ie(n, t))
    );
  }
}
ie.defaults = Yt(mt);
const wi = Object.freeze(
    Object.defineProperty(
      { __proto__: null, default: ie },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  Ti = Ue(() =>
    Se(
      () => import("./play-0d51a982.js"),
      ["./play-0d51a982.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  ki = Ue(() =>
    Se(
      () => import("./close-9703a3f7.js"),
      ["./close-9703a3f7.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  oe = "brandhub-video-playback",
  Ci = "brandhub-video-pause",
  Ei = "brandhub-video-close",
  Pi = "playback-ended",
  Ai = "close-fullscreen",
  Oi = ft({
    name: "VideoPlayer",
    props: {
      showControls: { type: Boolean, default: !0 },
      showControlsNative: Boolean,
      isPlaying: Boolean,
      playMuted: Boolean,
      autoPlay: Boolean,
      playLooped: Boolean,
      playOnHover: Boolean,
      playOnMount: Boolean,
      playOnIntersect: Boolean,
      preloadVideo: String,
      desktopVideo: String,
      tabletVideo: String,
      mobileVideo: String,
      posterImage: String,
      tabindex: String,
      posterImageObject: Object,
      withOverlay: Boolean,
      videoLength: String,
    },
    data() {
      return {
        videoPlayer: null,
        plyrOptions: {
          loadSprite: !1,
          controls: [],
          hideControls: !this.showControls,
          muted: !1,
        },
        showPosterImage: !1,
        showVideo: !1,
        showOverlay: !this.playOnIntersect,
      };
    },
    directives: { intersect: kt },
    components: { ResponsiveImage: bt, IconPlay: Ti, IconClose: ki },
    mixins: [wt],
    watch: {
      isPlaying(e) {
        e ? this.play() : this.pause();
      },
    },
    computed: {
      videoSource() {
        return this.mobileVideo && this.isMobile
          ? this.mobileVideo
          : this.tabletVideo && this.isTablet
          ? this.tabletVideo
          : this.desktopVideo
          ? this.desktopVideo
          : "";
      },
      startMuted() {
        return (
          this.playMuted ||
          this.autoPlay ||
          this.playOnHover ||
          this.playOnIntersect
        );
      },
    },
    methods: {
      async play(e = !1) {
        this.videoPlayerRef &&
          (await this.handleBlockingBrowsers(),
          e && (this.videoPlayerRef.currentTime = 0),
          await this.videoPlayerRef.play());
      },
      pause() {
        this.videoPlayerRef && this.videoPlayerRef.pause();
      },
      handleMouseEnter() {
        this.playOnHover && this.play();
      },
      handleMouseLeave() {
        this.playOnHover && this.pause();
      },
      handleIntersectChange(e) {
        e && (this.playOnIntersect || this.autoPlay)
          ? this.play()
          : e || this.pause();
      },
      dispatchPlayEvent() {
        !this.autoPlay &&
          !this.playOnHover &&
          !this.playOnIntersect &&
          window.dispatchEvent(
            new CustomEvent(oe, { detail: this.videoPlayerRef })
          );
      },
      dispatchPauseEvent() {
        this.$el.dispatchEvent(
          new CustomEvent(Ci, { bubbles: !0, composed: !0, detail: this })
        );
      },
      endedPlaying() {
        this.$emit(Pi);
      },
      pauseVideo(e) {
        !this.autoPlay &&
          e &&
          this.videoPlayer &&
          this.videoPlayerRef !== e.detail &&
          this.pause();
      },
      muteVideo() {
        this.videoPlayerRef && (this.videoPlayerRef.muted = !0);
      },
      unmuteVideo() {
        this.videoPlayerRef && (this.videoPlayerRef.muted = !1);
      },
      onPlayButtonClick() {
        this.$el.dispatchEvent(
          new CustomEvent(oe, {
            bubbles: !0,
            composed: !0,
            detail: this.videoPlayerRef,
          })
        ),
          (this.showOverlay = !1),
          this.play();
      },
      onCloseButtonClick() {
        this.$el.dispatchEvent(
          new CustomEvent(Ei, {
            bubbles: !0,
            composed: !0,
            detail: this.videoPlayerRef,
          })
        ),
          (this.showOverlay = !0),
          this.pause();
      },
      async canAutoplay() {
        return Promise.resolve()
          .then(() => new Promise((e) => setTimeout(() => e(), 500)))
          .then(() => yt.video({ inline: !0, muted: !0 }));
      },
      async handleBlockingBrowsers() {
        if (!this.posterImage && !this.posterImageObject) {
          this.showVideo = !0;
          return;
        }
        if (!this.videoSource && this.image) {
          (this.showVideo = !1),
            (this.showPosterImage = !0),
            (this.image.loadingTriggered = !0);
          return;
        }
        this.canAutoplay().then((e) => {
          e.error && e.error.name === "NotAllowedError" && this.image
            ? ((this.showPosterImage = !0), (this.image.loadingTriggered = !0))
            : ((this.showVideo = !0), (this.showPosterImage = !1));
        });
      },
    },
    setup() {
      const e = $e(),
        i = $e();
      return { videoPlayerRef: e, image: i };
    },
    mounted() {
      window.addEventListener(oe, this.pauseVideo),
        this.videoPlayerRef !== void 0 &&
          vt.getInstance().addNewVideo(this.videoPlayerRef),
        this.handleBlockingBrowsers(),
        this.showControls &&
          (this.plyrOptions.controls = [
            "play",
            "progress",
            "current-time",
            "duration",
            "mute",
            "volume",
            "fullscreen",
          ]),
        this.playOnMount && this.play(),
        window.innerWidth <= Tt &&
          this.videoPlayerRef !== void 0 &&
          this.videoPlayerRef.addEventListener(
            "webkitendfullscreen",
            () => {
              this.$emit(Ai);
            },
            { passive: !0 }
          ),
        this.showControls &&
          Se(
            () => Promise.resolve().then(() => wi),
            void 0,
            import.meta.url
          ).then((i) => {
            if (this.videoPlayerRef === void 0) return;
            const t = i.default;
            (this.videoPlayer = new t(this.videoPlayerRef, this.plyrOptions)),
              this.startMuted && (this.videoPlayer.muted = !0),
              this.autoPlay && this.videoPlayer.play();
          });
    },
    unmounted() {
      window.removeEventListener(oe, this.pauseVideo);
    },
  });
export { oe as V, Oi as _, Ci as a, Ei as b, Pi as c, Ai as d };
