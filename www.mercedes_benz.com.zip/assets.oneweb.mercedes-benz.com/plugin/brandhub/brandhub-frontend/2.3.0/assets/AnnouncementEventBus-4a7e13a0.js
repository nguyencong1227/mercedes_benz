import { i as s } from "./i18next-3def9235.js";
import { m as c } from "./mitt-f7ef348c.js";
const n = "Search",
  o = "Search for...",
  r = "Close Search",
  t = "Show more",
  a = "No results found.",
  u = "Provider/Privacy",
  m = "Jump to navigation",
  h = "Jump to content",
  i = "Jump to footer",
  d = "Menu",
  l = "Close",
  p = "Privacy notice",
  b = "Search",
  M = {
    search: n,
    searchplaceholder: o,
    closesearch: r,
    showmore: t,
    noresults: a,
    privacy: u,
    jumptoheader: m,
    jumptocontent: h,
    jumptofooter: i,
    menu: d,
    close: l,
    privacynotice: p,
    "art-and-culture": "Art & Culture",
    "mercedes-benz": "Mercedes-Benz",
    "mercedes-amg": "Mercedes-AMG",
    "mercedes-maybach": "Mercedes-Maybach",
    "g-class": "G-Class",
    "mercedes-eq": "Mercedes-EQ",
    "mercedes-benz-classic": "Mercedes-Benz Classic",
    "mercedes-benz-museum": "Mercedes-Benz Museum",
    "mercedes-benz-energy": "Mercedes-Benz Energy",
    searchbutton: b,
  },
  y = "Suche",
  g = "Suchen nach...",
  z = "Suche schließen",
  f = "Mehr Ergebnisse",
  v = "Keine Ergebnisse gefunden.",
  $ = "Anbieter/Datenschutz",
  j = "Zur Navigation springen",
  C = "Zu Inhalten springen",
  S = "Zum Footer springen",
  A = "Menü",
  B = "Schließen",
  E = "Anbieter",
  w = "Suchen",
  I = {
    search: y,
    searchplaceholder: g,
    closesearch: z,
    showmore: f,
    noresults: v,
    privacy: $,
    jumptoheader: j,
    jumptocontent: C,
    jumptofooter: S,
    menu: A,
    close: B,
    privacynotice: E,
    "art-and-culture": "Art & Culture",
    "mercedes-benz": "Mercedes-Benz",
    "mercedes-amg": "Mercedes-AMG",
    "mercedes-maybach": "Mercedes-Maybach",
    "g-class": "G-Class",
    "mercedes-eq": "Mercedes-EQ",
    "mercedes-benz-classic": "Mercedes-Benz Classic",
    "mercedes-benz-museum": "Mercedes-Benz Museum",
    "mercedes-benz-energy": "Mercedes-Benz Energy",
    searchbutton: w,
  };
function J() {
  const e = s.createInstance();
  return (
    e.init({
      lng:
        document.body.dataset.analyticsLanguage ||
        {}.VUE_APP_I18N_LOCALE ||
        "en",
      resources: { en: { translation: M }, de: { translation: I } },
    }),
    e
  );
}
var P = ((e) => (
  (e.FocusInteractable = "focus-interactable"),
  (e.FocusCloseButton = "focus-close-button"),
  e
))(P || {});
const L = c();
export { L as A, P as a, J as u };
