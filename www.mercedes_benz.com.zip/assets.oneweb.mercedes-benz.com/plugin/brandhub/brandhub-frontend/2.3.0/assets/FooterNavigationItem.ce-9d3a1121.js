import { _ as s } from "./FooterNavigationItem.ce.vue_vue_type_script_lang-53762bb6.js";
import { L as I } from "./FooterNavigationItem.ce.vue_vue_type_script_lang-53762bb6.js";
import { _ as l } from "./_plugin-vue_export-helper-c27b6911.js";
import { o as i, c as n, h as r, t as a } from "./index.js";
import "./TrackingPushService-374dd83c.js";
const b = `.brandhub-footer-navigation-item{background:none;border:none;color:#9f9f9f;font:inherit;font-size:1rem;line-height:1.5714285714rem;padding:0;text-decoration:none;transition:color .4s ease-in-out;white-space:nowrap}.brandhub-footer-navigation-item:hover{color:var(--text-color);cursor:pointer}.brandhub-footer-navigation-item:focus-visible{outline:none}.brandhub-footer-navigation-item:focus-visible .brandhub-footer-navigation-item__text{position:relative}.brandhub-footer-navigation-item:focus-visible .brandhub-footer-navigation-item__text:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-footer-navigation-item:focus-visible .brandhub-footer-navigation-item__text:after{left:-.5rem;padding-right:.5rem;top:-.1428571429rem}
`,
  f = { class: "brandhub-footer-navigation-item__text" },
  d = ["title", "href", "target", "rel"],
  m = { class: "brandhub-footer-navigation-item__text" };
function g(o, t, u, p, h, c) {
  return o.legalActionName
    ? (i(),
      n(
        "button",
        {
          key: 0,
          class: "brandhub-footer-navigation-item",
          onClick: t[0] || (t[0] = (...e) => o.onClick && o.onClick(...e)),
        },
        [r("span", f, a(o.linkText), 1)]
      ))
    : (i(),
      n(
        "a",
        {
          key: 1,
          class: "brandhub-footer-navigation-item",
          title: o.linkTitle,
          href: o.linkUrl,
          target: o.linkTarget,
          rel: o.linkTarget === "_blank" ? "noopener" : void 0,
          onClick:
            t[1] || (t[1] = (...e) => o.onItemClick && o.onItemClick(...e)),
        },
        [r("span", m, a(o.linkText), 1)],
        8,
        d
      ));
}
const y = l(s, [
  ["render", g],
  ["styles", [b]],
]);
export { I as LEGAL_LINK_CLICKED_EVENT, y as default };
