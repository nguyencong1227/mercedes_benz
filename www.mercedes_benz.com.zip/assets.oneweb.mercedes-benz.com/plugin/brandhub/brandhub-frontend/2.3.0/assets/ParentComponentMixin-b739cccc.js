var l = Object.defineProperty;
var s = (e, t, n) =>
  t in e
    ? l(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n })
    : (e[t] = n);
var o = (e, t, n) => (s(e, typeof t != "symbol" ? t + "" : t, n), n);
import { S as h } from "./ShadowDom-bc0a555e.js";
import { d } from "./index.js";
class m {
  constructor() {
    o(this, "items", []);
  }
  get length() {
    return this.items.length;
  }
  push(...t) {
    return this.items.push(...t);
  }
  get(t) {
    return t >= 0 && t < this.items.length ? this.items[t] : null;
  }
  first() {
    return this.items.length > 0 ? this.items[0] : null;
  }
  last() {
    return this.items.length > 0 ? this.items[this.items.length - 1] : null;
  }
  cleanUp() {
    const t = [];
    return (
      this.items.forEach((n, i) => {
        h.isInDocument(n.$el) || (this.items.splice(i), t.push(n));
      }),
      t
    );
  }
  toArray() {
    return this.items;
  }
  filter(t, n) {
    return this.items.filter(t, n);
  }
  forEach(t, n) {
    this.items.forEach(t, n);
  }
}
const C = d({
  data() {
    return {
      initParentComponentMixinCalled: !1,
      childComponentCollection: new m(),
      childComponentNames: [],
      childAddedCallback: null,
      childRemovedCallback: null,
    };
  },
  methods: {
    initParentComponentMixin(e, t, n, i) {
      (this.initParentComponentMixinCalled = !0),
        (this.childComponentCollection = e),
        (this.childComponentNames = t),
        (this.childAddedCallback = n || null),
        (this.childRemovedCallback = i || null);
    },
    onChildComponentMounted(e) {
      if (e instanceof CustomEvent && e.detail.item) {
        const t = e.detail.item;
        this.childComponentCollection.cleanUp().forEach((i) => {
          this.childRemovedCallback && this.childRemovedCallback(i);
        }),
          (t.index = this.childComponentCollection.length),
          this.childComponentCollection.push(t),
          this.childAddedCallback && this.childAddedCallback(t);
      }
    },
  },
  mounted() {
    this.initParentComponentMixinCalled ||
      console.error(
        "ParentComponentMixin not correctly initialized yet! Please add initParentComponentMixin() call in the created() method of your parent component."
      ),
      this.childComponentNames.forEach((e) => {
        this.$el
          .getRootNode()
          .addEventListener(
            `childComponentMounted_${e}`,
            this.onChildComponentMounted,
            { passive: !0 }
          );
      });
  },
  unmounted() {
    this.childComponentNames.forEach((e) => {
      this.$el
        .getRootNode()
        .removeEventListener(
          `childComponentMounted_${e}`,
          this.onChildComponentMounted
        );
    });
  },
});
export { m as C, C as P };
