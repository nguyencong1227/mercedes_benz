import {
  d as m,
  i as A,
  a as w,
  _ as h,
  r as g,
  o as a,
  c as o,
  h as l,
  F as b,
  b as u,
  k as f,
  n as p,
  M as v,
  e as n,
  B as d,
  f as y,
} from "./index.js";
import "./swiper-bundle.esm-fb150913.js";
import { P as B, C } from "./ParentComponentMixin-b739cccc.js";
import Y from "./VerticalGalleryItem.ce-aafc5839.js";
import { R as x } from "./ResizeUpdateMixin-a56b9b41.js";
import { S as E } from "./core-class-d6f76cb6.js";
import { _ } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ShadowDom-bc0a555e.js";
import "./ChildComponentMixin-dd022493.js";
import "./ResponsiveImage-0ce28426.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./index-12214b95.js";
import "./VideoPlayer-b44c2dc6.js";
import "./VideoPlayer.vue_vue_type_script_lang-ca49a257.js";
import "./can-autoplay.es-4e207aef.js";
import "./VideoPauseHandler-61c3b0c3.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const k = w(() =>
    h(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  G = m({
    name: "VerticalGallery",
    props: {
      headline: String,
      headlineTag: { type: String, default: "h2" },
      bigHeadline: { type: Boolean, default: !1 },
      copy: String,
      backgroundColor: { type: String, default: "primary" },
    },
    components: { VerticalGalleryItem: Y, WordFade: k },
    mixins: [B, x],
    data() {
      return {
        items: new C(),
        swiper: null,
        swiperOptions: {
          slidesPerView: 1,
          spaceBetween: 15,
          on: { slideChange: this.updateActiveClass },
        },
        swiperIndex: 0,
        activeClass: "brandhub-vertical-gallery-item--active",
      };
    },
    setup() {
      const e = A(),
        i = A(),
        r = A();
      return { itemsSlot: i, itemsSlotDesktop: r, swiperElement: e };
    },
    computed: {
      rootModifierClasses() {
        return {
          "brandhub-vertical-gallery--primary":
            this.backgroundColor === "primary",
          "brandhub-vertical-gallery--inverted":
            this.backgroundColor === "inverted",
          "brandhub-vertical-gallery--theme": this.backgroundColor === "theme",
          "brandhub-vertical-gallery--ipad":
            document.documentElement.classList.contains("isIPad"),
        };
      },
      mobileView() {
        return this.windowWidth < 768;
      },
    },
    methods: {
      updated() {
        this.initSlider();
      },
      initSlider() {
        var e;
        if (this.mobileView && !this.swiper && this.swiperElement) {
          this.swiper = new E(this.swiperElement, this.swiperOptions);
          const i =
            (e = this.itemsSlot) == null ? void 0 : e.assignedElements();
          i == null ||
            i.forEach((r) => {
              var t;
              (t = this.swiper) == null || t.appendSlide(r);
            });
        } else
          !this.mobileView &&
            this.swiper &&
            (this.swiper.destroy(), (this.swiper = null));
      },
      onItemAdded(e) {
        this.items.length === 1 && e.$el.classList.add(this.activeClass);
      },
      updateActiveClass() {
        this.swiper &&
          (this.items.items[this.swiperIndex].$el.classList.remove(
            this.activeClass
          ),
          this.items.items[this.swiper.activeIndex].$el.classList.add(
            this.activeClass
          ),
          (this.swiperIndex = this.swiper.activeIndex));
      },
    },
    created() {
      this.initParentComponentMixin(
        this.items,
        ["VerticalGalleryItem"],
        this.onItemAdded
      );
    },
    mounted() {
      this.initSlider(),
        this.$nextTick(() => {
          var i, r;
          const e = this.isMobile
            ? (i = this.itemsSlot) == null
              ? void 0
              : i.assignedElements()
            : (r = this.itemsSlotDesktop) == null
            ? void 0
            : r.assignedElements();
          e == null ||
            e.forEach((t) => {
              const s = t.firstElementChild;
              this.backgroundColor &&
                s.localName === "brandhub-vertical-gallery-item" &&
                s.setAttribute("background-color", this.backgroundColor);
            });
        });
    },
  }),
  M = `@font-face{font-family:swiper-icons;src:url(data:application/font-woff;charset=utf-8;base64,\\ d09GRgABAAAAAAZgABAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAGRAAAABoAAAAci6qHkUdERUYAAAWgAAAAIwAAACQAYABXR1BPUwAABhQAAAAuAAAANuAY7+xHU1VCAAAFxAAAAFAAAABm2fPczU9TLzIAAAHcAAAASgAAAGBP9V5RY21hcAAAAkQAAACIAAABYt6F0cBjdnQgAAACzAAAAAQAAAAEABEBRGdhc3AAAAWYAAAACAAAAAj//wADZ2x5ZgAAAywAAADMAAAD2MHtryVoZWFkAAABbAAAADAAAAA2E2+eoWhoZWEAAAGcAAAAHwAAACQC9gDzaG10eAAAAigAAAAZAAAArgJkABFsb2NhAAAC0AAAAFoAAABaFQAUGG1heHAAAAG8AAAAHwAAACAAcABAbmFtZQAAA/gAAAE5AAACXvFdBwlwb3N0AAAFNAAAAGIAAACE5s74hXjaY2BkYGAAYpf5Hu/j+W2+MnAzMYDAzaX6QjD6/4//Bxj5GA8AuRwMYGkAPywL13jaY2BkYGA88P8Agx4j+/8fQDYfA1AEBWgDAIB2BOoAeNpjYGRgYNBh4GdgYgABEMnIABJzYNADCQAACWgAsQB42mNgYfzCOIGBlYGB0YcxjYGBwR1Kf2WQZGhhYGBiYGVmgAFGBiQQkOaawtDAoMBQxXjg/wEGPcYDDA4wNUA2CCgwsAAAO4EL6gAAeNpj2M0gyAACqxgGNWBkZ2D4/wMA+xkDdgAAAHjaY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQrMOgyWDLEM1T9/w8UBfEMgLzE////P/5//f/V/xv+r4eaAAeMbAxwIUYmIMHEgKYAYjUcsDAwsLKxc3BycfPw8jEQA/gZBASFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTQZBgMAAMR+E+gAEQFEAAAAKgAqACoANAA+AEgAUgBcAGYAcAB6AIQAjgCYAKIArAC2AMAAygDUAN4A6ADyAPwBBgEQARoBJAEuATgBQgFMAVYBYAFqAXQBfgGIAZIBnAGmAbIBzgHsAAB42u2NMQ6CUAyGW568x9AneYYgm4MJbhKFaExIOAVX8ApewSt4Bic4AfeAid3VOBixDxfPYEza5O+Xfi04YADggiUIULCuEJK8VhO4bSvpdnktHI5QCYtdi2sl8ZnXaHlqUrNKzdKcT8cjlq+rwZSvIVczNiezsfnP/uznmfPFBNODM2K7MTQ45YEAZqGP81AmGGcF3iPqOop0r1SPTaTbVkfUe4HXj97wYE+yNwWYxwWu4v1ugWHgo3S1XdZEVqWM7ET0cfnLGxWfkgR42o2PvWrDMBSFj/IHLaF0zKjRgdiVMwScNRAoWUoH78Y2icB/yIY09An6AH2Bdu/UB+yxopYshQiEvnvu0dURgDt8QeC8PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA) format("woff");font-weight:400;font-style:normal}:root{--swiper-theme-color: #007aff}.swiper-container{margin-left:auto;margin-right:auto;position:relative;overflow:hidden;list-style:none;padding:0;z-index:1}.swiper-container-vertical>.swiper-wrapper{flex-direction:column}.swiper-wrapper{position:relative;width:100%;height:100%;z-index:1;display:flex;transition-property:transform;box-sizing:content-box}.swiper-container-android .swiper-slide,.swiper-wrapper{transform:translateZ(0)}.swiper-container-multirow>.swiper-wrapper{flex-wrap:wrap}.swiper-container-multirow-column>.swiper-wrapper{flex-wrap:wrap;flex-direction:column}.swiper-container-free-mode>.swiper-wrapper{transition-timing-function:ease-out;margin:0 auto}.swiper-container-pointer-events{touch-action:pan-y}.swiper-container-pointer-events.swiper-container-vertical{touch-action:pan-x}.swiper-slide{flex-shrink:0;width:100%;height:100%;position:relative;transition-property:transform}.swiper-slide-invisible-blank{visibility:hidden}.swiper-container-autoheight,.swiper-container-autoheight .swiper-slide{height:auto}.swiper-container-autoheight .swiper-wrapper{align-items:flex-start;transition-property:transform,height}.swiper-container-3d{perspective:1200px}.swiper-container-3d .swiper-wrapper,.swiper-container-3d .swiper-slide,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-cube-shadow{transform-style:preserve-3d}.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-slide-shadow-bottom{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:10}.swiper-container-3d .swiper-slide-shadow-left{background-image:linear-gradient(to left,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-right{background-image:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-top{background-image:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-bottom{background-image:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-css-mode>.swiper-wrapper{overflow:auto;scrollbar-width:none;-ms-overflow-style:none}.swiper-container-css-mode>.swiper-wrapper::-webkit-scrollbar{display:none}.swiper-container-css-mode>.swiper-wrapper>.swiper-slide{scroll-snap-align:start start}.swiper-container-horizontal.swiper-container-css-mode>.swiper-wrapper{scroll-snap-type:x mandatory}.swiper-container-vertical.swiper-container-css-mode>.swiper-wrapper{scroll-snap-type:y mandatory}.brandhub-vertical-gallery{--background-color: var(--wb-black);--text-color: var(--wb-white);background:var(--background-color);overflow:hidden}.brandhub-vertical-gallery--inverted{--background-color: var(--wb-white);--text-color: var(--wb-black);color:var(--wb-grey-20)}.brandhub-vertical-gallery--ipad .brandhub-vertical-gallery__item{display:inline-block}.brandhub-vertical-gallery--theme{--background-color: var(--campaign-gradient);--text-color: var(--campaign-text);--custom-button-hover-color: var(--wb-black);color:var(--campaign-text)}@media (max-width: 767px){.brandhub-vertical-gallery__wrapper{margin:0 auto;max-width:calc(90% - 30px);width:calc(90% - 30px)}}.brandhub-vertical-gallery__content{column-count:2;column-gap:10vw;column-gap:10%}@media (max-width: 479px){.brandhub-vertical-gallery__content{column-count:1}}@media (max-width: 767px){.brandhub-vertical-gallery__content{margin:0 auto;max-width:calc(90% - 30px);width:calc(90% - 30px)}}@media (min-width: 768px){.brandhub-vertical-gallery__content{margin-top:10.7142857143rem}}@media (min-width: 1024px){.brandhub-vertical-gallery__content{margin-top:21.4285714286rem}}.brandhub-vertical-gallery__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;display:block;font-size:2.8571428571rem;line-height:1em;margin:4.2857142857rem 0 0}.brandhub-vertical-gallery__headline--big{font-size:3.7142857143rem}.brandhub-vertical-gallery__copy{font-family:MBCorpo Text,sans-serif;font-size:1.4285714286rem;line-height:1.8571428571rem;margin-top:1rem}@media (min-width: 768px) and (max-width: 1439px){.brandhub-vertical-gallery__copy{font-size:1.2857142857rem;line-height:1.7142857143rem}}@media (min-width: 1680px){.brandhub-vertical-gallery__copy{font-size:1.7142857143rem;line-height:2.1428571429rem}}.brandhub-vertical-gallery__copy p{margin:0}.brandhub-vertical-gallery__slider{margin-bottom:4rem;margin-top:3.5714285714rem;overflow:visible}
`,
  I = { class: "brandhub-vertical-gallery__wrapper" },
  Q = ["innerHTML"],
  D = ["options"],
  P = { class: "swiper-wrapper" },
  z = { key: 1, class: "brandhub-vertical-gallery__content" };
function N(e, i, r, t, s, S) {
  const c = g("word-fade");
  return (
    a(),
    o(
      "div",
      { class: p(["brandhub-vertical-gallery", e.rootModifierClasses]) },
      [
        l("div", I, [
          e.mobileView
            ? (a(),
              o(
                b,
                { key: 0 },
                [
                  e.headline
                    ? (a(),
                      u(
                        v(e.headlineTag),
                        {
                          key: 0,
                          class: p([
                            "brandhub-vertical-gallery__headline",
                            {
                              "brandhub-vertical-gallery__headline--big":
                                e.bigHeadline,
                            },
                          ]),
                        },
                        {
                          default: f(() => [
                            y(
                              c,
                              {
                                "animated-text": e.headline,
                                "text-align": "left",
                              },
                              null,
                              8,
                              ["animated-text"]
                            ),
                          ]),
                          _: 1,
                        },
                        8,
                        ["class"]
                      ))
                    : n("", !0),
                  e.copy
                    ? (a(),
                      o(
                        "div",
                        {
                          key: 1,
                          class: "brandhub-vertical-gallery__copy",
                          innerHTML: e.copy,
                        },
                        null,
                        8,
                        Q
                      ))
                    : n("", !0),
                  l(
                    "div",
                    {
                      class:
                        "brandhub-vertical-gallery__slider swiper-container",
                      options: e.swiperOptions,
                      ref: "swiperElement",
                    },
                    [
                      l("div", P, [
                        d(e.$slots, "default", {
                          ref: "itemsSlot",
                          backgroundColor: e.backgroundColor,
                        }),
                      ]),
                    ],
                    8,
                    D
                  ),
                ],
                64
              ))
            : n("", !0),
          e.mobileView
            ? n("", !0)
            : (a(),
              o("div", z, [
                d(e.$slots, "default", { ref: "itemsSlotDesktop" }),
              ])),
        ]),
      ],
      2
    )
  );
}
const re = _(G, [
  ["render", N],
  ["styles", [M]],
]);
export { re as default };
