import { c as d } from "./bodyScrollLock.esm-5a01fb3c.js";
import { d as s, i as c, o as u, c as l, h as m, B as h } from "./index.js";
import { _ as g } from "./_plugin-vue_export-helper-c27b6911.js";
const f = s({
    name: "HeaderAnnouncement",
    setup() {
      return { announcement: c() };
    },
    data() {
      return {
        cookieBanner: document.querySelector("cmm-cookie-banner"),
        cookieBannerVisible: !1,
        cookieBannerContent: null,
      };
    },
    methods: {
      ariaHideUnderlyingElements(e) {
        const n = document.querySelector(".root.parsys"),
          t = document.querySelector(".footer");
        e
          ? (n.setAttribute("aria-hidden", "true"),
            t.setAttribute("aria-hidden", "true"))
          : (n.removeAttribute("aria-hidden"),
            t.removeAttribute("aria-hidden"));
      },
      toggleAriaHiddenCookieBanner() {
        const e = document.querySelector(".header");
        this.cookieBannerVisible
          ? e.setAttribute("aria-hidden", "true")
          : e.removeAttribute("aria-hidden");
      },
      async onConsentsLoaded() {
        var n;
        const e = await ((n = this.cookieBanner) == null
          ? void 0
          : n.getConsentsByCategory());
        e == null ||
          e.find((t) => {
            var o, r;
            return (
              t.slug === "essential" &&
                !t.userAccepted &&
                ((this.cookieBannerContent =
                  (r =
                    (o = this.cookieBanner) == null ? void 0 : o.shadowRoot) ==
                  null
                    ? void 0
                    : r.querySelector(".cmm-cookie-banner__content")),
                (this.cookieBannerVisible = !0),
                this.toggleAriaHiddenCookieBanner()),
              !0
            );
          });
      },
      focusLogo() {
        var e, n, t;
        this.cookieBannerVisible
          ? ((t = (
              (n = (
                (e = this.cookieBannerContent) == null
                  ? void 0
                  : e.querySelector(
                      ".cmm-languages-list__item.wb-button-group-item"
                    )
              ).shadowRoot) == null
                ? void 0
                : n.firstChild
            ).shadowRoot) == null
              ? void 0
              : t.querySelector("button")
            ).focus()
          : this.$emit("header-announcement-focus-logo");
      },
      onCookieBannerClosed() {
        (this.cookieBannerVisible = !1), this.toggleAriaHiddenCookieBanner();
      },
      closeOverlay() {
        d(),
          this.ariaHideUnderlyingElements(!1),
          setTimeout(() => {
            this.$emit("header-announcement-close");
          }, 1e3);
      },
    },
    mounted() {
      document.addEventListener(
        "usercentrics-consents-loaded",
        this.onConsentsLoaded
      ),
        document.addEventListener(
          "usercentrics-consents-updated",
          this.onCookieBannerClosed
        ),
        this.ariaHideUnderlyingElements(!0);
    },
  }),
  p = `.brandhub-header-announcement{box-sizing:border-box;display:flex;overflow-x:hidden;overflow-y:hidden;position:fixed;top:var(--menu-height);width:100%;z-index:100}.brandhub-header-announcement__container{padding-left:1.1428571429rem;padding-right:1.1428571429rem;overflow-y:auto;width:100%}@media (min-width: 768px){.brandhub-header-announcement__container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-header-announcement__container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-header-announcement__container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-header-announcement__container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}
`,
  b = { class: "brandhub-header-announcement", ref: "announcement" };
function B(e, n, t, o, r, i) {
  return (
    u(),
    l(
      "div",
      b,
      [
        m(
          "div",
          {
            class: "brandhub-header-announcement__container",
            onHeaderAnnouncementContentFocusLogo:
              n[0] || (n[0] = (...a) => e.focusLogo && e.focusLogo(...a)),
            onHeaderAnnouncementContentClose:
              n[1] || (n[1] = (...a) => e.closeOverlay && e.closeOverlay(...a)),
          },
          [h(e.$slots, "default")],
          32
        ),
      ],
      512
    )
  );
}
const C = g(f, [
  ["render", B],
  ["styles", [p]],
]);
export { C as default };
