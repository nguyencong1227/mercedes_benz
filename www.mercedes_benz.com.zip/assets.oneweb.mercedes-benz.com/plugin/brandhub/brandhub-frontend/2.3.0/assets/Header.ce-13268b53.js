import {
  d as Z,
  i as l,
  a as S,
  _ as y,
  r as u,
  o as c,
  c as $,
  h as n,
  t as i,
  B as h,
  f as A,
  n as j,
  C as J,
  G as Y,
  k as g,
  b as N,
  e as _,
  w as se,
  v as le,
  g as he,
} from "./index.js";
import { d as de, e as H } from "./bodyScrollLock.esm-5a01fb3c.js";
import { c as ue } from "./can-autoplay.es-4e207aef.js";
import be from "./ResponsiveImage-0ce28426.js";
import { R as ce } from "./ResizeUpdateMixin-a56b9b41.js";
import { T as F } from "./TrackingPushService-374dd83c.js";
import { J as U, a as G } from "./JumpToEventBus-9bec3b36.js";
import { m as me } from "./mitt-f7ef348c.js";
import { L as ge } from "./FooterNavigationItem.ce.vue_vue_type_script_lang-53762bb6.js";
import { u as _e, A as K, a as q } from "./AnnouncementEventBus-4a7e13a0.js";
import { _ as Q } from "./_plugin-vue_export-helper-c27b6911.js";
import { V as s } from "./VideoPauseHandler-61c3b0c3.js";
var O = ((e) => (
  (e.FocusInput = "focus-input"), (e.FocusCloseButton = "focus-close-button"), e
))(O || {});
const R = me(),
  pe = S(() =>
    y(
      () => import("./search-new-c7c929c5.js"),
      ["./search-new-c7c929c5.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  ve = S(() =>
    y(
      () => import("./arrow-right-9ff753e0.js"),
      ["./arrow-right-9ff753e0.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  fe = Z({
    name: "MetaNavigation",
    props: {
      menuOpen: Boolean,
      searchOpen: Boolean,
      announcementOpen: Boolean,
      privacyActionName: String,
    },
    components: { SearchIcon: pe, ArrowRightIcon: ve },
    setup() {
      const e = l(),
        { t } = _e();
      return { searchCloseButton: e, t };
    },
    data() {
      return { fadeIn: !1, loginOpen: !1 };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-meta-navigation--in": this.fadeIn,
          "brandhub-meta-navigation--search-open": this.searchOpen,
          "brandhub-meta-navigation--menu-open": this.menuOpen,
          "brandhub-meta-navigation--announcement-open": this.announcementOpen,
        };
      },
      loginClass() {
        return {
          "brandhub-meta-navigation__item-button--login-open": this.loginOpen,
        };
      },
    },
    methods: {
      onLegalLinkClick() {
        window.dispatchEvent(
          new CustomEvent(ge, { detail: this.privacyActionName })
        ),
          F.pushTrackingAttributes(
            "link",
            "Meta Navigation",
            this.privacyActionName
          );
      },
      onJumpToNavigationClick() {
        U.emit(G.JumpToNavigation);
      },
      onJumpToFooterClick() {
        U.emit(G.JumpToFooter);
      },
      onSearchClicked() {
        this.$emit("search-clicked"),
          F.pushTrackingAttributes("link", "Meta Navigation", "search flyout");
      },
      onLoginClicked() {
        this.loginOpen = !this.loginOpen;
        const e = new CustomEvent("loginClicked", {
          bubbles: !0,
          composed: !0,
        });
        this.$el.dispatchEvent(e),
          F.pushTrackingAttributes("link", "Meta Navigation", "login flyout");
      },
      onMenuClick() {
        this.$emit("mobile-menu-toggle");
      },
      focusCloseButton() {
        var e;
        (e = this.searchCloseButton) == null || e.focus();
      },
      handleSearchCloseButtonTab() {
        R.emit(O.FocusInput);
      },
    },
    mounted() {
      R.on(O.FocusCloseButton, this.focusCloseButton),
        setTimeout(() => {
          this.fadeIn = !0;
        }, 25);
      const e = window.document.querySelector(".root");
      e && (e.id = "content");
    },
  }),
  Se = `.brandhub-meta-navigation{height:4.5714285714rem;overflow:hidden;padding:0 1.7142857143rem;position:relative;transition:transform .8s var(--ease-out-expo);z-index:5}@media (min-width: 768px){.brandhub-meta-navigation{padding:0 2.5rem}}@media (min-width: 1024px){.brandhub-meta-navigation{height:5.1428571429rem}}.brandhub-meta-navigation__mobile{opacity:0;pointer-events:none;transform:translateY(-2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out;align-items:center;color:#9f9f9f;display:flex;height:4.5714285714rem;justify-content:space-between;transition:transform .8s var(--ease-out-expo) var(--fade-in-delay),opacity .8s ease-out var(--fade-in-delay)}.brandhub-meta-navigation--in .brandhub-meta-navigation__mobile{opacity:1;pointer-events:auto;transform:translateY(0)}@media (min-width: 1024px){.brandhub-meta-navigation__mobile{display:none}}.brandhub-meta-navigation__items{font-size:.8571428571rem}.brandhub-meta-navigation__items{opacity:0;pointer-events:none;transform:translateY(-2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out;display:flex;gap:3.5714285714rem;list-style:none;margin:0;padding:1.7142857143rem 0 0;transition:transform .8s var(--ease-out-expo) var(--fade-in-delay),opacity .8s ease-out var(--fade-in-delay)}.brandhub-meta-navigation--in .brandhub-meta-navigation__items{opacity:1;pointer-events:auto;transform:translateY(0)}@media (max-width: 1023px){.brandhub-meta-navigation__items{display:none}}.brandhub-meta-navigation--announcement-open .brandhub-meta-navigation__items,.brandhub-meta-navigation--search-open .brandhub-meta-navigation__items{opacity:0;transform:translate3d(0,-100%,0)}.brandhub-meta-navigation__item{color:#9f9f9f;transition:color .25s}.brandhub-meta-navigation__item:hover{color:var(--wb-white)}.brandhub-meta-navigation__item--language-switch{align-items:center;display:flex}.brandhub-meta-navigation__item--privacy-notice{margin-right:auto}@media (max-width: 1023px){.brandhub-meta-navigation__item--privacy-notice{background-color:var(--wb-black);display:flex;justify-content:center;padding:1.7142857143rem 0}}.brandhub-meta-navigation__item--skip-to-button:not(:focus-within){border:0;clip:rect(1px,1px,1px,1px);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute!important;width:1px}@media (max-width: 1023px){.brandhub-meta-navigation__item--skip-to-button{background-color:var(--wb-black);display:flex;justify-content:center;padding:1.7142857143rem 0}}.brandhub-meta-navigation__item-button{align-items:center;background:transparent;border:none;color:currentColor;cursor:pointer;display:flex;font:inherit;justify-content:flex-start;line-height:inherit;min-height:1.1em;min-width:3.5714285714rem;padding:.0714285714rem .2857142857rem;position:relative;text-decoration:none;transition:color .25s}.brandhub-meta-navigation__item-button:focus-visible{position:relative;color:var(--wb-white);outline:none}.brandhub-meta-navigation__item-button:focus-visible:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-meta-navigation__item-button:focus-visible:after{left:-.1428571429rem;top:-.1428571429rem}.brandhub-meta-navigation__item-button--login-open{color:var(--wb-white)}.brandhub-meta-navigation__item-button--login-open .brandhub-meta-navigation__login-icon{transform:rotate(270deg)}.brandhub-meta-navigation__item-button--mobile-menu,.brandhub-meta-navigation__item-button--mobile-search{font-size:1.1428571429rem}.brandhub-meta-navigation__item-button--mobile-search{min-width:10.7142857143rem}.brandhub-meta-navigation__item-button--mobile-menu{justify-content:flex-end}.brandhub-meta-navigation__item-button-text{transition:transform .5s,opacity .5s}.brandhub-meta-navigation--menu-open .brandhub-meta-navigation__item-button--mobile-menu .brandhub-meta-navigation__item-button-text--close,.brandhub-meta-navigation--search-open .brandhub-meta-navigation__item-button--mobile-search .brandhub-meta-navigation__item-button-text--close,.brandhub-meta-navigation--announcement-open .brandhub-meta-navigation__item-button--mobile-announcement .brandhub-meta-navigation__item-button-text--close,.brandhub-meta-navigation__item-button-text--open{opacity:1;transform:translateZ(0)}.brandhub-meta-navigation--menu-open .brandhub-meta-navigation__item-button--mobile-menu .brandhub-meta-navigation__item-button-text--open,.brandhub-meta-navigation--search-open .brandhub-meta-navigation__item-button--mobile-search .brandhub-meta-navigation__item-button-text--open,.brandhub-meta-navigation--announcement-open .brandhub-meta-navigation__item-button--mobile-announcement .brandhub-meta-navigation__item-button-text--open,.brandhub-meta-navigation__item-button-text--close{opacity:0}.brandhub-meta-navigation--menu-open .brandhub-meta-navigation__item-button--mobile-menu .brandhub-meta-navigation__item-button-text--open,.brandhub-meta-navigation--search-open .brandhub-meta-navigation__item-button--mobile-search .brandhub-meta-navigation__item-button-text--open,.brandhub-meta-navigation--announcement-open .brandhub-meta-navigation__item-button--mobile-announcement .brandhub-meta-navigation__item-button-text--open{transform:translate3d(0,-75%,0)}.brandhub-meta-navigation__item-button-text--close{color:var(--wb-white);position:absolute;transform:translate3d(0,75%,0)}.brandhub-meta-navigation__search-icon{color:currentColor;height:1.1428571429rem;position:relative;width:1.1428571429rem}.brandhub-meta-navigation__login-icon{height:1.1428571429rem;margin-left:.2857142857rem;transform:rotate(90deg);width:1.1428571429rem}
`,
  ye = { class: "brandhub-meta-navigation__items" },
  ke = {
    class:
      "brandhub-meta-navigation__item brandhub-meta-navigation__item--skip-to-button",
  },
  we = {
    class:
      "brandhub-meta-navigation__item brandhub-meta-navigation__item--skip-to-button",
  },
  Ce = { class: "brandhub-meta-navigation__item-button", href: "#content" },
  Le = {
    class:
      "brandhub-meta-navigation__item brandhub-meta-navigation__item--skip-to-button",
  },
  Te = {
    class:
      "brandhub-meta-navigation__item brandhub-meta-navigation__item--language-switch",
  },
  Ee = {
    class:
      "brandhub-meta-navigation__item brandhub-meta-navigation__item--privacy-notice",
  },
  Ae = { class: "brandhub-meta-navigation__item" },
  Oe = { class: "brandhub-meta-navigation__item" },
  Ne = n("span", null, "Login", -1),
  Me = { class: "brandhub-meta-navigation__mobile" },
  Be = {
    class:
      "brandhub-meta-navigation__item-button brandhub-meta-navigation__item--skip-to-button",
    href: "#content",
  },
  Ie = {
    class:
      "brandhub-meta-navigation__item-button-text brandhub-meta-navigation__item-button-text--open",
  },
  Pe = {
    class:
      "brandhub-meta-navigation__item-button-text brandhub-meta-navigation__item-button-text--close",
  },
  $e = {
    class:
      "brandhub-meta-navigation__item-button-text brandhub-meta-navigation__item-button-text--open",
  },
  Fe = {
    class:
      "brandhub-meta-navigation__item-button-text brandhub-meta-navigation__item-button-text--close",
  };
function Re(e, t, o, m, V, D) {
  const C = u("search-icon"),
    L = u("arrow-right-icon");
  return (
    c(),
    $(
      "div",
      { class: j(["brandhub-meta-navigation", e.rootClass]) },
      [
        n("ul", ye, [
          n("li", ke, [
            n(
              "button",
              {
                class: "brandhub-meta-navigation__item-button",
                onClick:
                  t[0] ||
                  (t[0] = (...a) =>
                    e.onJumpToNavigationClick &&
                    e.onJumpToNavigationClick(...a)),
              },
              i(e.t("jumptoheader")),
              1
            ),
          ]),
          n("li", we, [n("a", Ce, i(e.t("jumptocontent")), 1)]),
          n("li", Le, [
            n(
              "button",
              {
                class: "brandhub-meta-navigation__item-button",
                onClick:
                  t[1] ||
                  (t[1] = (...a) =>
                    e.onJumpToFooterClick && e.onJumpToFooterClick(...a)),
              },
              i(e.t("jumptofooter")),
              1
            ),
          ]),
          n("li", Te, [h(e.$slots, "default")]),
          n("li", Ee, [
            n(
              "button",
              {
                class: "brandhub-meta-navigation__item-button",
                onClick:
                  t[2] ||
                  (t[2] = (...a) =>
                    e.onLegalLinkClick && e.onLegalLinkClick(...a)),
              },
              i(e.t("privacy")),
              1
            ),
          ]),
          n("li", Ae, [
            n(
              "button",
              {
                class:
                  "brandhub-meta-navigation__item-button brandhub-meta-navigation__item-button--search",
                onClick:
                  t[3] ||
                  (t[3] = (...a) =>
                    e.onSearchClicked && e.onSearchClicked(...a)),
              },
              [
                n("span", null, i(e.t("search")), 1),
                A(C, { class: "brandhub-meta-navigation__search-icon" }),
              ]
            ),
          ]),
          n("li", Oe, [
            n(
              "button",
              {
                class: j([
                  "brandhub-meta-navigation__item-button brandhub-meta-navigation__item-button--login",
                  e.loginClass,
                ]),
                onClick:
                  t[4] ||
                  (t[4] = (...a) => e.onLoginClicked && e.onLoginClicked(...a)),
              },
              [Ne, A(L, { class: "brandhub-meta-navigation__login-icon" })],
              2
            ),
          ]),
        ]),
        n("div", Me, [
          n(
            "button",
            {
              class:
                "brandhub-meta-navigation__item-button brandhub-meta-navigation__item--skip-to-button",
              onClick:
                t[5] ||
                (t[5] = (...a) =>
                  e.onJumpToNavigationClick && e.onJumpToNavigationClick(...a)),
            },
            i(e.t("jumptoheader")),
            1
          ),
          n("a", Be, i(e.t("jumptocontent")), 1),
          n(
            "button",
            {
              class:
                "brandhub-meta-navigation__item-button brandhub-meta-navigation__item--skip-to-button",
              onClick:
                t[6] ||
                (t[6] = (...a) =>
                  e.onJumpToFooterClick && e.onJumpToFooterClick(...a)),
            },
            i(e.t("jumptofooter")),
            1
          ),
          n(
            "button",
            {
              class:
                "brandhub-meta-navigation__item-button brandhub-meta-navigation__item-button--mobile-search",
              onClick:
                t[7] ||
                (t[7] = (...a) => e.onSearchClicked && e.onSearchClicked(...a)),
              onKeydown:
                t[8] ||
                (t[8] = J(
                  Y(
                    (...a) =>
                      e.handleSearchCloseButtonTab &&
                      e.handleSearchCloseButtonTab(...a),
                    ["shift", "prevent"]
                  ),
                  ["tab"]
                )),
              ref: "searchCloseButton",
            },
            [
              n("span", Ie, i(e.t("search")), 1),
              n("span", Pe, i(e.t("closesearch")), 1),
            ],
            544
          ),
          n(
            "button",
            {
              class:
                "brandhub-meta-navigation__item-button brandhub-meta-navigation__item-button--mobile-menu",
              onClick:
                t[9] || (t[9] = (...a) => e.onMenuClick && e.onMenuClick(...a)),
            },
            [
              n("span", $e, i(e.t("menu")), 1),
              n("span", Fe, i(e.t("close")), 1),
            ]
          ),
        ]),
      ],
      2
    )
  );
}
const Ve = Q(fe, [
    ["render", Re],
    ["styles", [Se]],
  ]),
  De = S(() =>
    y(
      () => import("./HeaderMobileMenu-6ccc1cf9.js"),
      [
        "./HeaderMobileMenu-6ccc1cf9.js",
        "./index.js",
        "./index.css",
        "./bodyScrollLock.esm-5a01fb3c.js",
        "./JumpToEventBus-9bec3b36.js",
        "./mitt-f7ef348c.js",
        "./SubNavigation-2cee1e12.js",
        "./TrackingPushService-374dd83c.js",
        "./_plugin-vue_export-helper-c27b6911.js",
        "./HeaderFlyoutContent-d480d6d7.js",
        "./LoginFlyout-b0dd4eaf.js",
        "./FooterNavigationItem.ce.vue_vue_type_script_lang-53762bb6.js",
        "./AnnouncementEventBus-4a7e13a0.js",
        "./i18next-3def9235.js",
      ],
      import.meta.url
    )
  ),
  He = S(() =>
    y(
      () => import("./HeaderFlyout-6a2027cc.js"),
      [
        "./HeaderFlyout-6a2027cc.js",
        "./JumpToEventBus-9bec3b36.js",
        "./mitt-f7ef348c.js",
        "./SubNavigation-2cee1e12.js",
        "./index.js",
        "./index.css",
        "./TrackingPushService-374dd83c.js",
        "./_plugin-vue_export-helper-c27b6911.js",
        "./HeaderFlyoutContent-d480d6d7.js",
      ],
      import.meta.url
    )
  ),
  xe = S(() =>
    y(
      () => import("./HeaderAnnouncement-8499bd37.js"),
      [
        "./HeaderAnnouncement-8499bd37.js",
        "./bodyScrollLock.esm-5a01fb3c.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  ze = S(() =>
    y(
      () => import("./Search-0c292165.js"),
      [
        "./Search-0c292165.js",
        "./index.js",
        "./index.css",
        "./bodyScrollLock.esm-5a01fb3c.js",
        "./HeaderFlyoutImageItem.ce-17155541.js",
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./_plugin-vue_export-helper-c27b6911.js",
        "./TrackingPushService-374dd83c.js",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./ResizeUpdateMixin-a56b9b41.js",
        "./debounce-af874a22.js",
        "./_commonjsHelpers-725317a4.js",
        "./RelaunchButton-7fb95406.js",
        "./RelaunchButton.vue_vue_type_script_lang-6c2d2d7e.js",
        "./AnnouncementEventBus-4a7e13a0.js",
        "./i18next-3def9235.js",
        "./mitt-f7ef348c.js",
        "./can-autoplay.es-4e207aef.js",
        "./ResponsiveImage-0ce28426.js",
        "./JumpToEventBus-9bec3b36.js",
        "./FooterNavigationItem.ce.vue_vue_type_script_lang-53762bb6.js",
        "./VideoPauseHandler-61c3b0c3.js",
        "./ShadowDom-bc0a555e.js",
      ],
      import.meta.url
    )
  ),
  je = S(() =>
    y(
      () => import("./LoginFlyout-b0dd4eaf.js"),
      [
        "./LoginFlyout-b0dd4eaf.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  X = 288,
  d = 25,
  ee = 25,
  te = 840,
  ne = 660,
  p = "large",
  v = "scrolling",
  M = "snap",
  B = "snap-back",
  r = "scroll-down",
  k = "scroll-up",
  w = "flyout-open",
  W = "flyout-close",
  E = "announcement-open",
  x = "announcement-close",
  b = "menu-open",
  Je = "menu-close",
  f = "search-open",
  z = "search-close",
  I = "switch-to-search",
  P = "switch-to-menu",
  Ye = Z({
    name: "BrandhubHeader",
    props: {
      logoJson: String,
      logoLink: String,
      logoDescription: String,
      logoVideo: String,
      showLarge: Boolean,
      privacyActionName: String,
      searchApiEndpoint: String,
    },
    components: {
      HeaderFlyoutDynamic: He,
      HeaderAnnouncementDynamic: xe,
      HeaderMobileMenuDynamic: De,
      MetaNavigation: Ve,
      ResponsiveImage: be,
      SearchDynamic: ze,
      LoginFlyout: je,
    },
    mixins: [ce],
    setup() {
      const e = l(),
        t = l(),
        o = l(),
        m = l(),
        V = l(),
        D = l(),
        C = l(),
        L = l(),
        a = l();
      return {
        headerFlyout: e,
        headerAnnouncement: t,
        headerAnnouncementSlot: o,
        mobileMenu: m,
        search: V,
        metaNavigation: D,
        videoPlayer: C,
        headerLink: L,
        loginFlyout: a,
      };
    },
    data() {
      return {
        scrollPos: window.scrollY,
        scrollProgress: 0,
        activeMainNavItem: null,
        showVideo: !1,
        canShowVideo: !1,
        showLogo: !0,
        scrolledBackTimer: null,
        scrollState: r,
        nextScrollState: "",
        oldScrollState: "",
        mobileOldScrollState: "",
        snapDuration: 500,
        snapBackDuration: 500,
        showLoginFlyout: !1,
        loginRecentlyOpened: !1,
        announcementSlotElems: [],
      };
    },
    watch: {
      activeMainNavItem(e, t) {
        this.showVideo && this.hideVideo(),
          t && (t.isActive = !1),
          e
            ? (e.isActive = !0)
            : this.scrollState === w &&
              (this.scrollState = this.oldScrollState);
      },
      viewportSize(e, t) {
        const o = ["tablet", "tabletPortrait", "mobile"];
        ((t === "desktop" && o.includes(e) && this.scrollState === w) ||
          (o.includes(t) && e === "desktop" && this.scrollState === b)) &&
          this.finalizeFlyoutClose();
      },
      scrollState() {
        const e = new CustomEvent("header-state-change", {
          bubbles: !0,
          composed: !0,
          detail: {
            scrollState: this.scrollState,
            scrollProgress: this.scrollProgress,
          },
        });
        this.$el.dispatchEvent(e);
      },
      hasAnnouncement() {
        (this.scrollState = r),
          s.getInstance().pauseAllVideos(),
          (this.scrollState = E),
          this.$el
            .querySelector(".brandhub-header__main-navigation")
            .setAttribute("aria-hidden", "true");
        const t = this.$el.querySelector(".brandhub-header__meta-navigation");
        t.setAttribute("aria-hidden", "true");
        const o = t.querySelectorAll(".brandhub-meta-navigation__item-button");
        for (const m of o) m.tabIndex = -1;
      },
    },
    computed: {
      rootClass() {
        return {
          "brandhub-header--large": this.scrollState === p,
          "brandhub-header--menu-open": this.scrollState === b,
          "brandhub-header--flyout-open": this.scrollState === w,
          "brandhub-header--flyout-close": this.scrollState === W,
          "brandhub-header--announcement-open": this.scrollState === E,
          "brandhub-header--announcement-close": this.scrollState === x,
          "brandhub-header--search-open": this.scrollState === f,
          "brandhub-header--search-close": this.scrollState === z,
          "brandhub-header--switches-from-or-to-search": this.isSwitching,
          "brandhub-header--scroll-down": this.scrollState === r,
          "brandhub-header--scroll-up": this.scrollState === k,
          "brandhub-header--scrolling": this.scrollState === v,
          "brandhub-header--snap": this.scrollState === M,
          "brandhub-header--snap-back": this.scrollState === B,
          "brandhub-header--show-logo": this.showLogo,
          "brandhub-header--has-video": !!this.logoVideo,
        };
      },
      scrollStateAwareProgress() {
        let e = 0;
        return (
          [p, B].includes(this.scrollState)
            ? (e = 1)
            : this.scrollState === v && (e = this.scrollProgress),
          e
        );
      },
      rootStyle() {
        return {
          "--scroll-progress": this.scrollStateAwareProgress,
          "--fade-in-delay":
            this.logoVideo && this.showVideo && !this.searchOpen
              ? "1500ms"
              : "0ms",
          "--snap-back-duration": `${this.snapBackDuration}ms`,
        };
      },
      mobileMenuOpen() {
        return !this.isDesktop && [b, I].includes(this.scrollState);
      },
      searchOpen() {
        return [f, z, P].includes(this.scrollState);
      },
      hasAnnouncement() {
        return this.announcementSlotElems.length > 0;
      },
      announcementOpen() {
        return [E, x].includes(this.scrollState);
      },
      isSwitching() {
        return [I, P].includes(this.scrollState);
      },
      isLargeHeader() {
        return (
          this.showLarge &&
          ((this.windowWidth >= this.windowHeight && this.windowHeight >= te) ||
            (this.windowWidth < this.windowHeight && this.windowHeight >= ne))
        );
      },
    },
    methods: {
      onMobileMenuClick() {
        b === this.scrollState
          ? this.closeMenu()
          : f === this.scrollState
          ? ((this.scrollState = P), this.closeMenu())
          : (s.getInstance().pauseAllVideos(),
            this.isSwitching ||
              ((this.mobileOldScrollState = this.scrollState),
              this.hideVideo()),
            (this.scrollState = b));
      },
      onMainNavClick(e) {
        var t;
        if (
          (t = e == null ? void 0 : e.detail) != null &&
          t.clickedItem &&
          this.scrollState !== b
        ) {
          s.getInstance().pauseAllVideos();
          const o = e.detail.clickedItem;
          this.activeMainNavItem === o && this.headerFlyout
            ? this.headerFlyout.closeSubMenu()
            : this.activeMainNavItem
            ? (this.activeMainNavItem = o)
            : (de(this.$el),
              (this.oldScrollState = this.scrollState),
              [p, v].includes(this.scrollState)
                ? ((this.scrollState = M),
                  setTimeout(() => {
                    (this.scrollState = w), (this.activeMainNavItem = o);
                  }, this.snapDuration))
                : ((this.scrollState = w), (this.activeMainNavItem = o)));
        }
      },
      onSearchClick() {
        this.scrollState === f
          ? (this.closeMenu(), s.getInstance().playPausedVideos())
          : [w, b].includes(this.scrollState)
          ? ((this.scrollState = I), this.closeMenu())
          : (this.isSwitching || (this.oldScrollState = this.scrollState),
            s.getInstance().pauseAllVideos(),
            (this.scrollState = f));
      },
      onLoginClick() {
        this.showLoginFlyout
          ? (this.showLoginFlyout = !1)
          : ((this.showLoginFlyout = !0),
            (this.loginRecentlyOpened = !0),
            setTimeout(() => {
              this.loginRecentlyOpened = !1;
            }, 500));
      },
      onLoginClose() {
        !this.loginRecentlyOpened &&
          this.metaNavigation &&
          ((this.showLoginFlyout = !1), (this.metaNavigation.loginOpen = !1));
      },
      closeMenu() {
        this.headerFlyout && this.headerFlyout.closeOverlay(),
          this.hasAnnouncement &&
            this.headerAnnouncement &&
            this.headerAnnouncement.closeOverlay(),
          this.mobileMenu && this.mobileMenu.closeOverlay(),
          this.search && this.search.closeOverlay(),
          H(this.$el);
      },
      finalizeFlyoutClose() {
        if (this.scrollState === I) this.onSearchClick();
        else if (this.scrollState === P)
          s.getInstance().playPausedVideos(), this.onMobileMenuClick();
        else if (this.scrollState === b)
          s.getInstance().playPausedVideos(),
            (this.scrollState = Je),
            H(this.$el),
            setTimeout(() => {
              (this.scrollState = this.mobileOldScrollState),
                (this.mobileOldScrollState = "");
            }, 400);
        else if (this.scrollState === f)
          s.getInstance().playPausedVideos(),
            (this.scrollState = z),
            setTimeout(() => {
              this.scrollState = this.oldScrollState;
            }, 400);
        else if (this.scrollState === E) {
          s.getInstance().playPausedVideos(),
            (this.scrollState = x),
            this.$el
              .querySelector(".brandhub-header__main-navigation")
              .removeAttribute("aria-hidden");
          const t = this.$el.querySelector(".brandhub-header__meta-navigation");
          t.removeAttribute("aria-hidden"),
            t
              .querySelectorAll(".brandhub-meta-navigation__item-button")
              .forEach((m) => {
                m.removeAttribute("tabindex");
              }),
            setTimeout(() => {
              this.scrollState = k;
            }, 400);
        } else
          s.getInstance().playPausedVideos(),
            (this.scrollState = W),
            H(this.$el),
            setTimeout(() => {
              (this.activeMainNavItem = null),
                (this.scrollState = this.oldScrollState);
            }, 400);
      },
      focusLogo() {
        this.headerLink && this.headerLink.focus();
      },
      logoTab(e) {
        this.searchOpen
          ? (e.preventDefault(), R.emit(O.FocusInput))
          : this.announcementOpen &&
            (e.preventDefault(), K.emit(q.FocusInteractable));
      },
      logoShiftTab(e) {
        this.searchOpen
          ? this.isDesktop && (e.preventDefault(), R.emit(O.FocusCloseButton))
          : this.announcementOpen &&
            (e.preventDefault(), K.emit(q.FocusCloseButton));
      },
      onKeyUp(e) {
        !e.isComposing &&
          e.key === "Escape" &&
          (this.activeMainNavItem && this.closeMenu(),
          this.searchOpen && this.search && this.search.closeOverlay(),
          this.announcementOpen &&
            this.headerAnnouncement &&
            this.headerAnnouncement.closeOverlay());
      },
      hideVideo() {
        this.showVideo &&
          !this.showLogo &&
          ((this.showLogo = !0),
          setTimeout(() => {
            this.showVideo = !1;
          }, 350));
      },
      onScroll() {
        const e = Math.max(0, this.scrollPos),
          t = Math.max(0, window.scrollY);
        this.scrollState !== f &&
          this.scrollState !== E &&
          (this.isLargeHeader
            ? (this.scrollState === p && t > 0 && (this.scrollState = v),
              this.scrollState === v &&
                t > d &&
                ((this.scrollState = M),
                (this.nextScrollState = r),
                setTimeout(() => {
                  (this.scrollState = this.nextScrollState),
                    (this.nextScrollState = "");
                }, this.snapDuration),
                this.hideVideo()),
              this.scrollState === v && t < e && t < 10
                ? (this.scrollState = p)
                : [r, k].includes(this.scrollState) && t < d
                ? (this.calculateProgress(),
                  (this.scrollState = B),
                  setTimeout(() => {
                    (this.scrollState = p),
                      window.scrollY > d && (this.scrollState = r);
                  }, this.snapBackDuration))
                : this.scrollState === M &&
                  t < d &&
                  ((this.nextScrollState = B),
                  setTimeout(() => {
                    (this.scrollState = p),
                      window.scrollY > d && (this.scrollState = r);
                  }, this.snapBackDuration)))
            : this.scrollState !== r && t > d && e <= d
            ? (this.scrollState = r)
            : this.scrollState === r &&
              t < d &&
              ((this.scrollState = k),
              this.scrolledBackTimer &&
                (clearTimeout(this.scrolledBackTimer),
                (this.scrolledBackTimer = null))),
          this.scrollState === k && t > e && e > 0
            ? ((this.scrollState = r),
              this.scrolledBackTimer &&
                (clearTimeout(this.scrolledBackTimer),
                (this.scrolledBackTimer = null)))
            : this.scrollState === r &&
              t < e &&
              t > ee &&
              (this.scrolledBackTimer ||
                (this.scrolledBackTimer = window.setTimeout(() => {
                  (this.scrollState = k), (this.scrolledBackTimer = null);
                }, 100))),
          this.isLargeHeader &&
            this.scrollState === v &&
            this.calculateProgress(),
          (this.scrollPos = t));
      },
      calculateProgress() {
        this.scrollProgress = Math.max(1 - this.scrollPos / X, 0);
      },
      onLogoClick() {
        this.logoLink &&
          F.pushTrackingAttributes(
            "link",
            "Logo",
            "Mercedes-Benz logo",
            this.logoLink
          );
      },
      scrollToHeader() {
        this.$el.scrollIntoView({ behavior: "smooth" });
      },
      async canAutoplay() {
        return await this.delay(500), ue.video({ inline: !0, muted: !0 });
      },
      delay(e) {
        return new Promise((t) => {
          setTimeout(t, e);
        });
      },
      async handleBlockingBrowsers() {
        this.canAutoplay().then(({ error: e }) => {
          e && e.name === "NotAllowedError"
            ? this.hideVideo()
            : (this.canShowVideo = !0);
        });
      },
    },
    created() {
      this.handleBlockingBrowsers(),
        (this.windowHeight = window.innerHeight),
        (this.windowWidth = window.innerWidth),
        this.isLargeHeader &&
          this.logoVideo &&
          ((this.scrollState = "large"),
          window.scrollY > 10
            ? (this.scrollState = "scroll-up")
            : ((this.showVideo = !0), (this.showLogo = !1))),
        U.on(G.JumpToNavigation, this.scrollToHeader);
    },
    mounted() {
      this.$el.getRootNode().addEventListener("slotchange", () => {
        var e, t;
        (e = this.headerAnnouncementSlot) != null &&
          e.assignedElements() &&
          (this.announcementSlotElems =
            (t = this.headerAnnouncementSlot) == null
              ? void 0
              : t.assignedElements());
      }),
        this.onScroll(),
        document.addEventListener("scroll", this.onScroll, { passive: !0 }),
        document.addEventListener("keyup", this.onKeyUp, { passive: !0 }),
        this.$el.addEventListener("mainNavClicked", this.onMainNavClick),
        this.$el.addEventListener("loginClicked", this.onLoginClick),
        window.addEventListener(
          "keydown",
          (e) => {
            e.key === "Escape" && this.onLoginClose();
          },
          { passive: !0 }
        );
    },
  }),
  Ue = `.brandhub-header{--ease-in-out-expo: cubic-bezier(.8, 0, 0, .8);--ease-out-expo: cubic-bezier(0,0,.26,1);--menu-height: 5.1428571429rem;--main-menu-height: 4.5714285714rem;color:var(--wb-white);height:5.1428571429rem;position:relative;width:100%;z-index:100}@media (max-width: 1023px){.brandhub-header{--menu-height: 4.5714285714rem;height:4.5714285714rem}}.brandhub-header--has-video .brandhub-header__logo{opacity:0;transition:opacity .3s}.brandhub-header--has-video.brandhub-header--show-logo .brandhub-header__logo{opacity:1}.brandhub-header--large{--menu-height: 20.5714285714rem}@media (max-width: 1023px){.brandhub-header--large{--menu-height: 15.4285714286rem}}.brandhub-header--scroll-down:hover .brandhub-header__meta-navigation,.brandhub-header--scroll-up .brandhub-header__meta-navigation,.brandhub-header--flyout-open .brandhub-header__meta-navigation,.brandhub-header--flyout-close .brandhub-header__meta-navigation,.brandhub-header--menu-open .brandhub-header__meta-navigation,.brandhub-header--announcement-open .brandhub-header__meta-navigation{transform:translateZ(0)}.brandhub-header--scroll-down:hover .brandhub-header__main-navigation,.brandhub-header--scroll-up .brandhub-header__main-navigation,.brandhub-header--flyout-open .brandhub-header__main-navigation,.brandhub-header--flyout-close .brandhub-header__main-navigation,.brandhub-header--menu-open .brandhub-header__main-navigation,.brandhub-header--announcement-open .brandhub-header__main-navigation{--header-link-color: var(--wb-white);transform:translateZ(0)}.brandhub-header--scroll-down:hover .brandhub-header__main-navigation-content,.brandhub-header--scroll-up .brandhub-header__main-navigation-content,.brandhub-header--flyout-open .brandhub-header__main-navigation-content,.brandhub-header--flyout-close .brandhub-header__main-navigation-content,.brandhub-header--menu-open .brandhub-header__main-navigation-content,.brandhub-header--announcement-open .brandhub-header__main-navigation-content{opacity:1}.brandhub-header--scroll-down:hover .brandhub-header__blur,.brandhub-header--scroll-up .brandhub-header__blur,.brandhub-header--flyout-open .brandhub-header__blur,.brandhub-header--flyout-close .brandhub-header__blur,.brandhub-header--menu-open .brandhub-header__blur,.brandhub-header--announcement-open .brandhub-header__blur{height:var(--main-menu-height)}@media (max-width: 1023px){.brandhub-header--scroll-down:hover .brandhub-header__blur,.brandhub-header--scroll-up .brandhub-header__blur,.brandhub-header--flyout-open .brandhub-header__blur,.brandhub-header--flyout-close .brandhub-header__blur,.brandhub-header--menu-open .brandhub-header__blur,.brandhub-header--announcement-open .brandhub-header__blur{height:.0714285714rem}}.brandhub-header--flyout-open .brandhub-header__blur,.brandhub-header--menu-open .brandhub-header__blur,.brandhub-header--switches-from-or-to-search .brandhub-header__blur,.brandhub-header--search-open .brandhub-header__blur,.brandhub-header--announcement-open .brandhub-header__blur{height:calc(100vh - var(--menu-height));transition-duration:.6s}.brandhub-header--flyout-close .brandhub-header__blur,.brandhub-header--menu-close .brandhub-header__blur,.brandhub-header--search-close .brandhub-header__blur,.brandhub-header--announcement-close .brandhub-header__blur{transition-duration:.38s}.brandhub-header__content{position:fixed;top:0;width:100%;z-index:950}.brandhub-header__blur{background-color:#000000e6;height:.0714285714rem;position:absolute;top:4.5714285714rem;transition:height .75s var(--ease-in-out-expo);width:100%;z-index:-1}@supports (backdrop-filter: blur()){.brandhub-header__blur{-webkit-backdrop-filter:blur(1.7857142857rem);backdrop-filter:blur(1.7857142857rem);background-color:#000c}}@media (min-width: 1024px){.brandhub-header__blur{top:5.1428571429rem}}.brandhub-header__container{display:grid;grid-template:"left center right" auto "mainMenu mainMenu mainMenu" auto/1fr 1fr 1fr;position:relative}.brandhub-header__container-curtain{background-color:var(--wb-black);grid-area:left/left/right/right;z-index:3}.brandhub-header__meta-navigation{grid-area:left/left/right/right}.brandhub-header--scroll-down .brandhub-header__meta-navigation,.brandhub-header--announcement-open .brandhub-header__meta-navigation{transform:translate3d(0,-50px,0)}.brandhub-header__link{box-sizing:content-box;display:grid;grid-area:center;grid-template:"logo" 100%/auto;height:3rem;justify-content:center;justify-self:center;overflow:hidden;padding:1.0714285714rem;transition:padding-bottom .5s var(--ease-in-out-expo),padding-top .5s var(--ease-in-out-expo),height .5s var(--ease-in-out-expo);z-index:5}@media (max-width: 1023px){.brandhub-header__link{height:2.4285714286rem}}.brandhub-header__link:focus-visible{position:relative;outline:none}.brandhub-header__link:focus-visible:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-header__link:focus-visible:after{height:65%;left:3.0714285714rem;top:.6428571429rem;width:35%}.brandhub-header--large .brandhub-header__link:focus-visible:after{height:36%;left:3.2142857143rem;top:6.3571428571rem;width:45%}@media (min-width: 768px){.brandhub-header--large .brandhub-header__link:focus-visible:after{height:40%;left:2.6428571429rem;top:4.2142857143rem;width:50%}}@media (min-width: 1024px){.brandhub-header--large .brandhub-header__link:focus-visible:after{height:45%;left:4.5714285714rem;top:4.9285714286rem;width:47%}}.brandhub-header--large .brandhub-header__link,.brandhub-header--snap-back .brandhub-header__link{height:8rem;padding:5.2857142857rem 1.0714285714rem;width:16rem}@media (max-width: 1023px){.brandhub-header--large .brandhub-header__link,.brandhub-header--snap-back .brandhub-header__link{height:5.3571428571rem;padding:4.6428571429rem 1.0714285714rem;width:9.2857142857rem}}@media (max-width: 767px){.brandhub-header--large .brandhub-header__link,.brandhub-header--snap-back .brandhub-header__link{height:5.1428571429rem;padding:6.7857142857rem 1.0714285714rem 3.5714285714rem;width:10.2857142857rem}}.brandhub-header--snap-back .brandhub-header__link{transition-duration:var(--snap-back-duration)}.brandhub-header--scrolling .brandhub-header__link{height:8rem;padding-bottom:calc(1.0714285714rem + (var(--scroll-progress, 0) * 4.2142857143rem));padding-top:calc(1.0714285714rem + (var(--scroll-progress, 0) * 4.2142857143rem));transition:none}@media (max-width: 1023px){.brandhub-header--scrolling .brandhub-header__link{height:5.1428571429rem;padding-bottom:calc(.9285714286rem + (var(--scroll-progress, 0) * 2.6428571429rem));padding-top:calc(.9285714286rem + (var(--scroll-progress, 0) * 5.8571428571rem))}}.brandhub-header__video{display:flex;grid-area:logo;height:100%;margin-left:auto;margin-right:auto;object-fit:cover;transform:scale(2.25)}.brandhub-header__logo{display:flex;grid-area:logo;height:100%;margin-bottom:var(--logo-margin);margin-left:auto;margin-right:auto;object-fit:contain;width:8rem;z-index:1}.brandhub-header__main-navigation{--header-link-color: var(--wb-white);font-size:1.1428571429rem;grid-area:mainMenu;height:var(--main-menu-height);transform:translateZ(0);transition:transform .75s var(--ease-in-out-expo),background-color .5s,font-size .5s linear;width:100%}@media (max-width: 1023px){.brandhub-header__main-navigation{display:none}}@media (max-width: 1439px){.brandhub-header__main-navigation{font-size:1rem}}.brandhub-header--scroll-down .brandhub-header__main-navigation,.brandhub-header--search-open .brandhub-header__main-navigation,.brandhub-header--search-close .brandhub-header__main-navigation,.brandhub-header--announcement-open .brandhub-header__main-navigation,.brandhub-header--announcement-close .brandhub-header__main-navigation{--header-link-color: var(--wb-grey-45);transform:translate3d(0,-100%,0)}.brandhub-header--flyout-open .brandhub-header__main-navigation{--header-link-color: var(--wb-grey-45)}.brandhub-header--large .brandhub-header__main-navigation,.brandhub-header--scrolling .brandhub-header__main-navigation,.brandhub-header--snap-back .brandhub-header__main-navigation{background-color:var(--wb-black);font-size:1.2857142857rem}@media (max-width: 1439px){.brandhub-header--large .brandhub-header__main-navigation,.brandhub-header--scrolling .brandhub-header__main-navigation,.brandhub-header--snap-back .brandhub-header__main-navigation{font-size:1.1428571429rem}}.brandhub-header--snap .brandhub-header__main-navigation{background-color:var(--wb-black);transform:translate3d(0,-100%,0)}.brandhub-header__main-navigation-content{opacity:1;transition:opacity .75s var(--ease-in-out-expo)}.brandhub-header--scroll-down .brandhub-header__main-navigation-content,.brandhub-header--search-open .brandhub-header__main-navigation-content,.brandhub-header--search-close .brandhub-header__main-navigation-content,.brandhub-header--announcement-close .brandhub-header__main-navigation-content{opacity:.7}@media (max-width: 1023px){.brandhub-header__privacy-notice{margin-bottom:1.5rem;padding:.25rem .5rem;text-align:center}}@media (min-width: 1024px){.brandhub-header .brandhub-login-flyout{position:absolute;right:2.2857142857rem;top:4.5714285714rem;z-index:10050}}
`,
  Ge = { class: "brandhub-header__content" },
  Ke = n("div", { class: "brandhub-header__blur" }, null, -1),
  qe = { class: "brandhub-header__container" },
  We = n("div", { class: "brandhub-header__container-curtain" }, null, -1),
  Ze = ["href"],
  Qe = {
    key: 0,
    ref: "videoPlayer",
    role: "presentation",
    class: "brandhub-header__video",
    muted: "",
    playsinline: "",
    autoplay: "",
  },
  Xe = ["src"],
  et = { key: 1, class: "brandhub-header__main-navigation" },
  tt = { class: "brandhub-header__main-navigation-content" };
function nt(e, t, o, m, V, D) {
  const C = u("meta-navigation"),
    L = u("login-flyout"),
    a = u("responsive-image"),
    ae = u("header-flyout-dynamic"),
    oe = u("header-announcement-dynamic"),
    ie = u("search-dynamic"),
    re = u("header-mobile-menu-dynamic");
  return (
    c(),
    $(
      "div",
      { class: j(["brandhub-header", e.rootClass]), style: he(e.rootStyle) },
      [
        n("div", Ge, [
          Ke,
          n("div", qe, [
            We,
            A(
              C,
              {
                class: "brandhub-header__meta-navigation",
                "menu-open": e.scrollState === "menu-open",
                "search-open": e.scrollState === "search-open",
                "privacy-action-name": e.privacyActionName,
                ref: "metaNavigation",
                "announcement-open": e.announcementOpen,
                onSearchClicked: e.onSearchClick,
                onMobileMenuToggle: e.onMobileMenuClick,
              },
              {
                default: g(() => [
                  e.isDesktop
                    ? h(e.$slots, "language-switcher", { key: 0 })
                    : _("", !0),
                ]),
                _: 3,
              },
              8,
              [
                "menu-open",
                "search-open",
                "privacy-action-name",
                "announcement-open",
                "onSearchClicked",
                "onMobileMenuToggle",
              ]
            ),
            e.showLoginFlyout && e.isDesktop
              ? (c(),
                N(
                  L,
                  {
                    key: 0,
                    ref: "loginFlyout",
                    onOnLoginClose: e.onLoginClose,
                  },
                  {
                    "login-flyout-links": g(() => [
                      h(e.$slots, "login-flyout-links"),
                    ]),
                    _: 3,
                  },
                  8,
                  ["onOnLoginClose"]
                ))
              : _("", !0),
            n(
              "a",
              {
                class: "brandhub-header__link",
                ref: "headerLink",
                href: e.logoLink,
                onKeydown: [
                  t[0] ||
                    (t[0] = J(
                      Y((...T) => e.logoTab && e.logoTab(...T), ["exact"]),
                      ["tab"]
                    )),
                  t[1] ||
                    (t[1] = J(
                      Y(
                        (...T) => e.logoShiftTab && e.logoShiftTab(...T),
                        ["shift"]
                      ),
                      ["tab"]
                    )),
                ],
                onClick:
                  t[2] ||
                  (t[2] = (...T) => e.onLogoClick && e.onLogoClick(...T)),
              },
              [
                e.showVideo && e.canShowVideo
                  ? (c(),
                    $(
                      "video",
                      Qe,
                      [
                        n(
                          "source",
                          { src: e.logoVideo, type: "video/mp4" },
                          null,
                          8,
                          Xe
                        ),
                      ],
                      512
                    ))
                  : _("", !0),
                A(
                  a,
                  {
                    class: "brandhub-header__logo",
                    "picture-json": e.logoJson,
                    "object-fit": "contain",
                    "disable-lazy-loading": "",
                  },
                  null,
                  8,
                  ["picture-json"]
                ),
              ],
              40,
              Ze
            ),
            e.isDesktop
              ? (c(),
                $("div", et, [n("div", tt, [h(e.$slots, "main-navigation")])]))
              : _("", !0),
          ]),
          e.activeMainNavItem && e.isDesktop
            ? (c(),
              N(
                ae,
                {
                  key: 0,
                  ref: "headerFlyout",
                  "nav-item": e.activeMainNavItem,
                  onOnMenuClose: e.finalizeFlyoutClose,
                },
                null,
                8,
                ["nav-item", "onOnMenuClose"]
              ))
            : _("", !0),
          se(
            A(
              oe,
              {
                ref: "headerAnnouncement",
                onHeaderAnnouncementFocusLogo: e.focusLogo,
                onHeaderAnnouncementClose: e.finalizeFlyoutClose,
              },
              {
                default: g(() => [
                  h(e.$slots, "announcement", {
                    ref: "headerAnnouncementSlot",
                  }),
                ]),
                _: 3,
              },
              8,
              ["onHeaderAnnouncementFocusLogo", "onHeaderAnnouncementClose"]
            ),
            [[le, e.hasAnnouncement && e.announcementOpen]]
          ),
          e.searchOpen
            ? (c(),
              N(
                ie,
                {
                  key: 1,
                  ref: "search",
                  onSearchClose: e.finalizeFlyoutClose,
                  onFocusLogo: e.focusLogo,
                  "auto-suggestions": "",
                  "api-url": e.searchApiEndpoint,
                },
                {
                  "search-link-list": g(() => [
                    h(e.$slots, "search-link-list"),
                  ]),
                  _: 3,
                },
                8,
                ["onSearchClose", "onFocusLogo", "api-url"]
              ))
            : _("", !0),
          e.mobileMenuOpen
            ? (c(),
              N(
                re,
                {
                  key: 2,
                  ref: "mobileMenu",
                  "privacy-action-name": e.privacyActionName,
                  onOnMenuClose: e.finalizeFlyoutClose,
                },
                {
                  "main-navigation": g(() => [h(e.$slots, "main-navigation")]),
                  "bottom-navigation": g(() => [
                    h(e.$slots, "language-switcher"),
                  ]),
                  "login-flyout-links": g(() => [
                    h(e.$slots, "login-flyout-links"),
                  ]),
                  _: 3,
                },
                8,
                ["privacy-action-name", "onOnMenuClose"]
              ))
            : _("", !0),
        ]),
      ],
      6
    )
  );
}
const at = Q(Ye, [
    ["render", nt],
    ["styles", [Ue]],
  ]),
  _t = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        HEADER_HEIGHT: X,
        MIN_HEIGHT_LARGE_HEADER_LANDSCAPE: te,
        MIN_HEIGHT_LARGE_HEADER_PORTRAIT: ne,
        SCROLLED_BACK_ENABLED_OFFSET: ee,
        SCROLLED_OFFSET: d,
        default: at,
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  );
export { _t as H, R as S, O as a };
