import {
  d as k,
  i as a,
  a as _,
  _ as L,
  r as m,
  w as T,
  v as N,
  o as l,
  c as s,
  h as o,
  f as d,
  C as S,
  n as g,
  t as f,
  e as c,
  B as w,
  k as y,
} from "./index.js";
import { e as E, d as F } from "./bodyScrollLock.esm-5a01fb3c.js";
import { d as C } from "./index-f19cff0e.js";
import { R as z } from "./ResizeUpdateMixin-a56b9b41.js";
import M from "./Accordion.ce-794a13ca.js";
import P from "./AccordionItem.ce-12be3f57.js";
import { i as $ } from "./i18next-3def9235.js";
import { _ as B } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
import "./ParentComponentMixin-b739cccc.js";
import "./ShadowDom-bc0a555e.js";
import "./Icon.ce-1a736152.js";
import "./ChildComponentMixin-dd022493.js";
const I = "Provider",
  O = "Legal Notice",
  U = "Privacy Statement",
  H = "Settings",
  D = "#provider",
  V = "#legalNotice",
  q = "#privacyStatement",
  K = "Third Party License Notices",
  R = "#thirdPartyLicenseNotices",
  G = {
    provider: I,
    legalNotice: O,
    privacyStatement: U,
    cookiesText: H,
    providerAnchor: D,
    legalNoticeAnchor: V,
    privacyStatementAnchor: q,
    fossOverview: K,
    fossOverviewAnchor: R,
  },
  X = "Anbieter",
  j = "Rechtliche Hinweise",
  J = "Datenschutz",
  Q = "Einstellungen",
  W = "#anbieter",
  Y = "#rechtlicheHinweise",
  Z = "#datenschutz",
  x = "Lizenzhinweise Dritter",
  ee = "#lizenzhinweiseDritter",
  te = {
    provider: X,
    legalNotice: j,
    privacyStatement: J,
    cookiesText: Q,
    providerAnchor: W,
    legalNoticeAnchor: Y,
    privacyStatementAnchor: Z,
    fossOverview: x,
    fossOverviewAnchor: ee,
  };
function oe() {
  const e = $.createInstance();
  return (
    e.init({
      lng:
        document.body.dataset.analyticsLanguage ||
        {}.VUE_APP_I18N_LOCALE ||
        "en",
      resources: { en: { translation: G }, de: { translation: te } },
    }),
    e
  );
}
const ne = _(() =>
    L(
      () => import("./close-new-f0d12d75.js"),
      ["./close-new-f0d12d75.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  re = _(() =>
    L(
      () => import("./FossOverview.ce-aae042a5.js"),
      [
        "./FossOverview.ce-aae042a5.js",
        "./i18next-3def9235.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  ae = "brandhub-legal-link-clicked",
  ie = k({
    props: {
      editMode: { default: !1, type: Boolean },
      legalLayerContentPath: { required: !0, type: String },
      fossOverviewContentPath: { required: !0, type: String },
    },
    components: {
      FossOverview: re,
      AccordionItem: P,
      Accordion: M,
      IconClose: ne,
    },
    mixins: [z],
    data() {
      return {
        providerAnchor: this.t("providerAnchor").toString(),
        privacyAnchor: this.t("privacyStatementAnchor").toString(),
        legalNoticeAnchor: this.t("legalNoticeAnchor").toString(),
        cookiesAnchor: "#cookies",
        fossOverviewAnchor: this.t("fossOverviewAnchor").toString(),
        focusedTab: this.t("providerAnchor").toString(),
        open: !1,
        fetchedProviderContent: null,
        fetchedPrivacyContent: null,
        fetchedLegalContent: null,
        legalLayerIntervall: 0,
        legalLayerIntervallCounter: 0,
        lastFocusableElement: null,
        legalLayerBaseElement: null,
      };
    },
    setup() {
      const e = a(),
        t = a(),
        n = a(),
        u = a(),
        p = a(),
        v = a(),
        h = a(),
        b = a(),
        i = a(),
        A = a(),
        { t: r } = oe();
      return {
        overflowContent: e,
        providerAccordion: t,
        legalAccordion: n,
        cookiesAccordion: u,
        privacyAccordion: p,
        legalLayerCloseButton: v,
        privacyTab: h,
        providerContent: b,
        privacyContent: i,
        legalNoticeContent: A,
        t: r,
      };
    },
    computed: {
      rootClass() {
        return { "brandhub-legal-layer--edit-mode": this.editMode };
      },
    },
    methods: {
      translatedTitle(e) {
        return this.t(e).toString() || "";
      },
      changeTabFocus(e) {
        (this.focusedTab = e), (window.location.hash = "");
      },
      getFocusedClass(e) {
        return {
          "brandhub-legal-layer__tab-name--selected": this.focusedTab === e,
        };
      },
      sanitizedLegalUrls(e) {
        return C.sanitizeUrl(e);
      },
      openByDefault() {
        const e = !!document.querySelector(".xf-web-container");
        return e && this.fetchContent(), e;
      },
      fetchLegalContent() {
        return fetch(this.legalLayerContentPath).then((e) => e.text());
      },
      async fetchContent() {
        this.fetchLegalContent().then((e) => {
          var h, b, i;
          const n = new DOMParser().parseFromString(e, "text/html"),
            u =
              (h = n.querySelector(".provider-content")) == null
                ? void 0
                : h.textContent,
            p =
              (b = n.querySelector(".privacy-content")) == null
                ? void 0
                : b.textContent,
            v =
              (i = n.querySelector(".legal-content")) == null
                ? void 0
                : i.textContent;
          return (
            u && (this.fetchedProviderContent = C.sanitizeUrl(u)),
            p && (this.fetchedPrivacyContent = C.sanitizeUrl(p)),
            v && (this.fetchedLegalContent = C.sanitizeUrl(v)),
            null
          );
        });
      },
      closeLegalLayer() {
        (this.open = !1),
          this.overflowContent && E(this.overflowContent),
          (window.location.hash = "");
      },
      openAccordion() {
        this.providerAccordion &&
          this.legalAccordion &&
          this.cookiesAccordion &&
          this.privacyAccordion &&
          ((this.providerAccordion.open = !1),
          (this.legalAccordion.open = !1),
          (this.cookiesAccordion.open = !1),
          (this.privacyAccordion.open = !1),
          this.focusedTab === this.providerAnchor &&
            this.providerAccordion.openContent(),
          this.focusedTab === this.legalNoticeAnchor &&
            this.legalAccordion.openContent(),
          this.focusedTab === this.cookiesAnchor &&
            this.cookiesAccordion.openContent(),
          this.focusedTab === this.privacyAnchor &&
            this.privacyAccordion.openContent());
      },
      setUpLegalLayer(e) {
        (this.focusedTab = e),
          (this.open = !0),
          this.overflowContent && F(this.overflowContent),
          this.openAccordion(),
          e !== this.cookiesAnchor &&
            ((this.legalLayerIntervallCounter = 0),
            (this.legalLayerIntervall = window.setInterval(
              this.prepareFocusableElements,
              250
            )),
            this.prepareFocusableElements());
      },
      openLegalLayer(e) {
        (!this.fetchedProviderContent ||
          !this.fetchedLegalContent ||
          !this.fetchedPrivacyContent) &&
          this.fetchContent(),
          e.detail
            ? [
                this.providerAnchor,
                this.cookiesAnchor,
                this.privacyAnchor,
                this.legalNoticeAnchor,
              ].includes(e.detail.toString()) &&
              (this.open
                ? this.setUpLegalLayer(e.detail.toString())
                : (this.setUpLegalLayer(e.detail.toString()),
                  this.$nextTick(() => {
                    var t, n;
                    typeof ((t = this.legalLayerCloseButton) == null
                      ? void 0
                      : t.focus) == "function" &&
                      ((n = this.legalLayerCloseButton) == null || n.focus());
                  })))
            : [
                this.providerAnchor,
                this.cookiesAnchor,
                this.privacyAnchor,
                this.legalNoticeAnchor,
              ].includes(window.location.hash) &&
              (this.setUpLegalLayer(window.location.hash),
              this.open ||
                this.$nextTick(() => {
                  var t;
                  (t = this.legalLayerCloseButton) == null || t.focus();
                }));
      },
      prepareFocusableElements() {
        if (!this.$refs.overflowContent) {
          this.updateInterval();
          return;
        }
        this.searchFetchedContent(), this.updateInterval();
      },
      updateInterval() {
        this.legalLayerIntervallCounter > 9 &&
          clearInterval(this.legalLayerIntervall),
          (this.legalLayerIntervallCounter += 1);
      },
      searchFetchedContent() {
        this.focusedTab === this.providerAnchor &&
          this.addFocusableContent(this.providerContent),
          this.focusedTab === this.privacyAnchor &&
            this.addFocusableContent(this.privacyContent),
          this.focusedTab === this.legalNoticeAnchor &&
            this.addFocusableContent(this.legalNoticeContent);
      },
      addFocusableContent(e) {
        if (e && e.hasChildNodes()) {
          clearInterval(this.legalLayerIntervall);
          const t = e.getElementsByTagName("a");
          t.length > 0
            ? (this.lastFocusableElement = t[t.length - 1])
            : (this.lastFocusableElement = this.privacyTab || null);
        }
      },
      handleTabNavigation(e) {
        setTimeout(() => {
          var t, n;
          e.shiftKey && e.key === "Tab"
            ? this.legalLayerBaseElement !== document.activeElement &&
              (this.lastFocusableElement &&
              this.focusedTab !== this.cookiesAnchor
                ? this.lastFocusableElement.focus()
                : (t = this.privacyTab) == null || t.focus())
            : e.key === "Tab" &&
              this.legalLayerBaseElement !== document.activeElement &&
              ((n = this.legalLayerCloseButton) == null || n.focus());
        }, 50);
      },
    },
    watch: {
      open(e) {
        e
          ? window.addEventListener("keydown", this.handleTabNavigation)
          : window.removeEventListener("keydown", this.handleTabNavigation);
      },
    },
    mounted() {
      (this.open = this.openByDefault()),
        window.location.hash &&
          [
            this.providerAnchor,
            this.cookiesAnchor,
            this.privacyAnchor,
            this.legalNoticeAnchor,
          ].includes(window.location.hash) &&
          (this.setUpLegalLayer(window.location.hash), this.fetchContent()),
        window.addEventListener(ae, this.openLegalLayer),
        window.addEventListener("hashchange", this.openLegalLayer);
      const [e] = document.body.getElementsByTagName("brandhub-legal-layer");
      this.legalLayerBaseElement = e;
    },
  }),
  le = `.brandhub-legal-layer{background:rgba(0,0,0,.3);bottom:0;left:0;max-height:100%;overflow-y:auto;position:fixed;top:0;width:100%;z-index:10100}.brandhub-legal-layer--edit-mode{left:auto;position:initial;top:auto}.brandhub-legal-layer__dialog{margin:1.75rem auto;max-width:90%;position:relative;width:63.7142857143rem}@media (max-width: 1023px){.brandhub-legal-layer__dialog{margin:.7142857143rem auto;width:51rem}}.brandhub-legal-layer__dialog-content{background:var(--wb-white);display:flex;flex-direction:column}.brandhub-legal-layer__content-header{display:flex;flex-direction:row;height:4.4285714286rem}.brandhub-legal-layer__content-header-icon{color:var(--wb-black);cursor:pointer;height:1.5714285714rem;position:absolute;right:2.2142857143rem;top:2.2142857143rem;translate:50% -50%;width:1.5714285714rem;z-index:10150}.brandhub-legal-layer__content-header-icon:focus-visible{border:3px solid rgba(0,120,214,.8);outline:none}.brandhub-legal-layer__content-body{flex:1 1 auto;padding:0 2.8571428571rem;position:relative}.brandhub-legal-layer__content-body--mobile{padding-bottom:2.8571428571rem;padding-left:0;padding-right:0}.brandhub-legal-layer__tab-list{border-bottom:.0714285714rem solid var(--wb-grey-70);display:flex;flex-wrap:wrap;list-style:none;margin-bottom:2.8571428571rem;margin-top:0;padding-left:0;white-space:nowrap;width:100%}.brandhub-legal-layer__tab-item{cursor:pointer;margin-bottom:-.0714285714rem;vertical-align:initial}.brandhub-legal-layer__tab-name{background-color:transparent;border:.0714285714rem solid transparent;color:var(--wb-grey-20);display:block;margin:0 .0714285714rem;padding:.6428571429rem 1.3571428571rem;text-decoration:none}.brandhub-legal-layer__tab-name--selected{background-color:var(--wb-white);border:.0714285714rem solid var(--wb-grey-70);border-bottom-color:var(--wb-white);color:#0260ab}.brandhub-legal-layer__tab-name:focus-visible{box-shadow:inset 0 0 0 3px #0078d6cc;outline:none}.brandhub-legal-layer__foss-tab{line-height:1.5714285714rem}.brandhub-legal-layer__content-box{color:var(--wb-black);padding-bottom:2.8571428571rem;padding-left:2.8571428571rem;padding-right:2.8571428571rem}.brandhub-legal-layer__text{clear:both;color:var(--wb-grey-20);font-family:MBCorpo Text,sans-serif;font-size:1rem;line-height:1.375;padding-top:0;word-break:break-word}.brandhub-legal-layer__text p{margin-bottom:1rem;margin-top:0}.brandhub-legal-layer__text a{color:#0260ab;text-decoration:none}.brandhub-legal-layer__text a:focus-visible{border:3px solid rgba(0,120,214,.8);outline:none}.brandhub-legal-layer__text h4{font-size:1.375rem}.brandhub-legal-layer__text table{border:0 solid transparent;border-collapse:collapse;display:block;overflow-x:auto;text-indent:initial}.brandhub-legal-layer__text table tbody tr:nth-child(2n) td{background-color:#ececec}.brandhub-legal-layer__text table tbody tr td{border-right:.1428571429rem solid var(--wb-white);display:table-cell;padding:1.0714285714rem 1.4285714286rem;vertical-align:initial;word-break:keep-all}.brandhub-legal-layer__text table tbody tr td:last-child{border-right:none}.brandhub-legal-headline{clear:both;color:var(--wb-grey-20);line-height:1em;padding-top:0;word-break:break-word}.brandhub-legal-headline p{margin-bottom:1rem;margin-top:0}.brandhub-legal-headline a{color:#0260ab;text-decoration:none}.brandhub-legal-text{clear:both;color:var(--wb-grey-20);font-family:MBCorpo Text,sans-serif;font-size:1rem;line-height:1.375;padding-top:0;width:100%;word-break:break-word}.brandhub-legal-text p{margin-bottom:1rem;margin-top:0}.brandhub-legal-text a{color:#0260ab;text-decoration:none}
`,
  se = { class: "brandhub-legal-layer__dialog" },
  ce = { class: "brandhub-legal-layer__dialog-content" },
  de = { class: "brandhub-legal-layer__content-header" },
  he = { class: "brandhub-legal-layer__content-body" },
  be = { key: 0, class: "brandhub-legal-layer__tab-list", role: "tablist" },
  ge = { class: "brandhub-legal-layer__tab-item", role: "presentation" },
  ue = ["href", "textContent"],
  pe = { class: "brandhub-legal-layer__tab-item", role: "presentation" },
  ve = ["href", "textContent"],
  fe = { class: "brandhub-legal-layer__tab-item", role: "presentation" },
  ye = ["href", "textContent"],
  me = { class: "brandhub-legal-layer__tab-item", role: "presentation" },
  Ce = ["href", "textContent"],
  Ae = { class: "brandhub-legal-layer__tab-item", role: "presentation" },
  we = ["href", "textContent"],
  _e = { key: 0, class: "brandhub-legal-layer__content-box", role: "tabpanel" },
  Le = { key: 0 },
  ke = ["innerHTML"],
  Te = { key: 1 },
  Ne = ["innerHTML"],
  Se = { key: 2 },
  Ee = { key: 3 },
  Fe = ["innerHTML"],
  ze = { key: 4 },
  Me = {
    key: 1,
    class:
      "brandhub-legal-layer__content-body brandhub-legal-layer__content-body--mobile",
  },
  Pe = ["innerHTML"],
  $e = ["innerHTML"],
  Be = ["innerHTML"];
function Ie(e, t, n, u, p, v) {
  const h = m("icon-close"),
    b = m("foss-overview"),
    i = m("accordion-item"),
    A = m("accordion");
  return T(
    (l(),
    s(
      "div",
      {
        class: g(["brandhub-legal-layer", e.rootClass]),
        "aria-modal": "true",
        "aria-live": "polite",
        "aria-labelledby": "brandhub-legal-layer",
        role: "dialog",
        tabindex: "-1",
        ref: "overflowContent",
      },
      [
        o("div", se, [
          o("div", ce, [
            o("div", de, [
              d(
                h,
                {
                  tabindex: "0",
                  class: "brandhub-legal-layer__content-header-icon",
                  ref: "legalLayerCloseButton",
                  onClick: e.closeLegalLayer,
                  onKeydown: S(e.closeLegalLayer, ["enter"]),
                },
                null,
                8,
                ["onClick", "onKeydown"]
              ),
            ]),
            o("div", he, [
              e.isMobile
                ? c("", !0)
                : (l(),
                  s("ul", be, [
                    o("li", ge, [
                      o(
                        "a",
                        {
                          class: g([
                            "brandhub-legal-layer__tab-name",
                            e.getFocusedClass(e.providerAnchor),
                          ]),
                          href: e.sanitizedLegalUrls(e.providerAnchor),
                          onClick:
                            t[0] ||
                            (t[0] = (r) => e.changeTabFocus(e.providerAnchor)),
                          role: "tab",
                          textContent: f(e.t("provider")),
                        },
                        null,
                        10,
                        ue
                      ),
                    ]),
                    o("li", pe, [
                      o(
                        "a",
                        {
                          class: g([
                            "brandhub-legal-layer__tab-name",
                            e.getFocusedClass(e.legalNoticeAnchor),
                          ]),
                          href: e.sanitizedLegalUrls(e.legalNoticeAnchor),
                          onClick:
                            t[1] ||
                            (t[1] = (r) =>
                              e.changeTabFocus(e.legalNoticeAnchor)),
                          role: "tab",
                          textContent: f(e.t("legalNotice")),
                        },
                        null,
                        10,
                        ve
                      ),
                    ]),
                    o("li", fe, [
                      o(
                        "a",
                        {
                          class: g([
                            "brandhub-legal-layer__tab-name",
                            e.getFocusedClass(e.cookiesAnchor),
                          ]),
                          href: e.sanitizedLegalUrls(e.cookiesAnchor),
                          onClick:
                            t[2] ||
                            (t[2] = (r) => e.changeTabFocus(e.cookiesAnchor)),
                          role: "tab",
                          textContent: f(e.t("cookiesText")),
                        },
                        null,
                        10,
                        ye
                      ),
                    ]),
                    o("li", me, [
                      o(
                        "a",
                        {
                          class: g([
                            "brandhub-legal-layer__tab-name",
                            e.getFocusedClass(e.privacyAnchor),
                          ]),
                          href: e.sanitizedLegalUrls(e.privacyAnchor),
                          ref: "privacyTab",
                          onClick:
                            t[3] ||
                            (t[3] = (r) => e.changeTabFocus(e.privacyAnchor)),
                          role: "tab",
                          textContent: f(e.t("privacyStatement")),
                        },
                        null,
                        10,
                        Ce
                      ),
                    ]),
                    o("li", Ae, [
                      o(
                        "a",
                        {
                          class: g([
                            "brandhub-legal-layer__tab-name brandhub-legal-layer__foss-tab",
                            e.getFocusedClass(e.fossOverviewAnchor),
                          ]),
                          href: e.sanitizedLegalUrls(e.fossOverviewAnchor),
                          onClick:
                            t[4] ||
                            (t[4] = (r) =>
                              e.changeTabFocus(e.fossOverviewAnchor)),
                          role: "tab",
                          textContent: f(e.t("fossOverview")),
                        },
                        null,
                        10,
                        we
                      ),
                    ]),
                  ])),
            ]),
            e.isMobile
              ? c("", !0)
              : (l(),
                s("div", _e, [
                  e.focusedTab === e.providerAnchor || e.editMode
                    ? (l(),
                      s("div", Le, [
                        o(
                          "div",
                          {
                            class: "brandhub-legal-layer__text",
                            ref: "providerContent",
                            innerHTML: e.fetchedProviderContent,
                          },
                          null,
                          8,
                          ke
                        ),
                      ]))
                    : c("", !0),
                  e.focusedTab === e.legalNoticeAnchor || e.editMode
                    ? (l(),
                      s("div", Te, [
                        o(
                          "div",
                          {
                            class: "brandhub-legal-layer__text",
                            ref: "legalNoticeContent",
                            innerHTML: e.fetchedLegalContent,
                          },
                          null,
                          8,
                          Ne
                        ),
                      ]))
                    : c("", !0),
                  e.focusedTab === e.cookiesAnchor || e.editMode
                    ? (l(), s("div", Se, [w(e.$slots, "cookies")]))
                    : c("", !0),
                  e.focusedTab === e.privacyAnchor || e.editMode
                    ? (l(),
                      s("div", Ee, [
                        o(
                          "div",
                          {
                            class: "brandhub-legal-layer__text",
                            ref: "privacyContent",
                            innerHTML: e.fetchedPrivacyContent,
                          },
                          null,
                          8,
                          Fe
                        ),
                      ]))
                    : c("", !0),
                  e.focusedTab === e.fossOverviewAnchor || e.editMode
                    ? (l(),
                      s("div", ze, [
                        o("div", null, [
                          d(
                            b,
                            {
                              "foss-overview-content-path":
                                e.fossOverviewContentPath,
                            },
                            null,
                            8,
                            ["foss-overview-content-path"]
                          ),
                        ]),
                      ]))
                    : c("", !0),
                ])),
            e.isMobile
              ? (l(),
                s("div", Me, [
                  d(
                    A,
                    { collapse: !0, "bg-color": "background-white" },
                    {
                      default: y(() => [
                        d(
                          i,
                          {
                            ref: "providerAccordion",
                            href: e.sanitizedLegalUrls(e.providerAnchor),
                            title: e.translatedTitle("provider"),
                            collapsed: e.focusedTab !== e.providerAnchor,
                            onClick:
                              t[5] ||
                              (t[5] = (r) =>
                                e.changeTabFocus(e.providerAnchor)),
                          },
                          {
                            left: y(() => [
                              o(
                                "div",
                                {
                                  class: "brandhub-legal-layer__text",
                                  innerHTML: e.fetchedProviderContent,
                                },
                                null,
                                8,
                                Pe
                              ),
                            ]),
                            _: 1,
                          },
                          8,
                          ["href", "title", "collapsed"]
                        ),
                        d(
                          i,
                          {
                            ref: "legalAccordion",
                            href: e.sanitizedLegalUrls(e.legalNoticeAnchor),
                            title: e.translatedTitle("legalNotice"),
                            collapsed: e.focusedTab !== e.legalNoticeAnchor,
                            onClick:
                              t[6] ||
                              (t[6] = (r) =>
                                e.changeTabFocus(e.legalNoticeAnchor)),
                          },
                          {
                            left: y(() => [
                              o(
                                "div",
                                {
                                  class: "brandhub-legal-layer__text",
                                  innerHTML: e.fetchedLegalContent,
                                },
                                null,
                                8,
                                $e
                              ),
                            ]),
                            _: 1,
                          },
                          8,
                          ["href", "title", "collapsed"]
                        ),
                        d(
                          i,
                          {
                            ref: "cookiesAccordion",
                            href: e.sanitizedLegalUrls(e.cookiesAnchor),
                            title: "Cookies",
                            collapsed: e.focusedTab !== e.cookiesAnchor,
                            onClick:
                              t[7] ||
                              (t[7] = (r) => e.changeTabFocus(e.cookiesAnchor)),
                          },
                          { left: y(() => [w(e.$slots, "cookies")]), _: 3 },
                          8,
                          ["href", "collapsed"]
                        ),
                        d(
                          i,
                          {
                            ref: "privacyAccordion",
                            href: e.sanitizedLegalUrls(e.privacyAnchor),
                            title: e.translatedTitle("privacyStatement"),
                            collapsed: e.focusedTab !== e.privacyAnchor,
                            onClick:
                              t[8] ||
                              (t[8] = (r) => e.changeTabFocus(e.privacyAnchor)),
                          },
                          {
                            left: y(() => [
                              o(
                                "div",
                                {
                                  class: "brandhub-legal-layer__text",
                                  innerHTML: e.fetchedPrivacyContent,
                                },
                                null,
                                8,
                                Be
                              ),
                            ]),
                            _: 1,
                          },
                          8,
                          ["href", "title", "collapsed"]
                        ),
                      ]),
                      _: 3,
                    }
                  ),
                ]))
              : c("", !0),
          ]),
        ]),
      ],
      2
    )),
    [[N, e.open || e.editMode]]
  );
}
const Ye = B(ie, [
  ["render", Ie],
  ["styles", [le]],
]);
export { ae as LEGAL_LINK_CLICKED_EVENT, Ye as default };
