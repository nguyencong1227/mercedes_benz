import {
  d as e,
  L as n,
  a as s,
  _ as o,
  o as c,
  b as p,
  M as u,
} from "./index.js";
import { R as a } from "./ResizeUpdateMixin-a56b9b41.js";
import { _ as v } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const E = (m, t) => {
    const r = m[t];
    return r
      ? typeof r == "function"
        ? r()
        : Promise.resolve(r)
      : new Promise((_, i) => {
          (typeof queueMicrotask == "function" ? queueMicrotask : setTimeout)(
            i.bind(null, new Error("Unknown variable dynamic import: " + t))
          );
        });
  },
  l = e({
    name: "BrandhubIcon",
    props: {
      icon: { type: String, default: "mercedes-benz-star" },
      iconTitle: String,
      originalSize: Boolean,
    },
    data() {
      return { iconComponent: null };
    },
    mixins: [a],
    watch: {
      icon: {
        handler() {
          this.iconComponent = n(
            s(() =>
              E(
                Object.assign({
                  "../../common/icons/arrow-down-big.svg": () =>
                    o(
                      () => import("./arrow-down-big-450863a1.js"),
                      [
                        "./arrow-down-big-450863a1.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-external.svg": () =>
                    o(
                      () => import("./arrow-external-85400e28.js"),
                      [
                        "./arrow-external-85400e28.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-left-big.svg": () =>
                    o(
                      () => import("./arrow-left-big-778cbf1f.js"),
                      [
                        "./arrow-left-big-778cbf1f.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-left-circle-black.svg": () =>
                    o(
                      () => import("./arrow-left-circle-black-18997010.js"),
                      [
                        "./arrow-left-circle-black-18997010.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-left-circle-white.svg": () =>
                    o(
                      () => import("./arrow-left-circle-white-00f93bfd.js"),
                      [
                        "./arrow-left-circle-white-00f93bfd.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-right-16.svg": () =>
                    o(
                      () => import("./arrow-right-16-be7655f4.js"),
                      [
                        "./arrow-right-16-be7655f4.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-right-big.svg": () =>
                    o(
                      () => import("./arrow-right-big-be1bce86.js"),
                      [
                        "./arrow-right-big-be1bce86.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-right-circle-black.svg": () =>
                    o(
                      () => import("./arrow-right-circle-black-f1e56aa7.js"),
                      [
                        "./arrow-right-circle-black-f1e56aa7.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-right-circle-white.svg": () =>
                    o(
                      () => import("./arrow-right-circle-white-56d9c5c6.js"),
                      [
                        "./arrow-right-circle-white-56d9c5c6.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-right.svg": () =>
                    o(
                      () => import("./arrow-right-9ff753e0.js"),
                      [
                        "./arrow-right-9ff753e0.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow-up-big.svg": () =>
                    o(
                      () => import("./arrow-up-big-5d3eb07b.js"),
                      [
                        "./arrow-up-big-5d3eb07b.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/arrow_new_window.svg": () =>
                    o(
                      () => import("./arrow_new_window-1dbf2132.js"),
                      [
                        "./arrow_new_window-1dbf2132.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/audio.svg": () =>
                    o(
                      () => import("./audio-e2d317b4.js"),
                      ["./audio-e2d317b4.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/bds-search.svg": () =>
                    o(
                      () => import("./bds-search-88877269.js"),
                      ["./bds-search-88877269.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/bookmark.svg": () =>
                    o(
                      () => import("./bookmark-8a669d01.js"),
                      ["./bookmark-8a669d01.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/brochures.svg": () =>
                    o(
                      () => import("./brochures-53e73db9.js"),
                      ["./brochures-53e73db9.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/calendar.svg": () =>
                    o(
                      () => import("./calendar-ec32a973.js"),
                      ["./calendar-ec32a973.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/call.svg": () =>
                    o(
                      () => import("./call-ae23a70b.js"),
                      ["./call-ae23a70b.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/car-config.svg": () =>
                    o(
                      () => import("./car-config-2e0c3348.js"),
                      ["./car-config-2e0c3348.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/car.svg": () =>
                    o(
                      () => import("./car-73c56995.js"),
                      ["./car-73c56995.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/chevron-down.svg": () =>
                    o(
                      () => import("./chevron-down-b572442a.js"),
                      [
                        "./chevron-down-b572442a.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/chevron-left.svg": () =>
                    o(
                      () => import("./chevron-left-3961cd13.js"),
                      [
                        "./chevron-left-3961cd13.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/chevron-right.svg": () =>
                    o(
                      () => import("./chevron-right-66213fb9.js"),
                      [
                        "./chevron-right-66213fb9.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/chevron-up.svg": () =>
                    o(
                      () => import("./chevron-up-dc049ada.js"),
                      ["./chevron-up-dc049ada.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/classic.svg": () =>
                    o(
                      () => import("./classic-8d67e58a.js"),
                      ["./classic-8d67e58a.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/close-circle.svg": () =>
                    o(
                      () => import("./close-circle-5f08da32.js"),
                      [
                        "./close-circle-5f08da32.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/close-new.svg": () =>
                    o(
                      () => import("./close-new-f0d12d75.js"),
                      ["./close-new-f0d12d75.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/close.svg": () =>
                    o(
                      () => import("./close-9703a3f7.js"),
                      ["./close-9703a3f7.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/co2-updated.svg": () =>
                    o(
                      () => import("./co2-updated-9294d71d.js"),
                      [
                        "./co2-updated-9294d71d.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/co2.svg": () =>
                    o(
                      () => import("./co2-c61804ce.js"),
                      ["./co2-c61804ce.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/community.svg": () =>
                    o(
                      () => import("./community-b168bb6c.js"),
                      ["./community-b168bb6c.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/connector-domestic-plugged.svg": () =>
                    o(
                      () => import("./connector-domestic-plugged-96ec34a4.js"),
                      [
                        "./connector-domestic-plugged-96ec34a4.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/dealer.svg": () =>
                    o(
                      () => import("./dealer-29592ce4.js"),
                      ["./dealer-29592ce4.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/direction-arrow.svg": () =>
                    o(
                      () => import("./direction-arrow-05485239.js"),
                      [
                        "./direction-arrow-05485239.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/download.svg": () =>
                    o(
                      () => import("./download-80a353e7.js"),
                      ["./download-80a353e7.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/email.svg": () =>
                    o(
                      () => import("./email-e52969fa.js"),
                      ["./email-e52969fa.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/energizing-programs.svg": () =>
                    o(
                      () => import("./energizing-programs-50eb5ae2.js"),
                      [
                        "./energizing-programs-50eb5ae2.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/energy-consumption.svg": () =>
                    o(
                      () => import("./energy-consumption-e8f26acb.js"),
                      [
                        "./energy-consumption-e8f26acb.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/energy-updated.svg": () =>
                    o(
                      () => import("./energy-updated-e92f0774.js"),
                      [
                        "./energy-updated-e92f0774.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/eq.svg": () =>
                    o(
                      () => import("./eq-9401eb15.js"),
                      ["./eq-9401eb15.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/expand.svg": () =>
                    o(
                      () => import("./expand-2e27c76e.js"),
                      ["./expand-2e27c76e.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/facebook-round.svg": () =>
                    o(
                      () => import("./facebook-round-3cd1a521.js"),
                      [
                        "./facebook-round-3cd1a521.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/facebook.svg": () =>
                    o(
                      () => import("./facebook-63d6e21d.js"),
                      ["./facebook-63d6e21d.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/favorite.svg": () =>
                    o(
                      () => import("./favorite-78269969.js"),
                      ["./favorite-78269969.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/foursquare.svg": () =>
                    o(
                      () => import("./foursquare-7d840e24.js"),
                      ["./foursquare-7d840e24.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/fuel-consumption.svg": () =>
                    o(
                      () => import("./fuel-consumption-1d3a2eea.js"),
                      [
                        "./fuel-consumption-1d3a2eea.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/fuel-e-comp.svg": () =>
                    o(
                      () => import("./fuel-e-comp-94a260a6.js"),
                      [
                        "./fuel-e-comp-94a260a6.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/g-class-front.svg": () =>
                    o(
                      () => import("./g-class-front-6cd7ecd0.js"),
                      [
                        "./g-class-front-6cd7ecd0.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/g-class-rear.svg": () =>
                    o(
                      () => import("./g-class-rear-1132679f.js"),
                      [
                        "./g-class-rear-1132679f.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/g-class-top.svg": () =>
                    o(
                      () => import("./g-class-top-9a49f83e.js"),
                      [
                        "./g-class-top-9a49f83e.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/gallery-filled.svg": () =>
                    o(
                      () => import("./gallery-filled-6eae3016.js"),
                      [
                        "./gallery-filled-6eae3016.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/gas-updated.svg": () =>
                    o(
                      () => import("./gas-updated-7bd7a15e.js"),
                      [
                        "./gas-updated-7bd7a15e.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/heart-rate.svg": () =>
                    o(
                      () => import("./heart-rate-8914fc88.js"),
                      ["./heart-rate-8914fc88.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/info-circle.svg": () =>
                    o(
                      () => import("./info-circle-dc0dcdfb.js"),
                      [
                        "./info-circle-dc0dcdfb.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/info.svg": () =>
                    o(
                      () => import("./info-be0980ed.js"),
                      ["./info-be0980ed.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/instagram.svg": () =>
                    o(
                      () => import("./instagram-c401a209.js"),
                      ["./instagram-c401a209.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/linkedin.svg": () =>
                    o(
                      () => import("./linkedin-ba763e49.js"),
                      ["./linkedin-ba763e49.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/listview.svg": () =>
                    o(
                      () => import("./listview-f868137c.js"),
                      ["./listview-f868137c.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/location.svg": () =>
                    o(
                      () => import("./location-ef166989.js"),
                      ["./location-ef166989.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/maps.svg": () =>
                    o(
                      () => import("./maps-e4bf72fe.js"),
                      ["./maps-e4bf72fe.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/menu-small.svg": () =>
                    o(
                      () => import("./menu-small-d246aef8.js"),
                      ["./menu-small-d246aef8.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/menu.svg": () =>
                    o(
                      () => import("./menu-cc653551.js"),
                      ["./menu-cc653551.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/mercedes-amg.svg": () =>
                    o(
                      () => import("./mercedes-amg-995b1d81.js"),
                      [
                        "./mercedes-amg-995b1d81.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/mercedes-benz-star.svg": () =>
                    o(
                      () => import("./mercedes-benz-star-d28564db.js"),
                      [
                        "./mercedes-benz-star-d28564db.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/mercedes-me.svg": () =>
                    o(
                      () => import("./mercedes-me-5a1f1583.js"),
                      [
                        "./mercedes-me-5a1f1583.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/messenger.svg": () =>
                    o(
                      () => import("./messenger-46b93598.js"),
                      ["./messenger-46b93598.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/move-cursor.svg": () =>
                    o(
                      () => import("./move-cursor-28f3837e.js"),
                      [
                        "./move-cursor-28f3837e.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/museum.svg": () =>
                    o(
                      () => import("./museum-6b08d837.js"),
                      ["./museum-6b08d837.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/news.svg": () =>
                    o(
                      () => import("./news-3bb18602.js"),
                      ["./news-3bb18602.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/newsletter.svg": () =>
                    o(
                      () => import("./newsletter-4a99ae9e.js"),
                      ["./newsletter-4a99ae9e.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/parts-excellence.svg": () =>
                    o(
                      () => import("./parts-excellence-f1d6277a.js"),
                      [
                        "./parts-excellence-f1d6277a.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/parts-quality.svg": () =>
                    o(
                      () => import("./parts-quality-8cdc577a.js"),
                      [
                        "./parts-quality-8cdc577a.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/parts-safety.svg": () =>
                    o(
                      () => import("./parts-safety-d2614abf.js"),
                      [
                        "./parts-safety-d2614abf.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/parts-value-retention.svg": () =>
                    o(
                      () => import("./parts-value-retention-8320a57e.js"),
                      [
                        "./parts-value-retention-8320a57e.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/personalisation.svg": () =>
                    o(
                      () => import("./personalisation-533b78c6.js"),
                      [
                        "./personalisation-533b78c6.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/pinterest.svg": () =>
                    o(
                      () => import("./pinterest-49b66bb4.js"),
                      ["./pinterest-49b66bb4.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/play-circle.svg": () =>
                    o(
                      () => import("./play-circle-9622b6f6.js"),
                      [
                        "./play-circle-9622b6f6.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/play-transparent.svg": () =>
                    o(
                      () => import("./play-transparent-414ed998.js"),
                      [
                        "./play-transparent-414ed998.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/play.svg": () =>
                    o(
                      () => import("./play-0d51a982.js"),
                      ["./play-0d51a982.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/plus.svg": () =>
                    o(
                      () => import("./plus-7daebbd7.js"),
                      ["./plus-7daebbd7.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/pollution.svg": () =>
                    o(
                      () => import("./pollution-f3628f6e.js"),
                      ["./pollution-f3628f6e.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/recommended.svg": () =>
                    o(
                      () => import("./recommended-3e3c49de.js"),
                      [
                        "./recommended-3e3c49de.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/search-new.svg": () =>
                    o(
                      () => import("./search-new-c7c929c5.js"),
                      ["./search-new-c7c929c5.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/search.svg": () =>
                    o(
                      () => import("./search-0ea78e81.js"),
                      ["./search-0ea78e81.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/seat.svg": () =>
                    o(
                      () => import("./seat-76778914.js"),
                      ["./seat-76778914.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/series.svg": () =>
                    o(
                      () => import("./series-7c22e0ad.js"),
                      ["./series-7c22e0ad.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/share.svg": () =>
                    o(
                      () => import("./share-a751048a.js"),
                      ["./share-a751048a.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/shopping-cart.svg": () =>
                    o(
                      () => import("./shopping-cart-e4022631.js"),
                      [
                        "./shopping-cart-e4022631.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/social-cloud.svg": () =>
                    o(
                      () => import("./social-cloud-0887ae23.js"),
                      [
                        "./social-cloud-0887ae23.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/sound-max.svg": () =>
                    o(
                      () => import("./sound-max-4aab8f7b.js"),
                      ["./sound-max-4aab8f7b.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/sound-off.svg": () =>
                    o(
                      () => import("./sound-off-9ec03ccd.js"),
                      ["./sound-off-9ec03ccd.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/sound-on.svg": () =>
                    o(
                      () => import("./sound-on-6f51ec6c.js"),
                      ["./sound-on-6f51ec6c.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/sprdkl-angle.svg": () =>
                    o(
                      () => import("./sprdkl-angle-716f13d8.js"),
                      [
                        "./sprdkl-angle-716f13d8.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/sprdkl-back.svg": () =>
                    o(
                      () => import("./sprdkl-back-61a04486.js"),
                      [
                        "./sprdkl-back-61a04486.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/sprdkl-front.svg": () =>
                    o(
                      () => import("./sprdkl-front-6eb350c4.js"),
                      [
                        "./sprdkl-front-6eb350c4.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/sprdkl-left.svg": () =>
                    o(
                      () => import("./sprdkl-left-e42e7b4a.js"),
                      [
                        "./sprdkl-left-e42e7b4a.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/sprdkl-right.svg": () =>
                    o(
                      () => import("./sprdkl-right-f6c54dcb.js"),
                      [
                        "./sprdkl-right-f6c54dcb.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/swipe.svg": () =>
                    o(
                      () => import("./swipe-1065cf4d.js"),
                      ["./swipe-1065cf4d.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/testdrive.svg": () =>
                    o(
                      () => import("./testdrive-c9ac2b91.js"),
                      ["./testdrive-c9ac2b91.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/threesixty-degree.svg": () =>
                    o(
                      () => import("./threesixty-degree-de0df254.js"),
                      [
                        "./threesixty-degree-de0df254.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/tickets.svg": () =>
                    o(
                      () => import("./tickets-83dbdf38.js"),
                      ["./tickets-83dbdf38.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/tiktok.svg": () =>
                    o(
                      () => import("./tiktok-436d71cc.js"),
                      ["./tiktok-436d71cc.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/time.svg": () =>
                    o(
                      () => import("./time-6a6fd51c.js"),
                      ["./time-6a6fd51c.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/tumblr.svg": () =>
                    o(
                      () => import("./tumblr-861443d0.js"),
                      ["./tumblr-861443d0.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/twitter-legacy.svg": () =>
                    o(
                      () => import("./twitter-legacy-a024bdc0.js"),
                      [
                        "./twitter-legacy-a024bdc0.js",
                        "./index.js",
                        "./index.css",
                      ],
                      import.meta.url
                    ),
                  "../../common/icons/twitter.svg": () =>
                    o(
                      () => import("./twitter-5caa0b09.js"),
                      ["./twitter-5caa0b09.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/volume-up.svg": () =>
                    o(
                      () => import("./volume-up-0832aaa9.js"),
                      ["./volume-up-0832aaa9.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/weibo.svg": () =>
                    o(
                      () => import("./weibo-6a4f012d.js"),
                      ["./weibo-6a4f012d.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/whatsapp.svg": () =>
                    o(
                      () => import("./whatsapp-e691b570.js"),
                      ["./whatsapp-e691b570.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/xing.svg": () =>
                    o(
                      () => import("./xing-1d8af4f0.js"),
                      ["./xing-1d8af4f0.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                  "../../common/icons/youtube.svg": () =>
                    o(
                      () => import("./youtube-0fa13c49.js"),
                      ["./youtube-0fa13c49.js", "./index.js", "./index.css"],
                      import.meta.url
                    ),
                }),
                `../../common/icons/${this.icon}.svg`
              )
            )
          );
        },
        immediate: !0,
      },
    },
  }),
  d = `.brandhub-icon path{fill:var(--icon-color, currentColor);transition:fill var(--icon-transition, .16s ease-out)}.brandhub-icon circle{fill:var(--icon-circle-color, var(--wb-white));transition:fill var(--icon-transition, .16s ease-out)}
`;
function g(m, t, r, _, i, R) {
  return (
    c(),
    p(
      u(m.iconComponent),
      { class: "brandhub-icon", title: m.iconTitle },
      null,
      8,
      ["title"]
    )
  );
}
const L = v(l, [
  ["render", g],
  ["styles", [d]],
]);
export { L as default };
