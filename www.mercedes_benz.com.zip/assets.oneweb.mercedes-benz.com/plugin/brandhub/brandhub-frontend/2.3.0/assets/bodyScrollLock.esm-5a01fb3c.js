function y(n) {
  if (Array.isArray(n)) {
    for (var e = 0, o = Array(n.length); e < n.length; e++) o[e] = n[e];
    return o;
  } else return Array.from(n);
}
var s = !1;
if (typeof window < "u") {
  var v = {
    get passive() {
      s = !0;
    },
  };
  window.addEventListener("testPassive", null, v),
    window.removeEventListener("testPassive", null, v);
}
var c =
    typeof window < "u" &&
    window.navigator &&
    window.navigator.platform &&
    (/iP(ad|hone|od)/.test(window.navigator.platform) ||
      (window.navigator.platform === "MacIntel" &&
        window.navigator.maxTouchPoints > 1)),
  t = [],
  i = !1,
  f = -1,
  d = void 0,
  u = void 0,
  h = function (e) {
    return t.some(function (o) {
      return !!(o.options.allowTouchMove && o.options.allowTouchMove(e));
    });
  },
  a = function (e) {
    var o = e || window.event;
    return h(o.target) || o.touches.length > 1
      ? !0
      : (o.preventDefault && o.preventDefault(), !1);
  },
  g = function (e) {
    if (u === void 0) {
      var o = !!e && e.reserveScrollBarGap === !0,
        r = window.innerWidth - document.documentElement.clientWidth;
      o &&
        r > 0 &&
        ((u = document.body.style.paddingRight),
        (document.body.style.paddingRight = r + "px"));
    }
    d === void 0 &&
      ((d = document.body.style.overflow),
      (document.body.style.overflow = "hidden"));
  },
  w = function () {
    u !== void 0 && ((document.body.style.paddingRight = u), (u = void 0)),
      d !== void 0 && ((document.body.style.overflow = d), (d = void 0));
  },
  m = function (e) {
    return e ? e.scrollHeight - e.scrollTop <= e.clientHeight : !1;
  },
  p = function (e, o) {
    var r = e.targetTouches[0].clientY - f;
    return h(e.target)
      ? !1
      : (o && o.scrollTop === 0 && r > 0) || (m(o) && r < 0)
      ? a(e)
      : (e.stopPropagation(), !0);
  },
  S = function (e, o) {
    if (!e) {
      console.error(
        "disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices."
      );
      return;
    }
    if (
      !t.some(function (l) {
        return l.targetElement === e;
      })
    ) {
      var r = { targetElement: e, options: o || {} };
      (t = [].concat(y(t), [r])),
        c
          ? ((e.ontouchstart = function (l) {
              l.targetTouches.length === 1 && (f = l.targetTouches[0].clientY);
            }),
            (e.ontouchmove = function (l) {
              l.targetTouches.length === 1 && p(l, e);
            }),
            i ||
              (document.addEventListener(
                "touchmove",
                a,
                s ? { passive: !1 } : void 0
              ),
              (i = !0)))
          : g(o);
    }
  },
  b = function () {
    c
      ? (t.forEach(function (e) {
          (e.targetElement.ontouchstart = null),
            (e.targetElement.ontouchmove = null);
        }),
        i &&
          (document.removeEventListener(
            "touchmove",
            a,
            s ? { passive: !1 } : void 0
          ),
          (i = !1)),
        (f = -1))
      : w(),
      (t = []);
  },
  T = function (e) {
    if (!e) {
      console.error(
        "enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices."
      );
      return;
    }
    (t = t.filter(function (o) {
      return o.targetElement !== e;
    })),
      c
        ? ((e.ontouchstart = null),
          (e.ontouchmove = null),
          i &&
            t.length === 0 &&
            (document.removeEventListener(
              "touchmove",
              a,
              s ? { passive: !1 } : void 0
            ),
            (i = !1)))
        : t.length || w();
  };
export { b as c, S as d, T as e };
