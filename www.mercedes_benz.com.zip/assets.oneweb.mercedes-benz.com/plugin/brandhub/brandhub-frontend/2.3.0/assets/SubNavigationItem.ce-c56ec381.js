import { C as t } from "./ChildComponentMixin-dd022493.js";
import { d as e, o as i, c as n } from "./index.js";
import { _ as o } from "./_plugin-vue_export-helper-c27b6911.js";
const r = e({
  name: "SubNavigationItem",
  props: {
    itemText: String,
    itemLink: String,
    editMode: Boolean,
    flyoutUrl: String,
  },
  mixins: [t],
  setup() {
    return { isActive: !1, initial: !0 };
  },
  created() {
    this.initChildComponentMixin("SubNavigationItem");
  },
});
function a(s, m, c, p, d, f) {
  return i(), n("div");
}
const x = o(r, [["render", a]]);
export { x as default };
