import { c as b } from "./BrandSafeHyphens-ffe3b60a.js";
import { I as u } from "./index-12214b95.js";
import {
  d as c,
  j as m,
  w,
  o as a,
  c as d,
  F as o,
  D as p,
  n as s,
  g as v,
  e as l,
  h as f,
  t as y,
} from "./index.js";
import { _ as x } from "./_plugin-vue_export-helper-c27b6911.js";
const g = c({
    name: "WordFade",
    props: {
      animatedText: { type: String, default: "" },
      manualFade: { type: Boolean, default: !1 },
      manualFadeIn: Boolean,
      fadeToOpacity: { type: Number, default: 1 },
      delay: { type: Number, default: 0 },
      interimDelay: { type: Number, default: 75 },
      textAlign: {
        type: String,
        default: "left",
        validator: (e) =>
          [
            "left",
            "right",
            "center",
            "desktop-center",
            "always-center",
          ].includes(e),
      },
    },
    directives: { intersect: u },
    data() {
      return { textFadeIn: !1, visibleTextBlock: -1, isHiddenAbove: !1 };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-word-fade--left": this.textAlign === "left",
          "brandhub-word-fade--right": this.textAlign === "right",
          "brandhub-word-fade--center": this.textAlign === "center",
          "brandhub-word-fade--desktop-center":
            this.textAlign === "desktop-center",
          "brandhub-word-fade--always-center":
            this.textAlign === "always-center",
        };
      },
      splittedText() {
        return this.animatedText.replace("<br />", "<br/> ").split(" ");
      },
    },
    methods: {
      filteredWord(e) {
        return e.replace("<br/>", "");
      },
      handleIntersection(e, t) {
        if (!this.manualFade) {
          const { top: n } = t.getBoundingClientRect();
          e || n <= 0 ? this.fadeInText() : e || this.fadeOutWord();
        }
      },
      fadeInText(e = !0) {
        (this.isHiddenAbove = !e), (this.textFadeIn = !0), this.fadeInWord(e);
      },
      fadeInWord(e = !0) {
        const t = Math.floor(
          this.visibleTextBlock === -1 && this.delay ? this.delay : 0
        );
        setTimeout(() => {
          (this.visibleTextBlock += 1),
            this.visibleTextBlock + 1 < this.splittedText.length &&
              this.textFadeIn &&
              setTimeout(() => {
                this.fadeInWord(e);
              }, this.interimDelay);
        }, t);
      },
      fadeOutText() {
        this.$emit("fade-out-complete");
      },
      fadeOutWord(e = !1) {
        (this.isHiddenAbove = e),
          (this.textFadeIn = !1),
          (this.visibleTextBlock -= 1),
          this.visibleTextBlock < 0
            ? this.fadeOutText()
            : this.textFadeIn ||
              setTimeout(() => {
                this.fadeOutWord(e);
              }, 40);
      },
      fadeInTextClass(e, t) {
        return {
          "brandhub-word-fade__word--visible": t <= this.visibleTextBlock,
          "brandhub-word-fade__word--hidden-above": this.isHiddenAbove,
          ...b(e),
        };
      },
    },
    mounted() {
      this.manualFade && this.manualFadeIn && this.fadeInText();
    },
    watch: {
      manualFadeIn(e) {
        this.manualFade &&
          (e && !this.textFadeIn && this.fadeInText(),
          !e && this.textFadeIn && this.fadeOutWord());
      },
    },
  }),
  _ = `.brandhub-word-fade{display:flex;flex-flow:row wrap;justify-content:flex-start}@media (min-width: 480px){.brandhub-word-fade--right{justify-content:flex-end;margin-left:-.2em}.brandhub-word-fade--right .brandhub-word-fade__word-wrapper{margin-left:.2em;margin-right:0}}.brandhub-word-fade--center{margin-right:-.2em}@media (min-width: 480px){.brandhub-word-fade--center{justify-content:center}}.brandhub-word-fade--desktop-center{margin-right:-.2em}@media (min-width: 1024px){.brandhub-word-fade--desktop-center{justify-content:center}}.brandhub-word-fade--always-center{justify-content:center;margin-right:-.2em}.brandhub-word-fade--left{margin-right:-.2em}.brandhub-word-fade__word-wrapper{margin-bottom:-.1em;margin-right:.2em;overflow:hidden}.brandhub-word-fade__word{--word-transform: var(--overwrite-word-transform-start, var(--overwrite-word-transform, translateY(1.1em)));--word-transition: var(--overwrite-word-transition, transform .3s cubic-bezier(.46, 0, 1, .5)), opacity 1s;display:flex;line-height:var(--word-fade-line-height, 1.1em);opacity:var(--fade-to-opacity);transform:var(--word-transform);transition:var(--word-transition)}.brandhub-word-fade__word.no-break,.brandhub-word-fade__word .no-break{-webkit-hyphens:manual;hyphens:manual;white-space:nowrap}.brandhub-word-fade__word--hidden-above{--word-transform: translateY(-1.1em)}.brandhub-word-fade__word--visible{--word-transform: var(--overwrite-word-transform, translateY(0));--word-transition: var(--overwrite-word-transition, transform 1s cubic-bezier(0, 1, .45, 1)), opacity 1s;opacity:1}.brandhub-word-fade__line-break{content:"";width:100%}
`,
  T = { class: "brandhub-word-fade__word-wrapper" };
function k(e, t, n, I, F, B) {
  const h = m("intersect");
  return e.animatedText
    ? w(
        (a(),
        d(
          "div",
          {
            key: 0,
            class: s(["brandhub-word-fade", e.rootClass]),
            style: v(`--fade-to-opacity: ${e.fadeToOpacity}`),
          },
          [
            (a(!0),
            d(
              o,
              null,
              p(
                e.splittedText,
                (r, i) => (
                  a(),
                  d(
                    o,
                    { key: `text-${r}-${i}` },
                    [
                      f("div", T, [
                        f(
                          "div",
                          {
                            class: s([
                              "brandhub-word-fade__word",
                              e.fadeInTextClass(r, i),
                            ]),
                          },
                          y(e.filteredWord(r)),
                          3
                        ),
                      ]),
                      r.includes("<br/>")
                        ? (a(),
                          d("div", {
                            class: "brandhub-word-fade__line-break",
                            key: `br-${r}-${i}`,
                          }))
                        : l("", !0),
                    ],
                    64
                  )
                )
              ),
              128
            )),
          ],
          6
        )),
        [[h, { onChange: e.handleIntersection }]]
      )
    : l("", !0);
}
const D = x(g, [
  ["render", k],
  ["styles", [_]],
]);
export { D as default };
