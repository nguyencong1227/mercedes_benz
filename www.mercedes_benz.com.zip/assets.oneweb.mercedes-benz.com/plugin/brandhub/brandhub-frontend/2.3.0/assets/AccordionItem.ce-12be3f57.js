import { R as m } from "./ResizeUpdateMixin-a56b9b41.js";
import b from "./Icon.ce-1a736152.js";
import { C as _ } from "./ChildComponentMixin-dd022493.js";
import {
  d as u,
  i as p,
  r as f,
  o as e,
  c as n,
  h as i,
  t as x,
  e as o,
  f as r,
  n as d,
  k as g,
  T as v,
  g as c,
  w,
  v as y,
  B as s,
} from "./index.js";
import { _ as C } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const k = u({
    props: {
      title: String,
      text: { type: String, default: "" },
      collapsed: { type: Boolean },
      options: { type: String, default: "variant-12" },
    },
    components: { "accordion-icon": b },
    mixins: [_, m],
    data() {
      return { open: !1, height: 0, isBlock: !1 };
    },
    setup() {
      return { content: p() };
    },
    computed: {
      rootStyle() {
        return { "--content-height": `${this.height}px` };
      },
      contentClass() {
        return {
          "brandhub-accordion-item__content--variant-4-8":
            this.options === "variant-4-8",
          "brandhub-accordion-item__content--variant-8-4":
            this.options === "variant-8-4",
          "brandhub-accordion-item__content--variant-12":
            this.options === "variant-12",
        };
      },
      displayStyle() {
        return this.isBlock
          ? { "--content-display": "block" }
          : { "--content-display": "flex" };
      },
      arrowClass() {
        return {
          "brandhub-accordion-item__icon--opened": this.open,
          "brandhub-accordion-item__icon--closed": !this.open,
        };
      },
    },
    methods: {
      openContent() {
        this.open = !this.open;
        const t = new CustomEvent("accordionItemClicked", {
          bubbles: !0,
          composed: !0,
          detail: { clickedItem: this },
        });
        this.$el.dispatchEvent(t),
          this.open &&
            ((this.isBlock = !0),
            this.$nextTick(() => {
              this.content &&
                ((this.height = this.content.scrollHeight || 0),
                (this.isBlock = !1));
            }));
      },
    },
    created() {
      this.initChildComponentMixin("AccordionItem");
    },
    mounted() {
      this.collapsed || this.openContent();
    },
  }),
  B = `.brandhub-accordion-item{display:flex;flex-direction:column;position:relative;padding-left:1.1428571429rem;padding-right:1.1428571429rem}@media (min-width: 768px){.brandhub-accordion-item{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-accordion-item{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-accordion-item{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-accordion-item{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-accordion-item__header{align-items:center;background:none;border:none;color:var(--text-color);cursor:pointer;display:flex;font-family:MBCorpo Text,sans-serif;padding:1.7857142857rem 0;text-align:start;z-index:1}.brandhub-accordion-item__header:focus-visible{outline:3px solid rgba(0,120,214,.8)}.brandhub-accordion-item__headline{font-family:MBCorpo Title,sans-serif;line-height:1em;font-size:2.1428571429rem;font-weight:400;margin:0}.brandhub-accordion-item__sub-headline{font-size:1.2857142857rem}.brandhub-accordion-item__sub-headline p{margin:0}.brandhub-accordion-item__text{display:flex;flex-direction:column;font-size:1.1428571429rem}.brandhub-accordion-item__icon{justify-self:center}.brandhub-accordion-item__icon--opened{margin-left:auto;transform:rotate(180deg)}.brandhub-accordion-item__icon--closed{margin-left:auto;transform:rotate(0)}.brandhub-accordion-item__content{display:var(--content-display);flex-wrap:wrap}@media (max-width: 1279px){.brandhub-accordion-item__content--variant-12 .brandhub-accordion-item__col--left{flex:0 0 100%;max-width:100%}}@media (max-width: 1279px){.brandhub-accordion-item__content--variant-4-8 .brandhub-accordion-item__col--left{flex:0 0 100%;max-width:100%}}@media (min-width: 1280px){.brandhub-accordion-item__content--variant-4-8 .brandhub-accordion-item__col--left{flex:0 0 33.3333333333%;max-width:33.3333333333%}}@media (max-width: 1279px){.brandhub-accordion-item__content--variant-4-8 .brandhub-accordion-item__col--right{flex:0 0 100%;max-width:100%}}@media (min-width: 1280px){.brandhub-accordion-item__content--variant-4-8 .brandhub-accordion-item__col--right{flex:0 0 66.6666666667%;max-width:66.6666666667%}}@media (max-width: 1279px){.brandhub-accordion-item__content--variant-8-4 .brandhub-accordion-item__col--left{flex:0 0 100%;max-width:100%}}@media (min-width: 1280px){.brandhub-accordion-item__content--variant-8-4 .brandhub-accordion-item__col--left{flex:0 0 66.6666666667%;max-width:66.6666666667%}}@media (max-width: 1279px){.brandhub-accordion-item__content--variant-8-4 .brandhub-accordion-item__col--right{flex:0 0 100%;max-width:100%}}@media (min-width: 1280px){.brandhub-accordion-item__content--variant-8-4 .brandhub-accordion-item__col--right{flex:0 0 33.3333333333%;max-width:33.3333333333%}}.brandhub-accordion-item__content--slide-enter-active,.brandhub-accordion-item__content--slide-leave-active{transition:height .7s ease-in-out,opacity .7s ease-in-out}.brandhub-accordion-item__content--slide-enter-to,.brandhub-accordion-item__content--slide-leave-from{height:var(--content-height);opacity:1;overflow:hidden}.brandhub-accordion-item__content--slide-enter-from,.brandhub-accordion-item__content--slide-leave-to{height:0;opacity:0;overflow:hidden}.brandhub-accordion-item__seperation-line{border-bottom:1px solid var(--wb-grey-70);height:1px;position:relative;width:100%}
`,
  S = { class: "brandhub-accordion-item__text" },
  $ = ["textContent"],
  z = ["innerHTML"],
  M = {
    class: "brandhub-accordion-item__col brandhub-accordion-item__col--left",
  },
  T = {
    key: 0,
    class: "brandhub-accordion-item__col brandhub-accordion-item__col--right",
  },
  I = i("div", { class: "brandhub-accordion-item__seperation-line" }, null, -1);
function E(t, a, H, N, V, A) {
  const l = f("accordion-icon");
  return (
    e(),
    n(
      "div",
      { class: "brandhub-accordion-item", style: c(t.rootStyle) },
      [
        i(
          "button",
          {
            class: "brandhub-accordion-item__header",
            onClick:
              a[0] || (a[0] = (...h) => t.openContent && t.openContent(...h)),
          },
          [
            i("div", S, [
              t.title
                ? (e(),
                  n(
                    "h4",
                    {
                      key: 0,
                      textContent: x(t.title),
                      class: "brandhub-accordion-item__headline",
                    },
                    null,
                    8,
                    $
                  ))
                : o("", !0),
              t.text
                ? (e(),
                  n(
                    "div",
                    {
                      key: 1,
                      class: "brandhub-accordion-item__sub-headline",
                      innerHTML: t.text,
                    },
                    null,
                    8,
                    z
                  ))
                : o("", !0),
            ]),
            r(
              l,
              {
                icon: "arrow-down-big",
                width: 40,
                height: 40,
                class: d(t.arrowClass),
              },
              null,
              8,
              ["class"]
            ),
          ]
        ),
        r(
          v,
          { name: "brandhub-accordion-item__content--slide" },
          {
            default: g(() => [
              w(
                i(
                  "div",
                  {
                    ref: "content",
                    class: d([
                      "brandhub-accordion-item__content",
                      t.contentClass,
                    ]),
                    style: c(t.displayStyle),
                  },
                  [
                    i("div", M, [
                      s(t.$slots, "left", {
                        class: "brandhub-accordion-item__slot",
                      }),
                    ]),
                    t.options !== "variant-12"
                      ? (e(), n("div", T, [s(t.$slots, "right")]))
                      : o("", !0),
                  ],
                  6
                ),
                [[y, t.open]]
              ),
            ]),
            _: 3,
          }
        ),
        I,
      ],
      4
    )
  );
}
const G = C(k, [
  ["render", E],
  ["styles", [B]],
]);
export { G as default };
