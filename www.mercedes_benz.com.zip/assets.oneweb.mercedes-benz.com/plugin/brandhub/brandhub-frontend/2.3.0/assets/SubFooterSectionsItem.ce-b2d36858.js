import { C as s } from "./ChildComponentMixin-dd022493.js";
import { T as n } from "./TrackingPushService-374dd83c.js";
import { d as r, o as a, c as b, h as i, t as m } from "./index.js";
import { _ as l } from "./_plugin-vue_export-helper-c27b6911.js";
const d = r({
    name: "SubFooterSectionsItem",
    props: { linkUrl: String, linkText: String, linkTarget: String },
    mixins: [s],
    data() {
      return { parentIndex: -1 };
    },
    methods: {
      onItemClick() {
        if (this.linkUrl && this.linkText) {
          const e = this.linkUrl,
            t = this.linkText;
          n.pushTrackingAttributes("link", "Footer Section", t, e);
        }
      },
      onFocusIn() {
        this.$el.dispatchEvent(
          new CustomEvent("footerSectionsItemFocused", {
            bubbles: !0,
            composed: !0,
            detail: { item: this },
          })
        );
      },
    },
    created() {
      this.initChildComponentMixin("SubFooterSectionsItem");
    },
  }),
  u = `.brandhub-sub-footer-sections-item{color:var(--wb-grey-45);font-size:1.1428571429rem;line-height:2.2857142857rem;text-decoration:none;transition:color .4s ease-in-out}@media (min-width: 768px){.brandhub-sub-footer-sections-item{font-size:1.2857142857rem}}@media (min-width: 1440px){.brandhub-sub-footer-sections-item{font-size:1.4285714286rem;line-height:2.5714285714rem}}.brandhub-sub-footer-sections-item:hover{color:var(--text-color)}.brandhub-sub-footer-sections-item:focus-visible{outline:none}@media (min-width: 480px){.brandhub-sub-footer-sections-item:focus-visible .brandhub-sub-footer-sections-item__text{position:relative}.brandhub-sub-footer-sections-item:focus-visible .brandhub-sub-footer-sections-item__text:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-sub-footer-sections-item:focus-visible .brandhub-sub-footer-sections-item__text:after{left:-.5rem;padding-right:.5rem;top:-.1428571429rem}}@media (max-width: 479px){.brandhub-sub-footer-sections-item:focus-visible .brandhub-sub-footer-sections-item__text{box-shadow:inset 0 0 0 3px #0078d6cc}}@media (max-width: 479px){.brandhub-sub-footer-sections-item__text-wrapper{line-height:1.4285714286rem;margin-bottom:.8571428571rem;overflow:hidden;text-overflow:ellipsis;width:calc(100vw - 17.5rem)}}
`,
  c = ["href", "target"],
  h = { class: "brandhub-sub-footer-sections-item__text-wrapper" },
  f = { class: "brandhub-sub-footer-sections-item__text" };
function p(e, t, x, k, _, g) {
  return (
    a(),
    b(
      "a",
      {
        class: "brandhub-sub-footer-sections-item",
        tabindex: "0",
        href: e.linkUrl,
        target: e.linkTarget,
        rel: "linkTarget === '_blank' ? 'noopener' : undefined",
        onFocusin: t[0] || (t[0] = (...o) => e.onFocusIn && e.onFocusIn(...o)),
        onClick:
          t[1] || (t[1] = (...o) => e.onItemClick && e.onItemClick(...o)),
      },
      [i("div", h, [i("span", f, m(e.linkText), 1)])],
      40,
      c
    )
  );
}
const I = l(d, [
  ["render", p],
  ["styles", [u]],
]);
export { I as default };
