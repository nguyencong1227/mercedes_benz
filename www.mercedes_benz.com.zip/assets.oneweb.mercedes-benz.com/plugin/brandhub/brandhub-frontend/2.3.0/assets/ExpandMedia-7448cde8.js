import { _ as l } from "./ExpandMedia.vue_vue_type_script_lang-73e76b3f.js";
import {
  r as I,
  o,
  c as d,
  n as p,
  G as g,
  b as a,
  e,
  B as Z,
  C as t,
} from "./index.js";
import { _ as C } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./index-12214b95.js";
import "./ExpandedMediaEventEmitter-0b86e5ec.js";
import "./mitt-f7ef348c.js";
const R =
    ".brandhub-expand-media{cursor:url(" +
    new URL("fullscreen_small.svg?external", import.meta.url).href +
    ") 20 20,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAEumlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjQwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iNDAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSI0MCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNDAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLjAiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLjAiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDItMTFUMDk6NTA6NDYrMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDItMTFUMDk6NTA6NDYrMDE6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgKFNlcCAyMiAyMDE5KSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMC0wMi0xMVQwOTo1MDo0NiswMTowMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+n3K2UwAAAYJpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAACiRdZHPK0RRFMc/M0PkRxTJwmISVkZ+1MRGmUkoaRqjDDZvnnkzat7M672RJltlO0WJjV8L/gK2ylopIiUrC2tig57zPDWSObdzz+d+7z2ne88Fbyyj6lZFL+jZvBkdC/ln43P+qke81FJNHy2KahkjkcgkZe3tBo8TrwJOrfLn/rXaxaSlgqdaeFg1zLzwuPDkSt5weFO4WU0ri8LHwt2mXFD42tETLj85nHL5w2EzFg2Dt1HYn/rFiV+spk1dWF5Oh55ZVn/u47ykLpmdmZbYLt6GRZQxQviZYJQwQenKkMxBAvTTIyvK5Pd+50+Rk1xVZoMCJkukSJOnW9RlqZ6UqImelJGh4PT/b18tbaDfrV4XgsoH237phKoN+Cza9vu+bX8egO8ezrKl/NweDL6KXixpHbvQsAYn5yUtsQWn69B6Zyim8i35xL2aBs9HUB+HpkuomXd79rPP4S3EVuWrLmB7B7rkfMPCFz2gZ9MR3oxgAAAACXBIWXMAAAsTAAALEwEAmpwYAAACE0lEQVRYhdWZvXLTQBRGz9VITXCNZ9zGTxAegNpuSPwYGSrobQZKaN3oEZIiULnNC5AmpsJuPUnauLNnPgpJQRJJ0Ar9cWa2kEdXe7ya3b17ZZRE0hB4A7wCBqkGsEm178A3M1uV7ctFqi/pk6Sl3FnGsf06xHqSZpLuS4jluY+f1atKbiLppgKxPDeSJv8i5kn6UINYnpkkz1XuQNJ5A3IJ55IOXEauSbmEM0lWRHDWglzC9G9ykxblEjITx1JyPWAFVL9OuXELDM1sC5CePe9pXw4ih3fJhUG0QwBr4EVLUnm2wKGZ3SUj+JYK5cIwJAgCzCzTxuNx0Uf0YqeHV3xSldxzLBYLl9tPAExRVvKzFqMUZtF8lOQSNvSIUqaucuwR5XNd5cjnd5JZK77vlwkbNCY4n8/LhA1M0pburH95tm55WAt4RAebwoRhSBiGNen8wcYkXQKvi0YEQQDAbrerySnDpY/jCO73+5pcHmXjEZ1bu8qV81ZXcssqy9CLT/w/XCPTWUoQBHVMnKWZrZNl5qJo1Gg0qlrkKS4gm7CuiPKwLpBNWM3sFvjSrlOGz2Z2B//ToSn+4bQtqxSnidyjqMsH91iw26WPWLLp4tGZihaPciM5a0BuqqIj94RoNwuYOcle/E+rKgFPVVUJOCfal/RR0nUJses49qVLn6XfvaRD4Bg44vnPEFfAVzNbl+nnF2iGl9Ptf7oHAAAAAElFTkSuQmCC) 20 20,zoom-in;height:100%;left:0;position:absolute;top:0;transform:translateY(0);width:100%;z-index:10}.brandhub-expand-media:focus-visible{box-shadow:inset 0 0 0 3px #0078d6cc}@media (min-width: 1440px){.brandhub-expand-media{cursor:url(" +
    new URL("fullscreen_big.svg?external", import.meta.url).href +
    ") 30 30,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAEumlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjYwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iNjAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSI2MCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNjAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLjAiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLjAiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDItMTFUMDk6NTE6MDErMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDItMTFUMDk6NTE6MDErMDE6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgKFNlcCAyMiAyMDE5KSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMC0wMi0xMVQwOTo1MTowMSswMTowMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+D4g+dwAAAYJpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAACiRdZHPK0RRFMc/M0PkRxTJwmISVkZ+1MRGmUkoaRqjDDZvnnkzat7M672RJltlO0WJjV8L/gK2ylopIiUrC2tig57zPDWSObdzz+d+7z2ne88Fbyyj6lZFL+jZvBkdC/ln43P+qke81FJNHy2KahkjkcgkZe3tBo8TrwJOrfLn/rXaxaSlgqdaeFg1zLzwuPDkSt5weFO4WU0ri8LHwt2mXFD42tETLj85nHL5w2EzFg2Dt1HYn/rFiV+spk1dWF5Oh55ZVn/u47ykLpmdmZbYLt6GRZQxQviZYJQwQenKkMxBAvTTIyvK5Pd+50+Rk1xVZoMCJkukSJOnW9RlqZ6UqImelJGh4PT/b18tbaDfrV4XgsoH237phKoN+Cza9vu+bX8egO8ezrKl/NweDL6KXixpHbvQsAYn5yUtsQWn69B6Zyim8i35xL2aBs9HUB+HpkuomXd79rPP4S3EVuWrLmB7B7rkfMPCFz2gZ9MR3oxgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAD1ElEQVRoge2bv28cRRTHP+8EwtLtCSmKhW7LAII6ToOUJhRIiZAC6UIB+RfIkYoUV0C5ElDwo7Ld2HTIIoJ0NAgXkNQoSNDdCZGgIF8UCIm/FLNr+9Z36x87s7v28ZG2md178747N7Mzb94YgZD0FHAWWAC6QJy7AAa5awjcAr43s8ehfPOGpLakS5KWJd3T4bmX2rgkqV23rl1IWpD0laSHJURO42Fqe6FunUh6XtJqAJHTWJV0qg6h85I+kfSoQrEZjyR9LGm+KrEXJN2vQWie+5LOhxRqkt6TtFmvzjGeSOpJMt9i5yQt1autkEVJz+xHy55vRq6vrAGvlH1xgVkHLprZH0UPFQpO39p3NF9sxjpwzsz+mfZAa9oNuX7xBUdHLDhfP1dBn54qGLgKvOPdpfBcAd6ddnPim5B0Abgx7f4RYBN43cy+zd/YJSgdpH4Bnq3AsZD8BbxgZnd3Fk76S1/n6IsFp+F6vnCsheXmqT8DT1fkVGj+BV42s1+zgnwLf8jxEQtOywc7C7ZaWNIZ4MeqPaqIM2Z2C8Zb+P06PEmShE6ng5lNvKIoIkmSstVs9WUDkBQBd4F9zUd9Escxw+Gw8JkoitjY2ChTzd/ASTN7kLXwa9QgFqDX6xFFUeEzo9GobDVzOI1bLbwMvF3Wqm/Mtj8iksqaWzazKyYXXfwdOFHWom88C/4TeK6FC6U2TmwATgBnW7i48axwuoULks8K3RbbuwCNIxu99xrFD0DcaMH9fp9ut0u/3/dlMjZJd4AXfVlsOHdM0gho3v5NGEZFIZ5jSQu3TTkrDLwJTpKEOI59rGxCMjBJK8DlspY6nQ6j0cjHyiYkK95aOFvReFjZhGTQwqUZzArDFi6nYla47W156HkpFwK3PEyzZW7U7U0FfG1mj7OJx5pPy5OCcZ1Op+5P1hpsh3jauCDe3GGtZZ+lIrrdLoNBLfOc8SCemT0Abpax2O/3abenT8mjKKLX65Wpogw3U41jgfgF4Ke6PArM7kB8WvBlbS6FYzUTC7OxmfaSmf2WFYwtD9Ndts+q9iogn+4UC/9viEOa9vMW0Mjp0j7ZBC7nxcKUpBYz+wa4FtqrgFyblN9RiFyq4WJFmXQ+WVRB2tJxS0z7AXj1UIlpAOkPL+Iy3JrOOvBGkVjYQzBsDWLngGVPjoVgCZdyWJhneSDk+nRPLmW3KTyRdFW+04dzws9rFhLEc6Ln5dLw6zoC8JGkk5WIzQk/JWmlQrErquOQxwThs3GMJ4/cQa035Y4LlD2otZTa8rrRF2x00/ZRvNMc7CjebQIexfsPJsv+BMnwIx4AAAAASUVORK5CYII=) 30 30,zoom-in}}.brandhub-expand-media--desktop-video{cursor:url(" +
    new URL("play_small.svg?external", import.meta.url).href +
    ") 20 20,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAEumlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjQwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iNDAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSI0MCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNDAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLjAiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLjAiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6NDkrMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6NDkrMDE6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgKFNlcCAyMiAyMDE5KSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMC0wMi0xMVQxMTozNDo0OSswMTowMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+wu377wAAAYFpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAACiRdZHPK0RRFMc/HqIZolhYWDzCamhQExtlJg01SWOUX5uZZ36omfF670myVbZTlNj4teAvYKuslSJSsrKwJjboOW+eGsmc27nnc7/3ntO954ISy2o5s8oPubxlRMNBdXpmVq15QsGLhzZ8cc3UhycmIpS191sqnHjd7dQqf+5f8y4kTQ0qaoWHNN2whEeFIyuW7vCWcLOWiS8Inwj7DLmg8I2jJ1x+djjt8qfDRiwaAqVRWE3/4sQv1jJGTlheTkcuu6z93Md5SV0yPzUpsV28FZMoYYKojDFCiAC9DMocoJs+emRFmXx/MX+cJcnVZNZZxWCRNBksfKIuS/WkxJToSRlZVp3+/+2rmervc6vXBaH60bZfO6FmE74Ktv1xYNtfh1D5AOf5Uv7SPgy8iV4oaR170LAOpxclLbENZxvQcq/HjXhRqhRXUil4OYb6GWi6As+c27OffY7uILYmX3UJO7vQJecb5r8BTxBn24JPlw4AAAAJcEhZcwAACxMAAAsTAQCanBgAAAI1SURBVFiF1Zkxb9NAGIafL2IqyUok1kbKXpQx/yASbTb+QVQxNLAnCIYOIPVXwNAqKkwZyx+gS8tQaIdIUdR2TbaqfhlsI8ckUNuX2DySh0Tye0/ucufvzkZKJNWA58Az4GnkAphErm/AFzO7TNtWEqmqpHeSzpWc8+De6irEypL6kqYpxOJMg6yyK7m2pGsHYnGuJbWziJUkvVmBWJy+pFJSuQ1JR2uQCzmStJGk59YpF3IoyR4i2M9BLqT3L7l2jnIhcxPHInJl4BJwv04l4waomdkMIDp7XpO/HPgOr8IPBv4TArgCHuckFWcGbJrZbdiDLymOHEAZ3+n3EO/k57KUHQCTX5X8zFlmGbUSfsmUmfF4zGg0chEVZbuEX89lptFoUK/XGQwGLuJCtpD01cXqCgiQmeng4MBFpCSdIOmHi6RQMLz29vZ0f3+fNfYCSTMHfn8IAup2u1ljp8nqsIRMJpPsIVrRELdaLc1mmQfnwvkkAdTpdHR3d+ci9gRJn1wkVSoVAdrf35fneS4iJenjI/x964usf5XhcIjneTSbzaxRUU6L/6gLdvzf8zZZwLmZXYXLzHGuKos5hvmC9RK/DisC8wWrmd0AH/J1muO9md3C/7RpCr7Yzcsqwm4otxAVeeMeCBb76COQXPfh0aEeengU68n+GuR6emjPLREt5gFmTLIc/FJXR8A9uToCjolWJb2VdJZC7Cy490mSNlOPvaRNYBvY4u+vIU6Bz2Z2laadXzOb87HyTrGKAAAAAElFTkSuQmCC) 20 20,zoom-in}@media (min-width: 1440px){.brandhub-expand-media--desktop-video{cursor:url(" +
    new URL("play_big.svg?external", import.meta.url).href +
    `) 30 30,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAEumlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjYwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iNjAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSI2MCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNjAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLjAiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLjAiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6MzQrMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6MzQrMDE6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgKFNlcCAyMiAyMDE5KSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMC0wMi0xMVQxMTozNDozNCswMTowMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+/J49+AAAAYFpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAACiRdZHPK0RRFMc/HqIZolhYWDzCamhQExtlJg01SWOUX5uZZ36omfF670myVbZTlNj4teAvYKuslSJSsrKwJjboOW+eGsmc27nnc7/3ntO954ISy2o5s8oPubxlRMNBdXpmVq15QsGLhzZ8cc3UhycmIpS191sqnHjd7dQqf+5f8y4kTQ0qaoWHNN2whEeFIyuW7vCWcLOWiS8Inwj7DLmg8I2jJ1x+djjt8qfDRiwaAqVRWE3/4sQv1jJGTlheTkcuu6z93Md5SV0yPzUpsV28FZMoYYKojDFCiAC9DMocoJs+emRFmXx/MX+cJcnVZNZZxWCRNBksfKIuS/WkxJToSRlZVp3+/+2rmervc6vXBaH60bZfO6FmE74Ktv1xYNtfh1D5AOf5Uv7SPgy8iV4oaR170LAOpxclLbENZxvQcq/HjXhRqhRXUil4OYb6GWi6As+c27OffY7uILYmX3UJO7vQJecb5r8BTxBn24JPlw4AAAAJcEhZcwAACxMAAAsTAQCanBgAAAPsSURBVGiB7ZtPTBxVHMc/v43GTTAxgRLTHiCpJniWHjDZQytJkzYmaIGDXvTKDbf2ZLnpkcT1oPYEPVA4YYiNNiGhHoQl0Xq2mignCnHX1Ggp1i5fD28W2GF3+od9b1jwk8zlze6873dm3sub3/v9DE9IegbIAb3AceBE7ABYjR13gFvAd2b20Je2piGpTdIFSVcllfX0lKNrXJDUlravPUjqlfSlpPv7MNmI+9G1e9P2iaSXJE17MNmIaUkn0zDaKelTSQ8Cmq3yQFJBUmcos+cl3U3BaJy7ks75NGqSPpC0la7PGiqSLkqyZpvNSppM11siE5Keexwvj7wzcmNlDnhtvzfOM0VgwMx+T/pRouHort3k4JutUgTOmNk/jX6QaXRCblxcoXXMgtP6hRLGdEPDQB54t+mS/PMe8H6jk3XvhKTzwPVG51uALeANM/smfmKPoWiS+gV4IYAwn/wJvGxmpd2N9V7py7S+WXAeLscba56w3Dr1J+DZQKJ88y/wipn9Wm2IP+GPOTxmwXn5aHfD9hOWdAr4PrSiQJwys1tQ+4Q/TElMCLbHsgFIeh4oAY+1Hm1BNoFjZnav+oTPcnjNAmRxHrdf6YH0tARjAMDkoovrQHu6erzzB/BiBhdKDWK2VCoxNTXF+vp6iO7itAM55CIGQejr6xOgjo4OLS4uhup2N/kMLkgehOXlZQDK5TL9/f3Mzs6G6rrK8Qw7uwBB2dzcZGhoiEKhELLbE0j6NtT7BNQ9RkdHValUQki4iaSfQ/QkNTYMaHBwUBsbG74l3EbS3757qZJkGNDY2JhvCX8lhXiCs7a25r8THZBXuqenRysrK74l3M7g9mVTJZfLsbS0RHd3t++uVlM3PDw8zPz8PO3tQRZ76RrO5/PMzMyQzWZDdbmawaUZBKGrqwsAM6NQKDA+Pk4mE3TevIOk075niirFYlEjIyNaWFgI1WWc00fv8zDKlrmetpoAfGVmD6sDaC5VKWGYg50gXhsuiBdsugxMbRDPzO4BN9LV5JUbkceaQHwv8ENqkvyyNxAfNcykJskf01WzcDQ203rM7LdqQ80yJ9pl+zy0Ko98ttss/L8hDlHazzu479RWZQt4O24WGiS1mNnXwCXfqjxyqV5+RyJyqYYTaa3y98GEEtKWDlti2hLw+lMlpgFEfxzAZbgddIrAm0lm4RGGYXsSOwNcbZIwH0ziUg4T8yyfCLkxfVEuZfegUJGUV7PTh2PGz+koJIjHTHfKpeGnVQLwiaRjQczGjJ+UdC2g2WtKo8ijjvGjUcYTR65Q6y25coH9FmpNRtdqaqGWt9lNO6V4r/JkpXg/4rEU7z/68wjQkPEe+AAAAABJRU5ErkJggg==) 30 30,zoom-in}}.brandhub-expand-media--youtube-video{align-items:center;cursor:default;display:flex;justify-content:center}.brandhub-expand-media__expand-button{background:transparent;border:none;bottom:var(--icon-position-bottom);cursor:pointer;font-family:inherit;height:2.8571428571rem;left:var(--icon-position-left);opacity:1;padding:0;position:absolute;right:var(--icon-position-right);top:var(--icon-position-top);transition:opacity ease-in-out .1s;width:2.8571428571rem}@media (min-width: 1440px){.brandhub-expand-media__expand-button{height:4.2857142857rem;width:4.2857142857rem}}.brandhub-expand-media__expand-button--left-container{--icon-position-left:calc(50% - 20px);--icon-position-top:calc(50% - 20px)}@media (min-width: 768px){.brandhub-expand-media__expand-button--left-container{--icon-position-left:calc(5vw + 15px);--icon-position-top:calc(50% - .5em)}}@media (min-width: 1440px) and (max-width: 1919px){.brandhub-expand-media__expand-button--left-container{--icon-position-left:calc(7.5vw + 15px)}}@media (min-width: 1920px){.brandhub-expand-media__expand-button--left-container{--icon-position-left:calc(10vw + 15px)}}.brandhub-expand-media__expand-button--center{--icon-position-left:calc(50% - 20px);--icon-position-top:calc(50% - 20px)}@media (min-width: 1440px) and (max-width: 1919px){.brandhub-expand-media__expand-button--center{--icon-position-left:calc(50% - 30px);--icon-position-top:calc(50% - 30px)}}.brandhub-expand-media__expand-button--right{--icon-position-left: auto;--icon-position-right: 1.0714285714rem;--icon-position-top: 1.0714285714rem}@media (min-width: 1440px){.brandhub-expand-media__expand-button--right{display:none}}@media (hover: hover){.brandhub-expand-media:hover .brandhub-expand-media__expand-button{opacity:0;pointer-events:none}}.brandhub-expand-media__expand-icon{color:var(--wb-white);height:100%;width:100%}.brandhub-expand-media__webcomponent-content{display:none}
`,
  u = ["tabindex"],
  h = {
    key: 2,
    class: "brandhub-expand-media__webcomponent-content",
    ref: "webcomponentContent",
  };
function L(i, A, M, r, v, s) {
  const m = I("icon-play-circle"),
    b = I("icon-expand"),
    c = I("play-on-youtube-button");
  return (
    o(),
    d(
      "div",
      {
        tabindex: i.youTubeId ? -1 : 0,
        class: p(["brandhub-expand-media", i.rootClass]),
        ref: "expandSurface",
        onMousedown:
          A[1] ||
          (A[1] = (...n) => i.handleMousedown && i.handleMousedown(...n)),
        onKeydown: [
          A[2] || (A[2] = t((...n) => i.onClick && i.onClick(...n), ["enter"])),
          A[3] || (A[3] = t((...n) => i.onClick && i.onClick(...n), ["space"])),
        ],
        onClick: A[4] || (A[4] = (...n) => i.onClick && i.onClick(...n)),
      },
      [
        i.youTubeId
          ? e("", !0)
          : (o(),
            d(
              "button",
              {
                key: 0,
                tabindex: -1,
                ref: "expandMediaButton",
                class: p([
                  "brandhub-expand-media__expand-button",
                  i.buttonClass,
                ]),
                onClick:
                  A[0] ||
                  (A[0] = g((...n) => i.onClick && i.onClick(...n), ["stop"])),
              },
              [
                i.desktopVideo && !i.youTubeId
                  ? (o(),
                    a(m, {
                      key: 0,
                      class: "brandhub-expand-media__expand-icon",
                    }))
                  : e("", !0),
                i.isVideo
                  ? e("", !0)
                  : (o(),
                    a(b, {
                      key: 1,
                      class: "brandhub-expand-media__expand-icon",
                    })),
              ],
              2
            )),
        i.youTubeId
          ? (o(),
            a(
              c,
              {
                key: 1,
                class: "brandhub-expand-media__youtube-button",
                videoLength: i.videoLength,
              },
              null,
              8,
              ["videoLength"]
            ))
          : e("", !0),
        i.embedWebcomponent && i.isExpanded
          ? (o(), d("div", h, [Z(i.$slots, "webcomponent")], 512))
          : e("", !0),
      ],
      42,
      u
    )
  );
}
const y = C(l, [
  ["render", L],
  ["styles", [R]],
]);
export { y as default };
