import { d as i } from "./index.js";
const e = i({
  name: "ChildComponentMixin",
  data() {
    return {
      initChildComponentMixinCalled: !1,
      childComponentName: null,
      index: 0,
    };
  },
  methods: {
    initChildComponentMixin(n) {
      (this.initChildComponentMixinCalled = !0), (this.childComponentName = n);
    },
    dispatchItemMountedEvent() {
      this.initChildComponentMixinCalled ||
        console.error(
          "ChildComponentMixin not correctly initialized yet! Please add initChildComponentMixin() call in the created() method of your child component."
        );
      const n = new CustomEvent(
        `childComponentMounted_${this.childComponentName}`,
        { bubbles: !0, composed: !0, detail: { item: this } }
      );
      this.$el.dispatchEvent(n);
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.dispatchItemMountedEvent();
    });
  },
});
export { e as C };
