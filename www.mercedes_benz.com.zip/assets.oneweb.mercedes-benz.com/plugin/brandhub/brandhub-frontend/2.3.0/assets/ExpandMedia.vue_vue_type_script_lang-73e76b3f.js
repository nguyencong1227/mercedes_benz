import { d as l, i as d, a as s, _ as a } from "./index.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import { e as o, E as n } from "./ExpandedMediaEventEmitter-0b86e5ec.js";
const p = s(() =>
    a(
      () => import("./expand-2e27c76e.js"),
      ["./expand-2e27c76e.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  h = s(() =>
    a(
      () => import("./play-circle-9622b6f6.js"),
      ["./play-circle-9622b6f6.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  c = s(() =>
    a(
      () => import("./PlayOnYoutubeButton-e39b87b0.js"),
      [
        "./PlayOnYoutubeButton-e39b87b0.js",
        "./index.js",
        "./index.css",
        "./i18next-3def9235.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  f = l({
    name: "ExpandMedia",
    components: { PlayOnYoutubeButton: c, IconExpand: p, IconPlayCircle: h },
    props: {
      expanded: Boolean,
      fixMedia: Boolean,
      pictureJson: String,
      pictureObject: Object,
      desktopVideo: String,
      tabletVideo: String,
      mobileVideo: String,
      youTubeId: String,
      videoLength: String,
      trackingName: { type: String, default: "imagefullscreen" },
      iconPosition: { type: String, default: "left-container" },
      loopVideo: Boolean,
      muteVideo: Boolean,
      showControls: Boolean,
      showControlsNative: Boolean,
      embedWebcomponent: Boolean,
    },
    data() {
      return {
        isExpanded: !1,
        mousedownX: null,
        mousedownY: null,
        expandedMediaMountedInterval: [],
        expandedMediaMountedIntervalCounter: 0,
        activatedByKeyboard: !1,
      };
    },
    setup() {
      const e = d(),
        t = d(),
        i = d();
      return { expandSurface: e, expandMediaButton: t, webcomponentContent: i };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-expand-media--desktop-video": this.desktopVideo,
          "brandhub-expand-media--youtube-video": this.youTubeId,
        };
      },
      pictureString() {
        return this.pictureJson
          ? this.pictureJson
          : this.pictureObject
          ? JSON.stringify(this.pictureObject)
          : null;
      },
      isVideo() {
        return this.desktopVideo || this.youTubeId;
      },
      buttonClass() {
        return {
          "brandhub-expand-media__expand-button--video": this.isVideo,
          "brandhub-expand-media__expand-button--image": !this.isVideo,
          "brandhub-expand-media__expand-button--left-container":
            this.iconPosition === "left-container",
          "brandhub-expand-media__expand-button--center":
            this.iconPosition === "center",
          "brandhub-expand-media__expand-button--right":
            this.iconPosition === "right",
        };
      },
    },
    methods: {
      onClick(e) {
        (this.activatedByKeyboard = e.type !== "click"),
          !(
            this.mousedownX &&
            this.mousedownY &&
            (Math.abs(this.mousedownX - e.clientX) > 5 ||
              Math.abs(this.mousedownY - e.clientY) > 5)
          ) &&
            (this.expandMedia(),
            setTimeout(() => {
              o.emit(n.Play);
            }, 2e3));
      },
      expandMedia() {
        this.isExpanded = !0;
        const e = document.createElement("brandhub-expanded-media");
        this.embedWebcomponent
          ? e.setAttribute("embed-webcomponent", "")
          : this.pictureString
          ? e.setAttribute("picture-json", this.pictureString)
          : this.youTubeId
          ? e.setAttribute("you-tube-id", this.youTubeId)
          : (e.setAttribute("desktop-video", this.desktopVideo),
            e.setAttribute("tablet-video", this.tabletVideo),
            e.setAttribute("mobile-video", this.mobileVideo),
            this.loopVideo && e.setAttribute("loop-video", ""),
            this.muteVideo && e.setAttribute("mute-video", ""),
            this.showControls && e.setAttribute("show-controls", ""),
            this.showControlsNative &&
              e.setAttribute("show-controls-native", "")),
          e.setAttribute("tracking-name", this.trackingName);
        const t = this.expandSurface.getBoundingClientRect();
        e.setAttribute("origin-x", t.left.toString()),
          e.setAttribute("origin-y", t.top.toString()),
          e.setAttribute("origin-width", t.width.toString()),
          e.setAttribute("origin-height", t.height.toString()),
          this.fixMedia && e.setAttribute("fix-media", "true"),
          document.body.appendChild(e),
          this.expandedMediaMountedInterval.push(
            setInterval(this.afterExpandedMediaMounted, 250)
          );
      },
      afterExpandedMediaMounted() {
        const e = document.querySelector("brandhub-expanded-media");
        if (e) {
          this.expandedMediaMountedInterval.forEach((i) => {
            clearInterval(i);
          }),
            this.moveWebcomponentContentToOverlay(e);
          const t = this.$el.getElementsByClassName(
            "brandhub-expand-media__youtube-button"
          )[0];
          o.emit(n.Open, {
            previousFocusedElement: this.youTubeId ? t : this.expandSurface,
            activatedByKeyboard: this.activatedByKeyboard,
          });
        }
        this.expandedMediaMountedInterval > 9 &&
          clearInterval(this.expandedMediaMountedInterval),
          (this.expandedMediaMountedIntervalCounter += 1);
      },
      moveWebcomponentContentToOverlay(e) {
        setTimeout(() => {
          var r;
          const t =
              (r = this.webcomponentContent) == null
                ? void 0
                : r.querySelector("slot"),
            i = t == null ? void 0 : t.assignedElements()[0];
          if (e && e.shadowRoot) {
            const u = e.shadowRoot.querySelector(
              ".brandhub-expanded-media__webcomponent-content"
            );
            u && u.appendChild(i.childNodes.item(1).cloneNode(!0));
          }
        }, 600);
      },
      onClose() {
        (this.isExpanded = !1), this.$emit("close");
      },
      handleMousedown(e) {
        (this.mousedownX = e.clientX), (this.mousedownY = e.clientY);
      },
    },
    created() {
      o.on(n.ClosingFinished, this.onClose);
    },
    watch: {
      expanded(e) {
        e ? this.expandMedia() : (o.emit(n.Close), this.onClose());
      },
    },
  });
export { f as _ };
