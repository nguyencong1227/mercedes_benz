import { I as r } from "./index-12214b95.js";
import { d as s, i as a } from "./index.js";
const n =
    "data:image/gif;base64,R0lGODdhAQABAIABABcXF////ywAAAAAAQABAAACAkQBADs=",
  l = s({
    name: "ResponsiveImage",
    props: {
      placeholderUrl: { type: String, default: n },
      pictureJson: String,
      pictureObject: Object,
      objectFit: { type: String, default: "cover" },
      loadedEvent: { type: Boolean, default: !1 },
      disableLazyLoading: { type: Boolean, default: !1 },
      imageClass: String,
    },
    directives: { intersect: r },
    data() {
      return {
        loadingTriggered: !1,
        observerOptions: { rootMargin: "50%  0px 50% 0px" },
      };
    },
    computed: {
      sources() {
        return this.imageJson && this.loadingTriggered
          ? this.imageJson.sources
          : [];
      },
      fallbackImage() {
        return this.imageJson && this.loadingTriggered
          ? this.imageJson.src
          : this.placeholderUrl;
      },
      alt() {
        return this.imageJson ? this.imageJson.alt : void 0;
      },
      imageJson() {
        return this.pictureJson
          ? JSON.parse(this.pictureJson)
          : this.pictureObject
          ? this.pictureObject
          : null;
      },
      modifierClass() {
        return this.objectFit === "cover"
          ? "brandhub-picture--cover"
          : this.objectFit === "contain"
          ? "brandhub-picture--contain"
          : null;
      },
    },
    watch: {
      disableLazyLoading(e) {
        e && (this.loadingTriggered = !0);
      },
    },
    methods: {
      handleIntersectChange(e) {
        e && !this.loadingTriggered && (this.loadingTriggered = !0);
      },
      mq(e) {
        if (e) return `(max-width: ${e}px)`;
      },
    },
    setup() {
      return { img: a() };
    },
    mounted() {
      this.loadedEvent &&
        this.img &&
        (this.img.onload = (e) => {
          const t = e.target;
          if (t.src !== this.placeholderUrl) {
            const i = new CustomEvent("imgloaded", {
              bubbles: !0,
              composed: !0,
              detail: { img: t },
            });
            this.$el.dispatchEvent(i);
          }
        }),
        this.disableLazyLoading && (this.loadingTriggered = !0);
    },
  });
export { l as _, n as p };
