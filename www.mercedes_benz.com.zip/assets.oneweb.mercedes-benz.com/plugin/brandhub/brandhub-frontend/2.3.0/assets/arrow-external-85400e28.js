import { o as e, c as o, h as t } from "./index.js";
const r = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 16 16" },
  n = t(
    "path",
    {
      fill: "currentColor",
      "fill-rule": "evenodd",
      d: "M4 11.036 10.034 5H5.743V4h6v6h-1l-.001-4.291-6.035 6.034L4 11.036Z",
    },
    null,
    -1
  ),
  l = [n];
function s(c, a) {
  return e(), o("svg", r, [...l]);
}
const h = { render: s };
export { h as default, s as render };
