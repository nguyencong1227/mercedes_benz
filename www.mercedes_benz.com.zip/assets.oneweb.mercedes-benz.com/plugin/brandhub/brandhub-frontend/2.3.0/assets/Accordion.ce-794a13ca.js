import { R as e } from "./ResizeUpdateMixin-a56b9b41.js";
import { P as c, C as r } from "./ParentComponentMixin-b739cccc.js";
import { d as t, o as d, c as s, h as i, B as n, n as b } from "./index.js";
import { _ as l } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
import "./ShadowDom-bc0a555e.js";
const p = t({
    name: "BrandhubAccordion",
    props: {
      bgColor: {
        type: String,
        default: "background-black",
        validator: (o) => ["background-white", "background-black"].includes(o),
      },
      collapse: { type: Boolean, default: !1 },
      spacing: { type: String, default: "variant-no-spacing" },
    },
    mixins: [c, e],
    data() {
      return { items: new r(), activeItem: null };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-accordion--spacing-above": this.spacing.includes(
            "variant-spacing-above"
          ),
          "brandhub-accordion--spacing-below": this.spacing.includes(
            "variant-spacing-below"
          ),
          "brandhub-accordion--background-black":
            this.bgColor === "background-black",
          "brandhub-accordion--background-white":
            this.bgColor === "background-white",
          "brandhub-accordion--no-spacing":
            this.spacing === "variant-no-spacing",
        };
      },
    },
    methods: {
      onAccordionItemClick(o) {
        if (this.collapse && this.activeItem !== o.detail.clickedItem)
          for (const a of this.items.items)
            a === o.detail.clickedItem
              ? ((a.open = !0), (this.activeItem = a))
              : (a.open = !1);
      },
    },
    created() {
      this.initParentComponentMixin(this.items, ["AccordionItem"]);
    },
    mounted() {
      this.$el.addEventListener(
        "accordionItemClicked",
        this.onAccordionItemClick
      );
    },
  }),
  m = `.brandhub-accordion{--paragraph-padding-right: 2.1428571429rem;align-items:center;background-color:var(--background-color);color:var(--text-color);display:flex;flex-direction:column;height:max-content;width:100%}.brandhub-accordion--spacing-below{padding-bottom:4.2857142857rem}@media (min-width: 768px){.brandhub-accordion--spacing-below{padding-bottom:10.7142857143rem}}@media (min-width: 1440px){.brandhub-accordion--spacing-below{padding-bottom:12.8571428571rem}}@media (min-width: 1680px){.brandhub-accordion--spacing-below{padding-bottom:15.7142857143rem}}@media (min-width: 1920px){.brandhub-accordion--spacing-below{padding-bottom:17.8571428571rem}}.brandhub-accordion--spacing-above{padding-top:4.2857142857rem}@media (min-width: 768px){.brandhub-accordion--spacing-above{padding-top:10.7142857143rem}}@media (min-width: 1440px){.brandhub-accordion--spacing-above{padding-top:12.8571428571rem}}@media (min-width: 1680px){.brandhub-accordion--spacing-above{padding-top:15.7142857143rem}}@media (min-width: 1920px){.brandhub-accordion--spacing-above{padding-top:17.8571428571rem}}.brandhub-accordion--background-black{--background-color: var(--base-color);--text-color: var(--text-on-base-color)}.brandhub-accordion--background-white{--background-color: var(--text-on-base-color);--text-color: var(--base-color)}.brandhub-accordion__content{flex-grow:1;position:relative;width:100%}
`,
  h = { class: "brandhub-accordion__content" },
  g = i("div", { class: "brandhub-accordion__seperation-line" }, null, -1);
function u(o, a, k, v, f, w) {
  return (
    d(),
    s(
      "div",
      { class: b([o.rootClass, "brandhub-accordion"]) },
      [i("div", h, [n(o.$slots, "accordionItems"), n(o.$slots, "default")]), g],
      2
    )
  );
}
const A = l(p, [
  ["render", u],
  ["styles", [m]],
]);
export { A as default };
