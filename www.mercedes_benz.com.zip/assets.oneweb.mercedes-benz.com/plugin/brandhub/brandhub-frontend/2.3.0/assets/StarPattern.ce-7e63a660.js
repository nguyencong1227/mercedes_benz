import {
  d as S,
  i as p,
  a as v,
  _ as L,
  r as g,
  j as V,
  o as r,
  c as o,
  w as k,
  h as i,
  n as _,
  F as y,
  e as u,
  D as Z,
  g as w,
  f as I,
  b as M,
  N as f,
} from "./index.js";
import { T as P } from "./TrackingPushService-374dd83c.js";
import { R as A, M as x, T } from "./ResizeUpdateMixin-a56b9b41.js";
import { I as E } from "./index-12214b95.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import { _ as $ } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const H = v(() =>
    L(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  B = v(() =>
    L(
      () => import("./ResponsiveImage-0ce28426.js"),
      [
        "./ResponsiveImage-0ce28426.js",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  O = v(() =>
    L(
      () => import("./ExpandMedia-7448cde8.js"),
      [
        "./ExpandMedia-7448cde8.js",
        "./ExpandMedia.vue_vue_type_script_lang-73e76b3f.js",
        "./index.js",
        "./index.css",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./ExpandedMediaEventEmitter-0b86e5ec.js",
        "./mitt-f7ef348c.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  z = S({
    name: "StarPattern",
    components: { ResponsiveImage: B, WordFade: H, ExpandMedia: O },
    props: {
      editMode: Boolean,
      patternVariant: { type: String, default: "none" },
      backgroundColor: { type: String, default: "black" },
      indent: { type: Boolean, default: !1 },
      patternHeadline: String,
      imageSources: String,
      desktopVideo: String,
      tabletVideo: String,
      mobileVideo: String,
      youTubeId: String,
      videoLength: String,
      desktopPreviewVideo: String,
      tabletPreviewVideo: String,
      mobilePreviewVideo: String,
      loopPreviewVideo: Boolean,
      loopVideo: Boolean,
      muteVideo: Boolean,
      showControls: Boolean,
      dataAnalyticsContentMilestone: String,
    },
    directives: { intersect: E },
    mixins: [A],
    data() {
      return {
        observerOptions: { rootMargin: "0px 0px -45% 0px" },
        isFirefox: window.navigator.userAgent.toLowerCase().includes("firefox"),
        transform: null,
        fadedIn: !1,
        animationDelay: 0,
        headlineVh: 50,
        videoCanPlay: !1,
        videoPlaying: !1,
        videoScale: 0.4,
        videoOpacity: 0,
        videoTranslateY: 100,
        isExpandMediaShown: !1,
        isExpandMediaIn: !1,
        smallScreen: !1,
      };
    },
    setup() {
      const t = p(),
        e = p(),
        a = p(),
        s = p();
      return {
        referenceSize: t,
        svgStarPattern: e,
        previewVideo: a,
        headline: s,
      };
    },
    computed: {
      containsVideo() {
        return !!(this.youTubeId || this.desktopVideo || this.mobileVideo);
      },
      starsColor() {
        return this.backgroundColor === "white" ? "0,0,0" : "255,255,255";
      },
      rootClasses() {
        return {
          "brandhub-star-pattern--edit-mode": this.editMode,
          "brandhub-star-pattern--white": this.backgroundColor === "white",
          "brandhub-star-pattern--black": this.backgroundColor === "black",
          "brandhub-star-pattern--theme": this.backgroundColor === "theme",
          "brandhub-star-pattern--indent": this.indent,
          "brandhub-star-pattern--css-will-change":
            this.animationDelay > 0 && this.animationDelay < 100,
          "brandhub-star-pattern--multiple-words": this.patternHeadline
            ? this.patternHeadline.includes(" ")
            : !1,
        };
      },
      svgClasses() {
        return {
          "brandhub-star-pattern__svg--maybach":
            this.patternVariant === "maybach",
        };
      },
      patternId() {
        return this.dataAnalyticsContentMilestone
          ? `brandhub-star-pattern__svg-pattern--${this.dataAnalyticsContentMilestone}`
          : "brandhub-star-pattern__svg-pattern";
      },
      maskId() {
        return this.dataAnalyticsContentMilestone
          ? `brandhub-star-pattern__svg-mask--${this.dataAnalyticsContentMilestone}`
          : "brandhub-star-pattern__svg-mask";
      },
      gradientId() {
        return this.dataAnalyticsContentMilestone
          ? `brandhub-star-pattern__svg-gradient--${this.dataAnalyticsContentMilestone}`
          : "brandhub-star-pattern__svg-gradient";
      },
      vignetteId() {
        return this.dataAnalyticsContentMilestone
          ? `brandhub-star-pattern__svg-vignette--${this.dataAnalyticsContentMilestone}`
          : "brandhub-star-pattern__svg-vignette";
      },
      headlineStyle() {
        return `transform: translateY(${this.headlineVh}vh);`;
      },
      middleLayerStyle() {
        return {
          opacity: this.videoOpacity.toString(),
          transform: `translateY(${this.videoTranslateY}vh) scale(${this.videoScale})`,
        };
      },
      gradientStops() {
        const t = [0, 1, 0.5, 0.25, 0, 0, 0],
          e = [0, 0, 1, 0.5, 0.25, 0.05, 0.05, 0.05],
          a = [0, 0, 0, 1, 0.5, 0.05, 0.05, 0.05],
          s = [0, 0, 0, 0, 1, 0.5, 0.5, 0.5],
          d = [0, 0, 0, 0, 0, 1, 0.5, 0.5],
          l = [0, 0, 0, 0, 0, 0, 0.25, 0.1],
          h = this.generateGradientStop("0", t),
          c = this.generateGradientStop("0.2", e),
          b = this.generateGradientStop("0.4", a),
          m = this.generateGradientStop("0.6", s),
          n = this.generateGradientStop("0.8", d),
          C = this.generateGradientStop("1", l);
        return [h, c, b, m, n, C];
      },
      rectFill() {
        return this.patternVariant === "honeycombs"
          ? "rgba(255, 255, 255, .2)"
          : `url(#${this.vignetteId})`;
      },
      previewVideoSource() {
        const { innerWidth: t } = window;
        let e = "";
        return (
          this.mobilePreviewVideo && t <= x
            ? (e = this.mobilePreviewVideo)
            : this.tabletPreviewVideo && t <= T
            ? (e = this.tabletPreviewVideo)
            : this.desktopPreviewVideo && (e = this.desktopPreviewVideo),
          e
        );
      },
      posterImage() {
        if (this.imageSources) {
          const t = JSON.parse(this.imageSources),
            { innerWidth: e } = window;
          let a = t.src;
          return (
            t.sources.forEach((s) => {
              s.maxWidth < e && (a = s.src);
            }),
            a
          );
        }
        return null;
      },
    },
    methods: {
      fadeIn() {
        if (this.svgStarPattern) {
          const t = this.svgStarPattern.querySelectorAll("animate.fade-in");
          Array.from(Object.values(t)).forEach((e) => {
            e.beginElementAt(0);
          });
        }
        setTimeout(() => {
          this.fadedIn = !0;
        }, 350);
      },
      fadeOut() {
        if (this.svgStarPattern) {
          const t = this.svgStarPattern.querySelectorAll("animate.fade-out");
          Array.from(Object.values(t)).forEach((e) => {
            e.beginElementAt(0);
          });
        }
        this.fadedIn = !1;
      },
      stopColor(t) {
        return this.fadedIn
          ? `rgba(${this.starsColor},${t.toString()})`
          : `rgba(${this.starsColor},0)`;
      },
      resetMouseHandle() {
        this.transform = null;
      },
      handleMouseMove(t) {
        const e = this.svgStarPattern;
        e &&
          t &&
          t.target &&
          (this.transform = {
            x: t.clientX,
            y: t.clientY - e.getBoundingClientRect().y,
          });
      },
      handleTouchMove(t) {
        const e = this.svgStarPattern;
        e &&
          t &&
          t.target &&
          (this.transform = {
            x: t.touches[0].clientX,
            y: t.touches[0].clientY - e.getBoundingClientRect().y,
          });
      },
      handleIntersectChange(t, e) {
        const a = e.getBoundingClientRect().top;
        (t || a < 0) && !this.fadedIn
          ? this.fadeIn()
          : !t && a > 0 && this.fadedIn && this.fadeOut();
      },
      handleScroll() {
        if (!this.referenceSize) return;
        const { top: t } = this.referenceSize.getBoundingClientRect();
        if (t <= 0) {
          const { innerHeight: e } = window;
          (this.animationDelay = Math.max(
            Math.min(((t * 0.5) / e) * -100, 100),
            0
          )),
            this.calculateVideoStyles(),
            this.updateExpandMedia(),
            this.previewVideo &&
              (this.animationDelay === 100 && !this.videoPlaying
                ? ((this.videoPlaying = !0),
                  (this.videoCanPlay = !0),
                  this.previewVideo.play())
                : this.animationDelay < 100 &&
                  this.videoPlaying &&
                  ((this.videoPlaying = !1), this.previewVideo.pause()));
        } else this.animationDelay = 0;
      },
      calculateVideoStyles() {
        if (!this.headline) return;
        const t = this.animationDelay / 100,
          e =
            0.2 / (Math.E ** (35 * (t * -1 + 0.15)) + 1) +
            0.8 / (Math.E ** (15 * (t * -1 + 0.55)) + 1);
        (this.videoTranslateY = 60 - 60 * e),
          (this.videoOpacity = Math.min(e * 5, 1)),
          (this.videoScale = 0.4 + e * 0.6);
        const a = 35;
        if (
          (t >= 1 &&
            ((this.videoTranslateY = 0),
            (this.videoOpacity = 1),
            (this.videoScale = 1),
            (this.headlineVh = 13)),
          this.animationDelay >= a)
        ) {
          const s = ((this.animationDelay - a) * (100 / (100 - a))) / 100,
            d = Math.cos(Math.PI * s + Math.PI) / 2 + 0.5,
            l =
              ((this.headline.getBoundingClientRect().height * 0.5) /
                window.innerHeight) *
              100,
            h = l - l * d;
          this.headlineVh = 50 - 37 * d - h;
        }
        if (t <= 0) {
          const s =
            ((this.headline.getBoundingClientRect().height * 0.5) /
              window.innerHeight) *
            100;
          this.headlineVh = 50 - s;
        }
      },
      updateExpandMedia() {
        this.animationDelay === 100 && (this.desktopVideo || this.youTubeId)
          ? this.isExpandMediaShown ||
            ((this.isExpandMediaShown = !0),
            requestAnimationFrame(() => {
              this.isExpandMediaIn = !0;
            }))
          : ((this.isExpandMediaShown = !1), (this.isExpandMediaIn = !1));
      },
      generateGradientStop(t, e) {
        return {
          offset: t,
          stopColor: e[e.length - 1],
          animateIn: this.animateValues(e).join(";"),
          animateOut: this.animateValues(e.reverse()).join(";"),
        };
      },
      animateValues(t) {
        const e = [];
        return (
          t.forEach((a) => {
            e.push(`rgba(${this.starsColor},${a})`);
          }),
          e
        );
      },
      handleCanPlay() {
        this.previewVideo &&
          !this.videoCanPlay &&
          !this.videoPlaying &&
          (this.previewVideo.play(),
          this.previewVideo.pause(),
          (this.videoCanPlay = !0));
      },
      initHeadlineHeight() {
        if (!this.headline) return;
        const { height: t } = this.headline.getBoundingClientRect();
        t > 0
          ? this.$nextTick(() => {
              if (!this.headline) return;
              const e =
                ((this.headline.getBoundingClientRect().height * 0.5) /
                  window.innerHeight) *
                100;
              (this.headlineVh = 50 - e), this.handleScroll();
            })
          : requestAnimationFrame(this.initHeadlineHeight);
      },
      onItemClick() {
        const t = `Star Pattern - ${
          this.previewVideoSource ? this.previewVideoSource : this.desktopVideo
        }`;
        P.pushTrackingAttributes("video", t, "video started");
      },
      resize() {
        this.patternVariant === "maybach" &&
          (this.smallScreen = window.innerWidth < 1440);
      },
    },
    mounted() {
      this.editMode
        ? ((this.headlineVh = 0),
          (this.videoScale = 1),
          (this.videoOpacity = 1),
          (this.videoTranslateY = 0),
          this.fadeIn())
        : (window.addEventListener("scroll", this.handleScroll, {
            passive: !0,
          }),
          document.fonts.status === "loaded"
            ? this.initHeadlineHeight()
            : document.fonts.ready.then(this.initHeadlineHeight)),
        this.patternVariant === "maybach" && this.resize();
    },
    unmounted() {
      window.removeEventListener("scroll", this.handleScroll);
    },
  }),
  D = `@keyframes video-fade-in{0%{height:28vh;opacity:0;transform:translateY(100%);width:35%}20%{height:40vh;opacity:1;transform:translateY(90%);width:50%}to{height:80vh;opacity:1;transform:translateY(0);width:100%}}@keyframes headline-transform{0%{transform:translateY(calc(50vh - 50%))}54%{transform:translateY(calc(50vh - 50%))}to{transform:translateY(calc(20vh - .6em))}}.brandhub-star-pattern{--background-color: var(--wb-white);--text-color: var(--wb-black);background:var(--background-color);height:320vh;width:100%}.brandhub-star-pattern--black{--background-color: var(--wb-black);--text-color: var(--wb-white)}.brandhub-star-pattern--theme{--background-color: var(--campaign-gradient);--text-color: var(--campaign-text)}.brandhub-star-pattern--css-will-change .brandhub-star-pattern__headline{will-change:transform}.brandhub-star-pattern--css-will-change .brandhub-star-pattern__middle-layer{transition:transform .2s ease-out,opacity .1s ease-out;will-change:transform,opacity}.brandhub-star-pattern--edit-mode{height:800px;overflow:hidden}.brandhub-star-pattern--edit-mode .brandhub-star-pattern__sticky{height:100%}.brandhub-star-pattern--edit-mode .brandhub-star-pattern__headline{animation:none;transform:translateY(calc(160px - .6em))}.brandhub-star-pattern--edit-mode .brandhub-star-pattern__middle-layer{animation:none;height:500px;opacity:1;width:100%}.brandhub-star-pattern__sticky{background:var(--background-color);display:grid;grid-template:"surface" 100%/100%;height:100vh;position:sticky;top:0;width:100%}.brandhub-star-pattern__content{align-self:flex-start;color:var(--text-color);grid-area:surface;justify-self:center;max-width:100%;pointer-events:none;z-index:10}.brandhub-star-pattern__stars{grid-area:surface}.brandhub-star-pattern__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:3.9285714286rem;display:block;margin-left:auto;margin-right:auto;opacity:.99;text-align:center;transition:transform .2s ease-out}@media (min-width: 480px){.brandhub-star-pattern__headline{font-size:5.2142857143rem}}@media (min-width: 768px){.brandhub-star-pattern__headline{font-size:7.1428571429rem}}@media (min-width: 1280px){.brandhub-star-pattern__headline{font-size:7.8571428571rem}}@media (min-width: 1440px){.brandhub-star-pattern__headline{font-size:8.5714285714rem}}@media (min-width: 1680px){.brandhub-star-pattern__headline{font-size:10rem}}@media (min-width: 1920px){.brandhub-star-pattern__headline{font-size:11.4285714286rem}}@media (max-width: 767px){.brandhub-star-pattern__headline{font-size:4.1428571429rem}}.brandhub-star-pattern--multiple-words .brandhub-star-pattern__headline{padding-left:1.1428571429rem;padding-right:1.1428571429rem}@media (min-width: 768px){.brandhub-star-pattern--multiple-words .brandhub-star-pattern__headline{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-star-pattern--multiple-words .brandhub-star-pattern__headline{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-star-pattern--multiple-words .brandhub-star-pattern__headline{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-star-pattern--multiple-words .brandhub-star-pattern__headline{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (max-width: 767px){.brandhub-star-pattern .brandhub-star-pattern__word-fade{justify-content:center}}.brandhub-star-pattern__middle-layer{grid-area:surface;height:80vh;margin:auto auto 0;position:relative;width:100%;z-index:5}.brandhub-star-pattern--indent .brandhub-star-pattern__middle-layer{box-sizing:border-box}@media (min-width: 1024px) and (max-width: 1439px){.brandhub-star-pattern--indent .brandhub-star-pattern__middle-layer{padding:0 calc((5% + 15px)/2)}}@media (min-width: 1440px) and (max-width: 1919px){.brandhub-star-pattern--indent .brandhub-star-pattern__middle-layer{padding:0 calc((7.5% + 15px)/2)}}@media (min-width: 1920px){.brandhub-star-pattern--indent .brandhub-star-pattern__middle-layer{padding:0 calc((10% + 15px)/2)}}.brandhub-star-pattern__preview-image{height:100%}.brandhub-star-pattern__preview-video{object-fit:cover}.brandhub-star-pattern__svg{height:100%;width:100%}.brandhub-star-pattern__svg--maybach{opacity:.5}.brandhub-star-pattern__svg-line{fill:none;stroke:#ffffff4d}.brandhub-star-pattern__svg-star,.brandhub-star-pattern__svg-maybach{fill:var(--wb-white)}.brandhub-star-pattern__expand-media{opacity:0;pointer-events:none;transform:translateY(2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out}.brandhub-star-pattern__expand-media--in{opacity:1;pointer-events:auto;transform:translateY(0)}.brandhub-star-pattern .blend-screen{mix-blend-mode:screen}
`,
  Y = { class: "brandhub-star-pattern__sticky" },
  R = { class: "brandhub-star-pattern__stars" },
  j = ["id", "patternTransform"],
  F = f(
    '<path class="brandhub-star-pattern__svg-maybach" d="M112.14,4.62 C112.1,4.52 112.04,4.43 111.96,4.35 C111.31,3.66 109.42,2.83 109.42,2.83 C105.85,1.25 101.91,0.37 97.76,0.37 C93.61,0.37 89.67,1.25 86.1,2.83 C86.1,2.83 84.22,3.66 83.56,4.35 C83.48,4.43 83.42,4.53 83.38,4.62 C83.34,4.72 83.32,4.83 83.32,4.94 C83.32,5.89 84.12,7.79 84.12,7.79 C86.26,12.87 89.81,17.21 94.28,20.31 C94.28,20.31 96.73,22.01 97.75,22.01 C98.77,22.01 101.22,20.31 101.22,20.31 C105.69,17.2 109.24,12.86 111.38,7.79 C111.38,7.79 112.18,5.89 112.18,4.94 C112.18,4.83 112.16,4.72 112.12,4.62 L112.14,4.62 Z M102.53,2.37 C103.18,2.48 103.82,2.62 104.45,2.78 L104.33,11.11 L102.52,10.03 L102.52,2.37 L102.53,2.37 Z M95.03,2.09 C95.93,2 96.85,1.95 97.77,1.95 C98.69,1.95 99.61,2 100.51,2.09 L100.51,8.82 L97.77,7.17 L95.03,8.82 L95.03,2.09 Z M95.03,11.17 L97.77,9.52 L100.51,11.17 L100.51,14.88 L97.77,13.23 L95.03,14.88 L95.03,11.17 Z M85.6,7.17 C85.6,7.17 85.13,6.06 85.13,5.51 C85.13,5.44 85.14,5.38 85.17,5.32 C85.19,5.26 85.23,5.21 85.27,5.16 C85.65,4.76 86.75,4.27 86.75,4.27 C87.51,3.94 88.28,3.64 89.07,3.37 L89.21,13.34 C87.75,11.47 86.53,9.39 85.6,7.17 L85.6,7.17 Z M93.01,17.31 C91.91,16.36 90.88,15.33 89.94,14.22 L93.01,12.38 L93.01,17.31 L93.01,17.31 Z M93.01,10.02 L91.2,11.1 L91.08,2.77 C91.71,2.61 92.35,2.47 93,2.36 L93,10.02 L93.01,10.02 Z M100.34,19 C100.34,19 98.53,20.25 97.77,20.25 C97.01,20.25 95.2,19 95.2,19 C94.72,18.67 94.25,18.32 93.8,17.96 L97.77,15.58 L101.74,17.96 C101.28,18.32 100.82,18.67 100.34,19 Z M102.53,17.31 L102.53,12.38 L105.6,14.22 C104.66,15.33 103.63,16.36 102.53,17.31 L102.53,17.31 Z M109.94,7.17 C109.01,9.39 107.79,11.46 106.33,13.34 L106.47,3.37 C107.26,3.64 108.03,3.94 108.79,4.27 C108.79,4.27 109.89,4.76 110.27,5.16 C110.32,5.21 110.35,5.26 110.37,5.32 C110.39,5.38 110.41,5.44 110.41,5.51 C110.41,6.07 109.94,7.17 109.94,7.17 L109.94,7.17 Z"></path><path class="brandhub-star-pattern__svg-maybach" d="M70.08,21.25 C70.08,20.3 69.28,18.4 69.28,18.4 C67.14,13.32 63.59,8.98 59.12,5.88 C59.12,5.88 56.67,4.18 55.65,4.18 C54.63,4.18 52.18,5.88 52.18,5.88 C47.71,8.99 44.16,13.33 42.02,18.4 C42.02,18.4 41.22,20.3 41.22,21.25 C41.22,21.36 41.24,21.47 41.28,21.57 C41.32,21.67 41.38,21.76 41.46,21.84 C42.11,22.53 44,23.36 44,23.36 C47.57,24.94 51.51,25.82 55.66,25.82 C59.81,25.82 63.75,24.94 67.32,23.36 C67.32,23.36 69.2,22.53 69.86,21.84 C69.94,21.76 70,21.66 70.04,21.57 C70.08,21.47 70.1,21.36 70.1,21.25 L70.08,21.25 Z M60.41,16.16 L62.22,15.08 L62.34,23.41 C61.71,23.57 61.07,23.71 60.42,23.82 L60.42,16.16 L60.41,16.16 Z M52.91,17.37 L55.65,19.02 L58.39,17.37 L58.39,24.1 C57.49,24.19 56.57,24.24 55.65,24.24 C54.73,24.24 53.81,24.19 52.91,24.1 L52.91,17.37 Z M52.91,11.31 L55.65,12.96 L58.39,11.31 L58.39,15.02 L55.65,16.67 L52.91,15.02 L52.91,11.31 Z M47.09,12.85 L46.95,22.82 C46.16,22.55 45.39,22.25 44.63,21.92 C44.63,21.92 43.53,21.43 43.15,21.03 C43.1,20.98 43.07,20.93 43.05,20.87 C43.03,20.81 43.01,20.75 43.01,20.68 C43.01,20.12 43.48,19.02 43.48,19.02 C44.41,16.8 45.63,14.73 47.09,12.85 Z M50.89,13.81 L47.82,11.97 C48.76,10.86 49.79,9.83 50.89,8.88 L50.89,13.81 Z M50.89,23.83 C50.24,23.71 49.6,23.58 48.97,23.42 L49.09,15.09 L50.9,16.17 L50.9,23.83 L50.89,23.83 Z M59.62,8.23 L55.65,10.61 L51.68,8.23 C52.14,7.87 52.6,7.52 53.08,7.19 C53.08,7.19 54.89,5.94 55.65,5.94 C56.41,5.94 58.22,7.19 58.22,7.19 C58.7,7.52 59.17,7.87 59.62,8.23 Z M63.49,11.97 L60.42,13.81 L60.42,8.88 C61.52,9.83 62.55,10.86 63.49,11.97 Z M68.29,20.69 C68.29,20.76 68.28,20.82 68.25,20.88 C68.23,20.94 68.19,20.99 68.15,21.04 C67.77,21.44 66.67,21.93 66.67,21.93 C65.91,22.26 65.14,22.56 64.35,22.83 L64.21,12.86 C65.67,14.73 66.89,16.81 67.82,19.03 C67.82,19.03 68.29,20.14 68.29,20.69 L68.29,20.69 Z"></path><path class="brandhub-star-pattern__svg-maybach" d="M27.91,4.62 C27.87,4.52 27.81,4.43 27.73,4.35 C27.08,3.66 25.19,2.83 25.19,2.83 C21.62,1.25 17.68,0.37 13.53,0.37 C9.38,0.37 5.44,1.25 1.87,2.83 C1.87,2.83 -0.01,3.66 -0.67,4.35 C-0.75,4.43 -0.81,4.53 -0.85,4.62 C-0.89,4.72 -0.91,4.83 -0.91,4.94 C-0.91,5.89 -0.11,7.79 -0.11,7.79 C2.03,12.87 5.58,17.21 10.05,20.31 C10.05,20.31 12.5,22.01 13.52,22.01 C14.54,22.01 16.99,20.31 16.99,20.31 C21.46,17.2 25.01,12.86 27.15,7.79 C27.15,7.79 27.95,5.89 27.95,4.94 C27.95,4.83 27.93,4.72 27.89,4.62 L27.91,4.62 Z M18.3,2.37 C18.95,2.48 19.59,2.62 20.22,2.78 L20.1,11.11 L18.29,10.03 L18.29,2.37 L18.3,2.37 Z M10.8,2.09 C11.7,2 12.62,1.95 13.54,1.95 C14.46,1.95 15.38,2 16.28,2.09 L16.28,8.82 L13.54,7.17 L10.8,8.82 L10.8,2.09 Z M10.8,11.17 L13.54,9.52 L16.28,11.17 L16.28,14.88 L13.54,13.23 L10.8,14.88 L10.8,11.17 Z M1.37,7.17 C1.37,7.17 0.9,6.06 0.9,5.51 C0.9,5.44 0.91,5.38 0.94,5.32 C0.96,5.26 1,5.21 1.04,5.16 C1.42,4.76 2.52,4.27 2.52,4.27 C3.28,3.94 4.05,3.64 4.84,3.37 L4.98,13.34 C3.52,11.47 2.3,9.39 1.37,7.17 Z M8.78,17.31 C7.68,16.36 6.65,15.33 5.71,14.22 L8.78,12.38 L8.78,17.31 L8.78,17.31 Z M8.78,10.02 L6.97,11.1 L6.85,2.77 C7.48,2.61 8.12,2.47 8.77,2.36 L8.77,10.02 L8.78,10.02 Z M16.11,19 C16.11,19 14.3,20.25 13.54,20.25 C12.78,20.25 10.97,19 10.97,19 C10.49,18.67 10.02,18.32 9.57,17.96 L13.54,15.58 L17.51,17.96 C17.05,18.32 16.59,18.67 16.11,19 Z M18.3,17.31 L18.3,12.38 L21.37,14.22 C20.43,15.33 19.4,16.36 18.3,17.31 L18.3,17.31 Z M25.71,7.17 C24.78,9.39 23.56,11.46 22.1,13.34 L22.24,3.37 C23.03,3.64 23.8,3.94 24.56,4.27 C24.56,4.27 25.66,4.76 26.04,5.16 C26.09,5.21 26.12,5.26 26.14,5.32 C26.16,5.38 26.18,5.44 26.18,5.51 C26.18,6.07 25.71,7.17 25.71,7.17 Z"></path><path class="brandhub-star-pattern__svg-maybach" d="M84.12,56.61 C84.12,55.66 83.32,53.76 83.32,53.76 C81.18,48.68 77.63,44.34 73.16,41.24 C73.16,41.24 70.71,39.54 69.69,39.54 C68.67,39.54 66.22,41.24 66.22,41.24 C61.75,44.35 58.2,48.69 56.06,53.76 C56.06,53.76 55.26,55.66 55.26,56.61 C55.26,56.72 55.28,56.83 55.32,56.93 C55.36,57.03 55.42,57.12 55.5,57.2 C56.15,57.89 58.04,58.72 58.04,58.72 C61.61,60.3 65.55,61.18 69.7,61.18 C73.85,61.18 77.79,60.3 81.36,58.72 C81.36,58.72 83.24,57.89 83.9,57.2 C83.98,57.12 84.04,57.02 84.08,56.93 C84.12,56.83 84.14,56.72 84.14,56.61 L84.12,56.61 Z M74.45,51.52 L76.26,50.44 L76.38,58.77 C75.75,58.93 75.11,59.07 74.46,59.18 L74.46,51.52 L74.45,51.52 Z M66.95,52.73 L69.69,54.38 L72.43,52.73 L72.43,59.46 C71.53,59.55 70.61,59.6 69.69,59.6 C68.77,59.6 67.85,59.55 66.95,59.46 L66.95,52.73 Z M66.95,46.67 L69.69,48.32 L72.43,46.67 L72.43,50.37 L69.69,52.02 L66.95,50.37 L66.95,46.67 L66.95,46.67 Z M61.13,48.21 L60.99,58.18 C60.2,57.91 59.43,57.61 58.67,57.28 C58.67,57.28 57.57,56.79 57.19,56.39 C57.14,56.34 57.11,56.29 57.09,56.23 C57.07,56.17 57.05,56.11 57.05,56.04 C57.05,55.48 57.52,54.38 57.52,54.38 C58.46,52.16 59.67,50.09 61.13,48.21 L61.13,48.21 Z M64.93,49.17 L61.86,47.33 C62.8,46.22 63.83,45.19 64.93,44.24 L64.93,49.17 Z M64.93,59.19 C64.28,59.08 63.64,58.94 63.01,58.78 L63.13,50.45 L64.94,51.53 L64.94,59.19 L64.93,59.19 Z M73.66,43.59 L69.69,45.97 L65.72,43.59 C66.18,43.23 66.64,42.88 67.12,42.55 C67.12,42.55 68.93,41.3 69.69,41.3 C70.45,41.3 72.26,42.55 72.26,42.55 C72.74,42.88 73.21,43.23 73.66,43.59 Z M77.53,47.33 L74.46,49.17 L74.46,44.24 C75.56,45.19 76.59,46.22 77.53,47.33 L77.53,47.33 Z M82.33,56.05 C82.33,56.12 82.32,56.18 82.29,56.24 C82.27,56.3 82.23,56.35 82.19,56.4 C81.81,56.8 80.71,57.29 80.71,57.29 C79.95,57.62 79.18,57.92 78.39,58.19 L78.25,48.22 C79.71,50.09 80.93,52.17 81.86,54.39 C81.86,54.39 82.33,55.5 82.33,56.05 L82.33,56.05 Z"></path><path class="brandhub-star-pattern__svg-maybach" d="M41.94,39.98 C41.9,39.88 41.84,39.79 41.76,39.71 C41.11,39.02 39.22,38.19 39.22,38.19 C35.65,36.61 31.71,35.73 27.56,35.73 C23.41,35.73 19.47,36.61 15.9,38.19 C15.9,38.19 14.02,39.02 13.36,39.71 C13.28,39.79 13.22,39.89 13.18,39.98 C13.14,40.08 13.12,40.19 13.12,40.3 C13.12,41.25 13.92,43.15 13.92,43.15 C16.06,48.23 19.61,52.57 24.08,55.67 C24.08,55.67 26.53,57.37 27.55,57.37 C28.57,57.37 31.02,55.67 31.02,55.67 C35.49,52.56 39.04,48.22 41.18,43.15 C41.18,43.15 41.98,41.25 41.98,40.3 C41.98,40.19 41.96,40.08 41.92,39.98 L41.94,39.98 Z M32.33,37.73 C32.98,37.84 33.62,37.98 34.25,38.14 L34.13,46.47 L32.32,45.39 L32.32,37.73 L32.33,37.73 Z M24.83,37.45 C25.73,37.36 26.65,37.31 27.57,37.31 C28.49,37.31 29.41,37.36 30.31,37.45 L30.31,44.18 L27.57,42.53 L24.83,44.18 L24.83,37.45 Z M24.83,46.53 L27.57,44.88 L30.31,46.53 L30.31,50.24 L27.57,48.59 L24.83,50.24 L24.83,46.53 Z M15.4,42.53 C15.4,42.53 14.93,41.42 14.93,40.87 C14.93,40.8 14.94,40.74 14.97,40.68 C14.99,40.62 15.03,40.57 15.07,40.52 C15.45,40.12 16.55,39.63 16.55,39.63 C17.31,39.3 18.08,39 18.87,38.73 L19.01,48.7 C17.55,46.83 16.33,44.75 15.4,42.53 Z M22.81,52.67 C21.71,51.72 20.68,50.69 19.74,49.58 L22.81,47.74 L22.81,52.67 Z M22.81,45.38 L21,46.46 L20.88,38.13 C21.51,37.97 22.15,37.83 22.8,37.72 L22.8,45.38 L22.81,45.38 Z M30.14,54.36 C30.14,54.36 28.33,55.61 27.57,55.61 C26.81,55.61 25,54.36 25,54.36 C24.52,54.03 24.05,53.68 23.6,53.32 L27.57,50.94 L31.54,53.32 C31.08,53.68 30.62,54.03 30.14,54.36 Z M32.33,52.67 L32.33,47.74 L35.4,49.58 C34.46,50.69 33.43,51.72 32.33,52.67 Z M39.74,42.53 C38.81,44.75 37.59,46.82 36.13,48.7 L36.27,38.73 C37.06,39 37.83,39.3 38.59,39.63 C38.59,39.63 39.69,40.12 40.07,40.52 C40.12,40.57 40.15,40.62 40.17,40.68 C40.19,40.74 40.21,40.8 40.21,40.87 C40.21,41.43 39.74,42.53 39.74,42.53 Z"></path>',
    5
  ),
  G = [F],
  N = ["id"],
  W = f(
    '<path class="brandhub-star-pattern__svg-line" d="M144,82.5773503 L196.32755,112.788675 L196.32755,173.211325 L144,203.42265 L91.6724504,173.211325 L91.6724504,112.788675 L144,82.5773503 Z"></path><path class="brandhub-star-pattern__svg-line" d="M91.5,-8.42264973 L143.82755,21.7886751 L143.82755,82.2113249 L91.5,112.42265 L39.1724504,82.2113249 L39.1724504,21.7886751 L91.5,-8.42264973 Z"></path><path class="brandhub-star-pattern__svg-line" d="M196,-8.42264973 L248.32755,21.7886751 L248.32755,82.2113249 L196,112.42265 L143.67245,82.2113249 L143.67245,21.7886751 L196,-8.42264973 Z"></path><path class="brandhub-star-pattern__svg-line" d="M-13,-8.42264973 L39.3275496,21.7886751 L39.3275496,82.2113249 L-13,112.42265 L-65.3275496,82.2113249 L-65.3275496,21.7886751 L-13,-8.42264973 Z"></path><path class="brandhub-star-pattern__svg-line" d="M249,82.5773503 L301.32755,112.788675 L301.32755,173.211325 L249,203.42265 L196.67245,173.211325 L196.67245,112.788675 L249,82.5773503 Z"></path>',
    5
  ),
  U = f(
    '<path class="brandhub-star-pattern__svg-star" d="M52.22,90.25a4.53,4.53,0,0,0-.3-.9l-10.2-8.11L39.8,68.35a3.92,3.92,0,0,0-.64-.71,4.27,4.27,0,0,0-.63.71L36.6,81.24,26.41,89.35a3.53,3.53,0,0,0-.3.9,3.75,3.75,0,0,0,.93.19l12.12-4.77,12.12,4.77A3.74,3.74,0,0,0,52.22,90.25Z"></path><path class="brandhub-star-pattern__svg-star" d="M104.43,180.69a3.53,3.53,0,0,0-.3-.9l-10.19-8.11L92,158.79a3.53,3.53,0,0,0-.63-.71,3.53,3.53,0,0,0-.63.71l-1.93,12.89-10.2,8.11a4.53,4.53,0,0,0-.3.9,3.42,3.42,0,0,0,.94.19l12.12-4.77,12.12,4.77A3.35,3.35,0,0,0,104.43,180.69Z"></path><path class="brandhub-star-pattern__svg-star" d="M45.69,146.78a1.7,1.7,0,0,0-.15-.45l-5.1-4.06-1-6.44a2.17,2.17,0,0,0-.32-.36,2.11,2.11,0,0,0-.31.36l-1,6.44-5.09,4.06a1.7,1.7,0,0,0-.15.45,1.87,1.87,0,0,0,.46.09l6.06-2.38,6.06,2.38A1.86,1.86,0,0,0,45.69,146.78Z"></path><path class="brandhub-star-pattern__svg-star" d="M97.91,56.33a1.83,1.83,0,0,0-.15-.45l-5.1-4.05-1-6.45a2.11,2.11,0,0,0-.32-.35,2.11,2.11,0,0,0-.32.35l-1,6.45L85,55.88a1.83,1.83,0,0,0-.15.45,1.88,1.88,0,0,0,.47.1L91.38,54l6.06,2.39A1.88,1.88,0,0,0,97.91,56.33Z"></path><path class="brandhub-star-pattern__svg-star" d="M156.65,90.25a3.53,3.53,0,0,0-.3-.9l-10.2-8.11-1.92-12.89a4.27,4.27,0,0,0-.63-.71,3.92,3.92,0,0,0-.64.71L141,81.24l-10.2,8.11a3.53,3.53,0,0,0-.3.9,3.75,3.75,0,0,0,.93.19l12.13-4.77,12.12,4.77A3.75,3.75,0,0,0,156.65,90.25Z"></path><path class="brandhub-star-pattern__svg-star" d="M208.87,180.69a4.53,4.53,0,0,0-.3-.9l-10.2-8.11-1.92-12.89a3.92,3.92,0,0,0-.64-.71,4.27,4.27,0,0,0-.63.71l-1.93,12.89-10.19,8.11a3.53,3.53,0,0,0-.3.9,3.35,3.35,0,0,0,.93.19l12.12-4.77,12.12,4.77A3.34,3.34,0,0,0,208.87,180.69Z"></path><path class="brandhub-star-pattern__svg-star" d="M150.12,146.78a1.7,1.7,0,0,0-.15-.45l-5.09-4.06-1-6.44a2.11,2.11,0,0,0-.31-.36,2.17,2.17,0,0,0-.32.36l-1,6.44-5.1,4.06a1.7,1.7,0,0,0-.15.45,1.86,1.86,0,0,0,.47.09l6.06-2.38,6.06,2.38A1.87,1.87,0,0,0,150.12,146.78Z"></path><path class="brandhub-star-pattern__svg-star" d="M202.34,56.33a1.83,1.83,0,0,0-.15-.45l-5.1-4.05-1-6.45a2.11,2.11,0,0,0-.32-.35,2,2,0,0,0-.31.35l-1,6.45-5.09,4.05a1.83,1.83,0,0,0-.15.45,1.9,1.9,0,0,0,.46.1L195.81,54l6.06,2.39A1.88,1.88,0,0,0,202.34,56.33Z"></path>',
    8
  ),
  q = ["id"],
  J = ["fill"],
  X = ["id"],
  K = ["stop-color"],
  Q = ["stop-color"],
  tt = ["mask"],
  et = ["cx", "cy", "fill"],
  at = {
    viewBox: "0 0 100 100",
    width: "100%",
    height: "100%",
    preserveAspectRatio: "xMidYMid slice",
  },
  nt = ["id"],
  it = ["offset", "stop-color"],
  rt = ["values"],
  st = ["values"],
  ot = ["fill"],
  dt = { class: "brandhub-star-pattern__content" },
  lt = ["poster", "loop", "src"];
function ht(t, e, a, s, d, l) {
  const h = g("word-fade"),
    c = g("responsive-image"),
    b = g("expand-media"),
    m = V("intersect");
  return (
    r(),
    o(
      "div",
      {
        class: _(["brandhub-star-pattern", t.rootClasses]),
        onMousemovePassive:
          e[1] ||
          (e[1] = (...n) => t.handleMouseMove && t.handleMouseMove(...n)),
        onTouchmovePassive:
          e[2] ||
          (e[2] = (...n) => t.handleTouchMove && t.handleTouchMove(...n)),
        onMouseleavePassive:
          e[3] ||
          (e[3] = (...n) => t.resetMouseHandle && t.resetMouseHandle(...n)),
        onTouchendPassive:
          e[4] ||
          (e[4] = (...n) => t.resetMouseHandle && t.resetMouseHandle(...n)),
        ref: "referenceSize",
      },
      [
        k(
          (r(),
          o("div", Y, [
            i("div", R, [
              ["star-pattern", "honeycombs", "maybach"].includes(
                t.patternVariant
              )
                ? (r(),
                  o(
                    "svg",
                    {
                      key: 0,
                      class: _(["brandhub-star-pattern__svg", t.svgClasses]),
                      width: "100%",
                      height: "100%",
                      ref: "svgStarPattern",
                    },
                    [
                      i("defs", null, [
                        t.patternVariant === "maybach"
                          ? (r(),
                            o(
                              "pattern",
                              {
                                key: 0,
                                id: t.patternId,
                                x: "0",
                                y: "0",
                                width: "84",
                                height: "71",
                                patternUnits: "userSpaceOnUse",
                                patternTransform: t.smallScreen
                                  ? "scale(1.6 1.6)"
                                  : "scale(2 2)",
                              },
                              G,
                              8,
                              j
                            ))
                          : (r(),
                            o(
                              "pattern",
                              {
                                key: 1,
                                id: t.patternId,
                                x: "0",
                                y: "0",
                                width: "208.87",
                                height: "180.88",
                                patternUnits: "userSpaceOnUse",
                                patternTransform: "scale(0.95 0.95)",
                              },
                              [
                                t.patternVariant === "honeycombs"
                                  ? (r(), o(y, { key: 0 }, [W], 64))
                                  : u("", !0),
                                U,
                              ],
                              8,
                              N
                            )),
                        i(
                          "mask",
                          {
                            id: t.maskId,
                            x: "0",
                            y: "0",
                            width: "100%",
                            height: "100%",
                          },
                          [
                            i(
                              "rect",
                              {
                                width: "100%",
                                height: "100%",
                                fill: `url(#${t.patternId})`,
                              },
                              null,
                              8,
                              J
                            ),
                          ],
                          8,
                          q
                        ),
                        i(
                          "radialGradient",
                          { id: t.gradientId, cx: "0.5", cy: "0.5", r: "0.5" },
                          [
                            i(
                              "stop",
                              {
                                offset: "0",
                                "stop-color": `rgb(${t.starsColor})`,
                                "stop-opacity": "1",
                              },
                              null,
                              8,
                              K
                            ),
                            i(
                              "stop",
                              {
                                offset: "1",
                                "stop-color": `rgb(${t.starsColor})`,
                                "stop-opacity": "0",
                              },
                              null,
                              8,
                              Q
                            ),
                          ],
                          8,
                          X
                        ),
                      ]),
                      i(
                        "g",
                        { mask: `url(#${t.maskId})` },
                        [
                          t.transform && t.fadedIn && !t.isFirefox
                            ? (r(),
                              o(
                                "circle",
                                {
                                  key: 0,
                                  cx: t.transform.x.toString(),
                                  cy: t.transform.y.toString(),
                                  r: "200",
                                  fill: `url(#${t.gradientId})`,
                                  "fill-opacity": "1",
                                },
                                null,
                                8,
                                et
                              ))
                            : u("", !0),
                          (r(),
                          o("svg", at, [
                            i("defs", null, [
                              i(
                                "radialGradient",
                                {
                                  id: t.vignetteId,
                                  cx: "0.5",
                                  cy: "0.5",
                                  r: "0.5",
                                },
                                [
                                  (r(!0),
                                  o(
                                    y,
                                    null,
                                    Z(
                                      t.gradientStops,
                                      (n, C) => (
                                        r(),
                                        o(
                                          "stop",
                                          {
                                            key: `gradient-stop-${C}`,
                                            offset: n.offset,
                                            "stop-color": t.stopColor(
                                              n.stopColor
                                            ),
                                            "stop-opacity": "1",
                                          },
                                          [
                                            i(
                                              "animate",
                                              {
                                                begin: "indefinite",
                                                class: "fade-in",
                                                attributeName: "stop-color",
                                                values: n.animateIn,
                                                dur: "1s",
                                                repeatCount: "1",
                                              },
                                              null,
                                              8,
                                              rt
                                            ),
                                            i(
                                              "animate",
                                              {
                                                begin: "indefinite",
                                                class: "fade-out",
                                                attributeName: "stop-color",
                                                values: n.animateOut,
                                                dur: "0.5s",
                                                repeatCount: "1",
                                              },
                                              null,
                                              8,
                                              st
                                            ),
                                          ],
                                          8,
                                          it
                                        )
                                      )
                                    ),
                                    128
                                  )),
                                ],
                                8,
                                nt
                              ),
                            ]),
                            i(
                              "rect",
                              {
                                width: "100%",
                                height: "100%",
                                fill: t.rectFill,
                              },
                              null,
                              8,
                              ot
                            ),
                          ])),
                        ],
                        8,
                        tt
                      ),
                    ],
                    2
                  ))
                : u("", !0),
            ]),
            i("div", dt, [
              i(
                "div",
                {
                  class: "brandhub-star-pattern__headline",
                  style: w(t.headlineStyle),
                  ref: "headline",
                },
                [
                  I(
                    h,
                    {
                      class: "brandhub-star-pattern__word-fade",
                      "animated-text": t.patternHeadline,
                      "text-align": "center",
                      "manual-fade": !0,
                      "manual-fade-in": t.fadedIn,
                    },
                    null,
                    8,
                    ["animated-text", "manual-fade-in"]
                  ),
                ],
                4
              ),
            ]),
            i(
              "div",
              {
                class: "brandhub-star-pattern__middle-layer",
                style: w(t.middleLayerStyle),
              },
              [
                t.previewVideoSource
                  ? (r(),
                    o(
                      "video",
                      {
                        key: 0,
                        ref: "previewVideo",
                        class: "brandhub-star-pattern__preview-video",
                        poster: t.posterImage,
                        onLoadedmetadataPassive:
                          e[0] ||
                          (e[0] = (...n) =>
                            t.handleCanPlay && t.handleCanPlay(...n)),
                        muted: "",
                        playsinline: "",
                        loop: t.loopPreviewVideo,
                        preload: "auto",
                        width: "100%",
                        height: "100%",
                        src: t.previewVideoSource,
                      },
                      null,
                      40,
                      lt
                    ))
                  : (r(),
                    M(
                      c,
                      {
                        key: 1,
                        class: "brandhub-star-pattern__preview-image",
                        "picture-json": t.imageSources,
                      },
                      null,
                      8,
                      ["picture-json"]
                    )),
                t.containsVideo
                  ? (r(),
                    M(
                      b,
                      {
                        key: 2,
                        "icon-position": "left-container",
                        class:
                          "brandhub-star-pattern__expand-media brandhub-star-pattern__expand-media--in",
                        "you-tube-id": t.youTubeId,
                        "video-length": t.videoLength,
                        "desktop-video": t.desktopVideo,
                        "tablet-video": t.tabletVideo,
                        "mobile-video": t.mobileVideo,
                        "loop-video": t.loopVideo,
                        "mute-video": t.muteVideo,
                        "show-controls": t.showControls,
                        onClick: t.onItemClick,
                      },
                      null,
                      8,
                      [
                        "you-tube-id",
                        "video-length",
                        "desktop-video",
                        "tablet-video",
                        "mobile-video",
                        "loop-video",
                        "mute-video",
                        "show-controls",
                        "onClick",
                      ]
                    ))
                  : u("", !0),
              ],
              4
            ),
          ])),
          [
            [
              m,
              {
                observerOptions: t.observerOptions,
                onChange: t.handleIntersectChange,
              },
            ],
          ]
        ),
      ],
      34
    )
  );
}
const Lt = $(z, [
  ["render", ht],
  ["styles", [D]],
]);
export { Lt as default };
