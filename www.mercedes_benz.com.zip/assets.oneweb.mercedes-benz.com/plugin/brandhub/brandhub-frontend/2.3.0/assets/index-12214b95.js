var c = Object.defineProperty;
var h = (s, e, t) =>
  e in s
    ? c(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t })
    : (s[e] = t);
var i = (s, e, t) => (h(s, typeof e != "symbol" ? e + "" : e, t), t);
class l {
  constructor(e) {
    i(this, "interSectionObserver");
    i(this, "el");
    i(this, "options");
    i(this, "callback");
    i(this, "vm");
    (this.vue = e), (this.vm = e);
  }
  async bind(e, t) {
    await this.vm.$nextTick();
    const r = {
      ...{ root: null, rootMargin: "0px 0px -25% 0px", threshold: 0 },
      ...t.value.observerOptions,
    };
    (this.interSectionObserver = new IntersectionObserver(
      this.onIntersectChange.bind(this),
      r
    )),
      this.interSectionObserver.observe(e),
      (this.el = e),
      (this.options = {
        true: t.value.true,
        false: t.value.false,
        disposeWhen: t.value.disposeWhen,
      }),
      (this.callback = t.value.onChange);
  }
  unbind(e) {
    this.interSectionObserver && this.interSectionObserver.unobserve(e);
  }
  onIntersectChange(e) {
    const t = e[0];
    t &&
      (t.isIntersecting || t.boundingClientRect.top <= 0
        ? (this.options.true && this.addStyleOptions(this.options.true),
          this.options.false && this.removeStyleOptions(this.options.false))
        : t.boundingClientRect.top > 0 &&
          (this.options.true && this.removeStyleOptions(this.options.true),
          this.options.false && this.addStyleOptions(this.options.false)),
      this.callback && this.callback(t.isIntersecting, this.el, this.options),
      this.options.disposeWhen !== void 0 &&
        t.isIntersecting === this.options.disposeWhen &&
        this.unbind(this.el));
  }
  addStyleOptions(e) {
    Array.isArray(e)
      ? this.el.classList.add(...e)
      : Object.keys(e).forEach((t) => {
          this.el.style[t] = e[t];
        });
  }
  removeStyleOptions(e) {
    Array.isArray(e)
      ? this.el.classList.remove(...e)
      : Object.keys(e).forEach((t) => {
          this.el.style.removeProperty(t);
        });
  }
}
const n = new Map(),
  a = {
    mounted(s, e) {
      if (e.instance) {
        const t = new l(e.instance);
        n.set(s, t), t.bind(s, e);
      }
    },
    beforeUnmount(s) {
      const e = n.get(s);
      e && e.unbind(s);
    },
  },
  f = a;
export { f as I };
