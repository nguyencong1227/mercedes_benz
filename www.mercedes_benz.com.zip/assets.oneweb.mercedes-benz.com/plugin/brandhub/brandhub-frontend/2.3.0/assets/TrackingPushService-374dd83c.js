const n = "click";
class c {
  static pushTrackingAttributes(e, i, d, a) {
    window.dataLayer_dag = window.dataLayer_dag || [];
    const t = { event: n, eventDetail: { category: e, action: i, label: d } };
    a && (t.eventDetail.destinationUrl = a), window.dataLayer_dag.push(t);
  }
}
export { c as T };
