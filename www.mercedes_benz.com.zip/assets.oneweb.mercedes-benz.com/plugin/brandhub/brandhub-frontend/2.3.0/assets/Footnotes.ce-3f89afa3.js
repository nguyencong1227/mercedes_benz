import l from "./Icon.ce-1a736152.js";
import { B as u } from "./BackgroundColorMixin-87cd4cac.js";
import { i as h } from "./i18next-3def9235.js";
import {
  d as c,
  r as f,
  o as r,
  c as t,
  h as n,
  f as a,
  l as d,
  t as o,
  e as i,
  n as m,
  g,
} from "./index.js";
import { _ as b } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResizeUpdateMixin-a56b9b41.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const p = "CO₂-Emissionen kombiniert",
  w = "Kraftstoffverbrauch kombiniert",
  v =
    'Die angegebenen Werte wurden nach dem vorgeschriebenen Messverfahren ermittelt. Es handelt sich um die „NEFZ-CO₂-Werte“ i. S. v. Art. 2 Nr. 1 Durchführungsverordnung (EU) 2017/1153. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  _ =
    'Die angegebenen Werte sind die „gemessenen NEFZ-CO₂-Werte“ i. S. v. Art. 2 Nr. 2 Durchführungsverordnung (EU) 2017/1153, die im Einklang mit Anhang XII der Verordnung (EG) Nr. 692/2008 ermittelt wurden. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt. Aufgrund gesetzlicher Änderungen der maßgeblichen Prüfverfahren können in der für die Fahrzeugzulassung und ggf. Kfz-Steuer maßgeblichen Übereinstimmungsbescheinigung des Fahrzeugs höhere Werte eingetragen sein.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch und die CO₂-Emissionen neuer Personenkraftwagen“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  z =
    'Die angegebenen Werte wurden nach dem vorgeschriebenen Messverfahren ermittelt. Es handelt sich um „WLTP-CO₂-Werte“ i. S. v. Art. 2 Nr. 3 Durchführungsverordnung (EU) 2017/1153. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  E =
    "Angaben zu Kraftstoffverbrauch, Stromverbrauch und CO₂-Emissionen sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe des WLTP-Prüfverfahrens ermittelt und in NEFZ-Werte korreliert. Eine EG-Typgenehmigung und Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  k =
    "Angaben zum Kraftstoffverbrauch und CO₂-Emissionen sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe des WLTP-Prüfverfahrens ermittelt. Eine EG-Typgenehmigung und Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  W =
    'Stromverbrauch und Reichweite wurden auf der Grundlage der VO 692/2008/EG ermittelt. Stromverbrauch und Reichweite sind abhängig von der Fahrzeugkonfiguration. Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  A =
    "Angaben zu Stromverbrauch und Reichweite sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe der UN/ECE-Regelung Nr. 101 ermittelt. Die EG-Typgenehmigung und eine Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  C =
    "Alle technischen Angaben sind vorläufig und wurden intern nach Maßgabe der jeweils anwendbaren Zertifizierungsmethode ermittelt. Es liegen bislang weder bestätigte Werte vom TÜV noch eine EG-Typgenehmigung noch eine Konformitätsbescheinigung mit amtlichen Werten vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  D =
    'Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle” entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  T = {
    co2: p,
    "fuel e comp": "Stromverbrauch kombiniert",
    fuelcomp: w,
    "deadline press date": "Product may vary after press date on",
    "deadline press date 2": ".",
    nefz2: v,
    nefz1: _,
    wltp: z,
    provisionalNefz2: E,
    provisionalWltp: k,
    vo6922008Eg: W,
    provisionalElectric: A,
    provisionalAll: C,
    datDe: D,
  },
  K = "CO₂-Emissionen kombiniert",
  O = "Kraftstoffverbrauch kombiniert",
  G =
    'Die angegebenen Werte wurden nach dem vorgeschriebenen Messverfahren ermittelt. Es handelt sich um die „NEFZ-CO₂-Werte“ i. S. v. Art. 2 Nr. 1 Durchführungsverordnung (EU) 2017/1153. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  P =
    'Die angegebenen Werte sind die „gemessenen NEFZ-CO₂-Werte“ i. S. v. Art. 2 Nr. 2 Durchführungsverordnung (EU) 2017/1153, die im Einklang mit Anhang XII der Verordnung (EG) Nr. 692/2008 ermittelt wurden. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt. Aufgrund gesetzlicher Änderungen der maßgeblichen Prüfverfahren können in der für die Fahrzeugzulassung und ggf. Kfz-Steuer maßgeblichen Übereinstimmungsbescheinigung des Fahrzeugs höhere Werte eingetragen sein.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch und die CO₂-Emissionen neuer Personenkraftwagen“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  S =
    'Die angegebenen Werte wurden nach dem vorgeschriebenen Messverfahren ermittelt. Es handelt sich um „WLTP-CO₂-Werte“ i. S. v. Art. 2 Nr. 3 Durchführungsverordnung (EU) 2017/1153. Die Kraftstoffverbrauchswerte wurden auf Basis dieser Werte errechnet. Der Stromverbrauch wurde auf der Grundlage der VO 692/2008/EG ermittelt.&#xa;Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  y =
    "Angaben zu Kraftstoffverbrauch, Stromverbrauch und CO₂-Emissionen sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe des WLTP-Prüfverfahrens ermittelt und in NEFZ-Werte korreliert. Eine EG-Typgenehmigung und Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  B =
    "Angaben zum Kraftstoffverbrauch und CO₂-Emissionen sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe des WLTP-Prüfverfahrens ermittelt. Eine EG-Typgenehmigung und Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  L =
    'Stromverbrauch und Reichweite wurden auf der Grundlage der VO 692/2008/EG ermittelt. Stromverbrauch und Reichweite sind abhängig von der Fahrzeugkonfiguration. Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle“ entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  N =
    "Angaben zu Stromverbrauch und Reichweite sind vorläufig und wurden vom Technischen Dienst für das Zertifizierungsverfahren nach Maßgabe der UN/ECE-Regelung Nr. 101 ermittelt. Die EG-Typgenehmigung und eine Konformitätsbescheinigung mit amtlichen Werten liegen noch nicht vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  V =
    "Alle technischen Angaben sind vorläufig und wurden intern nach Maßgabe der jeweils anwendbaren Zertifizierungsmethode ermittelt. Es liegen bislang weder bestätigte Werte vom TÜV noch eine EG-Typgenehmigung noch eine Konformitätsbescheinigung mit amtlichen Werten vor. Abweichungen zwischen den Angaben und den amtlichen Werten sind möglich.",
  M =
    'Weitere Informationen zum offiziellen Kraftstoffverbrauch und den offiziellen spezifischen CO₂-Emissionen neuer Personenkraftwagen können dem „Leitfaden über den Kraftstoffverbrauch, die CO₂-Emissionen und den Stromverbrauch aller neuen Personenkraftwagenmodelle” entnommen werden, der an allen Verkaufsstellen und bei der Deutschen Automobil Treuhand GmbH unter <a target="_blank" href="https://www.dat.de">www.dat.de</a> unentgeltlich erhältlich ist.',
  I = {
    co2: K,
    "fuel e comp": "Stromverbrauch kombiniert",
    fuelcomp: O,
    "deadline press date": "Nach Redaktionsschluss,",
    "deadline press date 2":
      ", können sich Änderungen am Produkt ergeben haben.",
    nefz2: G,
    nefz1: P,
    wltp: S,
    provisionalNefz2: y,
    provisionalWltp: B,
    vo6922008Eg: L,
    provisionalElectric: N,
    provisionalAll: V,
    datDe: M,
  };
function H() {
  const e = h.createInstance();
  return (
    e.init({
      lng:
        document.body.dataset.analyticsLanguage ||
        {}.VUE_APP_I18N_LOCALE ||
        "en",
      resources: { en: { translation: T }, de: { translation: I } },
    }),
    e
  );
}
const $ = c({
    name: "BrandhubFootnotes",
    props: {
      editMode: Boolean,
      showIconsLegend: Boolean,
      nefz2: Boolean,
      nefz1: Boolean,
      wltp: Boolean,
      provisionalNefz2: Boolean,
      provisionalWltp: Boolean,
      vo6922008Eg: Boolean,
      provisionalElectric: Boolean,
      provisionalAll: Boolean,
      datDe: Boolean,
    },
    components: { BrandhubIcon: l },
    mixins: [u],
    setup() {
      const { t: e } = H();
      return { t: e };
    },
    computed: {
      rootClasses() {
        return { "brandhub-footnotes--edit-mode": this.editMode };
      },
    },
  }),
  F = `.brandhub-footnotes{padding-left:1.1428571429rem;padding-right:1.1428571429rem;--spacer-s: 2.2857142857rem;--spacer-m: 4.5714285714rem;--spacer-l: 6.8571428571rem;background-color:var(--background-color);color:#919191;display:flex;flex-direction:column;font-size:1rem;padding-bottom:var(--spacer-s)}@media (min-width: 768px){.brandhub-footnotes{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-footnotes{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-footnotes{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-footnotes{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 768px){.brandhub-footnotes{--spacer-s: 4rem;--spacer-m: 8rem;--spacer-l: 12rem}}@media (min-width: 1440px){.brandhub-footnotes{--spacer-s: 4.5714285714rem;--spacer-m: 9.1428571429rem;--spacer-l: 13.7142857143rem}}.brandhub-footnotes__line{border-top:1px solid var(--wb-grey-20);padding-top:var(--spacer-s)}.brandhub-footnotes__icon{--icon-color: #696969;height:1.1428571429rem;margin-bottom:1px;margin-right:.2rem;vertical-align:bottom;width:1.4285714286rem}.brandhub-footnotes__legend-item{color:#696969;display:inline-block;line-height:normal;margin-right:1.5rem}.brandhub-footnotes__item{display:grid;grid-template-columns:1.8rem 1fr;line-height:1.5}.brandhub-footnotes a{color:var(--wb-grey-70);text-decoration:none}.brandhub-footnotes a:hover{text-decoration:underline}.brandhub-footnotes a:focus-visible{position:relative;outline:none}.brandhub-footnotes a:focus-visible:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-footnotes a:focus-visible:after{left:-.2142857143rem;padding-right:.0714285714rem;top:-.2142857143rem}
`,
  Z = n("div", { class: "brandhub-footnotes__line" }, null, -1),
  x = { key: 0, class: "brandhub-footnotes__legend" },
  R = { class: "brandhub-footnotes__legend-item" },
  U = { class: "brandhub-footnotes__legend-item" },
  j = { class: "brandhub-footnotes__legend-item" },
  X = { key: 1, class: "brandhub-footnotes__item" },
  q = n("sup", null, "1", -1),
  J = ["innerHTML"],
  Q = { key: 2, class: "brandhub-footnotes__item" },
  Y = n("sup", null, "2", -1),
  ee = ["innerHTML"],
  ne = { key: 3, class: "brandhub-footnotes__item" },
  re = n("sup", null, "3", -1),
  te = ["innerHTML"],
  ie = { key: 4, class: "brandhub-footnotes__item" },
  oe = n("sup", null, "4", -1),
  se = ["textContent"],
  ae = { key: 5, class: "brandhub-footnotes__item" },
  de = n("sup", null, "5", -1),
  le = ["textContent"],
  ue = { key: 6, class: "brandhub-footnotes__item" },
  he = n("sup", null, "6", -1),
  ce = ["innerHTML"],
  fe = { key: 7, class: "brandhub-footnotes__item" },
  me = n("sup", null, "7", -1),
  ge = ["textContent"],
  be = { key: 8, class: "brandhub-footnotes__item" },
  pe = n("sup", null, "8", -1),
  we = ["textContent"],
  ve = { key: 9, class: "brandhub-footnotes__item" },
  _e = n("sup", null, "9", -1),
  ze = ["innerHTML"];
function Ee(e, ke, We, Ae, Ce, De) {
  const s = f("BrandhubIcon");
  return (
    r(),
    t(
      "div",
      {
        class: m(["brandhub-footnotes", e.rootClasses]),
        style: g(e.getBackgroundColorStyle),
      },
      [
        Z,
        e.showIconsLegend
          ? (r(),
            t("p", x, [
              n("span", R, [
                a(s, {
                  class: "brandhub-footnotes__icon",
                  icon: "fuel-e-comp",
                }),
                d(" " + o(e.t("fuel e comp")) + "² ", 1),
              ]),
              n("span", U, [
                a(s, {
                  class: "brandhub-footnotes__icon",
                  icon: "fuel-consumption",
                }),
                d(" " + o(e.t("fuelcomp")) + "¹ ² ", 1),
              ]),
              n("span", j, [
                a(s, { class: "brandhub-footnotes__icon", icon: "co2" }),
                d(" " + o(e.t("co2")) + "¹ ", 1),
              ]),
            ]))
          : i("", !0),
        e.nefz2
          ? (r(),
            t("p", X, [q, n("span", { innerHTML: e.t("nefz2") }, null, 8, J)]))
          : i("", !0),
        e.nefz1
          ? (r(),
            t("p", Q, [Y, n("span", { innerHTML: e.t("nefz1") }, null, 8, ee)]))
          : i("", !0),
        e.wltp
          ? (r(),
            t("p", ne, [
              re,
              n("span", { innerHTML: e.t("wltp") }, null, 8, te),
            ]))
          : i("", !0),
        e.provisionalNefz2
          ? (r(),
            t("p", ie, [
              oe,
              n(
                "span",
                { textContent: o(e.t("provisionalNefz2")) },
                null,
                8,
                se
              ),
            ]))
          : i("", !0),
        e.provisionalWltp
          ? (r(),
            t("p", ae, [
              de,
              n(
                "span",
                { textContent: o(e.t("provisionalWltp")) },
                null,
                8,
                le
              ),
            ]))
          : i("", !0),
        e.vo6922008Eg
          ? (r(),
            t("p", ue, [
              he,
              n("span", { innerHTML: e.t("vo6922008Eg") }, null, 8, ce),
            ]))
          : i("", !0),
        e.provisionalElectric
          ? (r(),
            t("p", fe, [
              me,
              n(
                "span",
                { textContent: o(e.t("provisionalElectric")) },
                null,
                8,
                ge
              ),
            ]))
          : i("", !0),
        e.provisionalAll
          ? (r(),
            t("p", be, [
              pe,
              n("span", { textContent: o(e.t("provisionalAll")) }, null, 8, we),
            ]))
          : i("", !0),
        e.datDe
          ? (r(),
            t("p", ve, [
              _e,
              n("span", { innerHTML: e.t("datDe") }, null, 8, ze),
            ]))
          : i("", !0),
      ],
      6
    )
  );
}
const Le = b($, [
  ["render", Ee],
  ["styles", [F]],
]);
export { Le as default };
