import { o as e, c as o, h as t } from "./index.js";
const r = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 60 60" },
  n = t(
    "path",
    {
      fill: "currentColor",
      "fill-rule": "evenodd",
      d: "m37.896 28.11-6.363 6.363a1.496 1.496 0 0 1-1.108.439 1.495 1.495 0 0 1-1.107-.439l-6.364-6.364a1.5 1.5 0 1 1 2.121-2.12l5.35 5.349 5.35-5.35a1.5 1.5 0 0 1 2.121 2.121z",
    },
    null,
    -1
  ),
  l = [n];
function s(a, c) {
  return e(), o("svg", r, [...l]);
}
const i = { render: s };
export { i as default, s as render };
