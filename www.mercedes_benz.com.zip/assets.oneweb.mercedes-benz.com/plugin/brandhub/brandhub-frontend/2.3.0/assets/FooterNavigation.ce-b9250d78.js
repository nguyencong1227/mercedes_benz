import { B as i } from "./BackgroundColorMixin-87cd4cac.js";
import { d as t, o as e, c as r, h as o, B as a, g as d } from "./index.js";
import { _ as m } from "./_plugin-vue_export-helper-c27b6911.js";
const g = t({ name: "BrandhubFooterNavigation", mixins: [i] }),
  s = `.brandhub-footer-navigation{padding:2.2857142857rem 1.1428571429rem 4.5714285714rem;background-color:var(--background-color);display:block}@media (min-width: 768px){.brandhub-footer-navigation{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-footer-navigation{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-footer-navigation{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-footer-navigation{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 768px){.brandhub-footer-navigation{padding-bottom:9.1428571429rem;padding-top:4.5714285714rem}}.brandhub-footer-navigation__line{border-bottom:1px solid var(--wb-grey-20);margin-bottom:2.2857142857rem;margin-top:-2.2857142857rem;position:inherit;width:100%}@media (min-width: 768px){.brandhub-footer-navigation__line{margin-bottom:4.5714285714rem;margin-top:-4.5714285714rem}}@media (min-width: 768px){.brandhub-footer-navigation__link-button-container{margin-bottom:3.5714285714rem}}.brandhub-footer-navigation__language-switch-container{--language-switcher-footer-color: #9f9f9f;--language-switcher-footer-padding: 1.7142857143rem 0;margin-left:auto}@media (min-width: 768px){.brandhub-footer-navigation__language-switch-container{--language-switcher-footer-padding: 0}}::slotted(div){column-gap:3.4285714286rem;display:flex;flex-wrap:wrap;justify-content:center;padding-left:0;row-gap:1.7142857143rem}@media (min-width: 768px){::slotted(div){column-gap:2.2857142857rem;flex:1 0 35%}}@media (min-width: 1440px){::slotted(div){column-gap:3.4285714286rem;flex:1 0 35%}}
`,
  l = o("div", { class: "brandhub-footer-navigation__line" }, null, -1),
  p = { class: "brandhub-footer-navigation__link-button-container" },
  c = { class: "brandhub-footer-navigation__language-switch-container" };
function h(n, b, f, u, _, v) {
  return (
    e(),
    r(
      "div",
      {
        class: "brandhub-footer-navigation",
        style: d(n.getBackgroundColorStyle),
      },
      [
        l,
        o("nav", p, [a(n.$slots, "default"), a(n.$slots, "navigation-items")]),
        o("nav", c, [a(n.$slots, "language-switcher")]),
      ],
      4
    )
  );
}
const y = m(g, [
  ["render", h],
  ["styles", [s]],
]);
export { y as default };
