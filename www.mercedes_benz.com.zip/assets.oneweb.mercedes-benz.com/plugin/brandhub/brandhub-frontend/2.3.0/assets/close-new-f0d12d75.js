import { o as e, c as o, h as t } from "./index.js";
const r = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 16 16" },
  s = t(
    "path",
    {
      fill: "currentColor",
      "fill-rule": "evenodd",
      d: "m12.581 4.096-3.89 3.889 3.89 3.89-.707.706-3.89-3.89-3.888 3.89-.707-.707 3.888-3.89L3.39 4.097l.707-.707 3.889 3.888 3.89-3.888.706.707Z",
    },
    null,
    -1
  ),
  c = [s];
function l(n, a) {
  return e(), o("svg", r, [...c]);
}
const i = { render: l };
export { i as default, l as render };
