import {
  d as s,
  i as g,
  a as o,
  _ as u,
  r as t,
  j as h,
  w as _,
  o as i,
  c,
  b as n,
  e as r,
  h as a,
  k as j,
  n as m,
  M as v,
  f,
  t as w,
} from "./index.js";
import k from "./ResponsiveImage-0ce28426.js";
import { C as x } from "./ChildComponentMixin-dd022493.js";
import { R as y } from "./ResizeUpdateMixin-a56b9b41.js";
import { I as C } from "./index-12214b95.js";
import { T as I } from "./TrackingPushService-374dd83c.js";
import { _ as L } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const z = o(() =>
    u(
      () => import("./arrow_new_window-1dbf2132.js"),
      ["./arrow_new_window-1dbf2132.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  J = o(() =>
    u(
      () => import("./Co2Labeling.ce-c45f884c.js"),
      [
        "./Co2Labeling.ce-c45f884c.js",
        "./index.js",
        "./index.css",
        "./i18next-3def9235.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  S = s({
    name: "ImageJumperItem",
    props: {
      text: String,
      externalLink: String,
      internalLink: String,
      linkTarget: { type: String, default: "_self" },
      pictureJson: String,
      labelingJson: String,
    },
    components: { ResponsiveImage: k, iconArrowNewWindow: z, Co2Labeling: J },
    data() {
      return { index: 0, status: null, initialItem: !1, singleButton: !1 };
    },
    setup() {
      return { video: g() };
    },
    directives: { intersect: C },
    mixins: [x, y],
    computed: {
      rootClasses() {
        return {
          "brandhub-image-jumper-item--active": this.status === "active",
          "brandhub-image-jumper-item--previous-active":
            this.status === "previous-active",
          "brandhub-image-jumper-item--single-button": this.singleButton,
        };
      },
      hasLink() {
        return !!(this.externalLink || this.internalLink);
      },
    },
    methods: {
      handleIntersection(e) {
        e && this.initialItem && this.video && this.video.play();
      },
      onItemClick() {
        if (this.hasLink) {
          const e = this.externalLink || this.internalLink;
          I.pushTrackingAttributes("link", "image jumper", this.text, e);
        }
      },
    },
    created() {
      this.initChildComponentMixin("ImageJumperItem");
    },
  }),
  D = `.brandhub-image-jumper-item{height:100%;width:100%}@media (max-width: 1023px){.brandhub-image-jumper-item{display:grid;grid-template:"content" 100%/100%}}@media (min-width: 1024px){.brandhub-image-jumper-item{bottom:0;left:0;opacity:0;pointer-events:none;position:absolute;right:0;top:0;transition:opacity .4s ease-out;width:100%;z-index:0}}.brandhub-image-jumper-item--previous-active{opacity:1;z-index:1}.brandhub-image-jumper-item--active{opacity:1;pointer-events:auto;z-index:2}@media (max-width: 1279px){.brandhub-image-jumper-item--single-button .brandhub-image-jumper-item__overlay{grid-template-rows:1fr}}.brandhub-image-jumper-item--single-button .brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item--single-button .brandhub-image-jumper-item__button{align-self:end;grid-column:2/6;margin-bottom:2rem}@media (min-width: 768px){.brandhub-image-jumper-item--single-button .brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item--single-button .brandhub-image-jumper-item__button{grid-column:2/8}}.brandhub-image-jumper-item:not(.brandhub-image-jumper-item--single-button) .brandhub-image-jumper-item__labeling,.brandhub-image-jumper-item:not(.brandhub-image-jumper-item--single-button) .brandhub-image-jumper-item__overlay:after{display:none}@media (max-width: 1023px){.brandhub-image-jumper-item__image{grid-area:content;height:var(--item-height)}}.brandhub-image-jumper-item__overlay{padding-left:1.1428571429rem;padding-right:1.1428571429rem;display:grid;grid-column-gap:1.1428571429rem;grid-template-columns:repeat(6,2fr);grid-area:content;position:relative}@media (min-width: 768px){.brandhub-image-jumper-item__overlay{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-image-jumper-item__overlay{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-image-jumper-item__overlay{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-image-jumper-item__overlay{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 768px){.brandhub-image-jumper-item__overlay{grid-column-gap:2.2857142857rem;grid-template-columns:repeat(8,2fr)}}@media (min-width: 1024px){.brandhub-image-jumper-item__overlay{grid-column-gap:1.7142857143rem;grid-template-columns:repeat(12,2fr)}}@media (min-width: 1440px){.brandhub-image-jumper-item__overlay{grid-column-gap:2.8571428571rem}}@media (min-width: 1920px){.brandhub-image-jumper-item__overlay{grid-column-gap:3.4285714286rem}}.brandhub-image-jumper-item__overlay:after{background-image:radial-gradient(circle at 50% 117%,var(--wb-black),rgba(0,0,0,.5) 6%,rgba(0,0,0,0) 19%),linear-gradient(to bottom,rgba(0,0,0,0),var(--wb-black));bottom:0;content:"";display:block;height:35%;position:absolute;width:100%}.brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item__button{align-items:center;align-self:center;-webkit-backdrop-filter:blur(15px);backdrop-filter:blur(15px);background-color:#0006;border:1px solid var(--wb-white);border-radius:1.0714285714rem;color:var(--wb-white);display:flex;grid-column:2/6;height:1.4285714286rem;justify-content:space-between;padding:1.4285714286rem 2.1428571429rem;text-decoration:none;transition:background-color .25s,color .25s;z-index:1}@media (min-width: 768px){.brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item__button{padding:3.5714285714rem 2.1428571429rem}}@media (min-width: 768px){.brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item__button{grid-column:2/8}}@media (min-width: 1024px){.brandhub-image-jumper-item__button-link,.brandhub-image-jumper-item__button{display:none}}.brandhub-image-jumper-item__button-link:hover,.brandhub-image-jumper-item__button-link:focus,.brandhub-image-jumper-item__button:hover,.brandhub-image-jumper-item__button:focus{background:var(--wb-white);color:var(--wb-black)}.brandhub-image-jumper-item__button-link[href] .brandhub-image-jumper-item__button-text,.brandhub-image-jumper-item__button[href] .brandhub-image-jumper-item__button-text{cursor:pointer}.brandhub-image-jumper-item__button-text{cursor:default;font-size:1.1428571429rem;line-height:1.8571428571rem}@media (min-width: 1440px){.brandhub-image-jumper-item__button-text{font-size:1.2857142857rem}}.brandhub-image-jumper-item__button-icon{flex-shrink:0;height:1.0714285714rem;padding-left:.3571428571rem;width:1.0714285714rem}.brandhub-image-jumper-item__button-icon--hidden{visibility:hidden}.brandhub-image-jumper-item__labeling{--co2-labeling-font-size: .8571428571rem;--co2-labeling-color: var(--wb-white);align-self:end;grid-area:content;grid-column:1/7;margin-bottom:1.7857142857rem;z-index:1}@media (max-width: 1023px){.brandhub-image-jumper-item__labeling{text-align:center}}@media (min-width: 768px){.brandhub-image-jumper-item__labeling{grid-column:1/9}}.brandhub-image-jumper-item .brandhub-co2-labeling__models{font-size:.8571428571rem}@media (min-width: 768px){.brandhub-image-jumper-item .brandhub-co2-labeling__models{font-size:1.1428571429rem}}
`,
  T = { class: "brandhub-image-jumper-item__overlay" },
  B = { class: "brandhub-image-jumper-item__button-text" };
function A(e, E, R, V, M, N) {
  const d = t("responsive-image"),
    b = t("icon-arrow-new-window"),
    l = t("co2-labeling"),
    p = h("intersect");
  return _(
    (i(),
    c(
      "div",
      { class: m(["brandhub-image-jumper-item", e.rootClasses]) },
      [
        e.pictureJson
          ? (i(),
            n(
              d,
              {
                key: 0,
                class: "brandhub-image-jumper-item__image",
                "picture-json": e.pictureJson,
                "object-fit": "cover",
              },
              null,
              8,
              ["picture-json"]
            ))
          : r("", !0),
        a("div", T, [
          (i(),
          n(
            v(e.hasLink ? "a" : "div"),
            {
              class: m(
                e.hasLink
                  ? "brandhub-image-jumper-item__button-link"
                  : "brandhub-image-jumper-item__button"
              ),
              href: e.externalLink || e.internalLink,
              target: e.linkTarget,
              onClick: e.onItemClick,
            },
            {
              default: j(() => [
                a("span", B, w(e.text), 1),
                e.externalLink
                  ? (i(),
                    n(b, {
                      key: 0,
                      class: "brandhub-image-jumper-item__button-icon",
                    }))
                  : r("", !0),
              ]),
              _: 1,
            },
            8,
            ["class", "href", "target", "onClick"]
          )),
          f(
            l,
            {
              class: "brandhub-image-jumper-item__labeling",
              "labeling-json": e.labelingJson,
              "layout-variant": "text-large",
            },
            null,
            8,
            ["labeling-json"]
          ),
        ]),
      ],
      2
    )),
    [[p, { onChange: e.handleIntersection }]]
  );
}
const Q = L(S, [
  ["render", A],
  ["styles", [D]],
]);
export { Q as default };
