const t = [
  "Mercedes-Benz",
  "Mercedes-Benz AMG",
  "Mercedes-Maybach",
  "Mercedes",
  "Klasse",
  "Class",
].sort((n, e) => e.length - n.length);
function d(n) {
  let { innerHTML: e } = n;
  const r = [];
  t.forEach((s) => {
    if (e.indexOf(s) !== -1) {
      const o = !r.some((a) => a.indexOf(s) > -1);
      r.push(s), o && (e = e.replace(s, `<span class="no-break">${s}</span>`));
    }
  });
  const c = n;
  c.innerHTML = e;
}
function f(n) {
  return t.some((e) => n.indexOf(e) !== -1) ? { "no-break": !0 } : {};
}
export { f as c, d as p };
