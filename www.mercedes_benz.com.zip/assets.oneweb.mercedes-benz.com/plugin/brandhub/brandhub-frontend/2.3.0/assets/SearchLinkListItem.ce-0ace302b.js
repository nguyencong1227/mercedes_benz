import { T as l } from "./TrackingPushService-374dd83c.js";
import {
  d as h,
  o as t,
  c as n,
  h as s,
  t as a,
  F as o,
  D as c,
} from "./index.js";
import { _ as m } from "./_plugin-vue_export-helper-c27b6911.js";
const d = h({
    name: "SearchLinkListItem",
    props: { headlineText: String, linkListJson: String },
    computed: {
      linkList() {
        return this.linkListJson ? JSON.parse(this.linkListJson).links : null;
      },
    },
    methods: {
      onTextLinkClick(e) {
        if (e.text) {
          const r = e.externalLink ? e.externalLink : e.internalLink;
          l.pushTrackingAttributes("link", "Search Link List", e.text, r);
        }
      },
    },
  }),
  k = `.brandhub-search-link-list-item{color:#9f9f9f;font-size:1.1428571429rem}@media (min-width: 480px){.brandhub-search-link-list-item{max-width:11.5rem}}@media (min-width: 768px){.brandhub-search-link-list-item{font-size:1.2857142857rem}}@media (min-width: 1280px){.brandhub-search-link-list-item{max-width:16.125rem}}@media (min-width: 1440px){.brandhub-search-link-list-item{font-size:1.4285714286rem;max-width:20.1875rem}}.brandhub-search-link-list-item__headline{font-weight:700}.brandhub-search-link-list-item__links,.brandhub-search-link-list-item{display:flex;flex-flow:column;gap:1.25rem}.brandhub-search-link-list-item__link{color:#9f9f9f;text-decoration:none;transition:color .4s ease-in-out}.brandhub-search-link-list-item__link:hover{color:var(--wb-white);cursor:pointer}.brandhub-search-link-list-item__links{list-style:none;margin:0;padding:0}
`,
  _ = { class: "brandhub-search-link-list-item" },
  b = { class: "brandhub-search-link-list-item__headline" },
  u = { class: "brandhub-search-link-list-item__links" },
  p = ["href", "target", "onClick"];
function f(e, r, x, L, g, w) {
  return (
    t(),
    n("div", _, [
      s("div", b, a(e.headlineText), 1),
      s("ul", u, [
        (t(!0),
        n(
          o,
          null,
          c(
            e.linkList,
            (i) => (
              t(),
              n(
                "li",
                {
                  key: i.text,
                  class: "brandhub-search-link-list-item__link-item",
                },
                [
                  s(
                    "a",
                    {
                      class: "brandhub-search-link-list-item__link",
                      href: i.internalLink || i.externalLink,
                      target: i.target,
                      onClick: (S) => e.onTextLinkClick(i),
                    },
                    a(i.text),
                    9,
                    p
                  ),
                ]
              )
            )
          ),
          128
        )),
      ]),
    ])
  );
}
const C = m(d, [
  ["render", f],
  ["styles", [k]],
]);
export { C as default };
