import { I as m } from "./index-12214b95.js";
import c from "./WordFade-cd7ee7b7.js";
import { R as f } from "./ResizeUpdateMixin-a56b9b41.js";
import {
  d as v,
  i as p,
  r as o,
  j as g,
  o as i,
  c as n,
  f as t,
  e as d,
  w as _,
  h as a,
  n as l,
} from "./index.js";
import { _ as w } from "./_plugin-vue_export-helper-c27b6911.js";
import "./BrandSafeHyphens-ffe3b60a.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const y = v({
    name: "FullscreenVideo",
    components: { WordFade: c },
    props: {
      backgroundColor: { type: String, default: "black" },
      headline: String,
      aspectRatio: { type: String, default: "fullscreen" },
      aspectRatioMobile: { type: String, default: "fullscreen" },
      desktopVideo: String,
      tabletVideo: String,
      mobileVideo: String,
      editMode: Boolean,
    },
    setup() {
      return { video: p() };
    },
    mixins: [f],
    directives: { intersect: m },
    data() {
      return { overlayVisible: !1 };
    },
    computed: {
      rootModifierClasses() {
        return {
          "brandhub-fullscreen-video--mobile-1by1":
            this.aspectRatioMobile === "1by1",
          "brandhub-fullscreen-video--mobile-fullscreen":
            this.aspectRatioMobile === "fullscreen",
          "brandhub-fullscreen-video--desktop-16by9":
            this.aspectRatio === "16by9",
          "brandhub-fullscreen-video--desktop-fullscreen":
            this.aspectRatio === "fullscreen",
          "brandhub-fullscreen-video--background-black":
            this.backgroundColor === "black",
          "brandhub-fullscreen-video--background-white":
            this.backgroundColor === "white",
          "brandhub-fullscreen-video--background-theme":
            this.backgroundColor === "theme",
          "brandhub-fullscreen-video--edit-mode": this.editMode,
        };
      },
      gradientClasses() {
        return this.overlayVisible
          ? "brandhub-fullscreen-video__gradient--visible"
          : "";
      },
      videoSource() {
        return this.mobileVideo && this.isMobile
          ? this.mobileVideo
          : this.tabletVideo && this.isTablet
          ? this.tabletVideo
          : this.desktopVideo
          ? this.desktopVideo
          : "";
      },
      isMobile1by1() {
        return this.aspectRatioMobile === "1by1" && this.isMobile;
      },
    },
    methods: {
      onVideoEnded() {
        this.overlayVisible = !0;
      },
      handleIntersection(e) {
        e
          ? this.$refs.video && this.$refs.video.play()
          : (this.overlayVisible = !1);
      },
    },
  }),
  k = `.brandhub-fullscreen-video{background-color:var(--wb-black);color:var(--wb-white);display:grid;grid-template:"mobileHeadline" auto "videoContent" 100vh/100%;position:relative}.brandhub-fullscreen-video--background-white{background-color:var(--wb-white);color:var(--wb-black)}.brandhub-fullscreen-video--background-theme{background:var(--campaign-gradient);color:var(--campaign-light)}@media (max-width: 1023px){.brandhub-fullscreen-video--mobile-1by1{grid-template:"mobileHeadline" auto "videoContent" 100vw/100%}}@media (min-width: 1024px){.brandhub-fullscreen-video--desktop-16by9{grid-template:"mobileHeadline" auto "videoContent" 56.25vw/100%}}.brandhub-fullscreen-video__gradient{background:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0));grid-area:videoContent;margin-right:auto;opacity:0;transition:opacity 1s;width:100%;z-index:1}@media (max-width: 1023px){.brandhub-fullscreen-video__gradient{height:50%;margin-top:auto}}@media (min-width: 1024px){.brandhub-fullscreen-video__gradient{background:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0));width:50%}}.brandhub-fullscreen-video__gradient--visible{opacity:1}.brandhub-fullscreen-video__overlay{padding-left:1.1428571429rem;padding-right:1.1428571429rem;align-items:center;display:flex;grid-area:videoContent;justify-content:flex-start;z-index:2}@media (min-width: 768px){.brandhub-fullscreen-video__overlay{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-fullscreen-video__overlay{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-fullscreen-video__overlay{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-fullscreen-video__overlay{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-fullscreen-video__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:3.9285714286rem;margin-right:auto;width:100%}@media (min-width: 480px){.brandhub-fullscreen-video__headline{font-size:5.2142857143rem}}@media (min-width: 768px){.brandhub-fullscreen-video__headline{font-size:7.1428571429rem}}@media (min-width: 1280px){.brandhub-fullscreen-video__headline{font-size:7.8571428571rem}}@media (min-width: 1440px){.brandhub-fullscreen-video__headline{font-size:8.5714285714rem}}@media (min-width: 1680px){.brandhub-fullscreen-video__headline{font-size:10rem}}@media (min-width: 1920px){.brandhub-fullscreen-video__headline{font-size:11.4285714286rem}}@media (min-width: 768px){.brandhub-fullscreen-video__headline{width:84%}}@media (max-width: 1023px){.brandhub-fullscreen-video__headline{margin-top:auto;padding-bottom:10vh}}@media (min-width: 1024px){.brandhub-fullscreen-video__headline{width:65%}}@media (min-width: 1280px){.brandhub-fullscreen-video__headline{width:47vw}}.brandhub-fullscreen-video__headline-mobile{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:3.9285714286rem;grid-area:mobileHeadline;margin:0;padding:4.2857142857rem 2.1428571429rem 3.5714285714rem}@media (min-width: 480px){.brandhub-fullscreen-video__headline-mobile{font-size:5.2142857143rem}}@media (min-width: 768px){.brandhub-fullscreen-video__headline-mobile{font-size:7.1428571429rem}}@media (min-width: 1280px){.brandhub-fullscreen-video__headline-mobile{font-size:7.8571428571rem}}@media (min-width: 1440px){.brandhub-fullscreen-video__headline-mobile{font-size:8.5714285714rem}}@media (min-width: 1680px){.brandhub-fullscreen-video__headline-mobile{font-size:10rem}}@media (min-width: 1920px){.brandhub-fullscreen-video__headline-mobile{font-size:11.4285714286rem}}.brandhub-fullscreen-video__video{opacity:0;pointer-events:none;transform:translateY(2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out;grid-area:videoContent;height:100%;object-fit:cover;width:100%}.brandhub-fullscreen-video__video--in{opacity:1;pointer-events:auto;transform:translateY(0)}.brandhub-fullscreen-video--edit-mode{grid-template:"mobileHeadline" auto "videoContent" 56.25vw/100%}
`,
  x = { key: 0, class: "brandhub-fullscreen-video__headline-mobile" },
  C = ["src"],
  V = { key: 3, class: "brandhub-fullscreen-video__overlay" },
  z = { class: "brandhub-fullscreen-video__headline" };
function M(e, r, S, R, B, $) {
  const s = o("word-fade"),
    b = o("WordFade"),
    u = g("intersect");
  return (
    i(),
    n(
      "div",
      { class: l(["brandhub-fullscreen-video", e.rootModifierClasses]) },
      [
        e.isMobile1by1
          ? (i(),
            n("h2", x, [
              t(
                s,
                { "animated-text": e.headline, "text-align": "left" },
                null,
                8,
                ["animated-text"]
              ),
            ]))
          : d("", !0),
        e.videoSource
          ? _(
              (i(),
              n(
                "video",
                {
                  class: "brandhub-fullscreen-video__video",
                  key: e.videoSource,
                  ref: "video",
                  muted: "",
                  playsinline: "",
                  onEnded:
                    r[0] ||
                    (r[0] = (...h) => e.onVideoEnded && e.onVideoEnded(...h)),
                },
                [
                  a(
                    "source",
                    { src: e.videoSource, type: "video/mp4" },
                    null,
                    8,
                    C
                  ),
                ],
                32
              )),
              [
                [
                  u,
                  {
                    true: ["brandhub-fullscreen-video__video--in"],
                    onChange: e.handleIntersection,
                  },
                ],
              ]
            )
          : d("", !0),
        e.isMobile1by1
          ? d("", !0)
          : (i(),
            n(
              "div",
              {
                key: 2,
                class: l([
                  "brandhub-fullscreen-video__gradient",
                  e.gradientClasses,
                ]),
              },
              null,
              2
            )),
        e.isMobile1by1
          ? d("", !0)
          : (i(),
            n("div", V, [
              a("h2", z, [
                t(
                  b,
                  {
                    "animated-text": e.headline,
                    "manual-fade": "",
                    "manual-fade-in": e.overlayVisible,
                    "text-align": "left",
                  },
                  null,
                  8,
                  ["animated-text", "manual-fade-in"]
                ),
              ]),
            ])),
      ],
      2
    )
  );
}
const W = w(y, [
  ["render", M],
  ["styles", [k]],
]);
export { W as default };
