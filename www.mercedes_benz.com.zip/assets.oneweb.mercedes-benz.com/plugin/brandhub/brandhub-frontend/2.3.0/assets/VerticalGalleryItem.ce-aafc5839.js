import {
  d as C,
  i as k,
  a as o,
  _ as m,
  r,
  j as z,
  o as i,
  c as n,
  F as R,
  b as l,
  k as g,
  n as d,
  M as b,
  e as t,
  w as c,
  g as M,
  C as E,
  f as p,
  v as G,
  h as v,
  l as L,
  t as S,
} from "./index.js";
import { C as P } from "./ChildComponentMixin-dd022493.js";
import T from "./ResponsiveImage-0ce28426.js";
import { I as J } from "./index-12214b95.js";
import { R as N } from "./ResizeUpdateMixin-a56b9b41.js";
import Z from "./VideoPlayer-b44c2dc6.js";
import { a as D } from "./VideoPlayer.vue_vue_type_script_lang-ca49a257.js";
import { _ as V } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
import "./can-autoplay.es-4e207aef.js";
import "./VideoPauseHandler-61c3b0c3.js";
import "./ShadowDom-bc0a555e.js";
const Q = o(() =>
    m(
      () => import("./ExpandMedia-7448cde8.js"),
      [
        "./ExpandMedia-7448cde8.js",
        "./ExpandMedia.vue_vue_type_script_lang-73e76b3f.js",
        "./index.js",
        "./index.css",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./ExpandedMediaEventEmitter-0b86e5ec.js",
        "./mitt-f7ef348c.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  j = o(() =>
    m(
      () => import("./RelaunchButton-7fb95406.js"),
      [
        "./RelaunchButton-7fb95406.js",
        "./RelaunchButton.vue_vue_type_script_lang-6c2d2d7e.js",
        "./index.js",
        "./index.css",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  B = o(() =>
    m(
      () => import("./play-circle-9622b6f6.js"),
      ["./play-circle-9622b6f6.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  W = o(() =>
    m(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  Y = o(() =>
    m(
      () => import("./Co2Labeling.ce-c45f884c.js"),
      [
        "./Co2Labeling.ce-c45f884c.js",
        "./index.js",
        "./index.css",
        "./i18next-3def9235.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  x = C({
    name: "VerticalGalleryItem",
    props: {
      position: { type: String, default: "right" },
      title: String,
      headlineTag: { type: String, default: "h2" },
      text: String,
      pictureJson: String,
      aspectStyle: String,
      video: String,
      autoplay: { type: Boolean, default: !1 },
      linkText: String,
      externalLink: String,
      internalLink: String,
      downloadLink: String,
      linkTarget: { type: String, default: "_self" },
      linkDownload: { type: Boolean, default: !1 },
      parentHeadline: String,
      parentHeadlineTag: { type: String, default: "h2" },
      parentHeadlineBig: { type: Boolean, default: !1 },
      parentCopy: String,
      isFirstItem: { type: Boolean, default: !1 },
      labelingJson: String,
      backgroundColor: {
        type: String,
        default: "theme",
        validator: (e) => ["background-white", "background-black"].includes(e),
      },
    },
    components: {
      ResponsiveImage: T,
      ExpandMedia: Q,
      RelaunchButton: j,
      IconPlayCircle: B,
      VideoPlayer: Z,
      WordFade: W,
      Co2Labeling: Y,
    },
    directives: { intersect: J },
    mixins: [P, N],
    setup() {
      return { videoElement: k() };
    },
    data() {
      return { videoPlaying: !1, overlayVisible: !0, noFloat: !1 };
    },
    computed: {
      rootModifierClasses() {
        return {
          "brandhub-vertical-gallery-item--position-left":
            this.position === "left",
          "brandhub-vertical-gallery-item--position-left-oversize":
            this.position === "left-oversize",
          "brandhub-vertical-gallery-item--position-right":
            this.position === "right",
          "brandhub-vertical-gallery-item--position-right-oversize":
            this.position === "right-oversize",
          "brandhub-vertical-gallery-item--no-float": this.noFloat,
        };
      },
      videoClasses() {
        return {
          "brandhub-vertical-gallery-item__video--playing": this.videoPlaying,
          "brandhub-vertical-gallery-item__video--autoplay": this.autoplay,
        };
      },
      desktopView() {
        return this.windowWidth >= 768;
      },
      showIcon() {
        return this.windowWidth < 1280;
      },
    },
    methods: {
      onVideoClick() {
        var e, a;
        (this.videoPlaying = !this.videoPlaying),
          this.videoPlaying
            ? ((this.overlayVisible = !1),
              (e = this.videoElement) == null || e.play())
            : (a = this.videoElement) == null || a.pause();
      },
      onVideoPause(e) {
        e.detail === this.videoElement && (this.videoPlaying = !1);
      },
      handleIntersection(e) {
        this.videoElement && this.autoplay && e && !this.videoPlaying
          ? ((this.videoPlaying = !0), this.videoElement.play())
          : this.videoElement &&
            this.autoplay &&
            this.videoPlaying &&
            ((this.videoPlaying = !1), this.videoElement.pause());
      },
    },
    created() {
      this.initChildComponentMixin("VerticalGalleryItem");
      const e = document.documentElement.classList;
      this.noFloat =
        e.contains("isSafari") && !e.contains("isIPhoneOrIPodOrIPad");
    },
    mounted() {
      this.$el.addEventListener(D, this.onVideoPause);
    },
  }),
  H =
    ".brandhub-vertical-gallery-item{break-inside:avoid-column;color:var(--text-color);display:inline-block;margin-bottom:0;overflow:hidden;page-break-inside:avoid;position:relative;width:100%}@media (min-width: 768px){.brandhub-vertical-gallery-item{margin-bottom:10.7142857143rem;max-width:80%}.brandhub-vertical-gallery-item--position-left{margin-left:20%}.brandhub-vertical-gallery-item--position-left-oversize{max-width:100%}.brandhub-vertical-gallery-item--position-left-oversize .brandhub-vertical-gallery-item__parent-headline,.brandhub-vertical-gallery-item--position-left-oversize .brandhub-vertical-gallery-item__parent-copy{margin-left:20%}.brandhub-vertical-gallery-item--position-left-oversize .brandhub-vertical-gallery-item__text-wrapper{margin-left:20%;width:55%}.brandhub-vertical-gallery-item--position-right-oversize{max-width:100%}}@media (min-width: 1024px){.brandhub-vertical-gallery-item{margin-bottom:21.4285714286rem}}.brandhub-vertical-gallery-item--active .brandhub-vertical-gallery-item__text-wrapper{opacity:1}.brandhub-vertical-gallery-item--no-float{float:none}.brandhub-vertical-gallery-item p{margin-bottom:1rem;margin-top:0}.brandhub-vertical-gallery-item__parent-headline{font-family:MBCorpo Title,sans-serif;font-weight:400;font-size:5.7142857143rem;line-height:1em;margin-bottom:1rem;margin-top:30%}@media (max-width: 1679px){.brandhub-vertical-gallery-item__parent-headline{font-size:4.2857142857rem}}@media (max-width: 1279px){.brandhub-vertical-gallery-item__parent-headline{font-size:2.8571428571rem;margin-top:7.1428571429rem}}.brandhub-vertical-gallery-item__parent-headline--big{font-size:3.7142857143rem}@media (min-width: 768px){.brandhub-vertical-gallery-item__parent-headline--big{font-size:4.2857142857rem}}@media (min-width: 1280px){.brandhub-vertical-gallery-item__parent-headline--big{font-size:5rem}}@media (min-width: 1440px){.brandhub-vertical-gallery-item__parent-headline--big{font-size:5.7142857143rem}}@media (min-width: 1680px){.brandhub-vertical-gallery-item__parent-headline--big{font-size:6.4285714286rem}}@media (min-width: 1920px){.brandhub-vertical-gallery-item__parent-headline--big{font-size:7.1428571429rem}}.brandhub-vertical-gallery-item__parent-copy{font-family:MBCorpo Text,sans-serif;font-size:1.4285714286rem;line-height:1.8571428571rem;margin-top:.5rem}@media (min-width: 768px) and (max-width: 1439px){.brandhub-vertical-gallery-item__parent-copy{font-size:1.2857142857rem;line-height:1.7142857143rem}}@media (min-width: 1680px){.brandhub-vertical-gallery-item__parent-copy{font-size:1.7142857143rem;line-height:2.1428571429rem}}.brandhub-vertical-gallery-item__media-element{overflow:hidden;padding-top:var(--desktop-aspect-ratio, 100%);position:relative}@media (max-width: 1023px){.brandhub-vertical-gallery-item__media-element{padding-top:var(--tablet-aspect-ratio, 100%)}}@media (max-width: 767px){.brandhub-vertical-gallery-item__media-element{padding-top:var(--mobile-aspect-ratio, 100%)}}@media (min-width: 768px){.brandhub-vertical-gallery-item__media-element{opacity:0;pointer-events:none;transform:translateY(2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out}.brandhub-vertical-gallery-item__media-element--in{opacity:1;pointer-events:auto;transform:translateY(0)}}.brandhub-vertical-gallery-item__media-element--spacing-top{margin-top:30%}@media (max-width: 767px){.brandhub-vertical-gallery-item__media-element--spacing-top{margin:0}}.brandhub-vertical-gallery-item__video,.brandhub-vertical-gallery-item__image{height:100%;left:0;position:absolute;top:0;width:100%}.brandhub-vertical-gallery-item__video{cursor:url(" +
    new URL("play.png", import.meta.url).href +
    `),pointer;pointer-events:initial}@media (min-width: 1440px){.brandhub-vertical-gallery-item__video{cursor:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAEumlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjYwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iNjAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSI2MCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNjAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLjAiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLjAiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6MzQrMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDItMTFUMTE6MzQ6MzQrMDE6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgKFNlcCAyMiAyMDE5KSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMC0wMi0xMVQxMTozNDozNCswMTowMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+/J49+AAAAYFpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAACiRdZHPK0RRFMc/HqIZolhYWDzCamhQExtlJg01SWOUX5uZZ36omfF670myVbZTlNj4teAvYKuslSJSsrKwJjboOW+eGsmc27nnc7/3ntO954ISy2o5s8oPubxlRMNBdXpmVq15QsGLhzZ8cc3UhycmIpS191sqnHjd7dQqf+5f8y4kTQ0qaoWHNN2whEeFIyuW7vCWcLOWiS8Inwj7DLmg8I2jJ1x+djjt8qfDRiwaAqVRWE3/4sQv1jJGTlheTkcuu6z93Md5SV0yPzUpsV28FZMoYYKojDFCiAC9DMocoJs+emRFmXx/MX+cJcnVZNZZxWCRNBksfKIuS/WkxJToSRlZVp3+/+2rmervc6vXBaH60bZfO6FmE74Ktv1xYNtfh1D5AOf5Uv7SPgy8iV4oaR170LAOpxclLbENZxvQcq/HjXhRqhRXUil4OYb6GWi6As+c27OffY7uILYmX3UJO7vQJecb5r8BTxBn24JPlw4AAAAJcEhZcwAACxMAAAsTAQCanBgAAAPsSURBVGiB7ZtPTBxVHMc/v43GTTAxgRLTHiCpJniWHjDZQytJkzYmaIGDXvTKDbf2ZLnpkcT1oPYEPVA4YYiNNiGhHoQl0Xq2mignCnHX1Ggp1i5fD28W2GF3+od9b1jwk8zlze6873dm3sub3/v9DE9IegbIAb3AceBE7ABYjR13gFvAd2b20Je2piGpTdIFSVcllfX0lKNrXJDUlravPUjqlfSlpPv7MNmI+9G1e9P2iaSXJE17MNmIaUkn0zDaKelTSQ8Cmq3yQFJBUmcos+cl3U3BaJy7ks75NGqSPpC0la7PGiqSLkqyZpvNSppM11siE5Keexwvj7wzcmNlDnhtvzfOM0VgwMx+T/pRouHort3k4JutUgTOmNk/jX6QaXRCblxcoXXMgtP6hRLGdEPDQB54t+mS/PMe8H6jk3XvhKTzwPVG51uALeANM/smfmKPoWiS+gV4IYAwn/wJvGxmpd2N9V7py7S+WXAeLscba56w3Dr1J+DZQKJ88y/wipn9Wm2IP+GPOTxmwXn5aHfD9hOWdAr4PrSiQJwys1tQ+4Q/TElMCLbHsgFIeh4oAY+1Hm1BNoFjZnav+oTPcnjNAmRxHrdf6YH0tARjAMDkoovrQHu6erzzB/BiBhdKDWK2VCoxNTXF+vp6iO7itAM55CIGQejr6xOgjo4OLS4uhup2N/kMLkgehOXlZQDK5TL9/f3Mzs6G6rrK8Qw7uwBB2dzcZGhoiEKhELLbE0j6NtT7BNQ9RkdHValUQki4iaSfQ/QkNTYMaHBwUBsbG74l3EbS3757qZJkGNDY2JhvCX8lhXiCs7a25r8THZBXuqenRysrK74l3M7g9mVTJZfLsbS0RHd3t++uVlM3PDw8zPz8PO3tQRZ76RrO5/PMzMyQzWZDdbmawaUZBKGrqwsAM6NQKDA+Pk4mE3TevIOk075niirFYlEjIyNaWFgI1WWc00fv8zDKlrmetpoAfGVmD6sDaC5VKWGYg50gXhsuiBdsugxMbRDPzO4BN9LV5JUbkceaQHwv8ENqkvyyNxAfNcykJskf01WzcDQ203rM7LdqQ80yJ9pl+zy0Ko98ttss/L8hDlHazzu479RWZQt4O24WGiS1mNnXwCXfqjxyqV5+RyJyqYYTaa3y98GEEtKWDlti2hLw+lMlpgFEfxzAZbgddIrAm0lm4RGGYXsSOwNcbZIwH0ziUg4T8yyfCLkxfVEuZfegUJGUV7PTh2PGz+koJIjHTHfKpeGnVQLwiaRjQczGjJ+UdC2g2WtKo8ijjvGjUcYTR65Q6y25coH9FmpNRtdqaqGWt9lNO6V4r/JkpXg/4rEU7z/68wjQkPEe+AAAAABJRU5ErkJggg==),pointer}}.brandhub-vertical-gallery-item__video--autoplay{cursor:default;pointer-events:none}.brandhub-vertical-gallery-item__video--playing{cursor:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHXSURBVHgBzZmBcYIwFIYfPQfQDeIEuoE4QieoG9QNqBOoE+gKnUA6gXYC6ASywev7Memld1glpvC+u18wx+HvH5I8IKFAmDmVzVQ0s9uhFahEpdWnKE+SJKf/RkwNRZnozO0pRDuRodhYY2uOxy6aUTnRK4cldotCtKBH4LipXWNNbeFLlx64O474zTYGj9w9hyYvTw3mEPmUuiflW90tByy4f5a+p8QzZ2SDmA31Cyb5sUzs2P7q4oz6NwcwWDL3pU7QpleQLkZI0SWYkT7qa9EliPQM6aKSBEcDvlQlhsKorIBfzZTeMX57G7BYpOjilMLZyr/EiBvL/rPXnnrt7xTOFAYnpJc6QUN6mWg3OITBkAu4K4ZPpBwYrEgvlXaDJQyeSC9fMPhBejkN6LEEX2Q5mtl9fzbYS7vbf6Q6z12xcCZ9002JpdJNM1vSR44PlyDSO5MuUGzUo5hs/a8pxT3MYce/aUKKKFz7vhZL0dwZ/FnqbIor6p+VM9eIJLnh/tjQPXC3z2UcxyYv16oZlO9dLoG5aE5t4W66+75u/cMkntcUHB88FF1SDORERrTneKBn4k9nntGC24PE3toaSygQvtzwQ7htNVb+awgIAw3l3Cn0NcQ3BYGJEXeR0NkAAAAASUVORK5CYII=),pointer}@media (min-width: 1440px){.brandhub-vertical-gallery-item__video--playing{cursor:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAACZUlEQVR4XuWbMUsDQRCFrSIEYmlI5z9JGm2srQV/QTrJH7C1spTYKFhbK2ggWNnaCOls0lhGLMZ5uTvdPINGs3tObj54ILt3O/Mk3O3O7q2tJUJE6qpt1aHqTHWvGqme5RP8jTb04Rpci3vqPJ5JNNGmqqu6Vb3mpv4C7sUYGKvJcf4dTaqtulK9BUnHAmNi7DbHLR1NoqMazOaXFMTqcB7J0aAt1TklUyaI3eK8kqCB9lQvlMB/gBz2OL9o6OA11QkFtQByqnG+S6EDNlQ3FMgSyK3Bef8JHWhT9UABLIIcNzn/X6EDbOQDrQrIdYN9LITeuK66pgFXAeS8zn5+RGw+oBblhP18i2SvnlVnsVeWZJMKC+/ZZYGHnycnetEF37nCXLC/GSSbG1eNDvv8QMpdCJTFgH1OkWyJV1W+Li0lW3NWlSs2i0pFisW7FeDts3IiWSml6nRDw6gfVZ3bwiyqi8sU3L7jWLVPCquWd9QHpXqWwGMdhne4JyK7Hz+jHG17DPpP5/QfBf2x2UGAHrdGxJrhHgL0uTUi1gz3EWDIrRGxZniIACNujYg1wyMEGHNrRKwZHiPAhFsjYs3wxKVhdz/pEbdGxJrh6UPL3Wupz60RsWZ4OvFwN7V0t3hIuTw8UG2RnoL+yzn9qXY8suVh/l/1UwDIDbsr8fgq4uWmU5VWLDBbps0Nt/mqCvG1EA/E01YLEG+baUA8bZcC8bYhDsTTkYcCSTfFK4PfHWoB4u3YEhBPB9MKxNPRwwLxdLi0QDwdHw4RLwfEQ8TTJwAh4uUjD0a8fMbDiJcPteYhRj/FewfrgDAWVEaTeAAAAABJRU5ErkJggg==),pointer}}@media (min-width: 768px){.brandhub-vertical-gallery-item__video:hover .brandhub-vertical-gallery-item__play-icon{opacity:0}}.brandhub-vertical-gallery-item__video:focus-visible{border:3px solid rgba(0,120,214,.8)}.brandhub-vertical-gallery-item video{object-fit:cover}.brandhub-vertical-gallery-item__image-overlay{bottom:0;height:100%;left:0;position:absolute;right:0;top:0;z-index:1}.brandhub-vertical-gallery-item__play-icon{height:2.8571428571rem;position:absolute;right:1.0714285714rem;top:1.0714285714rem;transition:opacity .5s ease-in-out;width:2.8571428571rem;z-index:10}@media (min-width: 1440px){.brandhub-vertical-gallery-item__play-icon{height:4.2857142857rem;width:4.2857142857rem}}.brandhub-vertical-gallery-item__text-wrapper{font-family:MBCorpo Text,sans-serif;font-size:1.4285714286rem;line-height:1.8571428571rem;max-width:75%}@media (min-width: 768px) and (max-width: 1439px){.brandhub-vertical-gallery-item__text-wrapper{font-size:1.2857142857rem;line-height:1.7142857143rem}}@media (min-width: 1680px){.brandhub-vertical-gallery-item__text-wrapper{font-size:1.7142857143rem;line-height:2.1428571429rem}}@media (max-width: 767px){.brandhub-vertical-gallery-item__text-wrapper{opacity:0;outline:none;transition:opacity .5s}}.brandhub-vertical-gallery-item__labeling{margin-top:2rem}.brandhub-vertical-gallery-item__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:2.2857142857rem;line-height:2.8571428571rem;margin-bottom:.5rem;margin-top:2rem}@media (min-width: 768px){.brandhub-vertical-gallery-item__headline{font-size:2.8571428571rem;line-height:3.4285714286rem;margin-bottom:0}}@media (min-width: 1024px){.brandhub-vertical-gallery-item__headline{font-size:2.4285714286rem;line-height:3.1428571429rem}}@media (min-width: 1440px){.brandhub-vertical-gallery-item__headline{font-size:3.4285714286rem;line-height:4.2857142857rem}}@media (min-width: 1920px){.brandhub-vertical-gallery-item__headline{font-size:4.5714285714rem;line-height:5.1428571429rem}}.brandhub-vertical-gallery-item__text{margin-top:.5rem}.brandhub-vertical-gallery-item__button{margin-top:2.1428571429rem}
`,
  U = ["innerHTML"],
  K = ["tabindex"],
  F = { class: "brandhub-vertical-gallery-item__text-wrapper" },
  O = ["innerHTML"];
function X(e, a, q, $, ee, ie) {
  const u = r("word-fade"),
    h = r("responsive-image"),
    y = r("video-player"),
    A = r("icon-play-circle"),
    w = r("expand-media"),
    f = r("co2-labeling"),
    I = r("relaunch-button"),
    _ = z("intersect");
  return (
    i(),
    n(
      "div",
      {
        class: d([
          "brandhub-vertical-gallery-item swiper-slide",
          e.rootModifierClasses,
        ]),
      },
      [
        e.desktopView
          ? (i(),
            n(
              R,
              { key: 0 },
              [
                e.parentHeadline && e.isFirstItem
                  ? (i(),
                    l(
                      b(e.parentHeadlineTag),
                      {
                        key: 0,
                        class: d([
                          "brandhub-vertical-gallery-item__parent-headline",
                          {
                            "brandhub-vertical-gallery-item__parent-headline--big":
                              e.parentHeadlineBig,
                          },
                        ]),
                      },
                      {
                        default: g(() => [
                          p(
                            u,
                            {
                              "animated-text": e.parentHeadline,
                              "text-align": "left",
                            },
                            null,
                            8,
                            ["animated-text"]
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["class"]
                    ))
                  : t("", !0),
                e.parentCopy && e.isFirstItem
                  ? (i(),
                    n(
                      "div",
                      {
                        key: 1,
                        class: "brandhub-vertical-gallery-item__parent-copy",
                        innerHTML: e.parentCopy,
                      },
                      null,
                      8,
                      U
                    ))
                  : t("", !0),
              ],
              64
            ))
          : t("", !0),
        c(
          (i(),
          n(
            "div",
            {
              class: d([
                "brandhub-vertical-gallery-item__media-element",
                {
                  "brandhub-vertical-gallery-item__media-element--spacing-top":
                    e.isFirstItem,
                },
              ]),
              style: M(e.aspectStyle),
            },
            [
              e.video
                ? (i(),
                  n(
                    "div",
                    {
                      key: 0,
                      class: d([
                        "brandhub-vertical-gallery-item__video",
                        e.videoClasses,
                      ]),
                      tabindex: e.video && !e.autoplay ? 0 : -1,
                      onClick:
                        a[0] ||
                        (a[0] = (...s) =>
                          e.onVideoClick && e.onVideoClick(...s)),
                      onKeydown:
                        a[1] ||
                        (a[1] = E(
                          (...s) => e.onVideoClick && e.onVideoClick(...s),
                          ["enter"]
                        )),
                    },
                    [
                      e.pictureJson && e.overlayVisible && !e.autoplay
                        ? (i(),
                          l(
                            h,
                            {
                              key: 0,
                              class:
                                "brandhub-vertical-gallery-item__image-overlay",
                              "picture-json": e.pictureJson,
                              "object-fit": "cover",
                            },
                            null,
                            8,
                            ["picture-json"]
                          ))
                        : t("", !0),
                      c(
                        p(
                          y,
                          {
                            ref: "videoElement",
                            "auto-play": e.autoplay,
                            "play-looped": e.autoplay,
                            "play-muted": !0,
                            "poster-image": e.pictureJson,
                            "show-controls": !1,
                            "show-controls-native": !1,
                            width: "100%",
                            height: "100%",
                            "desktop-video": e.video,
                          },
                          null,
                          8,
                          [
                            "auto-play",
                            "play-looped",
                            "poster-image",
                            "desktop-video",
                          ]
                        ),
                        [[G, !e.overlayVisible || e.autoplay]]
                      ),
                      !e.videoPlaying && !e.autoplay
                        ? (i(),
                          l(A, {
                            key: 1,
                            class: "brandhub-vertical-gallery-item__play-icon",
                          }))
                        : t("", !0),
                    ],
                    42,
                    K
                  ))
                : t("", !0),
              e.pictureJson && !e.video
                ? (i(),
                  l(
                    h,
                    {
                      key: 1,
                      class: "brandhub-vertical-gallery-item__image",
                      "picture-json": e.pictureJson,
                      "object-fit": "cover",
                    },
                    null,
                    8,
                    ["picture-json"]
                  ))
                : t("", !0),
              e.pictureJson && !e.video
                ? (i(),
                  l(
                    w,
                    {
                      key: 2,
                      "picture-json": e.pictureJson,
                      iconPosition: "right",
                      showIcon: e.showIcon,
                      trackingName: "vertical",
                      trackingLabel: e.title,
                    },
                    null,
                    8,
                    ["picture-json", "showIcon", "trackingLabel"]
                  ))
                : t("", !0),
            ],
            6
          )),
          [
            [
              _,
              {
                true: ["brandhub-vertical-gallery-item__media-element--in"],
                onChange: e.handleIntersection,
              },
            ],
          ]
        ),
        v("div", F, [
          p(
            f,
            {
              class: "brandhub-vertical-gallery-item__labeling",
              "labeling-json": e.labelingJson,
              "layout-variant": "text",
            },
            null,
            8,
            ["labeling-json"]
          ),
          (i(),
          l(
            b(e.headlineTag),
            { class: "brandhub-vertical-gallery-item__headline" },
            { default: g(() => [L(S(e.title), 1)]), _: 1 }
          )),
          v(
            "div",
            {
              class: "brandhub-vertical-gallery-item__text",
              innerHTML: e.text,
            },
            null,
            8,
            O
          ),
          e.linkText
            ? (i(),
              l(
                I,
                {
                  key: 0,
                  class: "brandhub-vertical-gallery-item__button",
                  "aria-label-text": e.title,
                  text: e.linkText,
                  "internal-link": e.internalLink,
                  "external-link": e.externalLink,
                  "link-target": e.linkTarget,
                  "show-icon": !0,
                  color: e.backgroundColor === "primary" ? "white" : "theme",
                },
                null,
                8,
                [
                  "aria-label-text",
                  "text",
                  "internal-link",
                  "external-link",
                  "link-target",
                  "color",
                ]
              ))
            : t("", !0),
        ]),
      ],
      2
    )
  );
}
const ve = V(x, [
  ["render", X],
  ["styles", [H]],
]);
export { ve as default };
