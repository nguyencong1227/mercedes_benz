import { R as u } from "./ResizeUpdateMixin-a56b9b41.js";
import { I as g } from "./index-12214b95.js";
import {
  d as f,
  i as x,
  j as w,
  o as s,
  c as a,
  w as v,
  h as b,
  F as _,
  D as C,
  n as k,
  l as T,
  t as $,
  g as y,
} from "./index.js";
import { _ as W } from "./_plugin-vue_export-helper-c27b6911.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const G = f({
    name: "ScrollTextFill",
    props: {
      editMode: Boolean,
      fillText: String,
      backgroundColor: { type: String, default: "black" },
      spacingBottom: Boolean,
      spacingTop: Boolean,
    },
    data() {
      return {
        observerOptions: { rootMargin: "0px 0px 0px 0px" },
        rectPercent: 0,
        inView: !1,
        wordGroups: [],
        canvas2d: null,
      };
    },
    directives: { intersect: g },
    mixins: [u],
    setup() {
      return { scrollContainer: x() };
    },
    computed: {
      textProgress() {
        const t = this.wordGroups.length,
          e = 100 / t,
          r = {};
        let i = 0;
        return (
          this.wordGroups.forEach((n, o) => {
            (r[`line-${o}`] = Math.min(
              Math.max((this.rectPercent - i) * t, 0),
              100
            )),
              (i += e);
          }),
          r
        );
      },
      rootModifier() {
        return {
          "brandhub-scroll-text-fill--white": this.backgroundColor === "white",
          "brandhub-scroll-text-fill--black": this.backgroundColor === "black",
          "brandhub-scroll-text-fill--theme": this.backgroundColor === "theme",
          "brandhub-scroll-text-fill--theme-background":
            this.backgroundColor === "theme-background",
          "brandhub-scroll-text-fill--spacing-bottom": this.spacingBottom,
          "brandhub-scroll-text-fill--spacing-top": this.spacingTop,
        };
      },
    },
    methods: {
      handleIntersectChange(t) {
        this.inView = t;
      },
      getTextWidth(t) {
        return this.canvas2d ? this.canvas2d.measureText(t).width : null;
      },
      calculateWordGroup(t) {
        if (!this.scrollContainer) return;
        let e = [];
        const { width: r } = this.scrollContainer.getBoundingClientRect();
        t.forEach((i) => {
          if (i.includes("-")) {
            const n = i.split("-");
            let o = "";
            n.forEach((c, d) => {
              let l = c;
              n.length > d + 1 && (l += "-");
              let h = `${e.join(" ")} ${o}`;
              e.length <= 0 && (h = o);
              const m = `${h}${l}`,
                p = this.getTextWidth(m);
              p && p > r
                ? (this.wordGroups.push(h), (e = []), (o = l))
                : (o += l);
            }),
              o !== "" && e.push(o);
          } else {
            const n = `${e.join(" ")} ${i}`,
              o = this.getTextWidth(n);
            o && o > r
              ? (this.wordGroups.push(e.join(" ")), (e = [i]))
              : e.push(i);
          }
        }),
          e.length > 0 && this.wordGroups.push(e.join(" "));
      },
      calculateWordGroups() {
        var e;
        if (
          ((this.wordGroups = []),
          this.canvas2d ||
            (this.canvas2d = document.createElement("canvas").getContext("2d")),
          this.canvas2d && this.scrollContainer)
        ) {
          const {
            fontWeight: r,
            fontFamily: i,
            fontSize: n,
          } = window.getComputedStyle(this.scrollContainer);
          this.canvas2d.font = `${r} ${n} ${i}`;
        }
        const t =
          (e = this.fillText) == null ? void 0 : e.split(/…\r\n|\r|\n/g);
        t == null ||
          t.forEach((r) => {
            const i = r.split(" ");
            this.calculateWordGroup(i);
          });
      },
      handleScroll() {
        this.inView && this.calculatePercent();
      },
      calculatePercent() {
        if (!this.scrollContainer) return;
        const { innerHeight: t } = window,
          { height: e, top: r } = this.scrollContainer.getBoundingClientRect(),
          i = t * 0.75,
          n = (-r + i) / e;
        this.rectPercent = Math.min(Math.max(n * 100, 0), 100);
      },
      resize() {
        this.calculateWordGroups();
      },
    },
    mounted() {
      const t = window.setInterval(() => {
        this.calculateWordGroups();
      }, 50);
      window.setTimeout(() => {
        clearInterval(t);
      }, 500),
        this.editMode
          ? (this.rectPercent = 50)
          : (window.addEventListener("scroll", this.handleScroll, {
              passive: !0,
            }),
            this.calculatePercent());
    },
  }),
  B = `.brandhub-scroll-text-fill{margin:0 auto;width:100%;font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:2.8571428571rem;line-height:3.0714285714rem;--background-color: var(--wb-black);background-color:var(--background-color);color:var(--wb-white)}@media (min-width: 480px){.brandhub-scroll-text-fill{font-size:4.2857142857rem;line-height:4.6428571429rem}}@media (min-width: 1440px){.brandhub-scroll-text-fill{font-size:5rem;line-height:5.3571428571rem}}@media (min-width: 1680px){.brandhub-scroll-text-fill{font-size:5.7142857143rem;line-height:1em}}@media (min-width: 1920px){.brandhub-scroll-text-fill{font-size:6.4285714286rem}}.brandhub-scroll-text-fill--white{--background-color: var(--wb-white);color:var(--wb-black)}.brandhub-scroll-text-fill--theme{--background-color: var(--wb-white);color:var(--campaign-light)}.brandhub-scroll-text-fill--theme-background{--background-color: var(--campaign-primary);color:var(--campaign-text)}.brandhub-scroll-text-fill--spacing-bottom{padding-bottom:4.2857142857rem}@media (min-width: 768px){.brandhub-scroll-text-fill--spacing-bottom{padding-bottom:10.7142857143rem}}@media (min-width: 1440px){.brandhub-scroll-text-fill--spacing-bottom{padding-bottom:12.8571428571rem}}@media (min-width: 1680px){.brandhub-scroll-text-fill--spacing-bottom{padding-bottom:15.7142857143rem}}@media (min-width: 1920px){.brandhub-scroll-text-fill--spacing-bottom{padding-bottom:17.8571428571rem}}.brandhub-scroll-text-fill--spacing-top{padding-top:4.2857142857rem}@media (min-width: 768px){.brandhub-scroll-text-fill--spacing-top{padding-top:10.7142857143rem}}@media (min-width: 1440px){.brandhub-scroll-text-fill--spacing-top{padding-top:12.8571428571rem}}@media (min-width: 1680px){.brandhub-scroll-text-fill--spacing-top{padding-top:15.7142857143rem}}@media (min-width: 1920px){.brandhub-scroll-text-fill--spacing-top{padding-top:17.8571428571rem}}.brandhub-scroll-text-fill__container{padding-left:1.1428571429rem;padding-right:1.1428571429rem}@media (min-width: 768px){.brandhub-scroll-text-fill__container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-scroll-text-fill__container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-scroll-text-fill__container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-scroll-text-fill__container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-scroll-text-fill__content{width:100%}@media (min-width: 1024px){.brandhub-scroll-text-fill__content{max-width:60vw}}@media (min-width: 1440px){.brandhub-scroll-text-fill__content{max-width:50vw}}.brandhub-scroll-text-fill__text{position:relative}.brandhub-scroll-text-fill__overlay{background-color:var(--background-color);height:105%;opacity:.7;pointer-events:none;position:absolute;right:0;top:0}
`,
  S = { class: "brandhub-scroll-text-fill__container" },
  M = { class: "brandhub-scroll-text-fill__content", ref: "scrollContainer" };
function z(t, e, r, i, n, o) {
  const c = w("intersect");
  return (
    s(),
    a(
      "div",
      { class: k(["brandhub-scroll-text-fill", t.rootModifier]) },
      [
        v(
          (s(),
          a("div", S, [
            b(
              "div",
              M,
              [
                (s(!0),
                a(
                  _,
                  null,
                  C(
                    t.wordGroups,
                    (d, l) => (
                      s(),
                      a(
                        "div",
                        {
                          class: "brandhub-scroll-text-fill__text",
                          key: `word-group-${l}`,
                        },
                        [
                          T($(d) + " ", 1),
                          b(
                            "div",
                            {
                              class: "brandhub-scroll-text-fill__overlay",
                              style: y(
                                `width:${100 - t.textProgress["line-" + l]}%`
                              ),
                            },
                            null,
                            4
                          ),
                        ]
                      )
                    )
                  ),
                  128
                )),
              ],
              512
            ),
          ])),
          [
            [
              c,
              {
                observerOptions: t.observerOptions,
                onChange: t.handleIntersectChange,
              },
            ],
          ]
        ),
      ],
      2
    )
  );
}
const R = W(G, [
  ["render", z],
  ["styles", [B]],
]);
export { R as default };
