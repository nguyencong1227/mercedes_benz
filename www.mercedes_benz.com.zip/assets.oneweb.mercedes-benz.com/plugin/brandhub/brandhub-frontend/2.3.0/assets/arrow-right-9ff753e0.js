import { o as e, c as o, h as t } from "./index.js";
const r = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" },
  n = t(
    "path",
    {
      fill: "currentColor",
      "fill-rule": "evenodd",
      d: "m9.121 19.728-.707-.707 7.07-7.071-7.07-7.071.707-.707 7.07 7.07h.001l.707.708-7.778 7.778Z",
    },
    null,
    -1
  ),
  s = [n];
function c(l, a) {
  return e(), o("svg", r, [...s]);
}
const h = { render: c };
export { h as default, c as render };
