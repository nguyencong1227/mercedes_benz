import { P as t, C as n } from "./ParentComponentMixin-b739cccc.js";
import "./i18next-3def9235.js";
import { d as a, o as i, c as r, h as s, B as o } from "./index.js";
import { _ as l } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ShadowDom-bc0a555e.js";
const d = a({
    mixins: [t],
    data() {
      return { items: new n() };
    },
    created() {
      this.initParentComponentMixin(this.items, ["LanguageSwitcherItem"]);
    },
  }),
  c = `@media (max-width: 1023px){.brandhub-language-switcher{display:flex;justify-content:center;padding:var(--language-switcher-footer-padding, 1.7142857143rem 0)}}.brandhub-language-switcher__items{list-style:none;margin:0;padding:0}::slotted(brandhub-language-switcher-item:not(brandhub-language-switcher-item:last-of-type)){display:inline-block}::slotted(brandhub-language-switcher-item:not(brandhub-language-switcher-item:last-of-type)):after{background:var(--wb-grey-45);content:"";display:inline-block;height:.7857142857rem;margin-left:.9285714286rem;margin-right:.9285714286rem;position:relative;top:1px;width:1px}
`,
  m = { class: "brandhub-language-switcher" },
  g = { role: "list", class: "brandhub-language-switcher__items" };
function h(e, p, u, b, _, f) {
  return i(), r("div", m, [s("div", g, [o(e.$slots, "default")])]);
}
const v = l(d, [
  ["render", h],
  ["styles", [c]],
]);
export { v as default };
