import { a as y } from "./LayeredGallery.ce.vue_vue_type_script_lang-5e3a1314.js";
import { _ as m } from "./_plugin-vue_export-helper-c27b6911.js";
import {
  r as h,
  o as a,
  c as r,
  h as i,
  b as u,
  e as t,
  f as o,
  t as d,
  g as s,
  F as b,
  D as g,
  n as c,
} from "./index.js";
const _ = `.brandhub-layered-gallery-item{display:flex;height:100vh;left:0;pointer-events:none;position:absolute;top:0;width:100%;z-index:1}.brandhub-layered-gallery-item--show-main-picture{pointer-events:auto}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item{flex-flow:column}}.brandhub-layered-gallery-item--edit-mode{height:800px;position:relative}.brandhub-layered-gallery-item--edit-mode .brandhub-layered-gallery-item__main-picture-container,.brandhub-layered-gallery-item--edit-mode .brandhub-layered-gallery-item__secondary-container{height:720px;max-height:720px;max-width:50%;width:50%}.brandhub-layered-gallery-item--edit-mode .brandhub-layered-gallery-item__main-picture,.brandhub-layered-gallery-item--edit-mode .brandhub-layered-gallery-item__secondary-picture{height:100%;width:100%}.brandhub-layered-gallery-item__main-picture-container,.brandhub-layered-gallery-item__secondary-container{flex:0 0 50%;height:50vw;max-height:90vh;max-width:90vw;position:relative;width:50vw}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__main-picture-container,.brandhub-layered-gallery-item__secondary-container{height:50vh;width:50vh}}.brandhub-layered-gallery-item__curtain{height:0;overflow:hidden;position:absolute;transition:height 1s;width:100%}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__curtain{height:100%;transition:width 1s;width:0}}.brandhub-layered-gallery-item__curtain--left,.brandhub-layered-gallery-item--inverse-transition-dir .brandhub-layered-gallery-item__curtain--right{bottom:auto;left:auto;right:0;top:0}.brandhub-layered-gallery-item__curtain--right{display:grid;grid-template:"content" 100%/100%}.brandhub-layered-gallery-item__curtain--right,.brandhub-layered-gallery-item--inverse-transition-dir .brandhub-layered-gallery-item__curtain--left{bottom:0;left:0;right:auto;top:auto}.brandhub-layered-gallery-item--show-main-picture .brandhub-layered-gallery-item__curtain{height:100%}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item--show-main-picture .brandhub-layered-gallery-item__curtain{width:100%}}.brandhub-layered-gallery-item__main-picture-container{margin-bottom:auto}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__main-picture-container{margin-bottom:0;margin-left:auto}}.brandhub-layered-gallery-item__secondary-container{margin-top:auto}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__secondary-container{margin-right:auto;margin-top:0}}.brandhub-layered-gallery-item__main-picture,.brandhub-layered-gallery-item__secondary-picture{height:50vw;max-height:90vh;position:absolute;transform:scale(1.1);transition:transform 1s;width:50vw}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__main-picture,.brandhub-layered-gallery-item__secondary-picture{height:50vh;max-width:90vw;width:50vh}}.brandhub-layered-gallery-item--show-main-picture .brandhub-layered-gallery-item__main-picture,.brandhub-layered-gallery-item--show-main-picture .brandhub-layered-gallery-item__secondary-picture{transform:scale(1)}.brandhub-layered-gallery-item__main-picture{right:0;top:0}.brandhub-layered-gallery-item--inverse-transition-dir .brandhub-layered-gallery-item__main-picture{bottom:0;left:0;right:auto;top:auto}.brandhub-layered-gallery-item__secondary-picture{bottom:0;grid-area:content;left:0}.brandhub-layered-gallery-item--inverse-transition-dir .brandhub-layered-gallery-item__secondary-picture{bottom:auto;left:auto;right:0;top:0}.brandhub-layered-gallery-item__svg-container{align-items:center;display:flex;grid-area:content;height:50vw;justify-content:center;margin:0 auto;max-height:90vh;max-width:90vw;overflow:hidden;position:relative;width:50vw;z-index:1}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__svg-container{height:50vh;width:50vh}}.brandhub-layered-gallery-item__secondary-headline{box-sizing:border-box;height:50vw;left:0;padding:0 2.5vw;position:absolute;width:100%}@media (max-width: 1279px) and (orientation: portrait){.brandhub-layered-gallery-item__secondary-headline{height:50vh}}.brandhub-layered-gallery-item__secondary-headline text{dominant-baseline:middle;font-family:MBCorpo Title,sans-serif;opacity:0;pointer-events:none;transition:opacity .4s;transition-delay:var(--fade-out-transition-delay, 0s)}.brandhub-layered-gallery-item--show-headline .brandhub-layered-gallery-item__secondary-headline text{opacity:var(--text-opacity, 1);pointer-events:auto;transition-delay:var(--fade-in-transition-delay, 0s)}.brandhub-layered-gallery-item__small-container{display:grid;grid-area:content;grid-template:"smallPicture" 100%/100%;margin:10%;opacity:0;overflow:hidden;pointer-events:none;transform:translateY(10%);transition:opacity .75s,transform .75s;z-index:2}@media (max-width: 1279px) and (max-width: 55vh) and (orientation: portrait){.brandhub-layered-gallery-item__small-container{margin-right:0}}@media (min-width: 1280px){.brandhub-layered-gallery-item__small-container{margin:12.5%}}.brandhub-layered-gallery-item--show-small-picture .brandhub-layered-gallery-item__small-container{opacity:1;pointer-events:auto;transform:translateY(0)}.brandhub-layered-gallery-item__small-picture{grid-area:smallPicture}.brandhub-layered-gallery-item__small-gradient{background:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0));grid-area:smallPicture;height:50%;margin-top:auto;opacity:0;transition:opacity .5s;width:100%}.brandhub-layered-gallery-item--show-copy .brandhub-layered-gallery-item__small-gradient{opacity:1}.brandhub-layered-gallery-item__small-copy{align-items:flex-end;display:flex;font-family:MBCorpo Text,sans-serif;font-size:1rem;grid-area:smallPicture;height:50%;line-height:1.2142857143rem;margin-bottom:8%;margin-top:auto;opacity:0;padding:0 5%;pointer-events:none;text-align:center;transform:translateY(6%);transition:opacity .5s,transform .5s;transition-delay:0s}@media (min-width: 768px){.brandhub-layered-gallery-item__small-copy{font-size:1.4285714286rem;line-height:1.8571428571rem;padding:0 10%}}@media (min-width: 1280px){.brandhub-layered-gallery-item__small-copy{font-size:1.7142857143rem;line-height:2.1428571429rem;padding:0 15%}}.brandhub-layered-gallery-item--show-copy .brandhub-layered-gallery-item__small-copy{opacity:1;pointer-events:auto;transform:translateY(0);transition-delay:.1s}
`,
  p = { class: "brandhub-layered-gallery-item__main-picture-container" },
  v = {
    class:
      "brandhub-layered-gallery-item__curtain brandhub-layered-gallery-item__curtain--left",
  },
  w = { key: 0, class: "brandhub-layered-gallery-item__secondary-container" },
  f = {
    class:
      "brandhub-layered-gallery-item__curtain brandhub-layered-gallery-item__curtain--right",
  },
  x = { key: 0, class: "brandhub-layered-gallery-item__svg-container" },
  k = ["viewBox"],
  z = ["y"],
  C = { key: 1, class: "brandhub-layered-gallery-item__small-container" },
  P = { key: 0, class: "brandhub-layered-gallery-item__small-gradient" },
  B = ["innerHTML"];
function j(e, H, M, $, Y, L) {
  const n = h("responsive-image");
  return (
    a(),
    r(
      "div",
      { class: c(["brandhub-layered-gallery-item", e.rootClass]) },
      [
        i("div", p, [
          i("div", v, [
            e.mainPicture
              ? (a(),
                u(
                  n,
                  {
                    key: 0,
                    class: "brandhub-layered-gallery-item__main-picture",
                    "picture-json": e.mainPicture,
                  },
                  null,
                  8,
                  ["picture-json"]
                ))
              : t("", !0),
          ]),
        ]),
        e.secondaryPicture
          ? (a(),
            r("div", w, [
              i("div", f, [
                o(
                  n,
                  {
                    class: "brandhub-layered-gallery-item__secondary-picture",
                    "picture-json": e.secondaryPicture,
                  },
                  null,
                  8,
                  ["picture-json"]
                ),
                e.secondaryHeadline
                  ? (a(),
                    r("div", x, [
                      (a(),
                      r(
                        "svg",
                        {
                          class:
                            "brandhub-layered-gallery-item__secondary-headline",
                          preserveAspectRatio: "xMidYMid meet",
                          viewBox: e.viewBox,
                        },
                        [
                          i("title", null, d(e.secondaryHeadline), 1),
                          i(
                            "text",
                            {
                              x: "0",
                              y: "1.2",
                              style: s(
                                `--fade-in-transition-delay: ${
                                  e.textsNeeded * 150
                                }ms;`
                              ),
                              "font-size": "16",
                              ref: "secondaryHeadlineNode",
                              fill: "currentColor",
                            },
                            d(e.secondaryHeadline),
                            5
                          ),
                          (a(!0),
                          r(
                            b,
                            null,
                            g(
                              e.svgTextNodes,
                              (l) => (
                                a(),
                                r(
                                  "text",
                                  {
                                    key: `svg-text-${l.index}`,
                                    x: "0",
                                    y: l.y,
                                    style: s(l.elementStyle),
                                    "font-size": "16",
                                    fill: "currentColor",
                                  },
                                  d(e.secondaryHeadline),
                                  13,
                                  z
                                )
                              )
                            ),
                            128
                          )),
                        ],
                        8,
                        k
                      )),
                    ]))
                  : t("", !0),
                e.smallPicture
                  ? (a(),
                    r("div", C, [
                      o(
                        n,
                        {
                          "picture-json": e.smallPicture,
                          class: "brandhub-layered-gallery-item__small-picture",
                        },
                        null,
                        8,
                        ["picture-json"]
                      ),
                      e.smallCopy ? (a(), r("div", P)) : t("", !0),
                      e.smallCopy
                        ? (a(),
                          r(
                            "div",
                            {
                              key: 1,
                              class:
                                "brandhub-layered-gallery-item__small-copy",
                              innerHTML: e.smallCopy,
                            },
                            null,
                            8,
                            B
                          ))
                        : t("", !0),
                    ]))
                  : t("", !0),
              ]),
            ]))
          : t("", !0),
      ],
      2
    )
  );
}
const V = m(y, [
  ["render", j],
  ["styles", [_]],
]);
export { V as default };
