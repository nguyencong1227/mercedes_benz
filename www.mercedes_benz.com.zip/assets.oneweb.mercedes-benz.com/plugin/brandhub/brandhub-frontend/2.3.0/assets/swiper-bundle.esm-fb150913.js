import {
  b as z,
  e as O,
  $ as g,
  g as L,
  a as k,
  n as G,
  c as R,
  d as oa,
  f as I,
  h as da,
  i as pa,
  S as fa,
} from "./core-class-d6f76cb6.js";
function F() {
  return (
    (F =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    F.apply(this, arguments)
  );
}
var ca = {
  update: function (a) {
    var e = this,
      t = e.params,
      r = t.slidesPerView,
      i = t.slidesPerGroup,
      s = t.centeredSlides,
      l = e.params.virtual,
      o = l.addSlidesBefore,
      d = l.addSlidesAfter,
      u = e.virtual,
      p = u.from,
      c = u.to,
      v = u.slides,
      f = u.slidesGrid,
      y = u.renderSlide,
      E = u.offset;
    e.updateActiveIndex();
    var m = e.activeIndex || 0,
      w;
    e.rtlTranslate ? (w = "right") : (w = e.isHorizontal() ? "left" : "top");
    var C, b;
    s
      ? ((C = Math.floor(r / 2) + i + d), (b = Math.floor(r / 2) + i + o))
      : ((C = r + (i - 1) + d), (b = i + o));
    var h = Math.max((m || 0) - b, 0),
      S = Math.min((m || 0) + C, v.length - 1),
      x = (e.slidesGrid[h] || 0) - (e.slidesGrid[0] || 0);
    O(e.virtual, { from: h, to: S, offset: x, slidesGrid: e.slidesGrid });
    function $() {
      e.updateSlides(),
        e.updateProgress(),
        e.updateSlidesClasses(),
        e.lazy && e.params.lazy.enabled && e.lazy.load();
    }
    if (p === h && c === S && !a) {
      e.slidesGrid !== f && x !== E && e.slides.css(w, x + "px"),
        e.updateProgress();
      return;
    }
    if (e.params.virtual.renderExternal) {
      e.params.virtual.renderExternal.call(e, {
        offset: x,
        from: h,
        to: S,
        slides: (function () {
          for (var X = [], Y = h; Y <= S; Y += 1) X.push(v[Y]);
          return X;
        })(),
      }),
        e.params.virtual.renderExternalUpdate && $();
      return;
    }
    var P = [],
      T = [];
    if (a) e.$wrapperEl.find("." + e.params.slideClass).remove();
    else
      for (var M = p; M <= c; M += 1)
        (M < h || M > S) &&
          e.$wrapperEl
            .find(
              "." +
                e.params.slideClass +
                '[data-swiper-slide-index="' +
                M +
                '"]'
            )
            .remove();
    for (var D = 0; D < v.length; D += 1)
      D >= h &&
        D <= S &&
        (typeof c > "u" || a
          ? T.push(D)
          : (D > c && T.push(D), D < p && P.push(D)));
    T.forEach(function (H) {
      e.$wrapperEl.append(y(v[H], H));
    }),
      P.sort(function (H, X) {
        return X - H;
      }).forEach(function (H) {
        e.$wrapperEl.prepend(y(v[H], H));
      }),
      e.$wrapperEl.children(".swiper-slide").css(w, x + "px"),
      $();
  },
  renderSlide: function (a, e) {
    var t = this,
      r = t.params.virtual;
    if (r.cache && t.virtual.cache[e]) return t.virtual.cache[e];
    var i = r.renderSlide
      ? g(r.renderSlide.call(t, a, e))
      : g(
          '<div class="' +
            t.params.slideClass +
            '" data-swiper-slide-index="' +
            e +
            '">' +
            a +
            "</div>"
        );
    return (
      i.attr("data-swiper-slide-index") || i.attr("data-swiper-slide-index", e),
      r.cache && (t.virtual.cache[e] = i),
      i
    );
  },
  appendSlide: function (a) {
    var e = this;
    if (typeof a == "object" && "length" in a)
      for (var t = 0; t < a.length; t += 1) a[t] && e.virtual.slides.push(a[t]);
    else e.virtual.slides.push(a);
    e.virtual.update(!0);
  },
  prependSlide: function (a) {
    var e = this,
      t = e.activeIndex,
      r = t + 1,
      i = 1;
    if (Array.isArray(a)) {
      for (var s = 0; s < a.length; s += 1)
        a[s] && e.virtual.slides.unshift(a[s]);
      (r = t + a.length), (i = a.length);
    } else e.virtual.slides.unshift(a);
    if (e.params.virtual.cache) {
      var l = e.virtual.cache,
        o = {};
      Object.keys(l).forEach(function (d) {
        var u = l[d],
          p = u.attr("data-swiper-slide-index");
        p && u.attr("data-swiper-slide-index", parseInt(p, 10) + 1),
          (o[parseInt(d, 10) + i] = u);
      }),
        (e.virtual.cache = o);
    }
    e.virtual.update(!0), e.slideTo(r, 0);
  },
  removeSlide: function (a) {
    var e = this;
    if (!(typeof a > "u" || a === null)) {
      var t = e.activeIndex;
      if (Array.isArray(a))
        for (var r = a.length - 1; r >= 0; r -= 1)
          e.virtual.slides.splice(a[r], 1),
            e.params.virtual.cache && delete e.virtual.cache[a[r]],
            a[r] < t && (t -= 1),
            (t = Math.max(t, 0));
      else
        e.virtual.slides.splice(a, 1),
          e.params.virtual.cache && delete e.virtual.cache[a],
          a < t && (t -= 1),
          (t = Math.max(t, 0));
      e.virtual.update(!0), e.slideTo(t, 0);
    }
  },
  removeAllSlides: function () {
    var a = this;
    (a.virtual.slides = []),
      a.params.virtual.cache && (a.virtual.cache = {}),
      a.virtual.update(!0),
      a.slideTo(0, 0);
  },
};
const va = {
  name: "virtual",
  params: {
    virtual: {
      enabled: !1,
      slides: [],
      cache: !0,
      renderSlide: null,
      renderExternal: null,
      renderExternalUpdate: !0,
      addSlidesBefore: 0,
      addSlidesAfter: 0,
    },
  },
  create: function () {
    var a = this;
    z(a, {
      virtual: F({}, ca, { slides: a.params.virtual.slides, cache: {} }),
    });
  },
  on: {
    beforeInit: function (a) {
      if (a.params.virtual.enabled) {
        a.classNames.push(a.params.containerModifierClass + "virtual");
        var e = { watchSlidesProgress: !0 };
        O(a.params, e),
          O(a.originalParams, e),
          a.params.initialSlide || a.virtual.update();
      }
    },
    setTranslate: function (a) {
      a.params.virtual.enabled && a.virtual.update();
    },
  },
};
function V() {
  return (
    (V =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    V.apply(this, arguments)
  );
}
var ma = {
  handle: function (a) {
    var e = this;
    if (e.enabled) {
      var t = L(),
        r = k(),
        i = e.rtlTranslate,
        s = a;
      s.originalEvent && (s = s.originalEvent);
      var l = s.keyCode || s.charCode,
        o = e.params.keyboard.pageUpDown,
        d = o && l === 33,
        u = o && l === 34,
        p = l === 37,
        c = l === 39,
        v = l === 38,
        f = l === 40;
      if (
        (!e.allowSlideNext &&
          ((e.isHorizontal() && c) || (e.isVertical() && f) || u)) ||
        (!e.allowSlidePrev &&
          ((e.isHorizontal() && p) || (e.isVertical() && v) || d))
      )
        return !1;
      if (
        !(s.shiftKey || s.altKey || s.ctrlKey || s.metaKey) &&
        !(
          r.activeElement &&
          r.activeElement.nodeName &&
          (r.activeElement.nodeName.toLowerCase() === "input" ||
            r.activeElement.nodeName.toLowerCase() === "textarea")
        )
      ) {
        if (e.params.keyboard.onlyInViewport && (d || u || p || c || v || f)) {
          var y = !1;
          if (
            e.$el.parents("." + e.params.slideClass).length > 0 &&
            e.$el.parents("." + e.params.slideActiveClass).length === 0
          )
            return;
          var E = e.$el,
            m = E[0].clientWidth,
            w = E[0].clientHeight,
            C = t.innerWidth,
            b = t.innerHeight,
            h = e.$el.offset();
          i && (h.left -= e.$el[0].scrollLeft);
          for (
            var S = [
                [h.left, h.top],
                [h.left + m, h.top],
                [h.left, h.top + w],
                [h.left + m, h.top + w],
              ],
              x = 0;
            x < S.length;
            x += 1
          ) {
            var $ = S[x];
            if ($[0] >= 0 && $[0] <= C && $[1] >= 0 && $[1] <= b) {
              if ($[0] === 0 && $[1] === 0) continue;
              y = !0;
            }
          }
          if (!y) return;
        }
        e.isHorizontal()
          ? ((d || u || p || c) &&
              (s.preventDefault ? s.preventDefault() : (s.returnValue = !1)),
            (((u || c) && !i) || ((d || p) && i)) && e.slideNext(),
            (((d || p) && !i) || ((u || c) && i)) && e.slidePrev())
          : ((d || u || v || f) &&
              (s.preventDefault ? s.preventDefault() : (s.returnValue = !1)),
            (u || f) && e.slideNext(),
            (d || v) && e.slidePrev()),
          e.emit("keyPress", l);
      }
    }
  },
  enable: function () {
    var a = this,
      e = k();
    a.keyboard.enabled ||
      (g(e).on("keydown", a.keyboard.handle), (a.keyboard.enabled = !0));
  },
  disable: function () {
    var a = this,
      e = k();
    a.keyboard.enabled &&
      (g(e).off("keydown", a.keyboard.handle), (a.keyboard.enabled = !1));
  },
};
const ha = {
  name: "keyboard",
  params: { keyboard: { enabled: !1, onlyInViewport: !0, pageUpDown: !0 } },
  create: function () {
    var a = this;
    z(a, { keyboard: V({ enabled: !1 }, ma) });
  },
  on: {
    init: function (a) {
      a.params.keyboard.enabled && a.keyboard.enable();
    },
    destroy: function (a) {
      a.keyboard.enabled && a.keyboard.disable();
    },
  },
};
function ga() {
  var n = k(),
    a = "onwheel",
    e = a in n;
  if (!e) {
    var t = n.createElement("div");
    t.setAttribute(a, "return;"), (e = typeof t[a] == "function");
  }
  return (
    !e &&
      n.implementation &&
      n.implementation.hasFeature &&
      n.implementation.hasFeature("", "") !== !0 &&
      (e = n.implementation.hasFeature("Events.wheel", "3.0")),
    e
  );
}
var N = {
  lastScrollTime: G(),
  lastEventBeforeSnap: void 0,
  recentWheelEvents: [],
  event: function () {
    var a = L();
    return a.navigator.userAgent.indexOf("firefox") > -1
      ? "DOMMouseScroll"
      : ga()
      ? "wheel"
      : "mousewheel";
  },
  normalize: function (a) {
    var e = 10,
      t = 40,
      r = 800,
      i = 0,
      s = 0,
      l = 0,
      o = 0;
    return (
      "detail" in a && (s = a.detail),
      "wheelDelta" in a && (s = -a.wheelDelta / 120),
      "wheelDeltaY" in a && (s = -a.wheelDeltaY / 120),
      "wheelDeltaX" in a && (i = -a.wheelDeltaX / 120),
      "axis" in a && a.axis === a.HORIZONTAL_AXIS && ((i = s), (s = 0)),
      (l = i * e),
      (o = s * e),
      "deltaY" in a && (o = a.deltaY),
      "deltaX" in a && (l = a.deltaX),
      a.shiftKey && !l && ((l = o), (o = 0)),
      (l || o) &&
        a.deltaMode &&
        (a.deltaMode === 1 ? ((l *= t), (o *= t)) : ((l *= r), (o *= r))),
      l && !i && (i = l < 1 ? -1 : 1),
      o && !s && (s = o < 1 ? -1 : 1),
      { spinX: i, spinY: s, pixelX: l, pixelY: o }
    );
  },
  handleMouseEnter: function () {
    var a = this;
    a.enabled && (a.mouseEntered = !0);
  },
  handleMouseLeave: function () {
    var a = this;
    a.enabled && (a.mouseEntered = !1);
  },
  handle: function (a) {
    var e = a,
      t = !0,
      r = this;
    if (r.enabled) {
      var i = r.params.mousewheel;
      r.params.cssMode && e.preventDefault();
      var s = r.$el;
      if (
        (r.params.mousewheel.eventsTarget !== "container" &&
          (s = g(r.params.mousewheel.eventsTarget)),
        !r.mouseEntered && !s[0].contains(e.target) && !i.releaseOnEdges)
      )
        return !0;
      e.originalEvent && (e = e.originalEvent);
      var l = 0,
        o = r.rtlTranslate ? -1 : 1,
        d = N.normalize(e);
      if (i.forceToAxis)
        if (r.isHorizontal())
          if (Math.abs(d.pixelX) > Math.abs(d.pixelY)) l = -d.pixelX * o;
          else return !0;
        else if (Math.abs(d.pixelY) > Math.abs(d.pixelX)) l = -d.pixelY;
        else return !0;
      else
        l = Math.abs(d.pixelX) > Math.abs(d.pixelY) ? -d.pixelX * o : -d.pixelY;
      if (l === 0) return !0;
      i.invert && (l = -l);
      var u = r.getTranslate() + l * i.sensitivity;
      if (
        (u >= r.minTranslate() && (u = r.minTranslate()),
        u <= r.maxTranslate() && (u = r.maxTranslate()),
        (t = r.params.loop
          ? !0
          : !(u === r.minTranslate() || u === r.maxTranslate())),
        t && r.params.nested && e.stopPropagation(),
        r.params.freeMode)
      ) {
        var f = { time: G(), delta: Math.abs(l), direction: Math.sign(l) },
          y = r.mousewheel.lastEventBeforeSnap,
          E =
            y &&
            f.time < y.time + 500 &&
            f.delta <= y.delta &&
            f.direction === y.direction;
        if (!E) {
          (r.mousewheel.lastEventBeforeSnap = void 0),
            r.params.loop && r.loopFix();
          var m = r.getTranslate() + l * i.sensitivity,
            w = r.isBeginning,
            C = r.isEnd;
          if (
            (m >= r.minTranslate() && (m = r.minTranslate()),
            m <= r.maxTranslate() && (m = r.maxTranslate()),
            r.setTransition(0),
            r.setTranslate(m),
            r.updateProgress(),
            r.updateActiveIndex(),
            r.updateSlidesClasses(),
            ((!w && r.isBeginning) || (!C && r.isEnd)) &&
              r.updateSlidesClasses(),
            r.params.freeModeSticky)
          ) {
            clearTimeout(r.mousewheel.timeout), (r.mousewheel.timeout = void 0);
            var b = r.mousewheel.recentWheelEvents;
            b.length >= 15 && b.shift();
            var h = b.length ? b[b.length - 1] : void 0,
              S = b[0];
            if (
              (b.push(f),
              h && (f.delta > h.delta || f.direction !== h.direction))
            )
              b.splice(0);
            else if (
              b.length >= 15 &&
              f.time - S.time < 500 &&
              S.delta - f.delta >= 1 &&
              f.delta <= 6
            ) {
              var x = l > 0 ? 0.8 : 0.2;
              (r.mousewheel.lastEventBeforeSnap = f),
                b.splice(0),
                (r.mousewheel.timeout = R(function () {
                  r.slideToClosest(r.params.speed, !0, void 0, x);
                }, 0));
            }
            r.mousewheel.timeout ||
              (r.mousewheel.timeout = R(function () {
                var $ = 0.5;
                (r.mousewheel.lastEventBeforeSnap = f),
                  b.splice(0),
                  r.slideToClosest(r.params.speed, !0, void 0, $);
              }, 500));
          }
          if (
            (E || r.emit("scroll", e),
            r.params.autoplay &&
              r.params.autoplayDisableOnInteraction &&
              r.autoplay.stop(),
            m === r.minTranslate() || m === r.maxTranslate())
          )
            return !0;
        }
      } else {
        var p = {
            time: G(),
            delta: Math.abs(l),
            direction: Math.sign(l),
            raw: a,
          },
          c = r.mousewheel.recentWheelEvents;
        c.length >= 2 && c.shift();
        var v = c.length ? c[c.length - 1] : void 0;
        if (
          (c.push(p),
          v
            ? (p.direction !== v.direction ||
                p.delta > v.delta ||
                p.time > v.time + 150) &&
              r.mousewheel.animateSlider(p)
            : r.mousewheel.animateSlider(p),
          r.mousewheel.releaseScroll(p))
        )
          return !0;
      }
      return e.preventDefault ? e.preventDefault() : (e.returnValue = !1), !1;
    }
  },
  animateSlider: function (a) {
    var e = this,
      t = L();
    return (this.params.mousewheel.thresholdDelta &&
      a.delta < this.params.mousewheel.thresholdDelta) ||
      (this.params.mousewheel.thresholdTime &&
        G() - e.mousewheel.lastScrollTime <
          this.params.mousewheel.thresholdTime)
      ? !1
      : a.delta >= 6 && G() - e.mousewheel.lastScrollTime < 60
      ? !0
      : (a.direction < 0
          ? (!e.isEnd || e.params.loop) &&
            !e.animating &&
            (e.slideNext(), e.emit("scroll", a.raw))
          : (!e.isBeginning || e.params.loop) &&
            !e.animating &&
            (e.slidePrev(), e.emit("scroll", a.raw)),
        (e.mousewheel.lastScrollTime = new t.Date().getTime()),
        !1);
  },
  releaseScroll: function (a) {
    var e = this,
      t = e.params.mousewheel;
    if (a.direction < 0) {
      if (e.isEnd && !e.params.loop && t.releaseOnEdges) return !0;
    } else if (e.isBeginning && !e.params.loop && t.releaseOnEdges) return !0;
    return !1;
  },
  enable: function () {
    var a = this,
      e = N.event();
    if (a.params.cssMode)
      return a.wrapperEl.removeEventListener(e, a.mousewheel.handle), !0;
    if (!e || a.mousewheel.enabled) return !1;
    var t = a.$el;
    return (
      a.params.mousewheel.eventsTarget !== "container" &&
        (t = g(a.params.mousewheel.eventsTarget)),
      t.on("mouseenter", a.mousewheel.handleMouseEnter),
      t.on("mouseleave", a.mousewheel.handleMouseLeave),
      t.on(e, a.mousewheel.handle),
      (a.mousewheel.enabled = !0),
      !0
    );
  },
  disable: function () {
    var a = this,
      e = N.event();
    if (a.params.cssMode)
      return a.wrapperEl.addEventListener(e, a.mousewheel.handle), !0;
    if (!e || !a.mousewheel.enabled) return !1;
    var t = a.$el;
    return (
      a.params.mousewheel.eventsTarget !== "container" &&
        (t = g(a.params.mousewheel.eventsTarget)),
      t.off(e, a.mousewheel.handle),
      (a.mousewheel.enabled = !1),
      !0
    );
  },
};
const ba = {
  name: "mousewheel",
  params: {
    mousewheel: {
      enabled: !1,
      releaseOnEdges: !1,
      invert: !1,
      forceToAxis: !1,
      sensitivity: 1,
      eventsTarget: "container",
      thresholdDelta: null,
      thresholdTime: null,
    },
  },
  create: function () {
    var a = this;
    z(a, {
      mousewheel: {
        enabled: !1,
        lastScrollTime: G(),
        lastEventBeforeSnap: void 0,
        recentWheelEvents: [],
        enable: N.enable,
        disable: N.disable,
        handle: N.handle,
        handleMouseEnter: N.handleMouseEnter,
        handleMouseLeave: N.handleMouseLeave,
        animateSlider: N.animateSlider,
        releaseScroll: N.releaseScroll,
      },
    });
  },
  on: {
    init: function (a) {
      !a.params.mousewheel.enabled &&
        a.params.cssMode &&
        a.mousewheel.disable(),
        a.params.mousewheel.enabled && a.mousewheel.enable();
    },
    destroy: function (a) {
      a.params.cssMode && a.mousewheel.enable(),
        a.mousewheel.enabled && a.mousewheel.disable();
    },
  },
};
function B() {
  return (
    (B =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    B.apply(this, arguments)
  );
}
var ya = {
  toggleEl: function (a, e) {
    a[e ? "addClass" : "removeClass"](this.params.navigation.disabledClass),
      a[0] && a[0].tagName === "BUTTON" && (a[0].disabled = e);
  },
  update: function () {
    var a = this,
      e = a.params.navigation,
      t = a.navigation.toggleEl;
    if (!a.params.loop) {
      var r = a.navigation,
        i = r.$nextEl,
        s = r.$prevEl;
      s &&
        s.length > 0 &&
        (a.isBeginning ? t(s, !0) : t(s, !1),
        a.params.watchOverflow &&
          a.enabled &&
          s[a.isLocked ? "addClass" : "removeClass"](e.lockClass)),
        i &&
          i.length > 0 &&
          (a.isEnd ? t(i, !0) : t(i, !1),
          a.params.watchOverflow &&
            a.enabled &&
            i[a.isLocked ? "addClass" : "removeClass"](e.lockClass));
    }
  },
  onPrevClick: function (a) {
    var e = this;
    a.preventDefault(), !(e.isBeginning && !e.params.loop) && e.slidePrev();
  },
  onNextClick: function (a) {
    var e = this;
    a.preventDefault(), !(e.isEnd && !e.params.loop) && e.slideNext();
  },
  init: function () {
    var a = this,
      e = a.params.navigation;
    if (
      ((a.params.navigation = oa(
        a.$el,
        a.params.navigation,
        a.params.createElements,
        { nextEl: "swiper-button-next", prevEl: "swiper-button-prev" }
      )),
      !!(e.nextEl || e.prevEl))
    ) {
      var t, r;
      e.nextEl &&
        ((t = g(e.nextEl)),
        a.params.uniqueNavElements &&
          typeof e.nextEl == "string" &&
          t.length > 1 &&
          a.$el.find(e.nextEl).length === 1 &&
          (t = a.$el.find(e.nextEl))),
        e.prevEl &&
          ((r = g(e.prevEl)),
          a.params.uniqueNavElements &&
            typeof e.prevEl == "string" &&
            r.length > 1 &&
            a.$el.find(e.prevEl).length === 1 &&
            (r = a.$el.find(e.prevEl))),
        t && t.length > 0 && t.on("click", a.navigation.onNextClick),
        r && r.length > 0 && r.on("click", a.navigation.onPrevClick),
        O(a.navigation, {
          $nextEl: t,
          nextEl: t && t[0],
          $prevEl: r,
          prevEl: r && r[0],
        }),
        a.enabled ||
          (t && t.addClass(e.lockClass), r && r.addClass(e.lockClass));
    }
  },
  destroy: function () {
    var a = this,
      e = a.navigation,
      t = e.$nextEl,
      r = e.$prevEl;
    t &&
      t.length &&
      (t.off("click", a.navigation.onNextClick),
      t.removeClass(a.params.navigation.disabledClass)),
      r &&
        r.length &&
        (r.off("click", a.navigation.onPrevClick),
        r.removeClass(a.params.navigation.disabledClass));
  },
};
const Ea = {
  name: "navigation",
  params: {
    navigation: {
      nextEl: null,
      prevEl: null,
      hideOnClick: !1,
      disabledClass: "swiper-button-disabled",
      hiddenClass: "swiper-button-hidden",
      lockClass: "swiper-button-lock",
    },
  },
  create: function () {
    var a = this;
    z(a, { navigation: B({}, ya) });
  },
  on: {
    init: function (a) {
      a.navigation.init(), a.navigation.update();
    },
    toEdge: function (a) {
      a.navigation.update();
    },
    fromEdge: function (a) {
      a.navigation.update();
    },
    destroy: function (a) {
      a.navigation.destroy();
    },
    "enable disable": function (a) {
      var e = a.navigation,
        t = e.$nextEl,
        r = e.$prevEl;
      t &&
        t[a.enabled ? "removeClass" : "addClass"](
          a.params.navigation.lockClass
        ),
        r &&
          r[a.enabled ? "removeClass" : "addClass"](
            a.params.navigation.lockClass
          );
    },
    click: function (a, e) {
      var t = a.navigation,
        r = t.$nextEl,
        i = t.$prevEl,
        s = e.target;
      if (a.params.navigation.hideOnClick && !g(s).is(i) && !g(s).is(r)) {
        if (
          a.pagination &&
          a.params.pagination &&
          a.params.pagination.clickable &&
          (a.pagination.el === s || a.pagination.el.contains(s))
        )
          return;
        var l;
        r
          ? (l = r.hasClass(a.params.navigation.hiddenClass))
          : i && (l = i.hasClass(a.params.navigation.hiddenClass)),
          l === !0 ? a.emit("navigationShow") : a.emit("navigationHide"),
          r && r.toggleClass(a.params.navigation.hiddenClass),
          i && i.toggleClass(a.params.navigation.hiddenClass);
      }
    },
  },
};
function j() {
  return (
    (j =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    j.apply(this, arguments)
  );
}
var wa = {
  update: function () {
    var a = this,
      e = a.rtl,
      t = a.params.pagination;
    if (
      !(
        !t.el ||
        !a.pagination.el ||
        !a.pagination.$el ||
        a.pagination.$el.length === 0
      )
    ) {
      var r =
          a.virtual && a.params.virtual.enabled
            ? a.virtual.slides.length
            : a.slides.length,
        i = a.pagination.$el,
        s,
        l = a.params.loop
          ? Math.ceil((r - a.loopedSlides * 2) / a.params.slidesPerGroup)
          : a.snapGrid.length;
      if (
        (a.params.loop
          ? ((s = Math.ceil(
              (a.activeIndex - a.loopedSlides) / a.params.slidesPerGroup
            )),
            s > r - 1 - a.loopedSlides * 2 && (s -= r - a.loopedSlides * 2),
            s > l - 1 && (s -= l),
            s < 0 && a.params.paginationType !== "bullets" && (s = l + s))
          : typeof a.snapIndex < "u"
          ? (s = a.snapIndex)
          : (s = a.activeIndex || 0),
        t.type === "bullets" &&
          a.pagination.bullets &&
          a.pagination.bullets.length > 0)
      ) {
        var o = a.pagination.bullets,
          d,
          u,
          p;
        if (
          (t.dynamicBullets &&
            ((a.pagination.bulletSize = o
              .eq(0)
              [a.isHorizontal() ? "outerWidth" : "outerHeight"](!0)),
            i.css(
              a.isHorizontal() ? "width" : "height",
              a.pagination.bulletSize * (t.dynamicMainBullets + 4) + "px"
            ),
            t.dynamicMainBullets > 1 &&
              a.previousIndex !== void 0 &&
              ((a.pagination.dynamicBulletIndex += s - a.previousIndex),
              a.pagination.dynamicBulletIndex > t.dynamicMainBullets - 1
                ? (a.pagination.dynamicBulletIndex = t.dynamicMainBullets - 1)
                : a.pagination.dynamicBulletIndex < 0 &&
                  (a.pagination.dynamicBulletIndex = 0)),
            (d = s - a.pagination.dynamicBulletIndex),
            (u = d + (Math.min(o.length, t.dynamicMainBullets) - 1)),
            (p = (u + d) / 2)),
          o.removeClass(
            t.bulletActiveClass +
              " " +
              t.bulletActiveClass +
              "-next " +
              t.bulletActiveClass +
              "-next-next " +
              t.bulletActiveClass +
              "-prev " +
              t.bulletActiveClass +
              "-prev-prev " +
              t.bulletActiveClass +
              "-main"
          ),
          i.length > 1)
        )
          o.each(function (P) {
            var T = g(P),
              M = T.index();
            M === s && T.addClass(t.bulletActiveClass),
              t.dynamicBullets &&
                (M >= d && M <= u && T.addClass(t.bulletActiveClass + "-main"),
                M === d &&
                  T.prev()
                    .addClass(t.bulletActiveClass + "-prev")
                    .prev()
                    .addClass(t.bulletActiveClass + "-prev-prev"),
                M === u &&
                  T.next()
                    .addClass(t.bulletActiveClass + "-next")
                    .next()
                    .addClass(t.bulletActiveClass + "-next-next"));
          });
        else {
          var c = o.eq(s),
            v = c.index();
          if ((c.addClass(t.bulletActiveClass), t.dynamicBullets)) {
            for (var f = o.eq(d), y = o.eq(u), E = d; E <= u; E += 1)
              o.eq(E).addClass(t.bulletActiveClass + "-main");
            if (a.params.loop)
              if (v >= o.length - t.dynamicMainBullets) {
                for (var m = t.dynamicMainBullets; m >= 0; m -= 1)
                  o.eq(o.length - m).addClass(t.bulletActiveClass + "-main");
                o.eq(o.length - t.dynamicMainBullets - 1).addClass(
                  t.bulletActiveClass + "-prev"
                );
              } else
                f
                  .prev()
                  .addClass(t.bulletActiveClass + "-prev")
                  .prev()
                  .addClass(t.bulletActiveClass + "-prev-prev"),
                  y
                    .next()
                    .addClass(t.bulletActiveClass + "-next")
                    .next()
                    .addClass(t.bulletActiveClass + "-next-next");
            else
              f
                .prev()
                .addClass(t.bulletActiveClass + "-prev")
                .prev()
                .addClass(t.bulletActiveClass + "-prev-prev"),
                y
                  .next()
                  .addClass(t.bulletActiveClass + "-next")
                  .next()
                  .addClass(t.bulletActiveClass + "-next-next");
          }
        }
        if (t.dynamicBullets) {
          var w = Math.min(o.length, t.dynamicMainBullets + 4),
            C =
              (a.pagination.bulletSize * w - a.pagination.bulletSize) / 2 -
              p * a.pagination.bulletSize,
            b = e ? "right" : "left";
          o.css(a.isHorizontal() ? b : "top", C + "px");
        }
      }
      if (
        (t.type === "fraction" &&
          (i.find(I(t.currentClass)).text(t.formatFractionCurrent(s + 1)),
          i.find(I(t.totalClass)).text(t.formatFractionTotal(l))),
        t.type === "progressbar")
      ) {
        var h;
        t.progressbarOpposite
          ? (h = a.isHorizontal() ? "vertical" : "horizontal")
          : (h = a.isHorizontal() ? "horizontal" : "vertical");
        var S = (s + 1) / l,
          x = 1,
          $ = 1;
        h === "horizontal" ? (x = S) : ($ = S),
          i
            .find(I(t.progressbarFillClass))
            .transform("translate3d(0,0,0) scaleX(" + x + ") scaleY(" + $ + ")")
            .transition(a.params.speed);
      }
      t.type === "custom" && t.renderCustom
        ? (i.html(t.renderCustom(a, s + 1, l)),
          a.emit("paginationRender", i[0]))
        : a.emit("paginationUpdate", i[0]),
        a.params.watchOverflow &&
          a.enabled &&
          i[a.isLocked ? "addClass" : "removeClass"](t.lockClass);
    }
  },
  render: function () {
    var a = this,
      e = a.params.pagination;
    if (
      !(
        !e.el ||
        !a.pagination.el ||
        !a.pagination.$el ||
        a.pagination.$el.length === 0
      )
    ) {
      var t =
          a.virtual && a.params.virtual.enabled
            ? a.virtual.slides.length
            : a.slides.length,
        r = a.pagination.$el,
        i = "";
      if (e.type === "bullets") {
        var s = a.params.loop
          ? Math.ceil((t - a.loopedSlides * 2) / a.params.slidesPerGroup)
          : a.snapGrid.length;
        a.params.freeMode && !a.params.loop && s > t && (s = t);
        for (var l = 0; l < s; l += 1)
          e.renderBullet
            ? (i += e.renderBullet.call(a, l, e.bulletClass))
            : (i +=
                "<" +
                e.bulletElement +
                ' class="' +
                e.bulletClass +
                '"></' +
                e.bulletElement +
                ">");
        r.html(i), (a.pagination.bullets = r.find(I(e.bulletClass)));
      }
      e.type === "fraction" &&
        (e.renderFraction
          ? (i = e.renderFraction.call(a, e.currentClass, e.totalClass))
          : (i =
              '<span class="' +
              e.currentClass +
              '"></span> / ' +
              ('<span class="' + e.totalClass + '"></span>')),
        r.html(i)),
        e.type === "progressbar" &&
          (e.renderProgressbar
            ? (i = e.renderProgressbar.call(a, e.progressbarFillClass))
            : (i = '<span class="' + e.progressbarFillClass + '"></span>'),
          r.html(i)),
        e.type !== "custom" && a.emit("paginationRender", a.pagination.$el[0]);
    }
  },
  init: function () {
    var a = this;
    a.params.pagination = oa(
      a.$el,
      a.params.pagination,
      a.params.createElements,
      { el: "swiper-pagination" }
    );
    var e = a.params.pagination;
    if (e.el) {
      var t = g(e.el);
      t.length !== 0 &&
        (a.params.uniqueNavElements &&
          typeof e.el == "string" &&
          t.length > 1 &&
          (t = a.$el.find(e.el)),
        e.type === "bullets" && e.clickable && t.addClass(e.clickableClass),
        t.addClass(e.modifierClass + e.type),
        e.type === "bullets" &&
          e.dynamicBullets &&
          (t.addClass("" + e.modifierClass + e.type + "-dynamic"),
          (a.pagination.dynamicBulletIndex = 0),
          e.dynamicMainBullets < 1 && (e.dynamicMainBullets = 1)),
        e.type === "progressbar" &&
          e.progressbarOpposite &&
          t.addClass(e.progressbarOppositeClass),
        e.clickable &&
          t.on("click", I(e.bulletClass), function (i) {
            i.preventDefault();
            var s = g(this).index() * a.params.slidesPerGroup;
            a.params.loop && (s += a.loopedSlides), a.slideTo(s);
          }),
        O(a.pagination, { $el: t, el: t[0] }),
        a.enabled || t.addClass(e.lockClass));
    }
  },
  destroy: function () {
    var a = this,
      e = a.params.pagination;
    if (
      !(
        !e.el ||
        !a.pagination.el ||
        !a.pagination.$el ||
        a.pagination.$el.length === 0
      )
    ) {
      var t = a.pagination.$el;
      t.removeClass(e.hiddenClass),
        t.removeClass(e.modifierClass + e.type),
        a.pagination.bullets &&
          a.pagination.bullets.removeClass(e.bulletActiveClass),
        e.clickable && t.off("click", I(e.bulletClass));
    }
  },
};
const Ca = {
  name: "pagination",
  params: {
    pagination: {
      el: null,
      bulletElement: "span",
      clickable: !1,
      hideOnClick: !1,
      renderBullet: null,
      renderProgressbar: null,
      renderFraction: null,
      renderCustom: null,
      progressbarOpposite: !1,
      type: "bullets",
      dynamicBullets: !1,
      dynamicMainBullets: 1,
      formatFractionCurrent: function (a) {
        return a;
      },
      formatFractionTotal: function (a) {
        return a;
      },
      bulletClass: "swiper-pagination-bullet",
      bulletActiveClass: "swiper-pagination-bullet-active",
      modifierClass: "swiper-pagination-",
      currentClass: "swiper-pagination-current",
      totalClass: "swiper-pagination-total",
      hiddenClass: "swiper-pagination-hidden",
      progressbarFillClass: "swiper-pagination-progressbar-fill",
      progressbarOppositeClass: "swiper-pagination-progressbar-opposite",
      clickableClass: "swiper-pagination-clickable",
      lockClass: "swiper-pagination-lock",
    },
  },
  create: function () {
    var a = this;
    z(a, { pagination: j({ dynamicBulletIndex: 0 }, wa) });
  },
  on: {
    init: function (a) {
      a.pagination.init(), a.pagination.render(), a.pagination.update();
    },
    activeIndexChange: function (a) {
      (a.params.loop || typeof a.snapIndex > "u") && a.pagination.update();
    },
    snapIndexChange: function (a) {
      a.params.loop || a.pagination.update();
    },
    slidesLengthChange: function (a) {
      a.params.loop && (a.pagination.render(), a.pagination.update());
    },
    snapGridLengthChange: function (a) {
      a.params.loop || (a.pagination.render(), a.pagination.update());
    },
    destroy: function (a) {
      a.pagination.destroy();
    },
    "enable disable": function (a) {
      var e = a.pagination.$el;
      e &&
        e[a.enabled ? "removeClass" : "addClass"](
          a.params.pagination.lockClass
        );
    },
    click: function (a, e) {
      var t = e.target;
      if (
        a.params.pagination.el &&
        a.params.pagination.hideOnClick &&
        a.pagination.$el.length > 0 &&
        !g(t).hasClass(a.params.pagination.bulletClass)
      ) {
        if (
          a.navigation &&
          ((a.navigation.nextEl && t === a.navigation.nextEl) ||
            (a.navigation.prevEl && t === a.navigation.prevEl))
        )
          return;
        var r = a.pagination.$el.hasClass(a.params.pagination.hiddenClass);
        r === !0 ? a.emit("paginationShow") : a.emit("paginationHide"),
          a.pagination.$el.toggleClass(a.params.pagination.hiddenClass);
      }
    },
  },
};
function q() {
  return (
    (q =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    q.apply(this, arguments)
  );
}
var xa = {
  setTranslate: function () {
    var a = this;
    if (!(!a.params.scrollbar.el || !a.scrollbar.el)) {
      var e = a.scrollbar,
        t = a.rtlTranslate,
        r = a.progress,
        i = e.dragSize,
        s = e.trackSize,
        l = e.$dragEl,
        o = e.$el,
        d = a.params.scrollbar,
        u = i,
        p = (s - i) * r;
      t
        ? ((p = -p), p > 0 ? ((u = i - p), (p = 0)) : -p + i > s && (u = s + p))
        : p < 0
        ? ((u = i + p), (p = 0))
        : p + i > s && (u = s - p),
        a.isHorizontal()
          ? (l.transform("translate3d(" + p + "px, 0, 0)"),
            (l[0].style.width = u + "px"))
          : (l.transform("translate3d(0px, " + p + "px, 0)"),
            (l[0].style.height = u + "px")),
        d.hide &&
          (clearTimeout(a.scrollbar.timeout),
          (o[0].style.opacity = 1),
          (a.scrollbar.timeout = setTimeout(function () {
            (o[0].style.opacity = 0), o.transition(400);
          }, 1e3)));
    }
  },
  setTransition: function (a) {
    var e = this;
    !e.params.scrollbar.el ||
      !e.scrollbar.el ||
      e.scrollbar.$dragEl.transition(a);
  },
  updateSize: function () {
    var a = this;
    if (!(!a.params.scrollbar.el || !a.scrollbar.el)) {
      var e = a.scrollbar,
        t = e.$dragEl,
        r = e.$el;
      (t[0].style.width = ""), (t[0].style.height = "");
      var i = a.isHorizontal() ? r[0].offsetWidth : r[0].offsetHeight,
        s = a.size / a.virtualSize,
        l = s * (i / a.size),
        o;
      a.params.scrollbar.dragSize === "auto"
        ? (o = i * s)
        : (o = parseInt(a.params.scrollbar.dragSize, 10)),
        a.isHorizontal()
          ? (t[0].style.width = o + "px")
          : (t[0].style.height = o + "px"),
        s >= 1 ? (r[0].style.display = "none") : (r[0].style.display = ""),
        a.params.scrollbar.hide && (r[0].style.opacity = 0),
        O(e, { trackSize: i, divider: s, moveDivider: l, dragSize: o }),
        a.params.watchOverflow &&
          a.enabled &&
          e.$el[a.isLocked ? "addClass" : "removeClass"](
            a.params.scrollbar.lockClass
          );
    }
  },
  getPointerPosition: function (a) {
    var e = this;
    return e.isHorizontal()
      ? a.type === "touchstart" || a.type === "touchmove"
        ? a.targetTouches[0].clientX
        : a.clientX
      : a.type === "touchstart" || a.type === "touchmove"
      ? a.targetTouches[0].clientY
      : a.clientY;
  },
  setDragPosition: function (a) {
    var e = this,
      t = e.scrollbar,
      r = e.rtlTranslate,
      i = t.$el,
      s = t.dragSize,
      l = t.trackSize,
      o = t.dragStartPos,
      d;
    (d =
      (t.getPointerPosition(a) -
        i.offset()[e.isHorizontal() ? "left" : "top"] -
        (o !== null ? o : s / 2)) /
      (l - s)),
      (d = Math.max(Math.min(d, 1), 0)),
      r && (d = 1 - d);
    var u = e.minTranslate() + (e.maxTranslate() - e.minTranslate()) * d;
    e.updateProgress(u),
      e.setTranslate(u),
      e.updateActiveIndex(),
      e.updateSlidesClasses();
  },
  onDragStart: function (a) {
    var e = this,
      t = e.params.scrollbar,
      r = e.scrollbar,
      i = e.$wrapperEl,
      s = r.$el,
      l = r.$dragEl;
    (e.scrollbar.isTouched = !0),
      (e.scrollbar.dragStartPos =
        a.target === l[0] || a.target === l
          ? r.getPointerPosition(a) -
            a.target.getBoundingClientRect()[e.isHorizontal() ? "left" : "top"]
          : null),
      a.preventDefault(),
      a.stopPropagation(),
      i.transition(100),
      l.transition(100),
      r.setDragPosition(a),
      clearTimeout(e.scrollbar.dragTimeout),
      s.transition(0),
      t.hide && s.css("opacity", 1),
      e.params.cssMode && e.$wrapperEl.css("scroll-snap-type", "none"),
      e.emit("scrollbarDragStart", a);
  },
  onDragMove: function (a) {
    var e = this,
      t = e.scrollbar,
      r = e.$wrapperEl,
      i = t.$el,
      s = t.$dragEl;
    e.scrollbar.isTouched &&
      (a.preventDefault ? a.preventDefault() : (a.returnValue = !1),
      t.setDragPosition(a),
      r.transition(0),
      i.transition(0),
      s.transition(0),
      e.emit("scrollbarDragMove", a));
  },
  onDragEnd: function (a) {
    var e = this,
      t = e.params.scrollbar,
      r = e.scrollbar,
      i = e.$wrapperEl,
      s = r.$el;
    e.scrollbar.isTouched &&
      ((e.scrollbar.isTouched = !1),
      e.params.cssMode &&
        (e.$wrapperEl.css("scroll-snap-type", ""), i.transition("")),
      t.hide &&
        (clearTimeout(e.scrollbar.dragTimeout),
        (e.scrollbar.dragTimeout = R(function () {
          s.css("opacity", 0), s.transition(400);
        }, 1e3))),
      e.emit("scrollbarDragEnd", a),
      t.snapOnRelease && e.slideToClosest());
  },
  enableDraggable: function () {
    var a = this;
    if (a.params.scrollbar.el) {
      var e = k(),
        t = a.scrollbar,
        r = a.touchEventsTouch,
        i = a.touchEventsDesktop,
        s = a.params,
        l = a.support,
        o = t.$el,
        d = o[0],
        u =
          l.passiveListener && s.passiveListeners
            ? { passive: !1, capture: !1 }
            : !1,
        p =
          l.passiveListener && s.passiveListeners
            ? { passive: !0, capture: !1 }
            : !1;
      d &&
        (l.touch
          ? (d.addEventListener(r.start, a.scrollbar.onDragStart, u),
            d.addEventListener(r.move, a.scrollbar.onDragMove, u),
            d.addEventListener(r.end, a.scrollbar.onDragEnd, p))
          : (d.addEventListener(i.start, a.scrollbar.onDragStart, u),
            e.addEventListener(i.move, a.scrollbar.onDragMove, u),
            e.addEventListener(i.end, a.scrollbar.onDragEnd, p)));
    }
  },
  disableDraggable: function () {
    var a = this;
    if (a.params.scrollbar.el) {
      var e = k(),
        t = a.scrollbar,
        r = a.touchEventsTouch,
        i = a.touchEventsDesktop,
        s = a.params,
        l = a.support,
        o = t.$el,
        d = o[0],
        u =
          l.passiveListener && s.passiveListeners
            ? { passive: !1, capture: !1 }
            : !1,
        p =
          l.passiveListener && s.passiveListeners
            ? { passive: !0, capture: !1 }
            : !1;
      d &&
        (l.touch
          ? (d.removeEventListener(r.start, a.scrollbar.onDragStart, u),
            d.removeEventListener(r.move, a.scrollbar.onDragMove, u),
            d.removeEventListener(r.end, a.scrollbar.onDragEnd, p))
          : (d.removeEventListener(i.start, a.scrollbar.onDragStart, u),
            e.removeEventListener(i.move, a.scrollbar.onDragMove, u),
            e.removeEventListener(i.end, a.scrollbar.onDragEnd, p)));
    }
  },
  init: function () {
    var a = this,
      e = a.scrollbar,
      t = a.$el;
    a.params.scrollbar = oa(t, a.params.scrollbar, a.params.createElements, {
      el: "swiper-scrollbar",
    });
    var r = a.params.scrollbar;
    if (r.el) {
      var i = g(r.el);
      a.params.uniqueNavElements &&
        typeof r.el == "string" &&
        i.length > 1 &&
        t.find(r.el).length === 1 &&
        (i = t.find(r.el));
      var s = i.find("." + a.params.scrollbar.dragClass);
      s.length === 0 &&
        ((s = g('<div class="' + a.params.scrollbar.dragClass + '"></div>')),
        i.append(s)),
        O(e, { $el: i, el: i[0], $dragEl: s, dragEl: s[0] }),
        r.draggable && e.enableDraggable(),
        i &&
          i[a.enabled ? "removeClass" : "addClass"](
            a.params.scrollbar.lockClass
          );
    }
  },
  destroy: function () {
    var a = this;
    a.scrollbar.disableDraggable();
  },
};
const Sa = {
  name: "scrollbar",
  params: {
    scrollbar: {
      el: null,
      dragSize: "auto",
      hide: !1,
      draggable: !1,
      snapOnRelease: !0,
      lockClass: "swiper-scrollbar-lock",
      dragClass: "swiper-scrollbar-drag",
    },
  },
  create: function () {
    var a = this;
    z(a, {
      scrollbar: q({ isTouched: !1, timeout: null, dragTimeout: null }, xa),
    });
  },
  on: {
    init: function (a) {
      a.scrollbar.init(), a.scrollbar.updateSize(), a.scrollbar.setTranslate();
    },
    update: function (a) {
      a.scrollbar.updateSize();
    },
    resize: function (a) {
      a.scrollbar.updateSize();
    },
    observerUpdate: function (a) {
      a.scrollbar.updateSize();
    },
    setTranslate: function (a) {
      a.scrollbar.setTranslate();
    },
    setTransition: function (a, e) {
      a.scrollbar.setTransition(e);
    },
    "enable disable": function (a) {
      var e = a.scrollbar.$el;
      e &&
        e[a.enabled ? "removeClass" : "addClass"](a.params.scrollbar.lockClass);
    },
    destroy: function (a) {
      a.scrollbar.destroy();
    },
  },
};
function W() {
  return (
    (W =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    W.apply(this, arguments)
  );
}
var $a = {
  setTransform: function (a, e) {
    var t = this,
      r = t.rtl,
      i = g(a),
      s = r ? -1 : 1,
      l = i.attr("data-swiper-parallax") || "0",
      o = i.attr("data-swiper-parallax-x"),
      d = i.attr("data-swiper-parallax-y"),
      u = i.attr("data-swiper-parallax-scale"),
      p = i.attr("data-swiper-parallax-opacity");
    if (
      (o || d
        ? ((o = o || "0"), (d = d || "0"))
        : t.isHorizontal()
        ? ((o = l), (d = "0"))
        : ((d = l), (o = "0")),
      o.indexOf("%") >= 0
        ? (o = parseInt(o, 10) * e * s + "%")
        : (o = o * e * s + "px"),
      d.indexOf("%") >= 0
        ? (d = parseInt(d, 10) * e + "%")
        : (d = d * e + "px"),
      typeof p < "u" && p !== null)
    ) {
      var c = p - (p - 1) * (1 - Math.abs(e));
      i[0].style.opacity = c;
    }
    if (typeof u > "u" || u === null)
      i.transform("translate3d(" + o + ", " + d + ", 0px)");
    else {
      var v = u - (u - 1) * (1 - Math.abs(e));
      i.transform("translate3d(" + o + ", " + d + ", 0px) scale(" + v + ")");
    }
  },
  setTranslate: function () {
    var a = this,
      e = a.$el,
      t = a.slides,
      r = a.progress,
      i = a.snapGrid;
    e
      .children(
        "[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]"
      )
      .each(function (s) {
        a.parallax.setTransform(s, r);
      }),
      t.each(function (s, l) {
        var o = s.progress;
        a.params.slidesPerGroup > 1 &&
          a.params.slidesPerView !== "auto" &&
          (o += Math.ceil(l / 2) - r * (i.length - 1)),
          (o = Math.min(Math.max(o, -1), 1)),
          g(s)
            .find(
              "[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]"
            )
            .each(function (d) {
              a.parallax.setTransform(d, o);
            });
      });
  },
  setTransition: function (a) {
    a === void 0 && (a = this.params.speed);
    var e = this,
      t = e.$el;
    t.find(
      "[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]"
    ).each(function (r) {
      var i = g(r),
        s = parseInt(i.attr("data-swiper-parallax-duration"), 10) || a;
      a === 0 && (s = 0), i.transition(s);
    });
  },
};
const Ta = {
  name: "parallax",
  params: { parallax: { enabled: !1 } },
  create: function () {
    var a = this;
    z(a, { parallax: W({}, $a) });
  },
  on: {
    beforeInit: function (a) {
      a.params.parallax.enabled &&
        ((a.params.watchSlidesProgress = !0),
        (a.originalParams.watchSlidesProgress = !0));
    },
    init: function (a) {
      a.params.parallax.enabled && a.parallax.setTranslate();
    },
    setTranslate: function (a) {
      a.params.parallax.enabled && a.parallax.setTranslate();
    },
    setTransition: function (a, e) {
      a.params.parallax.enabled && a.parallax.setTransition(e);
    },
  },
};
function U() {
  return (
    (U =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    U.apply(this, arguments)
  );
}
var K = {
  getDistanceBetweenTouches: function (a) {
    if (a.targetTouches.length < 2) return 1;
    var e = a.targetTouches[0].pageX,
      t = a.targetTouches[0].pageY,
      r = a.targetTouches[1].pageX,
      i = a.targetTouches[1].pageY,
      s = Math.sqrt(Math.pow(r - e, 2) + Math.pow(i - t, 2));
    return s;
  },
  onGestureStart: function (a) {
    var e = this,
      t = e.support,
      r = e.params.zoom,
      i = e.zoom,
      s = i.gesture;
    if (((i.fakeGestureTouched = !1), (i.fakeGestureMoved = !1), !t.gestures)) {
      if (
        a.type !== "touchstart" ||
        (a.type === "touchstart" && a.targetTouches.length < 2)
      )
        return;
      (i.fakeGestureTouched = !0),
        (s.scaleStart = K.getDistanceBetweenTouches(a));
    }
    if (
      (!s.$slideEl || !s.$slideEl.length) &&
      ((s.$slideEl = g(a.target).closest("." + e.params.slideClass)),
      s.$slideEl.length === 0 && (s.$slideEl = e.slides.eq(e.activeIndex)),
      (s.$imageEl = s.$slideEl.find(
        "img, svg, canvas, picture, .swiper-zoom-target"
      )),
      (s.$imageWrapEl = s.$imageEl.parent("." + r.containerClass)),
      (s.maxRatio = s.$imageWrapEl.attr("data-swiper-zoom") || r.maxRatio),
      s.$imageWrapEl.length === 0)
    ) {
      s.$imageEl = void 0;
      return;
    }
    s.$imageEl && s.$imageEl.transition(0), (e.zoom.isScaling = !0);
  },
  onGestureChange: function (a) {
    var e = this,
      t = e.support,
      r = e.params.zoom,
      i = e.zoom,
      s = i.gesture;
    if (!t.gestures) {
      if (
        a.type !== "touchmove" ||
        (a.type === "touchmove" && a.targetTouches.length < 2)
      )
        return;
      (i.fakeGestureMoved = !0), (s.scaleMove = K.getDistanceBetweenTouches(a));
    }
    if (!s.$imageEl || s.$imageEl.length === 0) {
      a.type === "gesturechange" && i.onGestureStart(a);
      return;
    }
    t.gestures
      ? (i.scale = a.scale * i.currentScale)
      : (i.scale = (s.scaleMove / s.scaleStart) * i.currentScale),
      i.scale > s.maxRatio &&
        (i.scale = s.maxRatio - 1 + Math.pow(i.scale - s.maxRatio + 1, 0.5)),
      i.scale < r.minRatio &&
        (i.scale = r.minRatio + 1 - Math.pow(r.minRatio - i.scale + 1, 0.5)),
      s.$imageEl.transform("translate3d(0,0,0) scale(" + i.scale + ")");
  },
  onGestureEnd: function (a) {
    var e = this,
      t = e.device,
      r = e.support,
      i = e.params.zoom,
      s = e.zoom,
      l = s.gesture;
    if (!r.gestures) {
      if (
        !s.fakeGestureTouched ||
        !s.fakeGestureMoved ||
        a.type !== "touchend" ||
        (a.type === "touchend" && a.changedTouches.length < 2 && !t.android)
      )
        return;
      (s.fakeGestureTouched = !1), (s.fakeGestureMoved = !1);
    }
    !l.$imageEl ||
      l.$imageEl.length === 0 ||
      ((s.scale = Math.max(Math.min(s.scale, l.maxRatio), i.minRatio)),
      l.$imageEl
        .transition(e.params.speed)
        .transform("translate3d(0,0,0) scale(" + s.scale + ")"),
      (s.currentScale = s.scale),
      (s.isScaling = !1),
      s.scale === 1 && (l.$slideEl = void 0));
  },
  onTouchStart: function (a) {
    var e = this,
      t = e.device,
      r = e.zoom,
      i = r.gesture,
      s = r.image;
    !i.$imageEl ||
      i.$imageEl.length === 0 ||
      s.isTouched ||
      (t.android && a.cancelable && a.preventDefault(),
      (s.isTouched = !0),
      (s.touchesStart.x =
        a.type === "touchstart" ? a.targetTouches[0].pageX : a.pageX),
      (s.touchesStart.y =
        a.type === "touchstart" ? a.targetTouches[0].pageY : a.pageY));
  },
  onTouchMove: function (a) {
    var e = this,
      t = e.zoom,
      r = t.gesture,
      i = t.image,
      s = t.velocity;
    if (
      !(!r.$imageEl || r.$imageEl.length === 0) &&
      ((e.allowClick = !1), !(!i.isTouched || !r.$slideEl))
    ) {
      i.isMoved ||
        ((i.width = r.$imageEl[0].offsetWidth),
        (i.height = r.$imageEl[0].offsetHeight),
        (i.startX = da(r.$imageWrapEl[0], "x") || 0),
        (i.startY = da(r.$imageWrapEl[0], "y") || 0),
        (r.slideWidth = r.$slideEl[0].offsetWidth),
        (r.slideHeight = r.$slideEl[0].offsetHeight),
        r.$imageWrapEl.transition(0));
      var l = i.width * t.scale,
        o = i.height * t.scale;
      if (!(l < r.slideWidth && o < r.slideHeight)) {
        if (
          ((i.minX = Math.min(r.slideWidth / 2 - l / 2, 0)),
          (i.maxX = -i.minX),
          (i.minY = Math.min(r.slideHeight / 2 - o / 2, 0)),
          (i.maxY = -i.minY),
          (i.touchesCurrent.x =
            a.type === "touchmove" ? a.targetTouches[0].pageX : a.pageX),
          (i.touchesCurrent.y =
            a.type === "touchmove" ? a.targetTouches[0].pageY : a.pageY),
          !i.isMoved && !t.isScaling)
        ) {
          if (
            e.isHorizontal() &&
            ((Math.floor(i.minX) === Math.floor(i.startX) &&
              i.touchesCurrent.x < i.touchesStart.x) ||
              (Math.floor(i.maxX) === Math.floor(i.startX) &&
                i.touchesCurrent.x > i.touchesStart.x))
          ) {
            i.isTouched = !1;
            return;
          }
          if (
            !e.isHorizontal() &&
            ((Math.floor(i.minY) === Math.floor(i.startY) &&
              i.touchesCurrent.y < i.touchesStart.y) ||
              (Math.floor(i.maxY) === Math.floor(i.startY) &&
                i.touchesCurrent.y > i.touchesStart.y))
          ) {
            i.isTouched = !1;
            return;
          }
        }
        a.cancelable && a.preventDefault(),
          a.stopPropagation(),
          (i.isMoved = !0),
          (i.currentX = i.touchesCurrent.x - i.touchesStart.x + i.startX),
          (i.currentY = i.touchesCurrent.y - i.touchesStart.y + i.startY),
          i.currentX < i.minX &&
            (i.currentX = i.minX + 1 - Math.pow(i.minX - i.currentX + 1, 0.8)),
          i.currentX > i.maxX &&
            (i.currentX = i.maxX - 1 + Math.pow(i.currentX - i.maxX + 1, 0.8)),
          i.currentY < i.minY &&
            (i.currentY = i.minY + 1 - Math.pow(i.minY - i.currentY + 1, 0.8)),
          i.currentY > i.maxY &&
            (i.currentY = i.maxY - 1 + Math.pow(i.currentY - i.maxY + 1, 0.8)),
          s.prevPositionX || (s.prevPositionX = i.touchesCurrent.x),
          s.prevPositionY || (s.prevPositionY = i.touchesCurrent.y),
          s.prevTime || (s.prevTime = Date.now()),
          (s.x =
            (i.touchesCurrent.x - s.prevPositionX) /
            (Date.now() - s.prevTime) /
            2),
          (s.y =
            (i.touchesCurrent.y - s.prevPositionY) /
            (Date.now() - s.prevTime) /
            2),
          Math.abs(i.touchesCurrent.x - s.prevPositionX) < 2 && (s.x = 0),
          Math.abs(i.touchesCurrent.y - s.prevPositionY) < 2 && (s.y = 0),
          (s.prevPositionX = i.touchesCurrent.x),
          (s.prevPositionY = i.touchesCurrent.y),
          (s.prevTime = Date.now()),
          r.$imageWrapEl.transform(
            "translate3d(" + i.currentX + "px, " + i.currentY + "px,0)"
          );
      }
    }
  },
  onTouchEnd: function () {
    var a = this,
      e = a.zoom,
      t = e.gesture,
      r = e.image,
      i = e.velocity;
    if (!(!t.$imageEl || t.$imageEl.length === 0)) {
      if (!r.isTouched || !r.isMoved) {
        (r.isTouched = !1), (r.isMoved = !1);
        return;
      }
      (r.isTouched = !1), (r.isMoved = !1);
      var s = 300,
        l = 300,
        o = i.x * s,
        d = r.currentX + o,
        u = i.y * l,
        p = r.currentY + u;
      i.x !== 0 && (s = Math.abs((d - r.currentX) / i.x)),
        i.y !== 0 && (l = Math.abs((p - r.currentY) / i.y));
      var c = Math.max(s, l);
      (r.currentX = d), (r.currentY = p);
      var v = r.width * e.scale,
        f = r.height * e.scale;
      (r.minX = Math.min(t.slideWidth / 2 - v / 2, 0)),
        (r.maxX = -r.minX),
        (r.minY = Math.min(t.slideHeight / 2 - f / 2, 0)),
        (r.maxY = -r.minY),
        (r.currentX = Math.max(Math.min(r.currentX, r.maxX), r.minX)),
        (r.currentY = Math.max(Math.min(r.currentY, r.maxY), r.minY)),
        t.$imageWrapEl
          .transition(c)
          .transform(
            "translate3d(" + r.currentX + "px, " + r.currentY + "px,0)"
          );
    }
  },
  onTransitionEnd: function () {
    var a = this,
      e = a.zoom,
      t = e.gesture;
    t.$slideEl &&
      a.previousIndex !== a.activeIndex &&
      (t.$imageEl && t.$imageEl.transform("translate3d(0,0,0) scale(1)"),
      t.$imageWrapEl && t.$imageWrapEl.transform("translate3d(0,0,0)"),
      (e.scale = 1),
      (e.currentScale = 1),
      (t.$slideEl = void 0),
      (t.$imageEl = void 0),
      (t.$imageWrapEl = void 0));
  },
  toggle: function (a) {
    var e = this,
      t = e.zoom;
    t.scale && t.scale !== 1 ? t.out() : t.in(a);
  },
  in: function (a) {
    var e = this,
      t = L(),
      r = e.zoom,
      i = e.params.zoom,
      s = r.gesture,
      l = r.image;
    if (
      (s.$slideEl ||
        (a &&
          a.target &&
          (s.$slideEl = g(a.target).closest("." + e.params.slideClass)),
        s.$slideEl ||
          (e.params.virtual && e.params.virtual.enabled && e.virtual
            ? (s.$slideEl = e.$wrapperEl.children(
                "." + e.params.slideActiveClass
              ))
            : (s.$slideEl = e.slides.eq(e.activeIndex))),
        (s.$imageEl = s.$slideEl.find(
          "img, svg, canvas, picture, .swiper-zoom-target"
        )),
        (s.$imageWrapEl = s.$imageEl.parent("." + i.containerClass))),
      !(
        !s.$imageEl ||
        s.$imageEl.length === 0 ||
        !s.$imageWrapEl ||
        s.$imageWrapEl.length === 0
      ))
    ) {
      s.$slideEl.addClass("" + i.zoomedSlideClass);
      var o, d, u, p, c, v, f, y, E, m, w, C, b, h, S, x, $, P;
      typeof l.touchesStart.x > "u" && a
        ? ((o = a.type === "touchend" ? a.changedTouches[0].pageX : a.pageX),
          (d = a.type === "touchend" ? a.changedTouches[0].pageY : a.pageY))
        : ((o = l.touchesStart.x), (d = l.touchesStart.y)),
        (r.scale = s.$imageWrapEl.attr("data-swiper-zoom") || i.maxRatio),
        (r.currentScale =
          s.$imageWrapEl.attr("data-swiper-zoom") || i.maxRatio),
        a
          ? (($ = s.$slideEl[0].offsetWidth),
            (P = s.$slideEl[0].offsetHeight),
            (u = s.$slideEl.offset().left + t.scrollX),
            (p = s.$slideEl.offset().top + t.scrollY),
            (c = u + $ / 2 - o),
            (v = p + P / 2 - d),
            (E = s.$imageEl[0].offsetWidth),
            (m = s.$imageEl[0].offsetHeight),
            (w = E * r.scale),
            (C = m * r.scale),
            (b = Math.min($ / 2 - w / 2, 0)),
            (h = Math.min(P / 2 - C / 2, 0)),
            (S = -b),
            (x = -h),
            (f = c * r.scale),
            (y = v * r.scale),
            f < b && (f = b),
            f > S && (f = S),
            y < h && (y = h),
            y > x && (y = x))
          : ((f = 0), (y = 0)),
        s.$imageWrapEl
          .transition(300)
          .transform("translate3d(" + f + "px, " + y + "px,0)"),
        s.$imageEl
          .transition(300)
          .transform("translate3d(0,0,0) scale(" + r.scale + ")");
    }
  },
  out: function () {
    var a = this,
      e = a.zoom,
      t = a.params.zoom,
      r = e.gesture;
    r.$slideEl ||
      (a.params.virtual && a.params.virtual.enabled && a.virtual
        ? (r.$slideEl = a.$wrapperEl.children("." + a.params.slideActiveClass))
        : (r.$slideEl = a.slides.eq(a.activeIndex)),
      (r.$imageEl = r.$slideEl.find(
        "img, svg, canvas, picture, .swiper-zoom-target"
      )),
      (r.$imageWrapEl = r.$imageEl.parent("." + t.containerClass))),
      !(
        !r.$imageEl ||
        r.$imageEl.length === 0 ||
        !r.$imageWrapEl ||
        r.$imageWrapEl.length === 0
      ) &&
        ((e.scale = 1),
        (e.currentScale = 1),
        r.$imageWrapEl.transition(300).transform("translate3d(0,0,0)"),
        r.$imageEl.transition(300).transform("translate3d(0,0,0) scale(1)"),
        r.$slideEl.removeClass("" + t.zoomedSlideClass),
        (r.$slideEl = void 0));
  },
  toggleGestures: function (a) {
    var e = this,
      t = e.zoom,
      r = t.slideSelector,
      i = t.passiveListener;
    e.$wrapperEl[a]("gesturestart", r, t.onGestureStart, i),
      e.$wrapperEl[a]("gesturechange", r, t.onGestureChange, i),
      e.$wrapperEl[a]("gestureend", r, t.onGestureEnd, i);
  },
  enableGestures: function () {
    this.zoom.gesturesEnabled ||
      ((this.zoom.gesturesEnabled = !0), this.zoom.toggleGestures("on"));
  },
  disableGestures: function () {
    this.zoom.gesturesEnabled &&
      ((this.zoom.gesturesEnabled = !1), this.zoom.toggleGestures("off"));
  },
  enable: function () {
    var a = this,
      e = a.support,
      t = a.zoom;
    if (!t.enabled) {
      t.enabled = !0;
      var r =
          a.touchEvents.start === "touchstart" &&
          e.passiveListener &&
          a.params.passiveListeners
            ? { passive: !0, capture: !1 }
            : !1,
        i = e.passiveListener ? { passive: !1, capture: !0 } : !0,
        s = "." + a.params.slideClass;
      (a.zoom.passiveListener = r),
        (a.zoom.slideSelector = s),
        e.gestures
          ? (a.$wrapperEl.on(a.touchEvents.start, a.zoom.enableGestures, r),
            a.$wrapperEl.on(a.touchEvents.end, a.zoom.disableGestures, r))
          : a.touchEvents.start === "touchstart" &&
            (a.$wrapperEl.on(a.touchEvents.start, s, t.onGestureStart, r),
            a.$wrapperEl.on(a.touchEvents.move, s, t.onGestureChange, i),
            a.$wrapperEl.on(a.touchEvents.end, s, t.onGestureEnd, r),
            a.touchEvents.cancel &&
              a.$wrapperEl.on(a.touchEvents.cancel, s, t.onGestureEnd, r)),
        a.$wrapperEl.on(
          a.touchEvents.move,
          "." + a.params.zoom.containerClass,
          t.onTouchMove,
          i
        );
    }
  },
  disable: function () {
    var a = this,
      e = a.zoom;
    if (e.enabled) {
      var t = a.support;
      a.zoom.enabled = !1;
      var r =
          a.touchEvents.start === "touchstart" &&
          t.passiveListener &&
          a.params.passiveListeners
            ? { passive: !0, capture: !1 }
            : !1,
        i = t.passiveListener ? { passive: !1, capture: !0 } : !0,
        s = "." + a.params.slideClass;
      t.gestures
        ? (a.$wrapperEl.off(a.touchEvents.start, a.zoom.enableGestures, r),
          a.$wrapperEl.off(a.touchEvents.end, a.zoom.disableGestures, r))
        : a.touchEvents.start === "touchstart" &&
          (a.$wrapperEl.off(a.touchEvents.start, s, e.onGestureStart, r),
          a.$wrapperEl.off(a.touchEvents.move, s, e.onGestureChange, i),
          a.$wrapperEl.off(a.touchEvents.end, s, e.onGestureEnd, r),
          a.touchEvents.cancel &&
            a.$wrapperEl.off(a.touchEvents.cancel, s, e.onGestureEnd, r)),
        a.$wrapperEl.off(
          a.touchEvents.move,
          "." + a.params.zoom.containerClass,
          e.onTouchMove,
          i
        );
    }
  },
};
const Ma = {
  name: "zoom",
  params: {
    zoom: {
      enabled: !1,
      maxRatio: 3,
      minRatio: 1,
      toggle: !0,
      containerClass: "swiper-zoom-container",
      zoomedSlideClass: "swiper-slide-zoomed",
    },
  },
  create: function () {
    var a = this;
    z(a, {
      zoom: U(
        {
          enabled: !1,
          scale: 1,
          currentScale: 1,
          isScaling: !1,
          gesture: {
            $slideEl: void 0,
            slideWidth: void 0,
            slideHeight: void 0,
            $imageEl: void 0,
            $imageWrapEl: void 0,
            maxRatio: 3,
          },
          image: {
            isTouched: void 0,
            isMoved: void 0,
            currentX: void 0,
            currentY: void 0,
            minX: void 0,
            minY: void 0,
            maxX: void 0,
            maxY: void 0,
            width: void 0,
            height: void 0,
            startX: void 0,
            startY: void 0,
            touchesStart: {},
            touchesCurrent: {},
          },
          velocity: {
            x: void 0,
            y: void 0,
            prevPositionX: void 0,
            prevPositionY: void 0,
            prevTime: void 0,
          },
        },
        K
      ),
    });
    var e = 1;
    Object.defineProperty(a.zoom, "scale", {
      get: function () {
        return e;
      },
      set: function (r) {
        if (e !== r) {
          var i = a.zoom.gesture.$imageEl ? a.zoom.gesture.$imageEl[0] : void 0,
            s = a.zoom.gesture.$slideEl ? a.zoom.gesture.$slideEl[0] : void 0;
          a.emit("zoomChange", r, i, s);
        }
        e = r;
      },
    });
  },
  on: {
    init: function (a) {
      a.params.zoom.enabled && a.zoom.enable();
    },
    destroy: function (a) {
      a.zoom.disable();
    },
    touchStart: function (a, e) {
      a.zoom.enabled && a.zoom.onTouchStart(e);
    },
    touchEnd: function (a, e) {
      a.zoom.enabled && a.zoom.onTouchEnd(e);
    },
    doubleTap: function (a, e) {
      !a.animating &&
        a.params.zoom.enabled &&
        a.zoom.enabled &&
        a.params.zoom.toggle &&
        a.zoom.toggle(e);
    },
    transitionEnd: function (a) {
      a.zoom.enabled && a.params.zoom.enabled && a.zoom.onTransitionEnd();
    },
    slideChange: function (a) {
      a.zoom.enabled &&
        a.params.zoom.enabled &&
        a.params.cssMode &&
        a.zoom.onTransitionEnd();
    },
  },
};
function Z() {
  return (
    (Z =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    Z.apply(this, arguments)
  );
}
var za = {
  loadInSlide: function (a, e) {
    e === void 0 && (e = !0);
    var t = this,
      r = t.params.lazy;
    if (!(typeof a > "u") && t.slides.length !== 0) {
      var i = t.virtual && t.params.virtual.enabled,
        s = i
          ? t.$wrapperEl.children(
              "." +
                t.params.slideClass +
                '[data-swiper-slide-index="' +
                a +
                '"]'
            )
          : t.slides.eq(a),
        l = s.find(
          "." +
            r.elementClass +
            ":not(." +
            r.loadedClass +
            "):not(." +
            r.loadingClass +
            ")"
        );
      s.hasClass(r.elementClass) &&
        !s.hasClass(r.loadedClass) &&
        !s.hasClass(r.loadingClass) &&
        l.push(s[0]),
        l.length !== 0 &&
          l.each(function (o) {
            var d = g(o);
            d.addClass(r.loadingClass);
            var u = d.attr("data-background"),
              p = d.attr("data-src"),
              c = d.attr("data-srcset"),
              v = d.attr("data-sizes"),
              f = d.parent("picture");
            t.loadImage(d[0], p || u, c, v, !1, function () {
              if (
                !(
                  typeof t > "u" ||
                  t === null ||
                  !t ||
                  (t && !t.params) ||
                  t.destroyed
                )
              ) {
                if (
                  (u
                    ? (d.css("background-image", 'url("' + u + '")'),
                      d.removeAttr("data-background"))
                    : (c && (d.attr("srcset", c), d.removeAttr("data-srcset")),
                      v && (d.attr("sizes", v), d.removeAttr("data-sizes")),
                      f.length &&
                        f.children("source").each(function (w) {
                          var C = g(w);
                          C.attr("data-srcset") &&
                            (C.attr("srcset", C.attr("data-srcset")),
                            C.removeAttr("data-srcset"));
                        }),
                      p && (d.attr("src", p), d.removeAttr("data-src"))),
                  d.addClass(r.loadedClass).removeClass(r.loadingClass),
                  s.find("." + r.preloaderClass).remove(),
                  t.params.loop && e)
                ) {
                  var y = s.attr("data-swiper-slide-index");
                  if (s.hasClass(t.params.slideDuplicateClass)) {
                    var E = t.$wrapperEl.children(
                      '[data-swiper-slide-index="' +
                        y +
                        '"]:not(.' +
                        t.params.slideDuplicateClass +
                        ")"
                    );
                    t.lazy.loadInSlide(E.index(), !1);
                  } else {
                    var m = t.$wrapperEl.children(
                      "." +
                        t.params.slideDuplicateClass +
                        '[data-swiper-slide-index="' +
                        y +
                        '"]'
                    );
                    t.lazy.loadInSlide(m.index(), !1);
                  }
                }
                t.emit("lazyImageReady", s[0], d[0]),
                  t.params.autoHeight && t.updateAutoHeight();
              }
            }),
              t.emit("lazyImageLoad", s[0], d[0]);
          });
    }
  },
  load: function () {
    var a = this,
      e = a.$wrapperEl,
      t = a.params,
      r = a.slides,
      i = a.activeIndex,
      s = a.virtual && t.virtual.enabled,
      l = t.lazy,
      o = t.slidesPerView;
    o === "auto" && (o = 0);
    function d(b) {
      if (s) {
        if (
          e.children(
            "." + t.slideClass + '[data-swiper-slide-index="' + b + '"]'
          ).length
        )
          return !0;
      } else if (r[b]) return !0;
      return !1;
    }
    function u(b) {
      return s ? g(b).attr("data-swiper-slide-index") : g(b).index();
    }
    if (
      (a.lazy.initialImageLoaded || (a.lazy.initialImageLoaded = !0),
      a.params.watchSlidesVisibility)
    )
      e.children("." + t.slideVisibleClass).each(function (b) {
        var h = s ? g(b).attr("data-swiper-slide-index") : g(b).index();
        a.lazy.loadInSlide(h);
      });
    else if (o > 1)
      for (var p = i; p < i + o; p += 1) d(p) && a.lazy.loadInSlide(p);
    else a.lazy.loadInSlide(i);
    if (l.loadPrevNext)
      if (o > 1 || (l.loadPrevNextAmount && l.loadPrevNextAmount > 1)) {
        for (
          var c = l.loadPrevNextAmount,
            v = o,
            f = Math.min(i + v + Math.max(c, v), r.length),
            y = Math.max(i - Math.max(v, c), 0),
            E = i + o;
          E < f;
          E += 1
        )
          d(E) && a.lazy.loadInSlide(E);
        for (var m = y; m < i; m += 1) d(m) && a.lazy.loadInSlide(m);
      } else {
        var w = e.children("." + t.slideNextClass);
        w.length > 0 && a.lazy.loadInSlide(u(w));
        var C = e.children("." + t.slidePrevClass);
        C.length > 0 && a.lazy.loadInSlide(u(C));
      }
  },
  checkInViewOnLoad: function () {
    var a = L(),
      e = this;
    if (!(!e || e.destroyed)) {
      var t = e.params.lazy.scrollingElement
          ? g(e.params.lazy.scrollingElement)
          : g(a),
        r = t[0] === a,
        i = r ? a.innerWidth : t[0].offsetWidth,
        s = r ? a.innerHeight : t[0].offsetHeight,
        l = e.$el.offset(),
        o = e.rtlTranslate,
        d = !1;
      o && (l.left -= e.$el[0].scrollLeft);
      for (
        var u = [
            [l.left, l.top],
            [l.left + e.width, l.top],
            [l.left, l.top + e.height],
            [l.left + e.width, l.top + e.height],
          ],
          p = 0;
        p < u.length;
        p += 1
      ) {
        var c = u[p];
        if (c[0] >= 0 && c[0] <= i && c[1] >= 0 && c[1] <= s) {
          if (c[0] === 0 && c[1] === 0) continue;
          d = !0;
        }
      }
      var v =
        e.touchEvents.start === "touchstart" &&
        e.support.passiveListener &&
        e.params.passiveListeners
          ? { passive: !0, capture: !1 }
          : !1;
      d
        ? (e.lazy.load(), t.off("scroll", e.lazy.checkInViewOnLoad, v))
        : e.lazy.scrollHandlerAttached ||
          ((e.lazy.scrollHandlerAttached = !0),
          t.on("scroll", e.lazy.checkInViewOnLoad, v));
    }
  },
};
const Pa = {
  name: "lazy",
  params: {
    lazy: {
      checkInView: !1,
      enabled: !1,
      loadPrevNext: !1,
      loadPrevNextAmount: 1,
      loadOnTransitionStart: !1,
      scrollingElement: "",
      elementClass: "swiper-lazy",
      loadingClass: "swiper-lazy-loading",
      loadedClass: "swiper-lazy-loaded",
      preloaderClass: "swiper-lazy-preloader",
    },
  },
  create: function () {
    var a = this;
    z(a, { lazy: Z({ initialImageLoaded: !1 }, za) });
  },
  on: {
    beforeInit: function (a) {
      a.params.lazy.enabled &&
        a.params.preloadImages &&
        (a.params.preloadImages = !1);
    },
    init: function (a) {
      a.params.lazy.enabled &&
        !a.params.loop &&
        a.params.initialSlide === 0 &&
        (a.params.lazy.checkInView
          ? a.lazy.checkInViewOnLoad()
          : a.lazy.load());
    },
    scroll: function (a) {
      a.params.freeMode && !a.params.freeModeSticky && a.lazy.load();
    },
    "scrollbarDragMove resize _freeModeNoMomentumRelease": function (a) {
      a.params.lazy.enabled && a.lazy.load();
    },
    transitionStart: function (a) {
      a.params.lazy.enabled &&
        (a.params.lazy.loadOnTransitionStart ||
          (!a.params.lazy.loadOnTransitionStart &&
            !a.lazy.initialImageLoaded)) &&
        a.lazy.load();
    },
    transitionEnd: function (a) {
      a.params.lazy.enabled &&
        !a.params.lazy.loadOnTransitionStart &&
        a.lazy.load();
    },
    slideChange: function (a) {
      var e = a.params,
        t = e.lazy,
        r = e.cssMode,
        i = e.watchSlidesVisibility,
        s = e.watchSlidesProgress,
        l = e.touchReleaseOnEdges,
        o = e.resistanceRatio;
      t.enabled && (r || ((i || s) && (l || o === 0))) && a.lazy.load();
    },
  },
};
function J() {
  return (
    (J =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    J.apply(this, arguments)
  );
}
var Q = {
  LinearSpline: function (a, e) {
    var t = (function () {
      var l, o, d;
      return function (u, p) {
        for (o = -1, l = u.length; l - o > 1; )
          (d = (l + o) >> 1), u[d] <= p ? (o = d) : (l = d);
        return l;
      };
    })();
    (this.x = a), (this.y = e), (this.lastIndex = a.length - 1);
    var r, i;
    return (
      (this.interpolate = function (l) {
        return l
          ? ((i = t(this.x, l)),
            (r = i - 1),
            ((l - this.x[r]) * (this.y[i] - this.y[r])) /
              (this.x[i] - this.x[r]) +
              this.y[r])
          : 0;
      }),
      this
    );
  },
  getInterpolateFunction: function (a) {
    var e = this;
    e.controller.spline ||
      (e.controller.spline = e.params.loop
        ? new Q.LinearSpline(e.slidesGrid, a.slidesGrid)
        : new Q.LinearSpline(e.snapGrid, a.snapGrid));
  },
  setTranslate: function (a, e) {
    var t = this,
      r = t.controller.control,
      i,
      s,
      l = t.constructor;
    function o(u) {
      var p = t.rtlTranslate ? -t.translate : t.translate;
      t.params.controller.by === "slide" &&
        (t.controller.getInterpolateFunction(u),
        (s = -t.controller.spline.interpolate(-p))),
        (!s || t.params.controller.by === "container") &&
          ((i =
            (u.maxTranslate() - u.minTranslate()) /
            (t.maxTranslate() - t.minTranslate())),
          (s = (p - t.minTranslate()) * i + u.minTranslate())),
        t.params.controller.inverse && (s = u.maxTranslate() - s),
        u.updateProgress(s),
        u.setTranslate(s, t),
        u.updateActiveIndex(),
        u.updateSlidesClasses();
    }
    if (Array.isArray(r))
      for (var d = 0; d < r.length; d += 1)
        r[d] !== e && r[d] instanceof l && o(r[d]);
    else r instanceof l && e !== r && o(r);
  },
  setTransition: function (a, e) {
    var t = this,
      r = t.constructor,
      i = t.controller.control,
      s;
    function l(o) {
      o.setTransition(a, t),
        a !== 0 &&
          (o.transitionStart(),
          o.params.autoHeight &&
            R(function () {
              o.updateAutoHeight();
            }),
          o.$wrapperEl.transitionEnd(function () {
            i &&
              (o.params.loop &&
                t.params.controller.by === "slide" &&
                o.loopFix(),
              o.transitionEnd());
          }));
    }
    if (Array.isArray(i))
      for (s = 0; s < i.length; s += 1)
        i[s] !== e && i[s] instanceof r && l(i[s]);
    else i instanceof r && e !== i && l(i);
  },
};
const Oa = {
  name: "controller",
  params: { controller: { control: void 0, inverse: !1, by: "slide" } },
  create: function () {
    var a = this;
    z(a, { controller: J({ control: a.params.controller.control }, Q) });
  },
  on: {
    update: function (a) {
      a.controller.control &&
        a.controller.spline &&
        ((a.controller.spline = void 0), delete a.controller.spline);
    },
    resize: function (a) {
      a.controller.control &&
        a.controller.spline &&
        ((a.controller.spline = void 0), delete a.controller.spline);
    },
    observerUpdate: function (a) {
      a.controller.control &&
        a.controller.spline &&
        ((a.controller.spline = void 0), delete a.controller.spline);
    },
    setTranslate: function (a, e, t) {
      a.controller.control && a.controller.setTranslate(e, t);
    },
    setTransition: function (a, e, t) {
      a.controller.control && a.controller.setTransition(e, t);
    },
  },
};
function _() {
  return (
    (_ =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    _.apply(this, arguments)
  );
}
var La = {
  getRandomNumber: function (a) {
    a === void 0 && (a = 16);
    var e = function () {
      return Math.round(16 * Math.random()).toString(16);
    };
    return "x".repeat(a).replace(/x/g, e);
  },
  makeElFocusable: function (a) {
    return a.attr("tabIndex", "0"), a;
  },
  makeElNotFocusable: function (a) {
    return a.attr("tabIndex", "-1"), a;
  },
  addElRole: function (a, e) {
    return a.attr("role", e), a;
  },
  addElRoleDescription: function (a, e) {
    return a.attr("aria-roledescription", e), a;
  },
  addElControls: function (a, e) {
    return a.attr("aria-controls", e), a;
  },
  addElLabel: function (a, e) {
    return a.attr("aria-label", e), a;
  },
  addElId: function (a, e) {
    return a.attr("id", e), a;
  },
  addElLive: function (a, e) {
    return a.attr("aria-live", e), a;
  },
  disableEl: function (a) {
    return a.attr("aria-disabled", !0), a;
  },
  enableEl: function (a) {
    return a.attr("aria-disabled", !1), a;
  },
  onEnterOrSpaceKey: function (a) {
    if (!(a.keyCode !== 13 && a.keyCode !== 32)) {
      var e = this,
        t = e.params.a11y,
        r = g(a.target);
      e.navigation &&
        e.navigation.$nextEl &&
        r.is(e.navigation.$nextEl) &&
        ((e.isEnd && !e.params.loop) || e.slideNext(),
        e.isEnd
          ? e.a11y.notify(t.lastSlideMessage)
          : e.a11y.notify(t.nextSlideMessage)),
        e.navigation &&
          e.navigation.$prevEl &&
          r.is(e.navigation.$prevEl) &&
          ((e.isBeginning && !e.params.loop) || e.slidePrev(),
          e.isBeginning
            ? e.a11y.notify(t.firstSlideMessage)
            : e.a11y.notify(t.prevSlideMessage)),
        e.pagination &&
          r.is(I(e.params.pagination.bulletClass)) &&
          r[0].click();
    }
  },
  notify: function (a) {
    var e = this,
      t = e.a11y.liveRegion;
    t.length !== 0 && (t.html(""), t.html(a));
  },
  updateNavigation: function () {
    var a = this;
    if (!(a.params.loop || !a.navigation)) {
      var e = a.navigation,
        t = e.$nextEl,
        r = e.$prevEl;
      r &&
        r.length > 0 &&
        (a.isBeginning
          ? (a.a11y.disableEl(r), a.a11y.makeElNotFocusable(r))
          : (a.a11y.enableEl(r), a.a11y.makeElFocusable(r))),
        t &&
          t.length > 0 &&
          (a.isEnd
            ? (a.a11y.disableEl(t), a.a11y.makeElNotFocusable(t))
            : (a.a11y.enableEl(t), a.a11y.makeElFocusable(t)));
    }
  },
  updatePagination: function () {
    var a = this,
      e = a.params.a11y;
    a.pagination &&
      a.params.pagination.clickable &&
      a.pagination.bullets &&
      a.pagination.bullets.length &&
      a.pagination.bullets.each(function (t) {
        var r = g(t);
        a.a11y.makeElFocusable(r),
          a.params.pagination.renderBullet ||
            (a.a11y.addElRole(r, "button"),
            a.a11y.addElLabel(
              r,
              e.paginationBulletMessage.replace(/\{\{index\}\}/, r.index() + 1)
            ));
      });
  },
  init: function () {
    var a = this,
      e = a.params.a11y;
    a.$el.append(a.a11y.liveRegion);
    var t = a.$el;
    e.containerRoleDescriptionMessage &&
      a.a11y.addElRoleDescription(t, e.containerRoleDescriptionMessage),
      e.containerMessage && a.a11y.addElLabel(t, e.containerMessage);
    var r = a.$wrapperEl,
      i = r.attr("id") || "swiper-wrapper-" + a.a11y.getRandomNumber(16),
      s = a.params.autoplay && a.params.autoplay.enabled ? "off" : "polite";
    a.a11y.addElId(r, i),
      a.a11y.addElLive(r, s),
      e.itemRoleDescriptionMessage &&
        a.a11y.addElRoleDescription(g(a.slides), e.itemRoleDescriptionMessage),
      a.a11y.addElRole(g(a.slides), e.slideRole);
    var l = a.params.loop
      ? a.slides.filter(function (u) {
          return !u.classList.contains(a.params.slideDuplicateClass);
        }).length
      : a.slides.length;
    a.slides.each(function (u, p) {
      var c = g(u),
        v = a.params.loop ? parseInt(c.attr("data-swiper-slide-index"), 10) : p,
        f = e.slideLabelMessage
          .replace(/\{\{index\}\}/, v + 1)
          .replace(/\{\{slidesLength\}\}/, l);
      a.a11y.addElLabel(c, f);
    });
    var o, d;
    a.navigation && a.navigation.$nextEl && (o = a.navigation.$nextEl),
      a.navigation && a.navigation.$prevEl && (d = a.navigation.$prevEl),
      o &&
        o.length &&
        (a.a11y.makeElFocusable(o),
        o[0].tagName !== "BUTTON" &&
          (a.a11y.addElRole(o, "button"),
          o.on("keydown", a.a11y.onEnterOrSpaceKey)),
        a.a11y.addElLabel(o, e.nextSlideMessage),
        a.a11y.addElControls(o, i)),
      d &&
        d.length &&
        (a.a11y.makeElFocusable(d),
        d[0].tagName !== "BUTTON" &&
          (a.a11y.addElRole(d, "button"),
          d.on("keydown", a.a11y.onEnterOrSpaceKey)),
        a.a11y.addElLabel(d, e.prevSlideMessage),
        a.a11y.addElControls(d, i)),
      a.pagination &&
        a.params.pagination.clickable &&
        a.pagination.bullets &&
        a.pagination.bullets.length &&
        a.pagination.$el.on(
          "keydown",
          I(a.params.pagination.bulletClass),
          a.a11y.onEnterOrSpaceKey
        );
  },
  destroy: function () {
    var a = this;
    a.a11y.liveRegion &&
      a.a11y.liveRegion.length > 0 &&
      a.a11y.liveRegion.remove();
    var e, t;
    a.navigation && a.navigation.$nextEl && (e = a.navigation.$nextEl),
      a.navigation && a.navigation.$prevEl && (t = a.navigation.$prevEl),
      e && e.off("keydown", a.a11y.onEnterOrSpaceKey),
      t && t.off("keydown", a.a11y.onEnterOrSpaceKey),
      a.pagination &&
        a.params.pagination.clickable &&
        a.pagination.bullets &&
        a.pagination.bullets.length &&
        a.pagination.$el.off(
          "keydown",
          I(a.params.pagination.bulletClass),
          a.a11y.onEnterOrSpaceKey
        );
  },
};
const ka = {
  name: "a11y",
  params: {
    a11y: {
      enabled: !0,
      notificationClass: "swiper-notification",
      prevSlideMessage: "Previous slide",
      nextSlideMessage: "Next slide",
      firstSlideMessage: "This is the first slide",
      lastSlideMessage: "This is the last slide",
      paginationBulletMessage: "Go to slide {{index}}",
      slideLabelMessage: "{{index}} / {{slidesLength}}",
      containerMessage: null,
      containerRoleDescriptionMessage: null,
      itemRoleDescriptionMessage: null,
      slideRole: "group",
    },
  },
  create: function () {
    var a = this;
    z(a, {
      a11y: _({}, La, {
        liveRegion: g(
          '<span class="' +
            a.params.a11y.notificationClass +
            '" aria-live="assertive" aria-atomic="true"></span>'
        ),
      }),
    });
  },
  on: {
    afterInit: function (a) {
      a.params.a11y.enabled && (a.a11y.init(), a.a11y.updateNavigation());
    },
    toEdge: function (a) {
      a.params.a11y.enabled && a.a11y.updateNavigation();
    },
    fromEdge: function (a) {
      a.params.a11y.enabled && a.a11y.updateNavigation();
    },
    paginationUpdate: function (a) {
      a.params.a11y.enabled && a.a11y.updatePagination();
    },
    destroy: function (a) {
      a.params.a11y.enabled && a.a11y.destroy();
    },
  },
};
function aa() {
  return (
    (aa =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    aa.apply(this, arguments)
  );
}
var A = {
  init: function () {
    var a = this,
      e = L();
    if (a.params.history) {
      if (!e.history || !e.history.pushState) {
        (a.params.history.enabled = !1), (a.params.hashNavigation.enabled = !0);
        return;
      }
      var t = a.history;
      (t.initialized = !0),
        (t.paths = A.getPathValues(a.params.url)),
        !(!t.paths.key && !t.paths.value) &&
          (t.scrollToSlide(0, t.paths.value, a.params.runCallbacksOnInit),
          a.params.history.replaceState ||
            e.addEventListener("popstate", a.history.setHistoryPopState));
    }
  },
  destroy: function () {
    var a = this,
      e = L();
    a.params.history.replaceState ||
      e.removeEventListener("popstate", a.history.setHistoryPopState);
  },
  setHistoryPopState: function () {
    var a = this;
    (a.history.paths = A.getPathValues(a.params.url)),
      a.history.scrollToSlide(a.params.speed, a.history.paths.value, !1);
  },
  getPathValues: function (a) {
    var e = L(),
      t;
    a ? (t = new URL(a)) : (t = e.location);
    var r = t.pathname
        .slice(1)
        .split("/")
        .filter(function (o) {
          return o !== "";
        }),
      i = r.length,
      s = r[i - 2],
      l = r[i - 1];
    return { key: s, value: l };
  },
  setHistory: function (a, e) {
    var t = this,
      r = L();
    if (!(!t.history.initialized || !t.params.history.enabled)) {
      var i;
      t.params.url ? (i = new URL(t.params.url)) : (i = r.location);
      var s = t.slides.eq(e),
        l = A.slugify(s.attr("data-history"));
      if (t.params.history.root.length > 0) {
        var o = t.params.history.root;
        o[o.length - 1] === "/" && (o = o.slice(0, o.length - 1)),
          (l = o + "/" + a + "/" + l);
      } else i.pathname.includes(a) || (l = a + "/" + l);
      var d = r.history.state;
      (d && d.value === l) ||
        (t.params.history.replaceState
          ? r.history.replaceState({ value: l }, null, l)
          : r.history.pushState({ value: l }, null, l));
    }
  },
  slugify: function (a) {
    return a
      .toString()
      .replace(/\s+/g, "-")
      .replace(/[^\w-]+/g, "")
      .replace(/--+/g, "-")
      .replace(/^-+/, "")
      .replace(/-+$/, "");
  },
  scrollToSlide: function (a, e, t) {
    var r = this;
    if (e)
      for (var i = 0, s = r.slides.length; i < s; i += 1) {
        var l = r.slides.eq(i),
          o = A.slugify(l.attr("data-history"));
        if (o === e && !l.hasClass(r.params.slideDuplicateClass)) {
          var d = l.index();
          r.slideTo(d, a, t);
        }
      }
    else r.slideTo(0, a, t);
  },
};
const Da = {
  name: "history",
  params: {
    history: { enabled: !1, root: "", replaceState: !1, key: "slides" },
  },
  create: function () {
    var a = this;
    z(a, { history: aa({}, A) });
  },
  on: {
    init: function (a) {
      a.params.history.enabled && a.history.init();
    },
    destroy: function (a) {
      a.params.history.enabled && a.history.destroy();
    },
    "transitionEnd _freeModeNoMomentumRelease": function (a) {
      a.history.initialized &&
        a.history.setHistory(a.params.history.key, a.activeIndex);
    },
    slideChange: function (a) {
      a.history.initialized &&
        a.params.cssMode &&
        a.history.setHistory(a.params.history.key, a.activeIndex);
    },
  },
};
function ea() {
  return (
    (ea =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    ea.apply(this, arguments)
  );
}
var Ha = {
  onHashChange: function () {
    var a = this,
      e = k();
    a.emit("hashChange");
    var t = e.location.hash.replace("#", ""),
      r = a.slides.eq(a.activeIndex).attr("data-hash");
    if (t !== r) {
      var i = a.$wrapperEl
        .children("." + a.params.slideClass + '[data-hash="' + t + '"]')
        .index();
      if (typeof i > "u") return;
      a.slideTo(i);
    }
  },
  setHash: function () {
    var a = this,
      e = L(),
      t = k();
    if (!(!a.hashNavigation.initialized || !a.params.hashNavigation.enabled))
      if (
        a.params.hashNavigation.replaceState &&
        e.history &&
        e.history.replaceState
      )
        e.history.replaceState(
          null,
          null,
          "#" + a.slides.eq(a.activeIndex).attr("data-hash") || ""
        ),
          a.emit("hashSet");
      else {
        var r = a.slides.eq(a.activeIndex),
          i = r.attr("data-hash") || r.attr("data-history");
        (t.location.hash = i || ""), a.emit("hashSet");
      }
  },
  init: function () {
    var a = this,
      e = k(),
      t = L();
    if (
      !(
        !a.params.hashNavigation.enabled ||
        (a.params.history && a.params.history.enabled)
      )
    ) {
      a.hashNavigation.initialized = !0;
      var r = e.location.hash.replace("#", "");
      if (r)
        for (var i = 0, s = 0, l = a.slides.length; s < l; s += 1) {
          var o = a.slides.eq(s),
            d = o.attr("data-hash") || o.attr("data-history");
          if (d === r && !o.hasClass(a.params.slideDuplicateClass)) {
            var u = o.index();
            a.slideTo(u, i, a.params.runCallbacksOnInit, !0);
          }
        }
      a.params.hashNavigation.watchState &&
        g(t).on("hashchange", a.hashNavigation.onHashChange);
    }
  },
  destroy: function () {
    var a = this,
      e = L();
    a.params.hashNavigation.watchState &&
      g(e).off("hashchange", a.hashNavigation.onHashChange);
  },
};
const Na = {
  name: "hash-navigation",
  params: { hashNavigation: { enabled: !1, replaceState: !1, watchState: !1 } },
  create: function () {
    var a = this;
    z(a, { hashNavigation: ea({ initialized: !1 }, Ha) });
  },
  on: {
    init: function (a) {
      a.params.hashNavigation.enabled && a.hashNavigation.init();
    },
    destroy: function (a) {
      a.params.hashNavigation.enabled && a.hashNavigation.destroy();
    },
    "transitionEnd _freeModeNoMomentumRelease": function (a) {
      a.hashNavigation.initialized && a.hashNavigation.setHash();
    },
    slideChange: function (a) {
      a.hashNavigation.initialized &&
        a.params.cssMode &&
        a.hashNavigation.setHash();
    },
  },
};
function ta() {
  return (
    (ta =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    ta.apply(this, arguments)
  );
}
var Ia = {
  run: function () {
    var a = this,
      e = a.slides.eq(a.activeIndex),
      t = a.params.autoplay.delay;
    e.attr("data-swiper-autoplay") &&
      (t = e.attr("data-swiper-autoplay") || a.params.autoplay.delay),
      clearTimeout(a.autoplay.timeout),
      (a.autoplay.timeout = R(function () {
        var r;
        a.params.autoplay.reverseDirection
          ? a.params.loop
            ? (a.loopFix(),
              (r = a.slidePrev(a.params.speed, !0, !0)),
              a.emit("autoplay"))
            : a.isBeginning
            ? a.params.autoplay.stopOnLastSlide
              ? a.autoplay.stop()
              : ((r = a.slideTo(a.slides.length - 1, a.params.speed, !0, !0)),
                a.emit("autoplay"))
            : ((r = a.slidePrev(a.params.speed, !0, !0)), a.emit("autoplay"))
          : a.params.loop
          ? (a.loopFix(),
            (r = a.slideNext(a.params.speed, !0, !0)),
            a.emit("autoplay"))
          : a.isEnd
          ? a.params.autoplay.stopOnLastSlide
            ? a.autoplay.stop()
            : ((r = a.slideTo(0, a.params.speed, !0, !0)), a.emit("autoplay"))
          : ((r = a.slideNext(a.params.speed, !0, !0)), a.emit("autoplay")),
          ((a.params.cssMode && a.autoplay.running) || r === !1) &&
            a.autoplay.run();
      }, t));
  },
  start: function () {
    var a = this;
    return typeof a.autoplay.timeout < "u" || a.autoplay.running
      ? !1
      : ((a.autoplay.running = !0),
        a.emit("autoplayStart"),
        a.autoplay.run(),
        !0);
  },
  stop: function () {
    var a = this;
    return !a.autoplay.running || typeof a.autoplay.timeout > "u"
      ? !1
      : (a.autoplay.timeout &&
          (clearTimeout(a.autoplay.timeout), (a.autoplay.timeout = void 0)),
        (a.autoplay.running = !1),
        a.emit("autoplayStop"),
        !0);
  },
  pause: function (a) {
    var e = this;
    e.autoplay.running &&
      (e.autoplay.paused ||
        (e.autoplay.timeout && clearTimeout(e.autoplay.timeout),
        (e.autoplay.paused = !0),
        a === 0 || !e.params.autoplay.waitForTransition
          ? ((e.autoplay.paused = !1), e.autoplay.run())
          : ["transitionend", "webkitTransitionEnd"].forEach(function (t) {
              e.$wrapperEl[0].addEventListener(t, e.autoplay.onTransitionEnd);
            })));
  },
  onVisibilityChange: function () {
    var a = this,
      e = k();
    e.visibilityState === "hidden" && a.autoplay.running && a.autoplay.pause(),
      e.visibilityState === "visible" &&
        a.autoplay.paused &&
        (a.autoplay.run(), (a.autoplay.paused = !1));
  },
  onTransitionEnd: function (a) {
    var e = this;
    !e ||
      e.destroyed ||
      !e.$wrapperEl ||
      (a.target === e.$wrapperEl[0] &&
        (["transitionend", "webkitTransitionEnd"].forEach(function (t) {
          e.$wrapperEl[0].removeEventListener(t, e.autoplay.onTransitionEnd);
        }),
        (e.autoplay.paused = !1),
        e.autoplay.running ? e.autoplay.run() : e.autoplay.stop()));
  },
  onMouseEnter: function () {
    var a = this;
    a.params.autoplay.disableOnInteraction
      ? a.autoplay.stop()
      : a.autoplay.pause(),
      ["transitionend", "webkitTransitionEnd"].forEach(function (e) {
        a.$wrapperEl[0].removeEventListener(e, a.autoplay.onTransitionEnd);
      });
  },
  onMouseLeave: function () {
    var a = this;
    a.params.autoplay.disableOnInteraction ||
      ((a.autoplay.paused = !1), a.autoplay.run());
  },
  attachMouseEvents: function () {
    var a = this;
    a.params.autoplay.pauseOnMouseEnter &&
      (a.$el.on("mouseenter", a.autoplay.onMouseEnter),
      a.$el.on("mouseleave", a.autoplay.onMouseLeave));
  },
  detachMouseEvents: function () {
    var a = this;
    a.$el.off("mouseenter", a.autoplay.onMouseEnter),
      a.$el.off("mouseleave", a.autoplay.onMouseLeave);
  },
};
const Xa = {
  name: "autoplay",
  params: {
    autoplay: {
      enabled: !1,
      delay: 3e3,
      waitForTransition: !0,
      disableOnInteraction: !0,
      stopOnLastSlide: !1,
      reverseDirection: !1,
      pauseOnMouseEnter: !1,
    },
  },
  create: function () {
    var a = this;
    z(a, { autoplay: ta({}, Ia, { running: !1, paused: !1 }) });
  },
  on: {
    init: function (a) {
      if (a.params.autoplay.enabled) {
        a.autoplay.start();
        var e = k();
        e.addEventListener("visibilitychange", a.autoplay.onVisibilityChange),
          a.autoplay.attachMouseEvents();
      }
    },
    beforeTransitionStart: function (a, e, t) {
      a.autoplay.running &&
        (t || !a.params.autoplay.disableOnInteraction
          ? a.autoplay.pause(e)
          : a.autoplay.stop());
    },
    sliderFirstMove: function (a) {
      a.autoplay.running &&
        (a.params.autoplay.disableOnInteraction
          ? a.autoplay.stop()
          : a.autoplay.pause());
    },
    touchEnd: function (a) {
      a.params.cssMode &&
        a.autoplay.paused &&
        !a.params.autoplay.disableOnInteraction &&
        a.autoplay.run();
    },
    destroy: function (a) {
      a.autoplay.detachMouseEvents(), a.autoplay.running && a.autoplay.stop();
      var e = k();
      e.removeEventListener("visibilitychange", a.autoplay.onVisibilityChange);
    },
  },
};
function ra() {
  return (
    (ra =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    ra.apply(this, arguments)
  );
}
var Ga = {
  setTranslate: function () {
    for (var a = this, e = a.slides, t = 0; t < e.length; t += 1) {
      var r = a.slides.eq(t),
        i = r[0].swiperSlideOffset,
        s = -i;
      a.params.virtualTranslate || (s -= a.translate);
      var l = 0;
      a.isHorizontal() || ((l = s), (s = 0));
      var o = a.params.fadeEffect.crossFade
        ? Math.max(1 - Math.abs(r[0].progress), 0)
        : 1 + Math.min(Math.max(r[0].progress, -1), 0);
      r.css({ opacity: o }).transform(
        "translate3d(" + s + "px, " + l + "px, 0px)"
      );
    }
  },
  setTransition: function (a) {
    var e = this,
      t = e.slides,
      r = e.$wrapperEl;
    if ((t.transition(a), e.params.virtualTranslate && a !== 0)) {
      var i = !1;
      t.transitionEnd(function () {
        if (!i && !(!e || e.destroyed)) {
          (i = !0), (e.animating = !1);
          for (
            var s = ["webkitTransitionEnd", "transitionend"], l = 0;
            l < s.length;
            l += 1
          )
            r.trigger(s[l]);
        }
      });
    }
  },
};
const Ya = {
  name: "effect-fade",
  params: { fadeEffect: { crossFade: !1 } },
  create: function () {
    var a = this;
    z(a, { fadeEffect: ra({}, Ga) });
  },
  on: {
    beforeInit: function (a) {
      if (a.params.effect === "fade") {
        a.classNames.push(a.params.containerModifierClass + "fade");
        var e = {
          slidesPerView: 1,
          slidesPerColumn: 1,
          slidesPerGroup: 1,
          watchSlidesProgress: !0,
          spaceBetween: 0,
          virtualTranslate: !0,
        };
        O(a.params, e), O(a.originalParams, e);
      }
    },
    setTranslate: function (a) {
      a.params.effect === "fade" && a.fadeEffect.setTranslate();
    },
    setTransition: function (a, e) {
      a.params.effect === "fade" && a.fadeEffect.setTransition(e);
    },
  },
};
function ia() {
  return (
    (ia =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    ia.apply(this, arguments)
  );
}
var Aa = {
  setTranslate: function () {
    var a = this,
      e = a.$el,
      t = a.$wrapperEl,
      r = a.slides,
      i = a.width,
      s = a.height,
      l = a.rtlTranslate,
      o = a.size,
      d = a.browser,
      u = a.params.cubeEffect,
      p = a.isHorizontal(),
      c = a.virtual && a.params.virtual.enabled,
      v = 0,
      f;
    u.shadow &&
      (p
        ? ((f = t.find(".swiper-cube-shadow")),
          f.length === 0 &&
            ((f = g('<div class="swiper-cube-shadow"></div>')), t.append(f)),
          f.css({ height: i + "px" }))
        : ((f = e.find(".swiper-cube-shadow")),
          f.length === 0 &&
            ((f = g('<div class="swiper-cube-shadow"></div>')), e.append(f))));
    for (var y = 0; y < r.length; y += 1) {
      var E = r.eq(y),
        m = y;
      c && (m = parseInt(E.attr("data-swiper-slide-index"), 10));
      var w = m * 90,
        C = Math.floor(w / 360);
      l && ((w = -w), (C = Math.floor(-w / 360)));
      var b = Math.max(Math.min(E[0].progress, 1), -1),
        h = 0,
        S = 0,
        x = 0;
      m % 4 === 0
        ? ((h = -C * 4 * o), (x = 0))
        : (m - 1) % 4 === 0
        ? ((h = 0), (x = -C * 4 * o))
        : (m - 2) % 4 === 0
        ? ((h = o + C * 4 * o), (x = o))
        : (m - 3) % 4 === 0 && ((h = -o), (x = 3 * o + o * 4 * C)),
        l && (h = -h),
        p || ((S = h), (h = 0));
      var $ =
        "rotateX(" +
        (p ? 0 : -w) +
        "deg) rotateY(" +
        (p ? w : 0) +
        "deg) translate3d(" +
        h +
        "px, " +
        S +
        "px, " +
        x +
        "px)";
      if (
        (b <= 1 &&
          b > -1 &&
          ((v = m * 90 + b * 90), l && (v = -m * 90 - b * 90)),
        E.transform($),
        u.slideShadows)
      ) {
        var P = p
            ? E.find(".swiper-slide-shadow-left")
            : E.find(".swiper-slide-shadow-top"),
          T = p
            ? E.find(".swiper-slide-shadow-right")
            : E.find(".swiper-slide-shadow-bottom");
        P.length === 0 &&
          ((P = g(
            '<div class="swiper-slide-shadow-' +
              (p ? "left" : "top") +
              '"></div>'
          )),
          E.append(P)),
          T.length === 0 &&
            ((T = g(
              '<div class="swiper-slide-shadow-' +
                (p ? "right" : "bottom") +
                '"></div>'
            )),
            E.append(T)),
          P.length && (P[0].style.opacity = Math.max(-b, 0)),
          T.length && (T[0].style.opacity = Math.max(b, 0));
      }
    }
    if (
      (t.css({
        "-webkit-transform-origin": "50% 50% -" + o / 2 + "px",
        "-moz-transform-origin": "50% 50% -" + o / 2 + "px",
        "-ms-transform-origin": "50% 50% -" + o / 2 + "px",
        "transform-origin": "50% 50% -" + o / 2 + "px",
      }),
      u.shadow)
    )
      if (p)
        f.transform(
          "translate3d(0px, " +
            (i / 2 + u.shadowOffset) +
            "px, " +
            -i / 2 +
            "px) rotateX(90deg) rotateZ(0deg) scale(" +
            u.shadowScale +
            ")"
        );
      else {
        var M = Math.abs(v) - Math.floor(Math.abs(v) / 90) * 90,
          D =
            1.5 -
            (Math.sin((M * 2 * Math.PI) / 360) / 2 +
              Math.cos((M * 2 * Math.PI) / 360) / 2),
          H = u.shadowScale,
          X = u.shadowScale / D,
          Y = u.shadowOffset;
        f.transform(
          "scale3d(" +
            H +
            ", 1, " +
            X +
            ") translate3d(0px, " +
            (s / 2 + Y) +
            "px, " +
            -s / 2 / X +
            "px) rotateX(-90deg)"
        );
      }
    var ua = d.isSafari || d.isWebView ? -o / 2 : 0;
    t.transform(
      "translate3d(0px,0," +
        ua +
        "px) rotateX(" +
        (a.isHorizontal() ? 0 : v) +
        "deg) rotateY(" +
        (a.isHorizontal() ? -v : 0) +
        "deg)"
    );
  },
  setTransition: function (a) {
    var e = this,
      t = e.$el,
      r = e.slides;
    r
      .transition(a)
      .find(
        ".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left"
      )
      .transition(a),
      e.params.cubeEffect.shadow &&
        !e.isHorizontal() &&
        t.find(".swiper-cube-shadow").transition(a);
  },
};
const Ra = {
  name: "effect-cube",
  params: {
    cubeEffect: {
      slideShadows: !0,
      shadow: !0,
      shadowOffset: 20,
      shadowScale: 0.94,
    },
  },
  create: function () {
    var a = this;
    z(a, { cubeEffect: ia({}, Aa) });
  },
  on: {
    beforeInit: function (a) {
      if (a.params.effect === "cube") {
        a.classNames.push(a.params.containerModifierClass + "cube"),
          a.classNames.push(a.params.containerModifierClass + "3d");
        var e = {
          slidesPerView: 1,
          slidesPerColumn: 1,
          slidesPerGroup: 1,
          watchSlidesProgress: !0,
          resistanceRatio: 0,
          spaceBetween: 0,
          centeredSlides: !1,
          virtualTranslate: !0,
        };
        O(a.params, e), O(a.originalParams, e);
      }
    },
    setTranslate: function (a) {
      a.params.effect === "cube" && a.cubeEffect.setTranslate();
    },
    setTransition: function (a, e) {
      a.params.effect === "cube" && a.cubeEffect.setTransition(e);
    },
  },
};
function sa() {
  return (
    (sa =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    sa.apply(this, arguments)
  );
}
var Fa = {
  setTranslate: function () {
    for (
      var a = this, e = a.slides, t = a.rtlTranslate, r = 0;
      r < e.length;
      r += 1
    ) {
      var i = e.eq(r),
        s = i[0].progress;
      a.params.flipEffect.limitRotation &&
        (s = Math.max(Math.min(i[0].progress, 1), -1));
      var l = i[0].swiperSlideOffset,
        o = -180 * s,
        d = o,
        u = 0,
        p = -l,
        c = 0;
      if (
        (a.isHorizontal()
          ? t && (d = -d)
          : ((c = p), (p = 0), (u = -d), (d = 0)),
        (i[0].style.zIndex = -Math.abs(Math.round(s)) + e.length),
        a.params.flipEffect.slideShadows)
      ) {
        var v = a.isHorizontal()
            ? i.find(".swiper-slide-shadow-left")
            : i.find(".swiper-slide-shadow-top"),
          f = a.isHorizontal()
            ? i.find(".swiper-slide-shadow-right")
            : i.find(".swiper-slide-shadow-bottom");
        v.length === 0 &&
          ((v = g(
            '<div class="swiper-slide-shadow-' +
              (a.isHorizontal() ? "left" : "top") +
              '"></div>'
          )),
          i.append(v)),
          f.length === 0 &&
            ((f = g(
              '<div class="swiper-slide-shadow-' +
                (a.isHorizontal() ? "right" : "bottom") +
                '"></div>'
            )),
            i.append(f)),
          v.length && (v[0].style.opacity = Math.max(-s, 0)),
          f.length && (f[0].style.opacity = Math.max(s, 0));
      }
      i.transform(
        "translate3d(" +
          p +
          "px, " +
          c +
          "px, 0px) rotateX(" +
          u +
          "deg) rotateY(" +
          d +
          "deg)"
      );
    }
  },
  setTransition: function (a) {
    var e = this,
      t = e.slides,
      r = e.activeIndex,
      i = e.$wrapperEl;
    if (
      (t
        .transition(a)
        .find(
          ".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left"
        )
        .transition(a),
      e.params.virtualTranslate && a !== 0)
    ) {
      var s = !1;
      t.eq(r).transitionEnd(function () {
        if (!s && !(!e || e.destroyed)) {
          (s = !0), (e.animating = !1);
          for (
            var o = ["webkitTransitionEnd", "transitionend"], d = 0;
            d < o.length;
            d += 1
          )
            i.trigger(o[d]);
        }
      });
    }
  },
};
const Va = {
  name: "effect-flip",
  params: { flipEffect: { slideShadows: !0, limitRotation: !0 } },
  create: function () {
    var a = this;
    z(a, { flipEffect: sa({}, Fa) });
  },
  on: {
    beforeInit: function (a) {
      if (a.params.effect === "flip") {
        a.classNames.push(a.params.containerModifierClass + "flip"),
          a.classNames.push(a.params.containerModifierClass + "3d");
        var e = {
          slidesPerView: 1,
          slidesPerColumn: 1,
          slidesPerGroup: 1,
          watchSlidesProgress: !0,
          spaceBetween: 0,
          virtualTranslate: !0,
        };
        O(a.params, e), O(a.originalParams, e);
      }
    },
    setTranslate: function (a) {
      a.params.effect === "flip" && a.flipEffect.setTranslate();
    },
    setTransition: function (a, e) {
      a.params.effect === "flip" && a.flipEffect.setTransition(e);
    },
  },
};
function na() {
  return (
    (na =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    na.apply(this, arguments)
  );
}
var Ba = {
  setTranslate: function () {
    for (
      var a = this,
        e = a.width,
        t = a.height,
        r = a.slides,
        i = a.slidesSizesGrid,
        s = a.params.coverflowEffect,
        l = a.isHorizontal(),
        o = a.translate,
        d = l ? -o + e / 2 : -o + t / 2,
        u = l ? s.rotate : -s.rotate,
        p = s.depth,
        c = 0,
        v = r.length;
      c < v;
      c += 1
    ) {
      var f = r.eq(c),
        y = i[c],
        E = f[0].swiperSlideOffset,
        m = ((d - E - y / 2) / y) * s.modifier,
        w = l ? u * m : 0,
        C = l ? 0 : u * m,
        b = -p * Math.abs(m),
        h = s.stretch;
      typeof h == "string" &&
        h.indexOf("%") !== -1 &&
        (h = (parseFloat(s.stretch) / 100) * y);
      var S = l ? 0 : h * m,
        x = l ? h * m : 0,
        $ = 1 - (1 - s.scale) * Math.abs(m);
      Math.abs(x) < 0.001 && (x = 0),
        Math.abs(S) < 0.001 && (S = 0),
        Math.abs(b) < 0.001 && (b = 0),
        Math.abs(w) < 0.001 && (w = 0),
        Math.abs(C) < 0.001 && (C = 0),
        Math.abs($) < 0.001 && ($ = 0);
      var P =
        "translate3d(" +
        x +
        "px," +
        S +
        "px," +
        b +
        "px)  rotateX(" +
        C +
        "deg) rotateY(" +
        w +
        "deg) scale(" +
        $ +
        ")";
      if (
        (f.transform(P),
        (f[0].style.zIndex = -Math.abs(Math.round(m)) + 1),
        s.slideShadows)
      ) {
        var T = l
            ? f.find(".swiper-slide-shadow-left")
            : f.find(".swiper-slide-shadow-top"),
          M = l
            ? f.find(".swiper-slide-shadow-right")
            : f.find(".swiper-slide-shadow-bottom");
        T.length === 0 &&
          ((T = g(
            '<div class="swiper-slide-shadow-' +
              (l ? "left" : "top") +
              '"></div>'
          )),
          f.append(T)),
          M.length === 0 &&
            ((M = g(
              '<div class="swiper-slide-shadow-' +
                (l ? "right" : "bottom") +
                '"></div>'
            )),
            f.append(M)),
          T.length && (T[0].style.opacity = m > 0 ? m : 0),
          M.length && (M[0].style.opacity = -m > 0 ? -m : 0);
      }
    }
  },
  setTransition: function (a) {
    var e = this;
    e.slides
      .transition(a)
      .find(
        ".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left"
      )
      .transition(a);
  },
};
const ja = {
  name: "effect-coverflow",
  params: {
    coverflowEffect: {
      rotate: 50,
      stretch: 0,
      depth: 100,
      scale: 1,
      modifier: 1,
      slideShadows: !0,
    },
  },
  create: function () {
    var a = this;
    z(a, { coverflowEffect: na({}, Ba) });
  },
  on: {
    beforeInit: function (a) {
      a.params.effect === "coverflow" &&
        (a.classNames.push(a.params.containerModifierClass + "coverflow"),
        a.classNames.push(a.params.containerModifierClass + "3d"),
        (a.params.watchSlidesProgress = !0),
        (a.originalParams.watchSlidesProgress = !0));
    },
    setTranslate: function (a) {
      a.params.effect === "coverflow" && a.coverflowEffect.setTranslate();
    },
    setTransition: function (a, e) {
      a.params.effect === "coverflow" && a.coverflowEffect.setTransition(e);
    },
  },
};
function la() {
  return (
    (la =
      Object.assign ||
      function (n) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];
          for (var t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
        }
        return n;
      }),
    la.apply(this, arguments)
  );
}
var qa = {
  init: function () {
    var a = this,
      e = a.params.thumbs;
    if (a.thumbs.initialized) return !1;
    a.thumbs.initialized = !0;
    var t = a.constructor;
    return (
      e.swiper instanceof t
        ? ((a.thumbs.swiper = e.swiper),
          O(a.thumbs.swiper.originalParams, {
            watchSlidesProgress: !0,
            slideToClickedSlide: !1,
          }),
          O(a.thumbs.swiper.params, {
            watchSlidesProgress: !0,
            slideToClickedSlide: !1,
          }))
        : pa(e.swiper) &&
          ((a.thumbs.swiper = new t(
            O({}, e.swiper, {
              watchSlidesVisibility: !0,
              watchSlidesProgress: !0,
              slideToClickedSlide: !1,
            })
          )),
          (a.thumbs.swiperCreated = !0)),
      a.thumbs.swiper.$el.addClass(a.params.thumbs.thumbsContainerClass),
      a.thumbs.swiper.on("tap", a.thumbs.onThumbClick),
      !0
    );
  },
  onThumbClick: function () {
    var a = this,
      e = a.thumbs.swiper;
    if (e) {
      var t = e.clickedIndex,
        r = e.clickedSlide;
      if (
        !(r && g(r).hasClass(a.params.thumbs.slideThumbActiveClass)) &&
        !(typeof t > "u" || t === null)
      ) {
        var i;
        if (
          (e.params.loop
            ? (i = parseInt(
                g(e.clickedSlide).attr("data-swiper-slide-index"),
                10
              ))
            : (i = t),
          a.params.loop)
        ) {
          var s = a.activeIndex;
          a.slides.eq(s).hasClass(a.params.slideDuplicateClass) &&
            (a.loopFix(),
            (a._clientLeft = a.$wrapperEl[0].clientLeft),
            (s = a.activeIndex));
          var l = a.slides
              .eq(s)
              .prevAll('[data-swiper-slide-index="' + i + '"]')
              .eq(0)
              .index(),
            o = a.slides
              .eq(s)
              .nextAll('[data-swiper-slide-index="' + i + '"]')
              .eq(0)
              .index();
          typeof l > "u"
            ? (i = o)
            : typeof o > "u"
            ? (i = l)
            : o - s < s - l
            ? (i = o)
            : (i = l);
        }
        a.slideTo(i);
      }
    }
  },
  update: function (a) {
    var e = this,
      t = e.thumbs.swiper;
    if (t) {
      var r =
          t.params.slidesPerView === "auto"
            ? t.slidesPerViewDynamic()
            : t.params.slidesPerView,
        i = e.params.thumbs.autoScrollOffset,
        s = i && !t.params.loop;
      if (e.realIndex !== t.realIndex || s) {
        var l = t.activeIndex,
          o,
          d;
        if (t.params.loop) {
          t.slides.eq(l).hasClass(t.params.slideDuplicateClass) &&
            (t.loopFix(),
            (t._clientLeft = t.$wrapperEl[0].clientLeft),
            (l = t.activeIndex));
          var u = t.slides
              .eq(l)
              .prevAll('[data-swiper-slide-index="' + e.realIndex + '"]')
              .eq(0)
              .index(),
            p = t.slides
              .eq(l)
              .nextAll('[data-swiper-slide-index="' + e.realIndex + '"]')
              .eq(0)
              .index();
          typeof u > "u"
            ? (o = p)
            : typeof p > "u"
            ? (o = u)
            : p - l === l - u
            ? (o = t.params.slidesPerGroup > 1 ? p : l)
            : p - l < l - u
            ? (o = p)
            : (o = u),
            (d = e.activeIndex > e.previousIndex ? "next" : "prev");
        } else (o = e.realIndex), (d = o > e.previousIndex ? "next" : "prev");
        s && (o += d === "next" ? i : -1 * i),
          t.visibleSlidesIndexes &&
            t.visibleSlidesIndexes.indexOf(o) < 0 &&
            (t.params.centeredSlides
              ? o > l
                ? (o = o - Math.floor(r / 2) + 1)
                : (o = o + Math.floor(r / 2) - 1)
              : o > l && t.params.slidesPerGroup,
            t.slideTo(o, a ? 0 : void 0));
      }
      var c = 1,
        v = e.params.thumbs.slideThumbActiveClass;
      if (
        (e.params.slidesPerView > 1 &&
          !e.params.centeredSlides &&
          (c = e.params.slidesPerView),
        e.params.thumbs.multipleActiveThumbs || (c = 1),
        (c = Math.floor(c)),
        t.slides.removeClass(v),
        t.params.loop || (t.params.virtual && t.params.virtual.enabled))
      )
        for (var f = 0; f < c; f += 1)
          t.$wrapperEl
            .children('[data-swiper-slide-index="' + (e.realIndex + f) + '"]')
            .addClass(v);
      else
        for (var y = 0; y < c; y += 1) t.slides.eq(e.realIndex + y).addClass(v);
    }
  },
};
const Wa = {
  name: "thumbs",
  params: {
    thumbs: {
      swiper: null,
      multipleActiveThumbs: !0,
      autoScrollOffset: 0,
      slideThumbActiveClass: "swiper-slide-thumb-active",
      thumbsContainerClass: "swiper-container-thumbs",
    },
  },
  create: function () {
    var a = this;
    z(a, { thumbs: la({ swiper: null, initialized: !1 }, qa) });
  },
  on: {
    beforeInit: function (a) {
      var e = a.params.thumbs;
      !e || !e.swiper || (a.thumbs.init(), a.thumbs.update(!0));
    },
    slideChange: function (a) {
      a.thumbs.swiper && a.thumbs.update();
    },
    update: function (a) {
      a.thumbs.swiper && a.thumbs.update();
    },
    resize: function (a) {
      a.thumbs.swiper && a.thumbs.update();
    },
    observerUpdate: function (a) {
      a.thumbs.swiper && a.thumbs.update();
    },
    setTransition: function (a, e) {
      var t = a.thumbs.swiper;
      t && t.setTransition(e);
    },
    beforeDestroy: function (a) {
      var e = a.thumbs.swiper;
      e && a.thumbs.swiperCreated && e && e.destroy();
    },
  },
};
var Ua = [
  va,
  ha,
  ba,
  Ea,
  Ca,
  Sa,
  Ta,
  Ma,
  Pa,
  Oa,
  ka,
  Da,
  Na,
  Xa,
  Ya,
  Ra,
  Va,
  ja,
  Wa,
];
fa.use(Ua);
