import {
  d as r,
  i as m,
  a,
  _ as s,
  r as c,
  o as n,
  c as t,
  h as d,
  b,
  n as u,
} from "./index.js";
import { T as h } from "./TrackingPushService-374dd83c.js";
import { J as p, a as _ } from "./JumpToEventBus-9bec3b36.js";
import { _ as k } from "./_plugin-vue_export-helper-c27b6911.js";
import "./mitt-f7ef348c.js";
const f = a(() =>
    s(
      () => import("./Icon.ce-1a736152.js"),
      [
        "./Icon.ce-1a736152.js",
        "./index.js",
        "./index.css",
        "./ResizeUpdateMixin-a56b9b41.js",
        "./debounce-af874a22.js",
        "./_commonjsHelpers-725317a4.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  x = a(() =>
    s(
      () => import("./linkedin-2ad50dac.js"),
      ["./linkedin-2ad50dac.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  I = r({
    name: "BrandhubSocialMediaBoxItem",
    props: {
      iconName: String,
      linkUrl: String,
      linkTitle: String,
      editMode: Boolean,
      itemIndex: Number,
    },
    components: { BrandhubIcon: f, LinkedinIcon: x },
    methods: {
      onFocusIn() {
        this.$el.scrollIntoView({ block: "center" });
      },
      onItemClick() {
        if (this.linkUrl && this.linkTitle) {
          const i = this.linkUrl,
            e = this.linkTitle;
          h.pushTrackingAttributes("link", "Social Media Box", e, i);
        }
      },
      focusItem() {
        var i;
        this.itemIndex === 0 && ((i = this.link) == null || i.focus());
      },
    },
    computed: {
      rootClasses() {
        return { "brandhub-social-media-box-item--edit-mode": this.editMode };
      },
    },
    setup() {
      return { link: m() };
    },
    created() {
      p.on(_.JumpToFooter, this.focusItem);
    },
  }),
  v = `.brandhub-social-media-box-item{list-style:none}.brandhub-social-media-box-item__icon{height:1.7142857143rem;transition:opacity .2s ease-in;width:1.7142857143rem}@media (min-width: 768px){.brandhub-social-media-box-item__icon{height:2.4285714286rem;width:2.4285714286rem}}.brandhub-social-media-box-item__icon:hover{opacity:.8}.brandhub-social-media-box-item__wb{fill:var(--icon-color, currentColor)}.brandhub-social-media-box-item__link{color:var(--text-color);display:inline-flex}.brandhub-social-media-box-item__link:focus-visible{position:relative;outline:none}.brandhub-social-media-box-item__link:focus-visible:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-social-media-box-item__link:focus-visible:after{left:-.7142857143rem;padding:.5rem;top:-.6428571429rem}.brandhub-social-media-box-item--edit-mode{align-items:center;display:flex;justify-content:center;min-height:100px;min-width:80px;padding-bottom:30px}
`,
  g = ["href", "title"],
  y = ["icon"];
function B(i, e, T, C, w, E) {
  const l = c("linkedin-icon");
  return (
    n(),
    t(
      "span",
      { class: u(["brandhub-social-media-box-item", i.rootClasses]) },
      [
        d(
          "a",
          {
            class: "brandhub-social-media-box-item__link",
            href: i.linkUrl,
            ref: "link",
            target: "_blank",
            rel: "noopener",
            title: i.linkTitle,
            onFocusin:
              e[0] || (e[0] = (...o) => i.onFocusIn && i.onFocusIn(...o)),
            onClick:
              e[1] || (e[1] = (...o) => i.onItemClick && i.onItemClick(...o)),
          },
          [
            i.iconName == "linkedin"
              ? (n(),
                b(l, {
                  key: 0,
                  class:
                    "brandhub-social-media-box-item__icon brandhub-social-media-box-item__wb",
                }))
              : (n(),
                t(
                  "brandhub-icon",
                  {
                    key: 1,
                    icon: i.iconName,
                    class: "brandhub-social-media-box-item__icon",
                  },
                  null,
                  8,
                  y
                )),
          ],
          40,
          g
        ),
      ],
      2
    )
  );
}
const A = k(I, [
  ["render", B],
  ["styles", [v]],
]);
export { A as default };
