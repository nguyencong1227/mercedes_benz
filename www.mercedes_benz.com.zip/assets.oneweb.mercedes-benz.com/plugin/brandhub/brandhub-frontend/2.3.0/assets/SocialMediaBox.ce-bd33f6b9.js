import {
  d,
  a as c,
  _ as m,
  r as b,
  j as h,
  o,
  c as a,
  h as u,
  b as p,
  k as _,
  M as x,
  w as f,
  n,
  B as r,
  f as g,
} from "./index.js";
import { I as w } from "./index-12214b95.js";
import { J as v, a as k } from "./JumpToEventBus-9bec3b36.js";
import { _ as y } from "./_plugin-vue_export-helper-c27b6911.js";
import "./mitt-f7ef348c.js";
const B = c(() =>
    m(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  C = d({
    name: "BrandhubSocialMediaBox",
    props: {
      headline: String,
      headlineTag: {
        type: String,
        default: "h2",
        validator: (e) => ["h2", "h3", "h4", "h5", "h6"].includes(e),
      },
      color: {
        type: String,
        default: "white",
        validator: (e) => ["white", "black"].includes(e),
      },
      editMode: Boolean,
    },
    components: { WordFade: B },
    directives: { intersect: w },
    data() {
      return { isIntersecting: !1 };
    },
    methods: {
      handleIntersection(e, i) {
        const { top: t } = i.getBoundingClientRect();
        e || t <= 0
          ? (this.isIntersecting = !0)
          : e || (this.isIntersecting = !1);
      },
      scrollToFooter() {
        this.$el.scrollIntoView({ behavior: "smooth" });
      },
    },
    computed: {
      rootClasses() {
        return {
          "brandhub-social-media-box--color-black": this.color === "black",
          "brandhub-social-media-box--color-white": this.color === "white",
          "brandhub-social-media-box--edit-mode": this.editMode,
        };
      },
    },
    created() {
      v.on(k.JumpToFooter, this.scrollToFooter);
    },
  }),
  I = `.brandhub-social-media-box{display:flex;flex-direction:column}.brandhub-social-media-box--color-white{--text-color: var(--wb-black);background-color:#fff}.brandhub-social-media-box--color-black{--text-color: var(--wb-white);background-color:#000}.brandhub-social-media-box__content-wrapper{margin:0 10%}.brandhub-social-media-box__link-button-container{margin-bottom:4.5714285714rem}@media (min-width: 768px){.brandhub-social-media-box__link-button-container{margin-bottom:8rem}}@media (min-width: 1440px){.brandhub-social-media-box__link-button-container{margin-bottom:9.1428571429rem}}.brandhub-social-media-box__link-button-container{display:flex;flex-wrap:wrap;justify-content:center;opacity:0;padding-left:0;row-gap:2.8571428571rem;text-align:center;transition:opacity .5s;z-index:2}.brandhub-social-media-box__link-button-container--shown{opacity:1;transition-duration:1.5s}.brandhub-social-media-box__link-button-container>:empty,.brandhub-social-media-box__link-button-container .socialmediaboxitem{display:inline-block}.brandhub-social-media-box__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;color:var(--text-color);display:block;font-size:2.2857142857rem;justify-content:center!important;line-height:2.8571428571rem;margin:4.5714285714rem auto 2.8571428571rem;text-align:center}@media (min-width: 768px){.brandhub-social-media-box__headline{font-size:3.4285714286rem;line-height:4.2857142857rem;margin:8rem auto 4.2857142857rem}}@media (min-width: 1440px){.brandhub-social-media-box__headline{font-size:4.5714285714rem;line-height:5.1428571429rem;margin:9.1428571429rem auto 5.7142857143rem}}.brandhub-social-media-box--edit-mode .new{height:2.875rem;margin:0 auto;width:10rem}::slotted(div){column-gap:4.5714285714rem;display:flex;flex-wrap:wrap;justify-content:center;padding-left:0;row-gap:2.8571428571rem;text-align:center;z-index:2}@media (min-width: 768px){::slotted(div){column-gap:5.7142857143rem}}@media (min-width: 1440px){::slotted(div){column-gap:10rem}}
`,
  T = { class: "brandhub-social-media-box__content-wrapper" };
function $(e, i, t, z, E, M) {
  const s = b("word-fade"),
    l = h("intersect");
  return (
    o(),
    a(
      "div",
      { class: n(["brandhub-social-media-box", e.rootClasses]) },
      [
        u("div", T, [
          (o(),
          p(
            x(e.headlineTag),
            { class: "brandhub-social-media-box__headline" },
            {
              default: _(() => [
                g(
                  s,
                  {
                    "animated-text": e.headline,
                    "text-align": "always-center",
                  },
                  null,
                  8,
                  ["animated-text"]
                ),
              ]),
              _: 1,
            }
          )),
          f(
            (o(),
            a(
              "nav",
              {
                class: n([
                  "brandhub-social-media-box__link-button-container",
                  {
                    "brandhub-social-media-box__link-button-container--shown":
                      e.isIntersecting,
                  },
                ]),
              },
              [r(e.$slots, "icons"), r(e.$slots, "default")],
              2
            )),
            [[l, { onChange: e.handleIntersection }]]
          ),
        ]),
      ],
      2
    )
  );
}
const V = y(C, [
  ["render", $],
  ["styles", [I]],
]);
export { V as default };
