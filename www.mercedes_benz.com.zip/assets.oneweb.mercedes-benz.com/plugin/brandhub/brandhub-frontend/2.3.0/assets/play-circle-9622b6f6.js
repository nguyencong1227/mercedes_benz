import { o, c as t, h as e } from "./index.js";
const c = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 40 40" },
  l = e(
    "g",
    { fill: "none", "fill-rule": "evenodd" },
    [
      e("circle", { cx: "20", cy: "20", r: "20", fill: "#FFF" }),
      e("path", {
        fill: "#000",
        d: "m19.66 15.947 3.846 3.381a1 1 0 0 1 0 1.502l-3.846 3.382A1 1 0 0 1 18 23.46v-6.763a1 1 0 0 1 1.66-.751z",
      }),
    ],
    -1
  ),
  r = [l];
function n(s, a) {
  return o(), t("svg", c, [...r]);
}
const d = { render: n };
export { d as default, n as render };
