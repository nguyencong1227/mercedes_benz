import { T as l } from "./TrackingPushService-374dd83c.js";
import { i as s } from "./i18next-3def9235.js";
import { C as r } from "./ChildComponentMixin-dd022493.js";
import { d as o, o as b, c, h as a, t, n as h } from "./index.js";
import { _ as u } from "./_plugin-vue_export-helper-c27b6911.js";
const g = { "language-switch": "Language Switch" },
  d = { "language-switch": "Sprachschalter" };
function m() {
  const e = s.createInstance();
  return (
    e.init({
      lng:
        document.body.dataset.analyticsLanguage ||
        {}.VUE_APP_I18N_LOCALE ||
        "en",
      resources: { en: { translation: g }, de: { translation: d } },
    }),
    e
  );
}
const _ = o({
    props: {
      linkRef: String,
      isActive: Boolean,
      labelDesktop: String,
      labelMobile: String,
    },
    mixins: [r],
    setup() {
      const { t: e } = m();
      return { t: e };
    },
    methods: {
      onItemClick() {
        if (this.linkRef && this.labelDesktop) {
          const e = this.linkRef,
            i = this.labelDesktop;
          l.pushTrackingAttributes("link", "Language Switcher", i, e);
        }
      },
    },
    created() {
      this.initChildComponentMixin("LanguageSwitcherItem");
    },
  }),
  p = `.brandhub-language-switcher-item{display:inline-block}.brandhub-language-switcher-item__link{color:var(--language-switcher-footer-color, var(--wb-grey-45));text-decoration:none;transition:color .25s}.brandhub-language-switcher-item__link:hover{color:var(--text-color, var(--wb-white));text-decoration:none}.brandhub-language-switcher-item__link:focus-visible{color:var(--text-color, var(--wb-white));outline:none}.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-mobile,.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-desktop{position:relative}.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-mobile:after,.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-desktop:after{border:3px solid rgba(0,120,214,.8);content:"";display:block;height:100%;position:absolute;width:100%}.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-mobile:after,.brandhub-language-switcher-item__link:focus-visible .brandhub-language-switcher-item__label-desktop:after{left:-.5rem;padding-right:.5rem;top:-.1428571429rem}.brandhub-language-switcher-item__link--active{color:var(--text-color, var(--wb-white));cursor:none;pointer-events:none}@media (min-width: 768px){.brandhub-language-switcher-item__label-mobile{display:none}}@media (max-width: 767px){.brandhub-language-switcher-item__label-desktop{display:none}}
`,
  w = { class: "brandhub-language-switcher-item" },
  k = ["href", "aria-label"],
  f = { class: "brandhub-language-switcher-item__label-mobile" },
  v = { class: "brandhub-language-switcher-item__label-desktop" };
function C(e, i, y, S, I, D) {
  return (
    b(),
    c("div", w, [
      a(
        "a",
        {
          class: h([
            "brandhub-language-switcher-item__link",
            { "brandhub-language-switcher-item__link--active": e.isActive },
          ]),
          href: e.linkRef,
          "aria-label": `${e.t("language-switch")} - ${e.labelDesktop}`,
          role: "listitem",
          onClick:
            i[0] || (i[0] = (...n) => e.onItemClick && e.onItemClick(...n)),
        },
        [
          a("span", f, t(e.labelMobile || e.labelDesktop), 1),
          a("span", v, t(e.labelDesktop), 1),
        ],
        10,
        k
      ),
    ])
  );
}
const M = u(_, [
  ["render", C],
  ["styles", [p]],
]);
export { M as default };
