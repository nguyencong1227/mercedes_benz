import {
  d as o,
  a as l,
  _ as m,
  r as i,
  o as n,
  c as a,
  h as s,
  f as r,
  n as g,
  t as p,
  e as c,
  g as u,
} from "./index.js";
import { B as f } from "./BackgroundColorMixin-87cd4cac.js";
import h from "./ResponsiveImage-0ce28426.js";
import { _ } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./index-12214b95.js";
const b = l(() =>
    m(
      () => import("./ExpandMedia-7448cde8.js"),
      [
        "./ExpandMedia-7448cde8.js",
        "./ExpandMedia.vue_vue_type_script_lang-73e76b3f.js",
        "./index.js",
        "./index.css",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./ExpandedMediaEventEmitter-0b86e5ec.js",
        "./mitt-f7ef348c.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  y = o({
    props: {
      bgColor: { type: String, default: "black" },
      fullWidth: { type: Boolean, default: !1 },
      pictureJson: String,
      title: String,
      legalCopy: String,
    },
    components: { ResponsiveImage: h, ExpandMedia: b },
    mixins: [f],
    computed: {
      rootClass() {
        return {
          "brandhub-fullscreen-image__image-container": !this.fullWidth,
          "brandhub-fullscreen-image__image-container--fullwidth":
            this.fullWidth,
        };
      },
    },
  }),
  v = `.brandhub-fullscreen-image{background-color:var(--background-color);display:flex;flex-direction:column;height:max-content;width:100%}.brandhub-fullscreen-image__image-container{padding-left:1.1428571429rem;padding-right:1.1428571429rem;position:relative}@media (min-width: 768px){.brandhub-fullscreen-image__image-container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-fullscreen-image__image-container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-fullscreen-image__image-container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-fullscreen-image__image-container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-fullscreen-image__image-container--fullwidth{margin:0;overflow:hidden;position:relative}.brandhub-fullscreen-image__image{height:100%;width:100%}.brandhub-fullscreen-image__description{padding-left:1.1428571429rem;padding-right:1.1428571429rem;color:var(--text-color);font-size:1rem}@media (min-width: 768px){.brandhub-fullscreen-image__description{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-fullscreen-image__description{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-fullscreen-image__description{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-fullscreen-image__description{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}
`,
  w = { key: 0, class: "brandhub-fullscreen-image__description" };
function x(e, C, k, B, S, j) {
  const t = i("responsive-image"),
    d = i("expand-media");
  return (
    n(),
    a(
      "div",
      {
        class: "brandhub-fullscreen-image",
        style: u(e.getBackgroundColorStyle),
      },
      [
        s(
          "div",
          { class: g(e.rootClass) },
          [
            r(
              t,
              {
                class: "brandhub-fullscreen-image__image",
                "picture-json": e.pictureJson,
                "object-fit": "contain",
              },
              null,
              8,
              ["picture-json"]
            ),
            r(
              d,
              { "picture-json": e.pictureJson, trackingLabel: e.title },
              null,
              8,
              ["picture-json", "trackingLabel"]
            ),
          ],
          2
        ),
        e.legalCopy ? (n(), a("p", w, p(e.legalCopy), 1)) : c("", !0),
      ],
      4
    )
  );
}
const L = _(y, [
  ["render", x],
  ["styles", [v]],
]);
export { L as default };
