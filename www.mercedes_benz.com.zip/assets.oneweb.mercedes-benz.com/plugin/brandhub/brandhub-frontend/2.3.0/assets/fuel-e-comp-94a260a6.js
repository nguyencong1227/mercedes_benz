import { o as e, c as o, h as t } from "./index.js";
const a = { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 58 70" },
  l = t(
    "path",
    {
      fill: "currentColor",
      d: "M57.62 23.59v-7.73H44.31V4a4 4 0 0 0-4-4h-1.39a4 4 0 0 0-4 4v11.9H23V4a4 4 0 0 0-4-4h-1.35a4 4 0 0 0-4 4v11.9H.38v7.73h4.38v.95a66.44 66.44 0 0 0 .31 8.6A24.14 24.14 0 0 0 26 53.45V70h7V53.34l.7-.11A24 24 0 0 0 53 32.5a88.13 88.13 0 0 0 .22-8.91h4.4zM25.38 44.38H24l3.58-9.21h-3.64l8.68-10.83H34l-3.58 9.21h3.67l-8.71 10.83z",
    },
    null,
    -1
  ),
  r = [l];
function s(c, h) {
  return e(), o("svg", a, [...r]);
}
const d = { render: s };
export { d as default, s as render };
