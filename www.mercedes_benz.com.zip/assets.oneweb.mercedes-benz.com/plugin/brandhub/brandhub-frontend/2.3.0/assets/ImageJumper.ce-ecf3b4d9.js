import {
  d as k,
  i as I,
  a as v,
  _ as f,
  r as h,
  o as a,
  c as m,
  f as _,
  e as b,
  h as o,
  n,
  B as C,
  g as c,
  b as d,
  k as s,
  M as p,
  F as j,
  D as w,
  t as T,
} from "./index.js";
import A from "./ImageJumperItem.ce-288f17d2.js";
import L from "./WordFade-cd7ee7b7.js";
import { T as M } from "./TrackingPushService-374dd83c.js";
import { P as B, C as z } from "./ParentComponentMixin-b739cccc.js";
import { S } from "./ShadowDom-bc0a555e.js";
import { R as $ } from "./ResizeUpdateMixin-a56b9b41.js";
import { _ as P } from "./_plugin-vue_export-helper-c27b6911.js";
import "./ResponsiveImage-0ce28426.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import "./index-12214b95.js";
import "./ChildComponentMixin-dd022493.js";
import "./BrandSafeHyphens-ffe3b60a.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const F = v(() =>
    f(
      () => import("./arrow_new_window-1dbf2132.js"),
      ["./arrow_new_window-1dbf2132.js", "./index.js", "./index.css"],
      import.meta.url
    )
  ),
  H = v(() =>
    f(
      () => import("./Co2Labeling.ce-c45f884c.js"),
      [
        "./Co2Labeling.ce-c45f884c.js",
        "./index.js",
        "./index.css",
        "./i18next-3def9235.js",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  D = k({
    name: "ImageJumper",
    props: {
      headline: String,
      textColor: { type: String, default: "inverted" },
      removeSpacingTop: Boolean,
      removeSpacingBottom: Boolean,
    },
    components: {
      "icon-arrow-new-window": F,
      ImageJumperItem: A,
      WordFade: L,
      Co2Labeling: H,
    },
    setup() {
      return { buttons: I() };
    },
    mixins: [B, $],
    data() {
      return {
        items: new z(),
        activeItem: null,
        buttonsHeight: 0,
        buttonsVisible: !0,
        isTouchAction: !1,
      };
    },
    computed: {
      rootClass() {
        return {
          "brandhub-image-jumper--text-inverted": this.textColor === "inverted",
          "brandhub-image-jumper--text-primary": this.textColor === "primary",
          "brandhub-image-jumper--text-theme": this.textColor === "theme",
          "brandhub-image-jumper--one-button": this.items.length === 1,
          "brandhub-image-jumper--two-buttons": this.items.length === 2,
          "brandhub-image-jumper--three-buttons": this.items.length === 3,
          "brandhub-image-jumper--no-spacing-top": this.removeSpacingTop,
          "brandhub-image-jumper--no-spacing-bottom": this.removeSpacingBottom,
        };
      },
      buttonItems() {
        return this.items.filter((e) => !!e.text);
      },
      dynamicMargin() {
        return this.isMobile
          ? `margin-bottom: ${Math.floor(this.buttonsHeight / 2)}px`
          : "";
      },
      dynamicHeight() {
        return this.isMobile
          ? `height: calc(100% + ${this.buttonsHeight / 2 + 1}px)`
          : "";
      },
      wrapperClass() {
        return { "brandhub-image-jumper__wrapper": this.items.length !== 0 };
      },
      contentClass() {
        return { "brandhub-image-jumper__content": this.items.length !== 0 };
      },
    },
    methods: {
      buttonClass(e) {
        const t = this.hasLink(this.items.items[e]),
          u = this.items.items[e] === this.activeItem;
        return {
          "brandhub-image-jumper__button-link": t,
          "brandhub-image-jumper__button": !t,
          "brandhub-image-jumper__button-link--active": t && u && e === 0,
          "brandhub-image-jumper__button--active": !t && u && e === 0,
        };
      },
      onItemAdded(e) {
        const t = e;
        (!this.activeItem || !S.isInDocument(this.activeItem.$el)) &&
          (this.clearPreviousActiveStatus(),
          (t.status = "active"),
          (this.activeItem = t)),
          this.items.length === 1 &&
            ((t.initialItem = !0), (t.singleButton = !0)),
          this.items.length === 2 && (this.items.items[0].singleButton = !1);
      },
      gotoItem(e) {
        e !== this.activeItem &&
          !this.isTouchAction &&
          (this.clearPreviousActiveStatus(),
          this.activeItem && (this.activeItem.status = "previous-active"),
          (this.activeItem = e),
          (e.status = "active"));
      },
      resetActiveItem(e) {
        const t = e.relatedTarget;
        (t.classList.contains("brandhub-image-jumper__overlay") ||
          t.classList.contains("brandhub-image-jumper__container") ||
          t.classList.contains("brandhub-image-jumper__buttons-list")) &&
          this.gotoItem(this.items.toArray()[0]);
      },
      preventMouseActionWhenTouch() {
        this.isTouchAction = !0;
      },
      clearPreviousActiveStatus() {
        for (const e of this.items.items)
          e.status === "previous-active" && (e.status = null);
      },
      onFocusOut(e) {
        e.relatedTarget || this.gotoItem(this.items.toArray()[0]);
      },
      updateButtonsHeight() {
        this.buttons &&
          (this.buttonsHeight = this.buttons.getBoundingClientRect().height);
      },
      hasLink(e) {
        return !!(e.externalLink || e.internalLink);
      },
      onItemClick(e) {
        if (this.hasLink(e)) {
          const t = e.externalLink || e.internalLink,
            u = e.text;
          M.pushTrackingAttributes("link", "image jumper", u, t);
        }
      },
    },
    created() {
      this.initParentComponentMixin(
        this.items,
        ["ImageJumperItem"],
        this.onItemAdded
      );
    },
    updated() {
      this.updateButtonsHeight();
    },
  }),
  V = `@keyframes brandhub-image-jumper-in{0%{transform:translateY(50px)}to{transform:translate(0)}}.brandhub-image-jumper{padding-top:1.7142857143rem;padding-bottom:1.7142857143rem;color:var(--text-on-base-color)}@media (min-width: 1024px){.brandhub-image-jumper{padding-top:2.2857142857rem}}@media (min-width: 1440px){.brandhub-image-jumper{padding-top:2.5714285714rem}}@media (min-width: 1024px){.brandhub-image-jumper{padding-bottom:2.2857142857rem}}@media (min-width: 1440px){.brandhub-image-jumper{padding-bottom:2.5714285714rem}}.brandhub-image-jumper--no-spacing-top{padding-top:0}.brandhub-image-jumper--no-spacing-bottom{padding-bottom:0}@media (min-width: 1024px){.brandhub-image-jumper--text-primary{color:var(--base-color)}}.brandhub-image-jumper--text-theme{color:var(--campaign-text)}@media (max-width: 1023px){.brandhub-image-jumper--three-buttons .brandhub-image-jumper__content{display:grid;grid-template-rows:repeat(3,1fr)}}@media (max-width: 767px){.brandhub-image-jumper--three-buttons .brandhub-image-jumper__content>*{--item-height: calc(177.7777777778vw / 3);height:var(--item-height)}}@media (min-width: 768px) and (max-width: 1023px){.brandhub-image-jumper--three-buttons .brandhub-image-jumper__content>*{--item-height: calc(133.33vw / 3);height:var(--item-height)}}@media (max-width: 1023px){.brandhub-image-jumper--two-buttons .brandhub-image-jumper__content{display:grid;grid-template-rows:repeat(2,1fr)}}@media (max-width: 767px){.brandhub-image-jumper--two-buttons .brandhub-image-jumper__content>*{--item-height: calc(177.7777777778vw / 2);height:var(--item-height)}}@media (min-width: 768px) and (max-width: 1023px){.brandhub-image-jumper--two-buttons .brandhub-image-jumper__content>*{--item-height:66.665vw;height:var(--item-height)}}@media (max-width: 1023px){.brandhub-image-jumper--one-button .brandhub-image-jumper__content{display:grid;grid-template-rows:repeat(1,1fr)}}@media (max-width: 767px){.brandhub-image-jumper--one-button .brandhub-image-jumper__content>*{--item-height: calc(177.7777777778vw / 1);height:var(--item-height)}}@media (min-width: 768px) and (max-width: 1023px){.brandhub-image-jumper--one-button .brandhub-image-jumper__content>*{--item-height:133.33vw;height:var(--item-height)}}@media (max-width: 1023px){.brandhub-image-jumper--three-buttons .brandhub-image-jumper__overlay,.brandhub-image-jumper--two-buttons .brandhub-image-jumper__overlay,.brandhub-image-jumper--one-button .brandhub-image-jumper__overlay{display:none}}.brandhub-image-jumper__headline-mobile{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;padding:1.9285714286rem 1.1428571429rem;font-size:2.8571428571rem;margin:0}@media (min-width: 768px){.brandhub-image-jumper__headline-mobile{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-image-jumper__headline-mobile{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-image-jumper__headline-mobile{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-image-jumper__headline-mobile{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 480px){.brandhub-image-jumper__headline-mobile{padding-bottom:3.4285714286rem;padding-top:2.7857142857rem}}@media (min-width: 1024px){.brandhub-image-jumper__headline-mobile{display:none}}.brandhub-image-jumper__wrapper{display:grid;grid-template:"content" 100%/100%;height:177.7777777778vw;width:100%}@media (min-width: 768px){.brandhub-image-jumper__wrapper{height:133.33vw}}@media (min-width: 1024px){.brandhub-image-jumper__wrapper{height:56.25vw}}.brandhub-image-jumper__content{animation:brandhub-image-jumper-in .8s;grid-area:content;overflow:hidden;position:relative;z-index:1}.brandhub-image-jumper__overlay{grid-area:content;position:relative;z-index:2}.brandhub-image-jumper__overlay:after{background-image:radial-gradient(circle at 50% 117%,var(--wb-black),rgba(0,0,0,.5) 6%,rgba(0,0,0,0) 19%),linear-gradient(to bottom,rgba(0,0,0,0),var(--wb-black));bottom:0;content:"";display:block;height:20%;position:absolute;width:100%}.brandhub-image-jumper__container{padding-left:1.1428571429rem;padding-right:1.1428571429rem;display:flex;flex-direction:column;height:100%;justify-content:space-between}@media (min-width: 768px){.brandhub-image-jumper__container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-image-jumper__container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-image-jumper__container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-image-jumper__container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-image-jumper__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:2.8571428571rem;margin-bottom:0;margin-top:4.2857142857rem}@media (min-width: 480px){.brandhub-image-jumper__headline{margin-bottom:2.1428571429rem;margin-left:0}}@media (min-width: 550px){.brandhub-image-jumper__headline{margin-top:7.1428571429rem}}@media (min-width: 768px){.brandhub-image-jumper__headline{margin-top:7.1428571429rem;max-width:69%}}@media (min-width: 1024px){.brandhub-image-jumper__headline{margin-bottom:0;max-width:65%}}@media (min-width: 1280px){.brandhub-image-jumper__headline{font-size:5.1428571429rem;max-width:55%}}@media (min-width: 1920px){.brandhub-image-jumper__headline{margin-top:8.5714285714rem}}.brandhub-image-jumper__buttons{margin-bottom:auto;margin-top:auto;opacity:0;transition:opacity .5s;visibility:hidden;width:100%;z-index:1}@media (min-width: 1024px){.brandhub-image-jumper__buttons{margin-bottom:3.5714285714rem}}.brandhub-image-jumper__buttons--visible{opacity:1;visibility:visible}.brandhub-image-jumper__buttons-list{list-style:none;margin:0;padding:0}@media (min-width: 550px){.brandhub-image-jumper__buttons-list{display:flex}}.brandhub-image-jumper__buttons-list-item{padding:.5357142857rem 0;width:100%}@media (min-width: 550px){.brandhub-image-jumper__buttons-list-item{height:100%;padding:0 1.0714285714rem 0 0}}@media (min-width: 768px){.brandhub-image-jumper__buttons-list-item{width:33%}}.brandhub-image-jumper__buttons-list-item:first-of-type{padding-top:0}.brandhub-image-jumper__buttons-list-item:last-of-type{padding-bottom:0;padding-right:0}.brandhub-image-jumper__button-link,.brandhub-image-jumper__button{align-items:center;-webkit-backdrop-filter:blur(15px);backdrop-filter:blur(15px);background-color:#0006;border:1px solid var(--wb-white);border-radius:1.0714285714rem;color:var(--wb-white);display:flex;height:1.4285714286rem;justify-content:space-between;padding:2.3571428571rem 2.1428571429rem;text-decoration:none;transition:background-color .25s,color .25s}@media (min-width: 1440px){.brandhub-image-jumper__button-link,.brandhub-image-jumper__button{padding:3.7857142857rem 2.1428571429rem}}@media (min-width: 1920px){.brandhub-image-jumper__button-link,.brandhub-image-jumper__button{padding:4.2142857143rem 2.1428571429rem}}.brandhub-image-jumper__button-link:hover,.brandhub-image-jumper__button-link:focus,.brandhub-image-jumper__button:hover,.brandhub-image-jumper__button:focus{background:var(--wb-white);color:var(--wb-black)}.brandhub-image-jumper__button-link[href] .brandhub-image-jumper__button-text,.brandhub-image-jumper__button[href] .brandhub-image-jumper__button-text{cursor:pointer}.brandhub-image-jumper__button-link--active:not(.brandhub-image-jumper__button-link:hover,.brandhub-image-jumper__button:hover):not(.brandhub-image-jumper__button-link:focus,.brandhub-image-jumper__button:focus),.brandhub-image-jumper__button--active:not(.brandhub-image-jumper__button-link:hover,.brandhub-image-jumper__button:hover):not(.brandhub-image-jumper__button-link:focus,.brandhub-image-jumper__button:focus){outline:1px solid var(--wb-white)}.brandhub-image-jumper__button-text{cursor:default;font-size:1.1428571429rem;line-height:1.8571428571rem}@media (min-width: 768px){.brandhub-image-jumper__button-text{font-size:1.2857142857rem}}.brandhub-image-jumper__button-icon{flex-shrink:0;height:1.4285714286rem;padding-left:.3571428571rem;width:1.4285714286rem}.brandhub-image-jumper__button-icon--hidden{visibility:hidden}.brandhub-image-jumper__labeling-wrapper{--co2-labeling-font-size: .8571428571rem;--co2-labeling-color: var(--wb-white);display:grid;grid-template:"labeling" 100%/100%;margin-bottom:1.9285714286rem}@media (min-width: 1440px){.brandhub-image-jumper__labeling-wrapper{margin-bottom:2.5rem}}@media (min-width: 1920px){.brandhub-image-jumper__labeling-wrapper{margin-bottom:2.8571428571rem}}.brandhub-image-jumper__labeling{grid-area:labeling;visibility:hidden;z-index:1}.brandhub-image-jumper__labeling--active{visibility:visible}.brandhub-image-jumper .brandhub-co2-labeling__models{font-size:1.1428571429rem}@media (min-width: 1680px){.brandhub-image-jumper .brandhub-co2-labeling__models{font-size:1.2857142857rem}}
`,
  E = { key: 0, class: "brandhub-image-jumper__headline-mobile" },
  J = { class: "brandhub-image-jumper__container" },
  R = { key: 0, class: "brandhub-image-jumper__headline" },
  W = { class: "brandhub-image-jumper__button-text" },
  N = { class: "brandhub-image-jumper__labeling-wrapper" };
function O(e, t, u, U, Y, q) {
  const g = h("word-fade"),
    x = h("icon-arrow-new-window"),
    y = h("co2-labeling");
  return (
    a(),
    m(
      "div",
      {
        class: n(["brandhub-image-jumper", e.rootClass]),
        style: c(e.dynamicMargin),
      },
      [
        e.headline
          ? (a(),
            m("h2", E, [
              _(g, { "animated-text": e.headline }, null, 8, ["animated-text"]),
            ]))
          : b("", !0),
        o(
          "div",
          { class: n(e.wrapperClass) },
          [
            o("div", { class: n(e.contentClass) }, [C(e.$slots, "default")], 2),
            e.items.length > 0
              ? (a(),
                m(
                  "div",
                  {
                    key: 0,
                    class: "brandhub-image-jumper__overlay",
                    style: c(e.dynamicHeight),
                  },
                  [
                    o("div", J, [
                      e.headline
                        ? (a(),
                          m("h2", R, [
                            _(g, { "animated-text": e.headline }, null, 8, [
                              "animated-text",
                            ]),
                          ]))
                        : b("", !0),
                      o(
                        "div",
                        {
                          class: n([
                            "brandhub-image-jumper__buttons",
                            {
                              "brandhub-image-jumper__buttons--visible":
                                e.buttonsVisible,
                            },
                          ]),
                          ref: "buttons",
                        },
                        [
                          (a(),
                          d(
                            p(e.buttonItems.length > 1 ? "ul" : "div"),
                            { class: "brandhub-image-jumper__buttons-list" },
                            {
                              default: s(() => [
                                (a(!0),
                                m(
                                  j,
                                  null,
                                  w(
                                    e.buttonItems,
                                    (i, l) => (
                                      a(),
                                      d(
                                        p(
                                          e.buttonItems.length > 1
                                            ? "li"
                                            : "div"
                                        ),
                                        {
                                          key: i.text,
                                          class: n([
                                            "brandhub-image-jumper__buttons-list-item",
                                            e.activeItem.index === l
                                              ? "brandhub-image-jumper__buttons-list-item--active"
                                              : "",
                                          ]),
                                          onMouseenter: (r) => e.gotoItem(i),
                                          onMouseleave:
                                            t[0] ||
                                            (t[0] = (r) =>
                                              e.resetActiveItem(r)),
                                          onTouchend:
                                            e.preventMouseActionWhenTouch,
                                          onTouchcancel:
                                            e.preventMouseActionWhenTouch,
                                          onFocusin: (r) => e.gotoItem(i),
                                          onFocusout:
                                            t[1] ||
                                            (t[1] = (r) => e.onFocusOut(r)),
                                        },
                                        {
                                          default: s(() => [
                                            (a(),
                                            d(
                                              p(e.hasLink(i) ? "a" : "div"),
                                              {
                                                class: n(e.buttonClass(l)),
                                                href:
                                                  i.externalLink ||
                                                  i.internalLink,
                                                target: i.linkTarget,
                                                onClick: (r) =>
                                                  e.onItemClick(i),
                                              },
                                              {
                                                default: s(() => [
                                                  o("span", W, T(i.text), 1),
                                                  i.externalLink
                                                    ? (a(),
                                                      d(x, {
                                                        key: 0,
                                                        class:
                                                          "brandhub-image-jumper__button-icon",
                                                      }))
                                                    : b("", !0),
                                                ]),
                                                _: 2,
                                              },
                                              1032,
                                              [
                                                "class",
                                                "href",
                                                "target",
                                                "onClick",
                                              ]
                                            )),
                                          ]),
                                          _: 2,
                                        },
                                        1064,
                                        [
                                          "class",
                                          "onMouseenter",
                                          "onTouchend",
                                          "onTouchcancel",
                                          "onFocusin",
                                        ]
                                      )
                                    )
                                  ),
                                  128
                                )),
                              ]),
                              _: 1,
                            }
                          )),
                        ],
                        2
                      ),
                      o("div", N, [
                        (a(!0),
                        m(
                          j,
                          null,
                          w(
                            e.buttonItems,
                            (i) => (
                              a(),
                              d(
                                y,
                                {
                                  class: n([
                                    "brandhub-image-jumper__labeling",
                                    {
                                      "brandhub-image-jumper__labeling--active":
                                        i.status === "active",
                                    },
                                  ]),
                                  key: i.text,
                                  "labeling-json": i.labelingJson,
                                  "layout-variant": "text-large",
                                },
                                null,
                                8,
                                ["class", "labeling-json"]
                              )
                            )
                          ),
                          128
                        )),
                      ]),
                    ]),
                  ],
                  4
                ))
              : b("", !0),
          ],
          2
        ),
      ],
      6
    )
  );
}
const be = P(D, [
  ["render", O],
  ["styles", [V]],
]);
export { be as default };
