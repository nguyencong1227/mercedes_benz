import { T as i } from "./TrackingPushService-374dd83c.js";
import { d as e } from "./index.js";
const l = "brandhub-legal-link-clicked",
  r = e({
    name: "BrandhubFooterNavigationItem",
    props: {
      linkUrl: String,
      linkTitle: String,
      linkText: String,
      linkTarget: String,
      legalActionName: String,
    },
    methods: {
      onClick() {
        this.legalActionName &&
          (window.dispatchEvent(
            new CustomEvent(l, { detail: this.legalActionName })
          ),
          i.pushTrackingAttributes(
            "link",
            "Footer Navigation",
            this.legalActionName
          ));
      },
      onItemClick() {
        if (this.linkUrl && this.linkText) {
          const t = this.linkUrl,
            n = this.linkText;
          i.pushTrackingAttributes("link", "Footer Navigation", n, t);
        }
      },
    },
  });
export { l as L, r as _ };
