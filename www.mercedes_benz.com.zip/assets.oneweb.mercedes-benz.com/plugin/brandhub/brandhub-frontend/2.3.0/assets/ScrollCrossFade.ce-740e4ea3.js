import {
  d as T,
  i as m,
  a as g,
  _ as w,
  r as c,
  j as S,
  w as k,
  o,
  c as l,
  h as p,
  F as f,
  D as V,
  n as d,
  f as P,
  e as b,
  g as E,
  b as u,
} from "./index.js";
import F from "./VideoPlayer-b44c2dc6.js";
import { T as M } from "./TextMask.ce.vue_vue_type_script_lang-065fa87d.js";
import "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js";
import { T as _ } from "./TrackingPushService-374dd83c.js";
import { I as z } from "./index-12214b95.js";
import { _ as O } from "./_plugin-vue_export-helper-c27b6911.js";
import "./VideoPlayer.vue_vue_type_script_lang-ca49a257.js";
import "./can-autoplay.es-4e207aef.js";
import "./ResponsiveImage-0ce28426.js";
import "./VideoPauseHandler-61c3b0c3.js";
import "./ShadowDom-bc0a555e.js";
import "./ResizeUpdateMixin-a56b9b41.js";
import "./debounce-af874a22.js";
import "./_commonjsHelpers-725317a4.js";
const $ = g(() =>
    w(
      () => import("./ResponsiveImage-0ce28426.js"),
      [
        "./ResponsiveImage-0ce28426.js",
        "./ResponsiveImage.vue_vue_type_script_lang-e242a44e.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  H = g(() =>
    w(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  v = 70,
  L = 70,
  j = T({
    name: "ScrollCrossFade",
    props: {
      editMode: Boolean,
      fadeText: String,
      textColor: String,
      itemSet: String,
    },
    components: { ResponsiveImage: $, WordFade: H, VideoPlayer: F },
    data() {
      return {
        isTextMaskChild: !1,
        itemHeight: null,
        visibleItem: 0,
        overlayVisible: !1,
        textFadeIn: !1,
        wordFadeIn: !1,
        hasScrolledImage: !1,
        firstVideoInPlayPosition: !1,
      };
    },
    setup() {
      const e = m(),
        t = m();
      return { wrapperElement: e, videoPlayer: t };
    },
    directives: { intersect: z },
    computed: {
      items() {
        return this.itemSet ? JSON.parse(this.itemSet) : [];
      },
      transparentOverlayClass() {
        return {
          "brandhub-scroll-cross-fade__transparent--visible":
            this.overlayVisible,
        };
      },
      crossFadeScrollClasses() {
        return {
          "brandhub-scroll-cross-fade--text-mask-child": this.isTextMaskChild,
          "brandhub-scroll-cross-fade--standalone": !this.isTextMaskChild,
          "brandhub-scroll-cross-fade--inverted": this.textColor === "inverted",
          "brandhub-scroll-cross-fade--primary": this.textColor === "primary",
          "brandhub-scroll-cross-fade--theme": this.textColor === "theme",
        };
      },
      crossFadeStyle() {
        return this.isTextMaskChild
          ? null
          : `--item-height: ${this.itemHeight}vh;`;
      },
    },
    methods: {
      handleScroll() {
        if (this.$refs.wrapperElement) {
          const { top: e } = this.wrapperElement.getBoundingClientRect();
          this.isTextMaskChild || this.handleVideoScrollCalculation(e),
            e && e <= 0 && this.handleScrollCalculation(e, window.innerHeight);
        }
      },
      handleIntersectChange(e) {
        e || (this.firstVideoInPlayPosition = !1);
      },
      shouldPlayVideo(e) {
        return (
          this.firstVideoInPlayPosition ||
          (e === this.visibleItem && this.visibleItem !== 0)
        );
      },
      handleScrolling(e) {
        this.handleVideoScrollCalculation(e.contentTop),
          e.contentTop < 0 &&
            this.handleScrollCalculation(e.contentTop, e.browserHeight);
      },
      handleVideoScrollCalculation(e) {
        this.$refs.videoPlayer &&
          this.$refs.videoPlayer[this.visibleItem] &&
          e !== 0 &&
          e > -window.innerHeight &&
          (!this.firstVideoInPlayPosition && this.visibleItem === 0 && e <= 400
            ? (this.firstVideoInPlayPosition = !0)
            : this.firstVideoInPlayPosition &&
              (this.visibleItem !== 0 || (this.visibleItem === 0 && e > 400)) &&
              (this.firstVideoInPlayPosition = !1));
      },
      handleScrollCalculation(e, t) {
        const n = t * (v / 100),
          h = Math.abs(e),
          i = Math.floor(h / n),
          r = this.items.length;
        i + 1 > r && !this.textFadeIn && this.fadeText
          ? this.fadeInText()
          : i + 1 <= r &&
            this.textFadeIn &&
            this.fadeText &&
            ((this.textFadeIn = !1), (this.wordFadeIn = !1)),
          i < r
            ? ((this.visibleItem = i), this.trackElemInteraction())
            : this.visibleItem === 0 && i >= r && (this.visibleItem = r - 1);
      },
      fadeInText() {
        (this.textFadeIn = !0),
          (this.overlayVisible = !0),
          this.trackElemInteraction(),
          setTimeout(() => {
            this.wordFadeIn = !0;
          }, 250);
      },
      fadeOutText() {
        this.overlayVisible = !1;
      },
      dispatchItemMountedEvent() {
        let e = this.items.length * v;
        this.fadeText && (e += L);
        const t = {
            bubbles: !0,
            composed: !0,
            detail: { item: this, itemHeight: e },
          },
          n = new CustomEvent(M, t);
        this.$el.dispatchEvent(n), (this.itemHeight = e + 100);
      },
      itemClasses(e) {
        const t = ["brandhub-scroll-cross-fade__item"];
        return (
          e <= this.visibleItem &&
            t.push("brandhub-scroll-cross-fade__item--visible"),
          t.join(" ")
        );
      },
      setIsTextMaskChild(e = !0) {
        (this.isTextMaskChild = e),
          window.removeEventListener("scroll", this.handleScroll);
      },
      trackElemInteraction() {
        this.hasScrolledImage ||
          (_.pushTrackingAttributes(
            "gallery",
            "cross fade images by scrolling",
            `${this.fadeText} - initialized`
          ),
          (this.hasScrolledImage = !0)),
          this.textFadeIn &&
            _.pushTrackingAttributes(
              "gallery",
              "cross fade images by scrolling",
              `${this.fadeText} - completed`
            );
      },
    },
    mounted() {
      this.$nextTick(() => {
        setTimeout(() => {
          this.dispatchItemMountedEvent();
        }, 200);
      }),
        window.addEventListener("scroll", this.handleScroll, { passive: !0 }),
        this.handleScroll();
    },
  }),
  D = `.brandhub-scroll-cross-fade{color:var(--text-on-base-color);height:var(--item-height, 100vh);width:100%}.brandhub-scroll-cross-fade--inverted{color:var(--base-color)}.brandhub-scroll-cross-fade--theme{color:var(--campaign-primary)}.brandhub-scroll-cross-fade--standalone{opacity:0;transform:translateY(2.1428571429rem);transition:transform .5s ease-out .2s,opacity .5s ease-out .2s}.brandhub-scroll-cross-fade--standalone.brandhub-scroll-cross-fade--in{opacity:1;transform:translate(0)}.brandhub-scroll-cross-fade__content{display:grid;grid-template:"content" 100%;height:100vh;left:0;position:sticky;top:0;width:100%}.brandhub-scroll-cross-fade__transparent{background:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0));grid-area:content;margin-right:auto;opacity:0;transition:opacity 1s;width:100%;z-index:1}@media (max-width: 1023px){.brandhub-scroll-cross-fade__transparent{height:50%;margin-top:auto}}@media (min-width: 1024px){.brandhub-scroll-cross-fade__transparent{background:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0));width:50%}}.brandhub-scroll-cross-fade__transparent--visible{opacity:1}.brandhub-scroll-cross-fade__container{padding-left:1.1428571429rem;padding-right:1.1428571429rem;align-items:center;display:flex;grid-area:content;justify-content:flex-start;z-index:1}@media (min-width: 768px){.brandhub-scroll-cross-fade__container{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-scroll-cross-fade__container{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-scroll-cross-fade__container{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-scroll-cross-fade__container{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}.brandhub-scroll-cross-fade__text-wrapper{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:3.9285714286rem;margin-right:auto;width:100%}@media (min-width: 480px){.brandhub-scroll-cross-fade__text-wrapper{font-size:5.2142857143rem}}@media (min-width: 768px){.brandhub-scroll-cross-fade__text-wrapper{font-size:7.1428571429rem}}@media (min-width: 1280px){.brandhub-scroll-cross-fade__text-wrapper{font-size:7.8571428571rem}}@media (min-width: 1440px){.brandhub-scroll-cross-fade__text-wrapper{font-size:8.5714285714rem}}@media (min-width: 1680px){.brandhub-scroll-cross-fade__text-wrapper{font-size:10rem}}@media (min-width: 1920px){.brandhub-scroll-cross-fade__text-wrapper{font-size:11.4285714286rem}}@media (min-width: 768px){.brandhub-scroll-cross-fade__text-wrapper{width:84%}}@media (max-width: 1023px){.brandhub-scroll-cross-fade__text-wrapper{margin-top:auto;padding-bottom:10vh}}@media (min-width: 1024px){.brandhub-scroll-cross-fade__text-wrapper{width:65%}}@media (min-width: 1280px){.brandhub-scroll-cross-fade__text-wrapper{width:47vw}}.brandhub-scroll-cross-fade__item{grid-area:content;height:100%;opacity:0;pointer-events:none;transition:opacity 1s;width:100%;z-index:1}.brandhub-scroll-cross-fade__item--visible{opacity:1;pointer-events:auto}.brandhub-scroll-cross-fade__video video{object-fit:cover}
`,
  B = { class: "brandhub-scroll-cross-fade__content" },
  A = { key: 0, class: "brandhub-scroll-cross-fade__container" };
function N(e, t, n, h, i, r) {
  const y = c("video-player"),
    x = c("responsive-image"),
    I = c("word-fade"),
    C = S("intersect");
  return k(
    (o(),
    l(
      "div",
      {
        class: d(["brandhub-scroll-cross-fade", e.crossFadeScrollClasses]),
        style: E(e.crossFadeStyle),
        ref: "wrapperElement",
      },
      [
        p("div", B, [
          (o(!0),
          l(
            f,
            null,
            V(
              e.items,
              (s, a) => (
                o(),
                l(
                  f,
                  null,
                  [
                    s.desktopVideo
                      ? (o(),
                        u(
                          y,
                          {
                            key: `item-${a}`,
                            class: d([
                              "brandhub-scroll-cross-fade__video",
                              e.itemClasses(a),
                            ]),
                            "desktop-video": s.desktopVideo,
                            "tablet-video": s.tabletVideo,
                            "mobile-video": s.mobileVideo,
                            "poster-image-object": s.pictureJson,
                            "play-muted": "",
                            ref_for: !0,
                            ref: "videoPlayer",
                            "show-controls": !1,
                            "is-playing": e.shouldPlayVideo(a),
                            "play-looped": s.videoLoop,
                          },
                          null,
                          8,
                          [
                            "class",
                            "desktop-video",
                            "tablet-video",
                            "mobile-video",
                            "poster-image-object",
                            "is-playing",
                            "play-looped",
                          ]
                        ))
                      : s.pictureJson
                      ? (o(),
                        u(
                          x,
                          {
                            key: `item-${a}`,
                            class: d(e.itemClasses(a)),
                            "aria-hidden": e.visibleItem < a ? "true" : "false",
                            "picture-object": s.pictureJson,
                          },
                          null,
                          8,
                          ["class", "aria-hidden", "picture-object"]
                        ))
                      : b("", !0),
                  ],
                  64
                )
              )
            ),
            256
          )),
          p(
            "div",
            {
              class: d([
                "brandhub-scroll-cross-fade__transparent",
                e.transparentOverlayClass,
              ]),
            },
            null,
            2
          ),
          e.fadeText
            ? (o(),
              l("div", A, [
                P(
                  I,
                  {
                    class: "brandhub-scroll-cross-fade__text-wrapper",
                    "animated-text": e.fadeText,
                    "manual-fade": !0,
                    "manual-fade-in": e.wordFadeIn,
                    onFadeOutComplete: e.fadeOutText,
                  },
                  null,
                  8,
                  ["animated-text", "manual-fade-in", "onFadeOutComplete"]
                ),
              ]))
            : b("", !0),
        ]),
      ],
      6
    )),
    [
      [
        C,
        {
          true: ["brandhub-scroll-cross-fade--in"],
          onChange: e.handleIntersectChange,
        },
      ],
    ]
  );
}
const re = O(j, [
  ["render", N],
  ["styles", [D]],
]);
export { re as default };
