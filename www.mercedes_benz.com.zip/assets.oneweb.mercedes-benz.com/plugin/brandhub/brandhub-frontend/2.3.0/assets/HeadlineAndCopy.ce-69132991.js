import {
  d as r,
  a as o,
  _ as h,
  r as p,
  j as m,
  o as n,
  c as a,
  h as l,
  b as c,
  k as b,
  M as s,
  e as d,
  w as g,
  n as u,
  f as y,
} from "./index.js";
import { I as _ } from "./index-12214b95.js";
import { _ as w } from "./_plugin-vue_export-helper-c27b6911.js";
const f = o(() =>
    h(
      () => import("./WordFade-cd7ee7b7.js"),
      [
        "./WordFade-cd7ee7b7.js",
        "./BrandSafeHyphens-ffe3b60a.js",
        "./index-12214b95.js",
        "./index.js",
        "./index.css",
        "./_plugin-vue_export-helper-c27b6911.js",
      ],
      import.meta.url
    )
  ),
  x = r({
    props: {
      headline: String,
      headlineTag: { type: String, default: "h2" },
      text: String,
      alignment: {
        type: String,
        default: "left",
        validator: (e) => ["left", "center"].includes(e),
      },
      bgColor: {
        type: String,
        default: "black",
        validator: (e) =>
          ["background-white", "background-black", "background-theme"].includes(
            e
          ),
      },
      spacingBottom: Boolean,
      spacingTop: Boolean,
    },
    components: { WordFade: f },
    directives: { intersect: _ },
    computed: {
      rootClasses() {
        return {
          "brandhub-headline-and-copy--background-white":
            this.bgColor === "background-white",
          "brandhub-headline-and-copy--background-black":
            this.bgColor === "background-black",
          "brandhub-headline-and-copy--background-theme":
            this.bgColor === "background-theme",
          "brandhub-headline-and-copy--alignment-center":
            this.alignment === "center",
          "brandhub-headline-and-copy--alignment-left":
            this.alignment === "left",
          "brandhub-headline-and-copy--spacing-bottom": this.spacingBottom,
          "brandhub-headline-and-copy--spacing-top": this.spacingTop,
        };
      },
      wordFadeAlignment() {
        return this.alignment === "left" ? "left" : "always-center";
      },
    },
  }),
  k = `.brandhub-headline-and-copy{padding:4.2857142857rem 1.1428571429rem;display:grid;grid-column-gap:1.1428571429rem;grid-template-columns:repeat(6,2fr)}@media (min-width: 768px){.brandhub-headline-and-copy{padding-left:2.2857142857rem;padding-right:2.2857142857rem}}@media (min-width: 1024px){.brandhub-headline-and-copy{padding-left:6.5714285714rem;padding-right:6.5714285714rem}}@media (min-width: 1440px){.brandhub-headline-and-copy{padding-left:8.2857142857rem;padding-right:8.2857142857rem}}@media (min-width: 1920px){.brandhub-headline-and-copy{padding-left:8.5714285714rem;padding-right:8.5714285714rem}}@media (min-width: 768px){.brandhub-headline-and-copy{grid-column-gap:2.2857142857rem;grid-template-columns:repeat(8,2fr)}}@media (min-width: 1024px){.brandhub-headline-and-copy{grid-column-gap:1.7142857143rem;grid-template-columns:repeat(12,2fr)}}@media (min-width: 1440px){.brandhub-headline-and-copy{grid-column-gap:2.8571428571rem}}@media (min-width: 1920px){.brandhub-headline-and-copy{grid-column-gap:3.4285714286rem}}.brandhub-headline-and-copy--background-black{background-color:var(--wb-black);color:var(--wb-white)}.brandhub-headline-and-copy--background-white{background-color:var(--wb-white);color:var(--wb-black)}.brandhub-headline-and-copy--background-theme{background:var(--campaign-gradient);color:var(--campaign-text)}.brandhub-headline-and-copy--spacing-bottom{padding-bottom:4.2857142857rem}@media (min-width: 768px){.brandhub-headline-and-copy--spacing-bottom{padding-bottom:10.7142857143rem}}@media (min-width: 1440px){.brandhub-headline-and-copy--spacing-bottom{padding-bottom:12.8571428571rem}}@media (min-width: 1680px){.brandhub-headline-and-copy--spacing-bottom{padding-bottom:15.7142857143rem}}@media (min-width: 1920px){.brandhub-headline-and-copy--spacing-bottom{padding-bottom:17.8571428571rem}}.brandhub-headline-and-copy--spacing-top{padding-top:4.2857142857rem}@media (min-width: 768px){.brandhub-headline-and-copy--spacing-top{padding-top:10.7142857143rem}}@media (min-width: 1440px){.brandhub-headline-and-copy--spacing-top{padding-top:12.8571428571rem}}@media (min-width: 1680px){.brandhub-headline-and-copy--spacing-top{padding-top:15.7142857143rem}}@media (min-width: 1920px){.brandhub-headline-and-copy--spacing-top{padding-top:17.8571428571rem}}@media (min-width: 768px){.brandhub-headline-and-copy--alignment-center .brandhub-headline-and-copy__wrapper{grid-column:2/span 6}}@media (min-width: 1024px){.brandhub-headline-and-copy--alignment-center .brandhub-headline-and-copy__wrapper{grid-column:3/span 8}}.brandhub-headline-and-copy--alignment-center .brandhub-headline-and-copy__text{text-align:center}.brandhub-headline-and-copy__wrapper{grid-column:1/span 6}@media (min-width: 1024px){.brandhub-headline-and-copy__wrapper{grid-column:1/span 8}}.brandhub-headline-and-copy__headline{font-family:MBCorpo Title,sans-serif;font-weight:400;line-height:1em;font-size:3.5714285714rem;line-height:4.2857142857rem;-webkit-hyphens:auto;hyphens:auto;line-height:4rem;margin-bottom:1.1428571429rem;margin-top:0}@media (min-width: 768px){.brandhub-headline-and-copy__headline{font-size:7.1428571429rem;line-height:7.1428571429rem}}@media (min-width: 1440px){.brandhub-headline-and-copy__headline{font-size:8.5714285714rem;line-height:8.5714285714rem}}@media (min-width: 768px){.brandhub-headline-and-copy__headline{font-size:5.1428571429rem;line-height:5.7142857143rem}}@media (min-width: 1024px){.brandhub-headline-and-copy__headline{font-size:5.7142857143rem;line-height:5.7142857143rem;margin-bottom:1.7142857143rem}}@media (min-width: 1440px){.brandhub-headline-and-copy__headline{font-size:7.1428571429rem;line-height:7.1428571429rem}}@media (min-width: 1920px){.brandhub-headline-and-copy__headline{font-size:8.5714285714rem;line-height:8.5714285714rem}}.brandhub-headline-and-copy__text{font-family:MBCorpo Text,sans-serif;font-size:1.1428571429rem;line-height:1.7142857143rem;opacity:0;pointer-events:none;transform:translateY(2.1428571429rem);transition:transform .4s ease-out,opacity .8s ease-out;transition-delay:.3s}@media (min-width: 1024px){.brandhub-headline-and-copy__text{font-size:1.2857142857rem;line-height:2rem}}.brandhub-headline-and-copy__text--in{opacity:1;pointer-events:auto;transform:translateY(0)}.brandhub-headline-and-copy__text p{margin-bottom:0;margin-top:0}@media (min-width: 1920px){.brandhub-headline-and-copy__text{font-size:1.5714285714rem;line-height:2.4285714286rem}}
`,
  v = { class: "brandhub-headline-and-copy__wrapper" },
  C = ["innerHTML"];
function z(e, B, T, A, D, M) {
  const i = p("word-fade"),
    t = m("intersect");
  return (
    n(),
    a(
      "div",
      { class: u(["brandhub-headline-and-copy", e.rootClasses]) },
      [
        l("div", v, [
          e.headline
            ? (n(),
              c(
                s(e.headlineTag),
                { key: 0, class: "brandhub-headline-and-copy__headline" },
                {
                  default: b(() => [
                    y(
                      i,
                      {
                        "animated-text": e.headline,
                        "text-align": e.wordFadeAlignment,
                      },
                      null,
                      8,
                      ["animated-text", "text-align"]
                    ),
                  ]),
                  _: 1,
                }
              ))
            : d("", !0),
          e.text
            ? g(
                (n(),
                a(
                  "div",
                  {
                    key: 1,
                    class: "brandhub-headline-and-copy__text",
                    innerHTML: e.text,
                  },
                  null,
                  8,
                  C
                )),
                [[t, { true: ["brandhub-headline-and-copy__text--in"] }]]
              )
            : d("", !0),
        ]),
      ],
      2
    )
  );
}
const E = w(x, [
  ["render", z],
  ["styles", [k]],
]);
export { E as default };
