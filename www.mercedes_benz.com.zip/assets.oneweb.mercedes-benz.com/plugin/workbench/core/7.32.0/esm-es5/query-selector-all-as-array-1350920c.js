/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var querySelectorAllAsArray = function (r, e) {
  return Array.from(r.querySelectorAll(e));
};
export { querySelectorAllAsArray as q };
//# sourceMappingURL=query-selector-all-as-array-1350920c.js.map
