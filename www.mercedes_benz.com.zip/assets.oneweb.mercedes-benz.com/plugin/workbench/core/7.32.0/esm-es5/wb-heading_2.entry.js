/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { r as registerInstance, h, a as Host } from "./index-5bae4795.js";
var headingCss =
  ':host{display:block}:host([tag=b]),:host([tag=em]),:host([tag=i]),:host([tag=small]),:host([tag=span]),:host([tag=strong]){display:inline}.tag{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-box-shadow:border-box;box-shadow:border-box;font:inherit;margin:0}:host([ellipsis]){overflow:hidden}:host([ellipsis]) .tag{overflow:hidden;text-overflow:ellipsis}:host([size=s]){font-family:var(--wb-font-text-bold);font-size:1.25rem;font-style:normal;font-weight:700;line-height:1.75rem}@media (min-width:64rem){:host([size=s]){font-size:1.5rem;line-height:2rem}}:host([size=xs]){font-family:var(--wb-font-text-bold);font-size:1.125rem;font-style:normal;font-weight:700;line-height:1.75rem}@media (min-width:64rem){:host([size=xs]){font-size:1.25rem;line-height:1.75rem}}:host([size=m]){font-family:var(--wb-font-title);font-size:1.625rem;font-style:normal;font-weight:400;line-height:2rem}@media (min-width:64rem){:host([size=m]){font-size:2.125rem;line-height:2.75rem}}:host([size=l]){font-family:var(--wb-font-title);font-size:2rem;font-style:normal;font-weight:400;line-height:2.5rem}@media (min-width:64rem){:host([size=l]){font-size:3rem;line-height:3.75rem}}:host([size=xl]){font-family:var(--wb-font-title);font-size:2.5rem;font-style:normal;font-weight:400;line-height:3rem}@media (min-width:64rem){:host([size=xl]){font-size:4rem;line-height:4.5rem}}:host([chinese]){--wb-font-title:"Hanyi","DaimlerCAC-Regular","Hanyi-Ext","SimSun",serif}::slotted(sup){font-size:max(.625rem,min(.6em,1rem));inset-block-end:.5em;line-height:0;position:relative}::slotted(sub){font-size:max(.45em,min(.7em,.875rem));line-height:0}';
var HeadingComponent = (function () {
  function e(e) {
    registerInstance(this, e);
    this.size = "m";
    this.ellipsis = false;
    this.chinese = false;
    this.tag = "div";
  }
  e.prototype.render = function () {
    var e = this.tag;
    return h(
      Host,
      { class: "wb-heading" },
      h(e, { class: "tag" }, h("slot", null))
    );
  };
  return e;
})();
HeadingComponent.style = headingCss;
var textCss =
  ":host{display:block}:host([tag=b]),:host([tag=em]),:host([tag=i]),:host([tag=small]),:host([tag=span]),:host([tag=strong]){display:inline}.tag{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-box-shadow:border-box;box-shadow:border-box;font:inherit;margin:0}:host([ellipsis]){overflow:hidden}:host([ellipsis]) .tag{overflow:hidden;text-overflow:ellipsis}:host([size=s]){font-family:var(--wb-font-text);font-size:.75rem;font-style:normal;font-weight:400;letter-spacing:.0125rem;line-height:1rem}:host([size=s]) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}@media (min-width:64rem){:host([size=s]:not([static])){font-size:.875rem;line-height:1.25rem}}:host([size=s]:not([static])) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([size=m]){font-family:var(--wb-font-text);font-size:.875rem;font-style:normal;font-weight:400;letter-spacing:.0125rem;line-height:1.25rem}:host([size=m]) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}@media (min-width:64rem){:host([size=m]:not([static])){font-size:1rem;line-height:1.5rem}}:host([size=m]:not([static])) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([size=l]){font-family:var(--wb-font-text);font-size:1rem;font-style:normal;font-weight:400;letter-spacing:.0125rem;line-height:1.5rem}:host([size=l]) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}@media (min-width:64rem){:host([size=l]:not([static])){font-size:1.125rem;line-height:1.75rem}}:host([size=l]:not([static])) sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([strong][size]){font-weight:700}::slotted(sup){font-size:max(.625rem,min(.6em,1rem));line-height:0}::slotted(sub){font-size:max(.45em,min(.7em,.875rem));line-height:0}";
var TextComponent = (function () {
  function e(e) {
    registerInstance(this, e);
    this.size = "m";
    this.static = false;
    this.strong = false;
    this.ellipsis = false;
    this.tag = "div";
  }
  e.prototype.render = function () {
    var e = this.tag;
    return h(
      Host,
      { class: "wb-text" },
      h(e, { class: "tag" }, h("slot", null))
    );
  };
  return e;
})();
TextComponent.style = textCss;
export { HeadingComponent as wb_heading, TextComponent as wb_text };
//# sourceMappingURL=wb-heading_2.entry.js.map
