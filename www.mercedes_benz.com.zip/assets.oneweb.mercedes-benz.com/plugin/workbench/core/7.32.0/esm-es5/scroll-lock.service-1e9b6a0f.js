/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { e as escapePrerender } from "./media-query.service-08aeb0ba.js";
var CONFIG = {
  attributes: true,
  childList: false,
  subtree: false,
  attributeFilter: ["dir"],
};
var DirectionService = (function () {
  function t(t) {
    var i = this;
    this.targetEl = t;
    escapePrerender(function () {
      i.createObserver();
      i.observe();
    });
  }
  t.prototype.setDir = function (t) {
    this.targetEl.setAttribute("dir", t);
  };
  Object.defineProperty(t.prototype, "dir", {
    get: function () {
      return this.targetEl.getAttribute("dir");
    },
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(t.prototype, "isRtl", {
    get: function () {
      return this.dir === "rtl";
    },
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(t.prototype, "isLtr", {
    get: function () {
      return !this.isRtl;
    },
    enumerable: false,
    configurable: true,
  });
  t.prototype.dispatchDirChangeEvent = function () {
    var t = new CustomEvent("wbdirchange", { detail: { dir: this.dir } });
    document.dispatchEvent(t);
  };
  t.prototype.createObserver = function () {
    var t = this;
    this.observer = new MutationObserver(function () {
      return t.dispatchDirChangeEvent();
    });
  };
  t.prototype.observe = function () {
    this.observer.observe(this.targetEl, CONFIG);
  };
  return t;
})();
var SCROLL_LOCK_CLASS = "wb-scroll-lock";
var ScrollLockService = (function () {
  function t(t) {
    if (t === void 0) {
      t = document.documentElement;
    }
    this.targetEl = t;
    this.scrollTopBeforeLock = 0;
    this.identifiers = new Set();
  }
  t.prototype.lock = function (t) {
    if (this.identifiers.size === 0) {
      this.scrollTopBeforeLock = this.targetEl.scrollTop;
      this.targetEl.style.top = "-".concat(this.scrollTopBeforeLock, "px");
    }
    var i = t ? "-".concat(t) : "";
    this.targetEl.classList.add("".concat(SCROLL_LOCK_CLASS).concat(i));
    if (t) {
      this.identifiers.add(t);
    }
    this.isLocked = true;
  };
  t.prototype.unlock = function (t) {
    if (!this.isLocked) {
      return;
    }
    var i = t ? "-".concat(t) : "";
    this.targetEl.classList.remove("".concat(SCROLL_LOCK_CLASS).concat(i));
    if (t) {
      this.identifiers.delete(t);
    }
    if (this.identifiers.size === 0) {
      this.targetEl.style.top = "";
      this.targetEl.scrollTop = this.scrollTopBeforeLock;
      this.isLocked = false;
    }
  };
  return t;
})();
export {
  DirectionService as D,
  ScrollLockService as S,
  SCROLL_LOCK_CLASS as a,
};
//# sourceMappingURL=scroll-lock.service-1e9b6a0f.js.map
