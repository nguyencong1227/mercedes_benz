/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { g as getElement } from "./index-5bae4795.js";
var applyTagNameTransformation = function (a, r, t) {
  if (!t.tagName) {
    return a;
  }
  var e = t.tagName.toLowerCase();
  var n = r.split("wb-")[1];
  var o = a.split("wb-")[1];
  var i = e.split(n),
    m = i[0],
    C = i[1];
  return m + o + C;
};
var CACHE = {};
function transformTagNameWithCache(a, r, t) {
  if (!CACHE[a]) {
    CACHE[a] = applyTagNameTransformation(a, r, t);
  }
  return CACHE[a];
}
function toCapitalizedCamelCase(a) {
  return (" " + a).toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, function (a, r) {
    return r.toUpperCase();
  });
}
function transformTagNames(a, r, t) {
  var e = getElement(a);
  var n = {};
  t.forEach(function (a) {
    var t = toCapitalizedCamelCase(a);
    n[t] = transformTagNameWithCache(a, r, e);
  });
  return n;
}
export { transformTagNames as t };
//# sourceMappingURL=transform-tag-name-a73790cf.js.map
