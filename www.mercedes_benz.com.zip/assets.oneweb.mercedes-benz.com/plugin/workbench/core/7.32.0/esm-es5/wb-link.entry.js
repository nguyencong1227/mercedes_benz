/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { r as registerInstance, h, a as Host } from "./index-5bae4795.js";
import { b as SharedDirectionService } from "./workbench-global-3eaf1f19.js";
import "./scroll-lock.service-1e9b6a0f.js";
import "./media-query.service-08aeb0ba.js";
var linkCss =
  ":host{--link-text-color:var(--wb-grey-20);--link-outline-color:var(--wb-blue-45)}:host([variant=inline]){--link-text-color:var(--wb-blue-45)}:host([variant=inline]:focus),:host([variant=inline]:hover){--link-text-color:var(--wb-blue-35)}:host([variant=standalone]){--link-text-color:var(--wb-grey-20);--link-underline-gradient:var(--linear-gradient-blue-45)}:host([variant=small]),:host([variant=tiny]){--link-underline-gradient:var(--linear-gradient-black)}:host([variant=small]:focus-within),:host([variant=small]:hover),:host([variant=tiny]:focus-within),:host([variant=tiny]:hover){--link-text-color:var(--wb-black)}:host([theme=dark]){--link-text-color:var(--wb-grey-70);--link-outline-color:var(--wb-blue-45)}:host([theme=dark][variant=inline]){--link-text-color:var(--wb-blue-55)}:host([theme=dark][variant=inline]:focus),:host([theme=dark][variant=inline]:hover){--link-text-color:var(--wb-blue-65)}:host([theme=dark][variant=standalone]){--link-text-color:var(--wb-white);--link-underline-gradient:var(--linear-gradient-blue-50)}:host([theme=dark][variant=small]),:host([theme=dark][variant=tiny]){--link-underline-gradient:var(--linear-gradient-white)}:host([theme=dark][variant=small]:focus-within),:host([theme=dark][variant=small]:hover),:host([theme=dark][variant=tiny]:focus-within),:host([theme=dark][variant=tiny]:hover){--link-text-color:var(--wb-white)}:host{--color:var(--link-text-color);--outline-color:var(--link-outline-color);display:inline}a{-webkit-tap-highlight-color:transparent;background-color:transparent;color:var(--color);cursor:pointer;outline-color:var(--outline-color);text-decoration:none}a:focus{outline-offset:.3125rem;outline-style:solid;outline-width:.0625rem}:host([variant=inline]) a{-webkit-border-after:.0625rem solid currentColor;border-block-end:.0625rem solid currentColor}:host([variant=standalone]) a{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;background-image:var(--link-underline-gradient);font-family:var(--wb-font-text-bold);font-size:1rem;font-style:normal;font-weight:700;letter-spacing:.0125rem;line-height:1.5rem}:host([variant=standalone]) a sup{font-size:max(.625rem,min(.6em,1rem));line-height:0}:host([variant=standalone]) a sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([variant=small]) a{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text);font-size:.875rem;font-style:normal;font-weight:400;letter-spacing:.0125rem;line-height:1.25rem}@media (min-width:64rem){:host([variant=small]) a{font-size:1rem;line-height:1.5rem}}:host([variant=small]) a sup{font-size:max(.625rem,min(.6em,1rem));line-height:0}:host([variant=small]) a sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([variant=tiny]) a{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:var(--wb-font-text-bold);font-size:.75rem;font-style:normal;font-weight:700;letter-spacing:.0125rem;line-height:1rem}@media (min-width:64rem){:host([variant=tiny]) a{font-size:.875rem;line-height:1.25rem}}:host([variant=tiny]) a sup{font-size:max(.625rem,min(.6em,1rem));line-height:0}:host([variant=tiny]) a sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host([variant=small]) a,:host([variant=tiny]) a{background-image:var(--link-underline-gradient)}:host([variant=small]) a,:host([variant=standalone]) a,:host([variant=tiny]) a{background-origin:right;background-position-x:left;background-repeat:no-repeat,no-repeat;background-size:0 100%,100% 100%;-webkit-padding-after:.125rem;padding-block-end:.125rem;-webkit-transition:background-size .42s cubic-bezier(.165,.84,.44,1);transition:background-size .42s cubic-bezier(.165,.84,.44,1)}@media (prefers-reduced-motion){:host([variant=small]) a,:host([variant=standalone]) a,:host([variant=tiny]) a{-webkit-transition:background-size 0s;transition:background-size 0s}}:host([is-rtl]) a{background-position-x:right}:host([variant=small]:focus-within) a,:host([variant=small]:hover) a,:host([variant=standalone]:focus-within) a,:host([variant=standalone]:hover) a,:host([variant=tiny]:focus-within) a,:host([variant=tiny]:hover) a{background-size:100% 100%,100% 100%}::slotted(.wb-icon){--size:0.75rem;-webkit-margin-end:.5rem;margin-inline-end:.5rem;overflow:hidden}";
var LinkComponent = (function () {
  function t(t) {
    registerInstance(this, t);
    this.variant = undefined;
    this.theme = "light";
    this.href = undefined;
    this.download = undefined;
    this.referrerPolicy = undefined;
    this.rel = undefined;
    this.target = undefined;
    this.isRtl = false;
  }
  t.prototype.connectedCallback = function () {
    this.updateDirection();
  };
  t.prototype.updateDirection = function () {
    this.isRtl = SharedDirectionService.isRtl;
  };
  t.prototype.render = function () {
    return h(
      Host,
      { class: "wb-link" },
      h(
        "a",
        {
          href: this.href,
          download: this.download,
          referrerPolicy: this.referrerPolicy,
          rel: this.rel,
          target: this.target,
        },
        h("slot", { name: "icon" }),
        h("slot", null)
      )
    );
  };
  return t;
})();
LinkComponent.style = linkCss;
export { LinkComponent as wb_link };
//# sourceMappingURL=wb-link.entry.js.map
