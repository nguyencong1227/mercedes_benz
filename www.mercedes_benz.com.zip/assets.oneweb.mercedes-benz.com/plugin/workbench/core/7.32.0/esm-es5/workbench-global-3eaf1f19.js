/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var __awaiter =
  (this && this.__awaiter) ||
  function (e, r, n, i) {
    function t(e) {
      return e instanceof n
        ? e
        : new n(function (r) {
            r(e);
          });
    }
    return new (n || (n = Promise))(function (n, o) {
      function c(e) {
        try {
          s(i.next(e));
        } catch (e) {
          o(e);
        }
      }
      function a(e) {
        try {
          s(i["throw"](e));
        } catch (e) {
          o(e);
        }
      }
      function s(e) {
        e.done ? n(e.value) : t(e.value).then(c, a);
      }
      s((i = i.apply(e, r || [])).next());
    });
  };
var __generator =
  (this && this.__generator) ||
  function (e, r) {
    var n = {
        label: 0,
        sent: function () {
          if (o[0] & 1) throw o[1];
          return o[1];
        },
        trys: [],
        ops: [],
      },
      i,
      t,
      o,
      c;
    return (
      (c = { next: a(0), throw: a(1), return: a(2) }),
      typeof Symbol === "function" &&
        (c[Symbol.iterator] = function () {
          return this;
        }),
      c
    );
    function a(e) {
      return function (r) {
        return s([e, r]);
      };
    }
    function s(a) {
      if (i) throw new TypeError("Generator is already executing.");
      while ((c && ((c = 0), a[0] && (n = 0)), n))
        try {
          if (
            ((i = 1),
            t &&
              (o =
                a[0] & 2
                  ? t["return"]
                  : a[0]
                  ? t["throw"] || ((o = t["return"]) && o.call(t), 0)
                  : t.next) &&
              !(o = o.call(t, a[1])).done)
          )
            return o;
          if (((t = 0), o)) a = [a[0] & 2, o.value];
          switch (a[0]) {
            case 0:
            case 1:
              o = a;
              break;
            case 4:
              n.label++;
              return { value: a[1], done: false };
            case 5:
              n.label++;
              t = a[1];
              a = [0];
              continue;
            case 7:
              a = n.ops.pop();
              n.trys.pop();
              continue;
            default:
              if (
                !((o = n.trys), (o = o.length > 0 && o[o.length - 1])) &&
                (a[0] === 6 || a[0] === 2)
              ) {
                n = 0;
                continue;
              }
              if (a[0] === 3 && (!o || (a[1] > o[0] && a[1] < o[3]))) {
                n.label = a[1];
                break;
              }
              if (a[0] === 6 && n.label < o[1]) {
                n.label = o[1];
                o = a;
                break;
              }
              if (o && n.label < o[2]) {
                n.label = o[2];
                n.ops.push(a);
                break;
              }
              if (o[2]) n.ops.pop();
              n.trys.pop();
              continue;
          }
          a = r.call(e, n);
        } catch (e) {
          a = [6, e];
          t = 0;
        } finally {
          i = o = 0;
        }
      if (a[0] & 5) throw a[1];
      return { value: a[0] ? a[1] : void 0, done: true };
    }
  };
import {
  D as DirectionService,
  S as ScrollLockService,
} from "./scroll-lock.service-1e9b6a0f.js";
import { M as MediaQueryService } from "./media-query.service-08aeb0ba.js";
var versions = { assets: "4.6.0", core: "7.32.0", fonts: "2.1.0" };
var CONFIG_DEFAULTS = {
  iconRootPath:
    "https://assets.oneweb.mercedes-benz.com/plugin/workbench/assets/".concat(
      versions.assets,
      "/icons"
    ),
  instances: [],
  showExperimentalWarnings: true,
  updateDirection: function () {
    return window.dispatchEvent(new Event("wbupdatedirection"));
  },
};
var SharedScrollLockService = new ScrollLockService();
var SharedMediaQueryService = new MediaQueryService(window);
var SharedDirectionService = new DirectionService(document.documentElement);
var appGlobalScript = function () {
  return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (e) {
      if (window.workbench) {
        window.workbench = Object.assign(
          Object.assign({}, CONFIG_DEFAULTS),
          window.workbench
        );
      } else {
        window.workbench = Object.assign({}, CONFIG_DEFAULTS);
      }
      window.workbench.instances.push(versions);
      SharedMediaQueryService.observe();
      return [2];
    });
  });
};
export {
  SharedScrollLockService as S,
  appGlobalScript as a,
  SharedDirectionService as b,
  SharedMediaQueryService as c,
};
//# sourceMappingURL=workbench-global-3eaf1f19.js.map
