import { escapePrerender } from '../../global/escape-prerender';

export type MediaQuery = 'mq1' | 'mq2' | 'mq3' | 'mq4' | 'mq5' | 'mq6';

export class MediaQueryChangeEvent {
  constructor(public current: MediaQuery, public previous: MediaQuery) {}
}

export const MEDIA_QUERY_SIZES = {
  mq1: 320,
  mq2: 480,
  mq3: 768,
  mq4: 1024,
  mq5: 1280,
  mq6: 1440,
};

export const WB_RESIZE_EVENT_NAME = 'wbresize';

// NOTE: mq1 is implicit
const MEDIA_QUERIES_TO_OBSERVE: Array<MediaQuery> = ['mq2', 'mq3', 'mq4', 'mq5', 'mq6'];

class MediaQueryListener {
  public remove!: () => void;

  constructor(public window: Window, public mq: MediaQuery, public callbackFn: (mq: MediaQuery, matches: boolean) => any) {
    escapePrerender(() => {
      const mediaQueryList = this.window.matchMedia(`(min-width: ${MEDIA_QUERY_SIZES[mq]}px)`);
      const eventListenerFn = (event: MediaQueryListEvent) => this.callbackFn(this.mq, event.matches);

      mediaQueryList.addListener(eventListenerFn);
      this.remove = () => mediaQueryList.removeListener(eventListenerFn);
    });
  }
}

/**
 * @name MediaQueryService
 *
 * @description Class that informs about current media query
 *
 * @example
 * import { MediaQueryService } from '@workbench/core';
 *
 * const myMediaQueryService = new MediaQueryService(window);
 *
 * // To get the current media query
 * const currentMediaQuery: MediaQuery = myMediaQueryService.getCurrentMediaQuery();
 *
 * // To observe media query changes across time
 * window.addEventListener('wbresize', ((e: CustomEvent<MediaQueryChangeEvent>) => {
 *   console.log(`Media query changed from ${e.detail.previous} to ${e.detail.current}`);
 * }) as EventListener);
 *
 * // Pass in `true` if you are interested in the media query in the moment of calling the function
 * myMediaQueryService.observe(true);
 *
 * // When you don't need to observe anymore
 * myMediaQueryService.disconnect();
 */
export class MediaQueryService {
  private previousMediaQuery: MediaQuery;
  private activeMediaQuery!: MediaQuery;

  private listeners: Array<MediaQueryListener> = [];

  constructor(private window: Window) {}

  /**
   * returns the currently active media query
   */
  public getCurrentMediaQuery(): MediaQuery {
    // NOTE: using for loop to immediately return when a first match was found
    for (let i = MEDIA_QUERIES_TO_OBSERVE.length - 1; i >= 0; i--) {
      if (this.window.matchMedia(`(min-width: ${MEDIA_QUERY_SIZES[MEDIA_QUERIES_TO_OBSERVE[i]]}px)`).matches) {
        return MEDIA_QUERIES_TO_OBSERVE[i];
      }
    }

    return 'mq1';
  }

  /**
   * Starts observing all media query changes and dispatches `wbresize` events on `window`
   * @param emitCurrentValue set to true if you are interested in the media query in the moment of calling the function
   */
  public observe(emitCurrentValue: boolean = false): void {
    if (emitCurrentValue) {
      this.activeMediaQuery = this.activeMediaQuery || this.getCurrentMediaQuery();
      this.emit();
    }

    MEDIA_QUERIES_TO_OBSERVE.filter((mq: MediaQuery) => !this.listeners.find((listener) => listener.mq === mq)) //
      .forEach((mq: MediaQuery) => this.listeners.push(new MediaQueryListener(this.window, mq, this.onMediaQueryChange)));
  }

  /**
   * Cleans up all remaining event listeners
   */
  public disconnect(): void {
    this.listeners.forEach((listener) => listener.remove());
    this.listeners = [];
  }

  /**
   * Determines if a change is new and unique and should be emitted
   */
  private onMediaQueryChange = (mq: MediaQuery, matches: boolean): void => {
    if (matches) {
      this.activeMediaQuery = mq;
    } else {
      const previousMediaQuery = this.activeMediaQuery;
      this.activeMediaQuery = this.getCurrentMediaQuery();

      if (previousMediaQuery === this.activeMediaQuery) {
        // NOTE: not emitting duplicates
        return;
      }
    }

    this.emit();
  };

  /**
   * Emits the wbresize event on window as a custom event
   */
  private emit(): void {
    this.window.dispatchEvent(new CustomEvent<MediaQueryChangeEvent>(WB_RESIZE_EVENT_NAME, { detail: new MediaQueryChangeEvent(this.activeMediaQuery, this.previousMediaQuery) }));

    // NOTE: Active media query becomes previous media query after next media query change
    this.previousMediaQuery = this.activeMediaQuery;
  }
}
