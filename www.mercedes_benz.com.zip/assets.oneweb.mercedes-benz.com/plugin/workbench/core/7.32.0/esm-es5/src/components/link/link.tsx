import { Component, ComponentInterface, h, Host, JSX, Listen, Prop } from '@stencil/core';
import { SharedDirectionService } from '../../global/workbench-global';

/**
 * @slot - text content of the link
 * @slot icon - optional wb-icon element
 */
@Component({
  tag: 'wb-link',
  styleUrl: 'link.scss',
  shadow: true,
})
export class LinkComponent implements ComponentInterface {
  // TODO Rename 'standalone' link!? All links except 'inline' are standalone
  // https://git.i.mercedes-benz.com/dh-io-workbench/core/issues/2848

  /** link variant (inline links inherit typography from parent) */
  @Prop({ reflect: true })
  public variant!: 'inline' | 'standalone' | 'small' | 'tiny';

  /** color scheme */
  @Prop({ reflect: true })
  public theme: 'light' | 'dark' = 'light';

  /** passed through to internal <a> */
  @Prop()
  public href: string;

  /** passed through to internal <a> */
  @Prop()
  public download: any;

  /** passed through to internal <a> */
  @Prop()
  public referrerPolicy: ReferrerPolicy;

  /** passed through to internal <a> */
  @Prop()
  public rel: string;

  /** passed through to internal <a> */
  @Prop()
  public target: string;

  /** @internal */
  @Prop({ reflect: true, mutable: true })
  public isRtl: boolean = false;

  public connectedCallback(): void {
    this.updateDirection();
  }

  @Listen('wbdirchange', { target: 'document' })
  public updateDirection() {
    this.isRtl = SharedDirectionService.isRtl;
  }

  public render(): JSX.Element {
    return (
      <Host class="wb-link">
        <a href={this.href} download={this.download} referrerPolicy={this.referrerPolicy} rel={this.rel} target={this.target}>
          <slot name="icon" />
          <slot />
        </a>
      </Host>
    );
  }
}
