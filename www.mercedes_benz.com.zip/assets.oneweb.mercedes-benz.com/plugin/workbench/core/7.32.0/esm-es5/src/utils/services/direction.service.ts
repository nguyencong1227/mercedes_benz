import { escapePrerender } from '../../global/escape-prerender';

const CONFIG = { attributes: true, childList: false, subtree: false, attributeFilter: ['dir'] };

/**
 * @name DirectionService
 *
 * @description Class that informs about dir attribute changes on the given targetEl. One instance of this is globally registered and observes dir attribute changes on the html element.
 *
 * @example
 * import { DirectionService } from '@workbench/core';
 *
 * const myDirectionService = new DirectionService(document.documentElement);
 *
 * // to get the current direction
 * myDirectionService.dir; // "ltr"
 *
 * // to check if the current direction context is rtl
 * myDirectionService.isRtl; // false
 *
 * // to check if the current direction context is ltr
 * myDirectionService.isLtr; // true
 *
 * // to listen for direction changes
 * document.addEventListener('wbdirchange', (event) => {
 *  const currentDir = event.detail.dir;
 * });
 *
 * // to set the direction
 * myDirectionService.setDir('rtl');
 */
export class DirectionService {
  private observer;

  constructor(private targetEl: HTMLElement) {
    escapePrerender(() => {
      this.createObserver();
      this.observe();
    });
  }

  public setDir(dir: 'ltr' | 'rtl') {
    this.targetEl.setAttribute('dir', dir);
  }

  public get dir(): string {
    return this.targetEl.getAttribute('dir');
  }

  public get isRtl(): boolean {
    return this.dir === 'rtl';
  }

  public get isLtr(): boolean {
    return !this.isRtl;
  }

  private dispatchDirChangeEvent() {
    const event = new CustomEvent('wbdirchange', { detail: { dir: this.dir } });
    document.dispatchEvent(event);
  }

  private createObserver() {
    this.observer = new MutationObserver(() => this.dispatchDirChangeEvent());
  }

  private observe() {
    this.observer.observe(this.targetEl, CONFIG);
  }
}
