export const versions = {
  assets: '4.6.0', // needs manual update when upgrading dependencies
  core: '7.32.0', // don't change. value is updated automatically
  fonts: '2.1.0', // needs manual update when upgrading dependencies
};
