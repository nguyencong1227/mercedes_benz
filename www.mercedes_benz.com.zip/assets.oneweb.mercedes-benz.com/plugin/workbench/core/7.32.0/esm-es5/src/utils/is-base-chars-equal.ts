/**
 * @name isBaseCharsEqual
 *
 * @description Checks if the given strings base chars are equal
 *
 * @example
 * import { isBaseCharsEqual } from '@workbench/core';
 *
 * isBaseCharsEqual('string', 'STRING'); // true
 * isBaseCharsEqual('string', 'otherString'); // false
 */
export const isBaseCharsEqual = (string: string, otherString: string): boolean => {
  return string?.localeCompare(otherString, 'en', { sensitivity: 'base' }) === 0;
};
