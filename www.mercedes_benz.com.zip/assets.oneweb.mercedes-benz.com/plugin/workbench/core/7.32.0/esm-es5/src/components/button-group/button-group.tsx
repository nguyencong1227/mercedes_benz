import { Component, ComponentInterface, Element, h, Host, JSX, Listen, Prop, Watch } from '@stencil/core';
import { transformTagNames } from '../../global/transform-tag-name';
import { DEFAULT_WORKBENCH_THEME, WorkbenchTheme } from '../../shared/themes';
import { querySelectorAllAsArray } from '../../utils/query-selector-all-as-array';
import { isBaseCharsEqual } from '../../utils/is-base-chars-equal';

/**
 * @slot - Contents placed within the component
 */
@Component({
  tag: 'wb-button-group',
  styleUrl: 'button-group.scss',
  shadow: true,
})
export class ButtonGroupComponent implements ComponentInterface {
  @Element()
  public el!: HTMLElement;

  /** the colour scheme */
  @Prop({ reflect: true })
  public theme: WorkbenchTheme = DEFAULT_WORKBENCH_THEME;

  /** functional variant of the component */
  @Prop({ reflect: true })
  public variant: 'default' | 'radio' = 'default';

  /** aligns buttons in button group horizontally or vertically */
  @Prop({ reflect: true })
  public direction: 'horizontal' | 'vertical' = 'horizontal';

  private TagNames = transformTagNames(this, 'wb-button-group', ['wb-button-group-item']);

  private buttons: Array<HTMLWbButtonGroupItemElement>;

  @Listen('click')
  public handleClick(e): void {
    if (this.variant !== 'radio') {
      return;
    }

    const eventPath = e.composedPath();
    const clickedItem = eventPath.find((el) => isBaseCharsEqual(el?.tagName, this.TagNames.WbButtonGroupItem));

    if (!clickedItem || clickedItem.disabled) {
      return;
    }

    this.buttons.forEach((button) => {
      button.selected = button === clickedItem;
    });
  }

  @Watch('direction')
  public onDirectionChange(): void {
    this.passPropsToButtons();
  }

  private passPropsToButtons(): void {
    this.buttons.forEach((button) => {
      button.theme = this.theme;
      button.direction = this.direction;
    });
  }

  private updateButtonReferences(): void {
    this.buttons = querySelectorAllAsArray(this.el, this.TagNames.WbButtonGroupItem);
  }

  private handleSlotChange = (): void => {
    this.updateButtonReferences();
    this.passPropsToButtons();
  };

  public render(): JSX.Element {
    return (
      <Host role="group" class="wb-button-group">
        <slot onSlotchange={this.handleSlotChange} />
      </Host>
    );
  }
}
