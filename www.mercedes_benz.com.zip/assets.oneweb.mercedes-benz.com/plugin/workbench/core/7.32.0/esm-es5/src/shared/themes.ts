export type WorkbenchTheme = 'light' | 'dark';

export const MERCEDES_BENZ_LIGHT: WorkbenchTheme = 'light';
export const MERCEDES_BENZ_DARK: WorkbenchTheme = 'dark';

export const DEFAULT_WORKBENCH_THEME: WorkbenchTheme = MERCEDES_BENZ_LIGHT;
