import { getElement } from '@stencil/core';

/**
 * transforms a tagName during runtime according to the Stencil transformTagName extra. required for multi version support
 * @param tagToBeTransformed i.e. 'wb-stepper'
 * @param knownUntransformedTag  i.e 'wb-step'
 * @param knownUntransformedTagElementReference
 * @returns i.e. 'PREFIX-wb7-stepper-SUFFIX'
 */
export const applyTagNameTransformation = (tagToBeTransformed: string, knownUntransformedTag: string, knownUntransformedTagElementReference: HTMLElement): string => {
  /* eslint-disable workbench/tag-name-transform */

  /* return initial tag if host tag is not available (fixes issues with spec tests) */
  if (!knownUntransformedTagElementReference.tagName) {
    return tagToBeTransformed;
  }

  const actualCurrentTag = knownUntransformedTagElementReference.tagName.toLowerCase(); // 'PREFIX-wb7-step-SUFFIX'
  const knownTagWithoutDesignSystemPrefix = knownUntransformedTag.split('wb-')[1]; // 'step'
  const targetTagWithoutDesignSystemPrefix = tagToBeTransformed.split('wb-')[1]; // 'stepper'
  const [prefix, suffix] = actualCurrentTag.split(knownTagWithoutDesignSystemPrefix); // ['PREFIX-wb7', '-SUFFIX']
  return prefix + targetTagWithoutDesignSystemPrefix + suffix; // 'PREFIX-wb7-stepper-SUFFIX'
};

const CACHE = {};

function transformTagNameWithCache(originalTagName: string, hostElTagName: string, host: HTMLElement): void {
  if (!CACHE[originalTagName]) {
    CACHE[originalTagName] = applyTagNameTransformation(originalTagName, hostElTagName, host);
  }

  return CACHE[originalTagName];
}

function toCapitalizedCamelCase(str: string): string {
  return (' ' + str).toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (_m, chr) => {
    return chr.toUpperCase();
  });
}

type SnakeCaseToCapitalizedCamelCase<S extends string> = S extends `${infer T}-${infer U}` ? `${Capitalize<T>}${Capitalize<SnakeCaseToCapitalizedCamelCase<U>>}` : S;

export function transformTagNames<T extends string>(that, hostElTagName: string, tagNamesToTransform: Array<T>): Record<SnakeCaseToCapitalizedCamelCase<T>, string> {
  const host = getElement(that);
  const map = {};

  tagNamesToTransform.forEach((tagName) => {
    const camelCase = toCapitalizedCamelCase(tagName);
    map[camelCase] = transformTagNameWithCache(tagName, hostElTagName, host);
  });

  return map as Record<SnakeCaseToCapitalizedCamelCase<T>, string>;
}
