import { WorkbenchConfig } from '../shared/config-types';
import { versions } from './versions';

export const CONFIG_DEFAULTS: WorkbenchConfig = {
  iconRootPath: `https://assets.oneweb.mercedes-benz.com/plugin/workbench/assets/${versions.assets}/icons`,
  instances: [],
  showExperimentalWarnings: true,
  updateDirection: () => window.dispatchEvent(new Event('wbupdatedirection')),
};
