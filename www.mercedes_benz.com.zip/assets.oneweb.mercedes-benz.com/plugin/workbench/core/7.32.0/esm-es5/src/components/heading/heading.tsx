import { Component, ComponentInterface, h, Host, JSX, Prop } from '@stencil/core';

/** @slot - text content */
@Component({
  tag: 'wb-heading',
  styleUrl: 'heading.scss',
  shadow: true,
})
export class HeadingComponent implements ComponentInterface {
  /** size of the font */
  @Prop({ reflect: true })
  public size: 'xl' | 'l' | 'm' | 's' | 'xs' = 'm';

  /** sets text overflow ellipsis */
  @Prop({ reflect: true })
  public ellipsis: boolean = false;

  /** chinese font variants - only available in combination with `size` xl, l and m */
  @Prop({ reflect: true })
  public chinese: boolean = false;

  /** (semantic) html tag to wrap around text content */
  @Prop({ reflect: true })
  public tag: string = 'div';

  public render(): JSX.Element {
    const TagName = this.tag;

    return (
      <Host class="wb-heading">
        <TagName class="tag">
          <slot />
        </TagName>
      </Host>
    );
  }
}
