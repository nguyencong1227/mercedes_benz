import { Component, ComponentInterface, h, Host, JSX, Prop } from '@stencil/core';
import { transformTagNames } from '../../global/transform-tag-name';
import { DEFAULT_WORKBENCH_THEME, WorkbenchTheme } from '../../shared/themes';
import { ButtonSize } from '../button/button-size';

/**
 * @slot - Contents passed to the internal button
 * @slot icon - optional wb-icon element
 */
@Component({
  tag: 'wb-button-group-item',
  styleUrl: 'button-group-item.scss',
  shadow: true,
})
export class ButtonGroupComponent implements ComponentInterface {
  /** @interal used in combination with wb-button-group */
  @Prop({ reflect: true })
  public direction?: 'horizontal' | 'vertical';

  /** @interal used in combination with wb-button-group */
  @Prop({ reflect: true })
  public selected: boolean = false;

  /** displays loading state */
  @Prop({ reflect: true })
  public loading: boolean = false;

  /** button variant */
  @Prop({ reflect: true })
  public variant!: 'secondary' | 'translucent';

  /** button size */
  @Prop({ reflect: true })
  public size: ButtonSize = 'l';

  /** hides text and shows only icon */
  @Prop({ reflect: true })
  public iconOnly: boolean = false;

  /** prevents interaction with the button */
  @Prop({ reflect: true })
  public disabled: boolean = false;

  /** renders an anchor tag linked to the passed in URL (fragment) */
  @Prop()
  public href: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public download: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public rel: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public target: string | undefined;

  /** @internal the colour scheme */
  @Prop({ reflect: true })
  public theme: WorkbenchTheme = DEFAULT_WORKBENCH_THEME;

  private TagNames = transformTagNames(this, 'wb-button-group-item', ['wb-button']);

  public render(): JSX.Element {
    const { WbButton } = this.TagNames;

    return (
      <Host role="group" class="wb-button-group-item">
        <WbButton //
          loading={this.loading}
          variant={this.variant}
          size={this.size}
          theme={this.theme}
          iconOnly={this.iconOnly}
          disabled={this.disabled}
          href={this.href}
          download={this.download}
          rel={this.rel}
          target={this.target}
        >
          <slot name="icon" slot="icon" />
          <slot />
        </WbButton>
      </Host>
    );
  }
}
