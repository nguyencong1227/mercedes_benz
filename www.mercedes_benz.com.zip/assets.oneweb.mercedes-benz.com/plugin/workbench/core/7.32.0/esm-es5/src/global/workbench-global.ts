import { DirectionService } from '../utils/services/direction.service';
import { MediaQueryService } from '../utils/services/media-query.service';
import { ScrollLockService } from '../utils/services/scroll-lock.service';
import { CONFIG_DEFAULTS } from './config-defaults';
import { versions } from './versions';

export const SharedScrollLockService = new ScrollLockService();
export const SharedMediaQueryService = new MediaQueryService(window);
export const SharedDirectionService = new DirectionService(document.documentElement);

export default async (): Promise<void> => {
  if (window.workbench) {
    window.workbench = { ...CONFIG_DEFAULTS, ...window.workbench };
  } else {
    window.workbench = { ...CONFIG_DEFAULTS };
  }

  window.workbench.instances.push(versions);
  SharedMediaQueryService.observe();
};
