import { Build } from '@stencil/core';

/**
 * @name escapePrerender
 *
 * @description Prevent running while prerendering
 *
 * @example
 * escapePrerender(() => {
 *   console.log("I won't prerender");
 * });
 */
export const escapePrerender = (callback: () => void) => {
  if (Build.isBrowser || Build.isTesting) {
    callback();
  }
};
