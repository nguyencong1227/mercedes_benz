import { Component, ComponentInterface, h, Host, JSX, Prop } from '@stencil/core';

/** @slot - text content */
@Component({
  tag: 'wb-text',
  styleUrl: 'text.scss',
  shadow: true,
})
export class TextComponent implements ComponentInterface {
  /** size of the font */
  @Prop({ reflect: true })
  public size: 's' | 'm' | 'l' = 'm';

  /** prevents fonts from scaling up on larger screen sizes */
  @Prop({ reflect: true })
  public static: boolean = false;

  /** renders contents with a stronger font weight */
  @Prop({ reflect: true })
  public strong: boolean = false;

  /** sets text overflow ellipsis */
  @Prop({ reflect: true })
  public ellipsis: boolean = false;

  /** (semantic) html tag to wrap around text content */
  @Prop({ reflect: true })
  public tag: string = 'div';

  public render(): JSX.Element {
    const TagName = this.tag;

    return (
      <Host class="wb-text">
        <TagName class="tag">
          <slot />
        </TagName>
      </Host>
    );
  }
}
