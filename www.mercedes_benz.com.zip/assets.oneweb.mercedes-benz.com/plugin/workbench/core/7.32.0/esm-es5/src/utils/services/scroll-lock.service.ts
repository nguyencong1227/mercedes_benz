// NOTE: The below css class has to be publicly available

export const SCROLL_LOCK_CLASS = 'wb-scroll-lock'; // eslint-disable-line workbench/tag-name-transform

/**
 * @name ScrollLockService
 *
 * @description Locks/unlocks scrolling by adding/removing the `.wb-scroll-lock` class to the documentElement. Used for preventing scrolling of the background behind an open modal
 *
 * @example
 * import { ScrollLockService } from '@workbench/core';
 *
 * const scrollLockService = new ScrollLockService();
 *
 * // lock scrolling
 * scrollLockService.lock();
 *
 * // unlock scrolling
 * scrollLockService.unlock();
 */
export class ScrollLockService {
  public isLocked: boolean;

  private scrollTopBeforeLock: number = 0;
  private identifiers: Set<string> = new Set();

  constructor(public targetEl: HTMLElement = document.documentElement) {}

  public lock(id?: string): void {
    if (this.identifiers.size === 0) {
      this.scrollTopBeforeLock = this.targetEl.scrollTop;
      this.targetEl.style.top = `-${this.scrollTopBeforeLock}px`;
    }

    const prefix = id ? `-${id}` : '';
    this.targetEl.classList.add(`${SCROLL_LOCK_CLASS}${prefix}`);

    if (id) {
      this.identifiers.add(id);
    }

    this.isLocked = true;
  }

  public unlock(id?: string): void {
    if (!this.isLocked) {
      return;
    }

    const prefix = id ? `-${id}` : '';
    this.targetEl.classList.remove(`${SCROLL_LOCK_CLASS}${prefix}`);

    if (id) {
      this.identifiers.delete(id);
    }

    if (this.identifiers.size === 0) {
      this.targetEl.style.top = '';
      this.targetEl.scrollTop = this.scrollTopBeforeLock;
      this.isLocked = false;
    }
  }
}
