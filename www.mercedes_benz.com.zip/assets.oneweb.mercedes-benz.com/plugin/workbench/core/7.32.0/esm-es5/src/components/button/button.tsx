import { Component, ComponentInterface, Element, Event, EventEmitter, h, Host, JSX, Prop } from '@stencil/core';
import { transformTagNames } from '../../global/transform-tag-name';
import { DEFAULT_WORKBENCH_THEME, WorkbenchTheme } from '../../shared/themes';
import { SpinnerTheme } from '../spinner/spinner-theme';
import { ButtonSize } from './button-size';
import { ButtonVariant } from './button-variant';

/**
 * @slot - text content placed within button
 * @slot icon - optional icon
 * @part button - the button or anchor element rendered within the wb-button
 */
@Component({
  tag: 'wb-button',
  styleUrl: './button.scss',
  shadow: true,
})
export class Button implements ComponentInterface {
  @Element()
  public el: HTMLElement;

  /** displays loading state */
  @Prop({ reflect: true })
  public loading: boolean = false;

  /** button variant */
  @Prop({ reflect: true })
  public variant!: ButtonVariant;

  /** button size */
  @Prop({ reflect: true })
  public size: ButtonSize = 'l';

  /** colour scheme */
  @Prop({ reflect: true })
  public theme: WorkbenchTheme = DEFAULT_WORKBENCH_THEME;

  /** hides text and shows only icon */
  @Prop({ reflect: true })
  public iconOnly: boolean = false;

  /** prevents interaction with the button */
  @Prop({ reflect: true })
  public disabled: boolean = false;

  /** type of the button */
  @Prop()
  public type: 'button' | 'submit' = 'button';

  /** renders an anchor tag linked to the passed in URL (fragment) */
  @Prop()
  public href: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public download: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public rel: string | undefined;

  /** can be used in combination with `href` property */
  @Prop()
  public target: string | undefined;

  /** emitted when the button receives focus */
  @Event()
  public wbfocus!: EventEmitter<void>;

  /** emitted when the button loses focus */
  @Event()
  public wbblur!: EventEmitter<void>;

  private TagNames = transformTagNames(this, 'wb-button', ['wb-spinner']);

  private get spinnerTheme(): SpinnerTheme {
    if (this.variant === 'primary') {
      return 'blue';
    }

    if (this.theme === 'dark') {
      return 'dark';
    }

    return 'light';
  }

  private handleClick = (ev: Event) => {
    const shouldTriggerSubmitOnForm = !this.href && this.type === 'submit';

    if (shouldTriggerSubmitOnForm) {
      // this button wants to specifically submit a form
      // climb up the dom to see if we're in a <form>
      // and if so, then use JS to submit it
      const form = this.el.closest('form');

      if (form) {
        ev.preventDefault();

        const fakeButton = document.createElement('button');
        fakeButton.type = 'submit';
        fakeButton.style.display = 'none';
        form.appendChild(fakeButton);
        fakeButton.click();
        fakeButton.remove();
      }
    }
  };

  private onFocus = () => this.wbfocus.emit();

  private onBlur = () => this.wbblur.emit();

  public render(): JSX.Element {
    const { WbSpinner } = this.TagNames;

    return (
      <Host //
        class="wb-button"
        onClick={this.handleClick}
        aria-disabled={this.disabled ? 'true' : null}
      >
        {this.href && !this.disabled /* render button if component is disabled, which prevents click listeners from firing */ ? (
          <a //
            class="button"
            onFocus={this.onFocus}
            onBlur={this.onBlur}
            aria-label={this.el.getAttribute('aria-label')}
            href={this.href}
            rel={this.rel}
            target={this.target}
            download={this.download}
            part="button"
          >
            <slot name="icon" />
            <slot />
          </a>
        ) : (
          <button //
            class="button"
            onFocus={this.onFocus}
            onBlur={this.onBlur}
            aria-label={this.el.getAttribute('aria-label')}
            type={this.type}
            disabled={this.disabled}
            part="button"
          >
            <slot name="icon" />
            <slot />
          </button>
        )}
        {this.loading && <WbSpinner theme={this.spinnerTheme} />}
      </Host>
    );
  }
}
