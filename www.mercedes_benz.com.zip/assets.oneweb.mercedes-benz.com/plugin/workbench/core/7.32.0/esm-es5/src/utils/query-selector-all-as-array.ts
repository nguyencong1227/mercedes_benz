/**
 * @name querySelectorAllAsArray
 *
 * @description Returns an array of all matches for a given query selector
 *
 * @example
 * import { querySelectorAllAsArray } from '@workbench/core';
 *
 * const allPrimaryButtons: Array<HTMLButton> = querySelectorAllAsArray<HTMLButton>('button.primary');
 */
export const querySelectorAllAsArray = <T extends Element>(baseEl: HTMLElement | ShadowRoot, selector: string): Array<T> => Array.from<T>(baseEl.querySelectorAll(selector));
