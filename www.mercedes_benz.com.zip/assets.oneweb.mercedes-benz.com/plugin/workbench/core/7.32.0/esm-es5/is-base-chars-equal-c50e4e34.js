/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var isBaseCharsEqual = function (s, a) {
  return (
    (s === null || s === void 0
      ? void 0
      : s.localeCompare(a, "en", { sensitivity: "base" })) === 0
  );
};
export { isBaseCharsEqual as i };
//# sourceMappingURL=is-base-chars-equal-c50e4e34.js.map
