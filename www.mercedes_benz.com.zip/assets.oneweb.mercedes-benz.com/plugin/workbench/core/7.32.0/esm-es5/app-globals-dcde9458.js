/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import { a as appGlobalScript } from "./workbench-global-3eaf1f19.js";
var globalScripts = appGlobalScript;
export { globalScripts as g };
//# sourceMappingURL=app-globals-dcde9458.js.map
