/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var escapePrerender = function (e) {
  {
    e();
  }
};
var MediaQueryChangeEvent = (function () {
  function e(e, n) {
    this.current = e;
    this.previous = n;
  }
  return e;
})();
var MEDIA_QUERY_SIZES = {
  mq1: 320,
  mq2: 480,
  mq3: 768,
  mq4: 1024,
  mq5: 1280,
  mq6: 1440,
};
var WB_RESIZE_EVENT_NAME = "wbresize";
var MEDIA_QUERIES_TO_OBSERVE = ["mq2", "mq3", "mq4", "mq5", "mq6"];
var MediaQueryListener = (function () {
  function e(e, n, i) {
    var t = this;
    this.window = e;
    this.mq = n;
    this.callbackFn = i;
    escapePrerender(function () {
      var e = t.window.matchMedia(
        "(min-width: ".concat(MEDIA_QUERY_SIZES[n], "px)")
      );
      var i = function (e) {
        return t.callbackFn(t.mq, e.matches);
      };
      e.addListener(i);
      t.remove = function () {
        return e.removeListener(i);
      };
    });
  }
  return e;
})();
var MediaQueryService = (function () {
  function e(e) {
    var n = this;
    this.window = e;
    this.listeners = [];
    this.onMediaQueryChange = function (e, i) {
      if (i) {
        n.activeMediaQuery = e;
      } else {
        var t = n.activeMediaQuery;
        n.activeMediaQuery = n.getCurrentMediaQuery();
        if (t === n.activeMediaQuery) {
          return;
        }
      }
      n.emit();
    };
  }
  e.prototype.getCurrentMediaQuery = function () {
    for (var e = MEDIA_QUERIES_TO_OBSERVE.length - 1; e >= 0; e--) {
      if (
        this.window.matchMedia(
          "(min-width: ".concat(
            MEDIA_QUERY_SIZES[MEDIA_QUERIES_TO_OBSERVE[e]],
            "px)"
          )
        ).matches
      ) {
        return MEDIA_QUERIES_TO_OBSERVE[e];
      }
    }
    return "mq1";
  };
  e.prototype.observe = function (e) {
    var n = this;
    if (e === void 0) {
      e = false;
    }
    if (e) {
      this.activeMediaQuery =
        this.activeMediaQuery || this.getCurrentMediaQuery();
      this.emit();
    }
    MEDIA_QUERIES_TO_OBSERVE.filter(function (e) {
      return !n.listeners.find(function (n) {
        return n.mq === e;
      });
    }).forEach(function (e) {
      return n.listeners.push(
        new MediaQueryListener(n.window, e, n.onMediaQueryChange)
      );
    });
  };
  e.prototype.disconnect = function () {
    this.listeners.forEach(function (e) {
      return e.remove();
    });
    this.listeners = [];
  };
  e.prototype.emit = function () {
    this.window.dispatchEvent(
      new CustomEvent(WB_RESIZE_EVENT_NAME, {
        detail: new MediaQueryChangeEvent(
          this.activeMediaQuery,
          this.previousMediaQuery
        ),
      })
    );
    this.previousMediaQuery = this.activeMediaQuery;
  };
  return e;
})();
export {
  MediaQueryService as M,
  WB_RESIZE_EVENT_NAME as W,
  MediaQueryChangeEvent as a,
  MEDIA_QUERY_SIZES as b,
  escapePrerender as e,
};
//# sourceMappingURL=media-query.service-08aeb0ba.js.map
