/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import {
  r as registerInstance,
  c as createEvent,
  h,
  a as Host,
  g as getElement,
} from "./index-5bae4795.js";
import { t as transformTagNames } from "./transform-tag-name-a73790cf.js";
import { D as DEFAULT_WORKBENCH_THEME } from "./themes-a8a87b7c.js";
var buttonCss =
  ':host{--btn-bg-color:var(--wb-blue-45);--btn-bg-color-hover:var(--wb-blue-25);--btn-bg-color-active:var(--wb-blue-35);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-blue-45);--btn-box-shadow:0 0 0 0.0625rem var(--wb-white) inset;--btn-border-radius:var(--wb-radius-s);--btn-transition:color $btn-animation-duration var(--wb-fade),background-color $btn-animation-duration var(--wb-fade);--btn-animation-duration:2s}:host([variant=secondary]){--btn-bg-color:var(--wb-transparent);--btn-bg-color-hover:var(--wb-grey-85);--btn-bg-color-active:var(--wb-grey-95);--btn-text-color:var(--wb-grey-20);--btn-border:0.0625rem solid var(--wb-grey-70);--btn-box-shadow:0 0 0 0.0625rem var(--wb-blue-45) inset}:host([variant=tertiary]){--btn-bg-color:var(--wb-transparent);--btn-bg-color-hover:var(--wb-black-opacity-low);--btn-bg-color-active:var(--wb-black-opacity-extra-low);--btn-text-color:var(--wb-blue-40);--btn-border:0.0625rem solid var(--wb-transparent);--btn-box-shadow:0 0 0 0.0625rem var(--wb-blue-45) inset}:host([variant=translucent]){--btn-bg-color:var(--wb-white-opacity-medium);--btn-bg-color-hover:var(--wb-white);--btn-bg-color-active:var(--wb-white-opacity-high);--btn-text-color:var(--wb-grey-20);--btn-border:0.0625rem solid var(--wb-grey-70);--btn-box-shadow:0 0 0 0.0625rem var(--wb-blue-45) inset}:host([variant=destructive]){--btn-bg-color:var(--wb-red-45);--btn-bg-color-hover:var(--wb-red-30);--btn-bg-color-active:var(--wb-red-35);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-red-45);--btn-box-shadow:0 0 0 0.0625rem var(--wb-white) inset}:host([theme=dark]){--btn-bg-color:var(--wb-blue-45);--btn-bg-color-hover:var(--wb-blue-25);--btn-bg-color-active:var(--wb-blue-35);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-blue-45);--btn-box-shadow:0 0 0 0.0625rem var(--wb-white) inset;--btn-border-radius:var(--wb-radius-s);--btn-transition:color $btn-animation-duration var(--wb-fade),background-color $btn-animation-duration var(--wb-fade);--btn-animation-duration:2s}:host([theme=dark][variant=secondary]){--btn-bg-color:var(--wb-transparent);--btn-bg-color-hover:var(--wb-grey-25);--btn-bg-color-active:var(--wb-grey-15);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-grey-40);--btn-box-shadow:0 0 0 0.0625rem var(--wb-blue-40) inset}:host([theme=dark][variant=tertiary]){--btn-bg-color:var(--wb-transparent);--btn-bg-color-hover:var(--wb-white-opacity-low);--btn-bg-color-active:var(--wb-white-opacity-extra-low);--btn-text-color:var(--wb-blue-55);--btn-border:0.0625rem solid var(--wb-transparent);--btn-box-shadow:0 0 0 0.0625rem var(--wb-white) inset}:host([theme=dark][variant=translucent]){--btn-bg-color:var(--wb-black-opacity-medium);--btn-bg-color-hover:var(--wb-black);--btn-bg-color-active:var(--wb-black-opacity-high);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-grey-40);--btn-box-shadow:0 0 0 0.0625rem var(--wb-white) inset}:host([theme=dark][variant=destructive]){--btn-bg-color:var(--wb-red-45);--btn-bg-color-hover:var(--wb-red-30);--btn-bg-color-active:var(--wb-red-35);--btn-text-color:var(--wb-white);--btn-border:0.0625rem solid var(--wb-red-45);--btn-box-shadow:0 0 0 0.0625rem var(--wb-blue-45) inset}:host{display:-ms-inline-flexbox;display:inline-flex;min-width:9rem;position:relative;vertical-align:middle}:host .button{-webkit-tap-highlight-color:transparent;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-ms-flex-align:center;align-items:center;-webkit-appearance:none;-moz-appearance:none;appearance:none;background:var(--btn-bg-color);border:var(--btn-border);border-radius:var(--wb-radius-s);-webkit-box-sizing:border-box;box-sizing:border-box;color:var(--btn-text-color);cursor:pointer;display:-ms-inline-flexbox;display:inline-flex;-ms-flex:1;flex:1;font-family:var(--wb-font-text-bold);font-size:1rem;font-style:normal;font-weight:700;gap:.5rem;-ms-flex-pack:center;justify-content:center;letter-spacing:.0125rem;line-height:1.5rem;margin:0;outline:none;outline-offset:0;overflow:visible;text-align:center;text-decoration:none;text-transform:none;-webkit-transition:var(--btn-transition);transition:var(--btn-transition)}:host .button:focus{-webkit-box-shadow:var(--btn-box-shadow);box-shadow:var(--btn-box-shadow)}:host .button:hover:not([disabled]){background:var(--btn-bg-color-hover)}:host .button:active:not([disabled]){background:var(--btn-bg-color-active)}:host .button::-moz-focus-inner{border-style:none;padding:0}:host .button sup{font-size:max(.625rem,min(.6em,1rem));line-height:0}:host .button sub{font-size:max(.45em,min(.7em,.875rem));line-height:0}:host .wb-spinner{--size:var(--spinner-size);cursor:pointer;left:50%;opacity:0;position:absolute;top:50%;-webkit-transform:translate3d(-50%,-50%,0);transform:translate3d(-50%,-50%,0);-webkit-transition:opacity var(--btn-animation-duration) var(--wb-fade);transition:opacity var(--btn-animation-duration) var(--wb-fade)}::slotted(.wb-icon){--size:0.75rem;-ms-flex-negative:0;flex-shrink:0;overflow:hidden}::slotted(.wb-icon[name*="/"]){--size:1rem}:host([disabled]){cursor:not-allowed;opacity:.4}:host([disabled]) .button{cursor:not-allowed}:host([disabled]) .wb-spinner,:host([disabled]) slot{pointer-events:none}:host([size=l]){--spinner-size:2rem}:host([size=l]) .button{padding:.9375rem 1.9375rem}:host([size=m]){--spinner-size:1.5rem}:host([size=m]) .button{padding:.6875rem 1.4375rem}:host([size=s]){--spinner-size:1rem}:host([size=s]) .button{padding:.4375rem .9375rem}:host([variant=tertiary][size=l]) .button{-webkit-padding-end:1.4375rem;padding-inline-end:1.4375rem;-webkit-padding-start:1.4375rem;padding-inline-start:1.4375rem}:host([variant=tertiary][size=m]) .button{-webkit-padding-end:.9375rem;padding-inline-end:.9375rem;-webkit-padding-start:.9375rem;padding-inline-start:.9375rem}:host([variant=tertiary][size=s]) .button{-webkit-padding-end:.4375rem;padding-inline-end:.4375rem;-webkit-padding-start:.4375rem;padding-inline-start:.4375rem}:host([loading]) .button{color:transparent!important}:host([loading]) .wb-spinner{opacity:1}:host([icon-only]),:host([variant=tertiary]){min-width:auto}:host([icon-only]) .button{font-size:0;gap:0;min-width:0;padding:0}:host([icon-only]) ::slotted(.wb-icon){--size:1rem}:host([icon-only]) ::slotted(.wb-icon[name*="/"]){--size:1.5rem}:host([icon-only][size=l]) .button{height:3.5rem;width:3.5rem}:host([icon-only][size=m]) .button{height:3rem;width:3rem}:host([icon-only][size=s]) .button{height:2.5rem;width:2.5rem}';
var Button = (function () {
  function t(t) {
    var e = this;
    registerInstance(this, t);
    this.wbfocus = createEvent(this, "wbfocus", 7);
    this.wbblur = createEvent(this, "wbblur", 7);
    this.TagNames = transformTagNames(this, "wb-button", ["wb-spinner"]);
    this.handleClick = function (t) {
      var r = !e.href && e.type === "submit";
      if (r) {
        var n = e.el.closest("form");
        if (n) {
          t.preventDefault();
          var o = document.createElement("button");
          o.type = "submit";
          o.style.display = "none";
          n.appendChild(o);
          o.click();
          o.remove();
        }
      }
    };
    this.onFocus = function () {
      return e.wbfocus.emit();
    };
    this.onBlur = function () {
      return e.wbblur.emit();
    };
    this.loading = false;
    this.variant = undefined;
    this.size = "l";
    this.theme = DEFAULT_WORKBENCH_THEME;
    this.iconOnly = false;
    this.disabled = false;
    this.type = "button";
    this.href = undefined;
    this.download = undefined;
    this.rel = undefined;
    this.target = undefined;
  }
  Object.defineProperty(t.prototype, "spinnerTheme", {
    get: function () {
      if (this.variant === "primary") {
        return "blue";
      }
      if (this.theme === "dark") {
        return "dark";
      }
      return "light";
    },
    enumerable: false,
    configurable: true,
  });
  t.prototype.render = function () {
    var t = this.TagNames.WbSpinner;
    return h(
      Host,
      {
        class: "wb-button",
        onClick: this.handleClick,
        "aria-disabled": this.disabled ? "true" : null,
      },
      this.href && !this.disabled
        ? h(
            "a",
            {
              class: "button",
              onFocus: this.onFocus,
              onBlur: this.onBlur,
              "aria-label": this.el.getAttribute("aria-label"),
              href: this.href,
              rel: this.rel,
              target: this.target,
              download: this.download,
              part: "button",
            },
            h("slot", { name: "icon" }),
            h("slot", null)
          )
        : h(
            "button",
            {
              class: "button",
              onFocus: this.onFocus,
              onBlur: this.onBlur,
              "aria-label": this.el.getAttribute("aria-label"),
              type: this.type,
              disabled: this.disabled,
              part: "button",
            },
            h("slot", { name: "icon" }),
            h("slot", null)
          ),
      this.loading && h(t, { theme: this.spinnerTheme })
    );
  };
  Object.defineProperty(t.prototype, "el", {
    get: function () {
      return getElement(this);
    },
    enumerable: false,
    configurable: true,
  });
  return t;
})();
Button.style = buttonCss;
export { Button as wb_button };
//# sourceMappingURL=wb-button.entry.js.map
