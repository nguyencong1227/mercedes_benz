/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var __extends =
  (this && this.__extends) ||
  (function () {
    var e = function (n, r) {
      e =
        Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array &&
          function (e, n) {
            e.__proto__ = n;
          }) ||
        function (e, n) {
          for (var r in n)
            if (Object.prototype.hasOwnProperty.call(n, r)) e[r] = n[r];
        };
      return e(n, r);
    };
    return function (n, r) {
      if (typeof r !== "function" && r !== null)
        throw new TypeError(
          "Class extends value " + String(r) + " is not a constructor or null"
        );
      e(n, r);
      function t() {
        this.constructor = n;
      }
      n.prototype =
        r === null ? Object.create(r) : ((t.prototype = r.prototype), new t());
    };
  })();
var __awaiter =
  (this && this.__awaiter) ||
  function (e, n, r, t) {
    function i(e) {
      return e instanceof r
        ? e
        : new r(function (n) {
            n(e);
          });
    }
    return new (r || (r = Promise))(function (r, a) {
      function o(e) {
        try {
          f(t.next(e));
        } catch (e) {
          a(e);
        }
      }
      function u(e) {
        try {
          f(t["throw"](e));
        } catch (e) {
          a(e);
        }
      }
      function f(e) {
        e.done ? r(e.value) : i(e.value).then(o, u);
      }
      f((t = t.apply(e, n || [])).next());
    });
  };
var __generator =
  (this && this.__generator) ||
  function (e, n) {
    var r = {
        label: 0,
        sent: function () {
          if (a[0] & 1) throw a[1];
          return a[1];
        },
        trys: [],
        ops: [],
      },
      t,
      i,
      a,
      o;
    return (
      (o = { next: u(0), throw: u(1), return: u(2) }),
      typeof Symbol === "function" &&
        (o[Symbol.iterator] = function () {
          return this;
        }),
      o
    );
    function u(e) {
      return function (n) {
        return f([e, n]);
      };
    }
    function f(u) {
      if (t) throw new TypeError("Generator is already executing.");
      while ((o && ((o = 0), u[0] && (r = 0)), r))
        try {
          if (
            ((t = 1),
            i &&
              (a =
                u[0] & 2
                  ? i["return"]
                  : u[0]
                  ? i["throw"] || ((a = i["return"]) && a.call(i), 0)
                  : i.next) &&
              !(a = a.call(i, u[1])).done)
          )
            return a;
          if (((i = 0), a)) u = [u[0] & 2, a.value];
          switch (u[0]) {
            case 0:
            case 1:
              a = u;
              break;
            case 4:
              r.label++;
              return { value: u[1], done: false };
            case 5:
              r.label++;
              i = u[1];
              u = [0];
              continue;
            case 7:
              u = r.ops.pop();
              r.trys.pop();
              continue;
            default:
              if (
                !((a = r.trys), (a = a.length > 0 && a[a.length - 1])) &&
                (u[0] === 6 || u[0] === 2)
              ) {
                r = 0;
                continue;
              }
              if (u[0] === 3 && (!a || (u[1] > a[0] && u[1] < a[3]))) {
                r.label = u[1];
                break;
              }
              if (u[0] === 6 && r.label < a[1]) {
                r.label = a[1];
                a = u;
                break;
              }
              if (a && r.label < a[2]) {
                r.label = a[2];
                r.ops.push(u);
                break;
              }
              if (a[2]) r.ops.pop();
              r.trys.pop();
              continue;
          }
          u = n.call(e, r);
        } catch (e) {
          u = [6, e];
          i = 0;
        } finally {
          t = a = 0;
        }
      if (u[0] & 5) throw u[1];
      return { value: u[0] ? u[1] : void 0, done: true };
    }
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (e, n, r) {
    if (r || arguments.length === 2)
      for (var t = 0, i = n.length, a; t < i; t++) {
        if (a || !(t in n)) {
          if (!a) a = Array.prototype.slice.call(n, 0, t);
          a[t] = n[t];
        }
      }
    return e.concat(a || Array.prototype.slice.call(n));
  };
var NAMESPACE = "workbench";
var scopeId;
var hostTagName;
var isSvgMode = false;
var queuePending = false;
var createTime = function (e, n) {
  if (n === void 0) {
    n = "";
  }
  {
    return function () {
      return;
    };
  }
};
var uniqueTime = function (e, n) {
  {
    return function () {
      return;
    };
  }
};
var CONTENT_REF_ID = "r";
var ORG_LOCATION_ID = "o";
var SLOT_NODE_ID = "s";
var TEXT_NODE_ID = "t";
var HYDRATE_ID = "s-id";
var HYDRATED_STYLE_ID = "sty-id";
var HYDRATE_CHILD_ID = "c-id";
var HYDRATED_CSS = "{visibility:hidden}.hydrated{visibility:inherit}";
var SLOT_FB_CSS = "slot-fb{display:contents}slot-fb[hidden]{display:none}";
var XLINK_NS = "http://www.w3.org/1999/xlink";
var EMPTY_OBJ = {};
var SVG_NS = "http://www.w3.org/2000/svg";
var HTML_NS = "http://www.w3.org/1999/xhtml";
var isDef = function (e) {
  return e != null;
};
var isComplexType = function (e) {
  e = typeof e;
  return e === "object" || e === "function";
};
function queryNonceMetaTagContent(e) {
  var n, r, t;
  return (t =
    (r =
      (n = e.head) === null || n === void 0
        ? void 0
        : n.querySelector('meta[name="csp-nonce"]')) === null || r === void 0
      ? void 0
      : r.getAttribute("content")) !== null && t !== void 0
    ? t
    : undefined;
}
var h = function (e, n) {
  var r = [];
  for (var t = 2; t < arguments.length; t++) {
    r[t - 2] = arguments[t];
  }
  var i = null;
  var a = null;
  var o = false;
  var u = false;
  var f = [];
  var l = function (n) {
    for (var r = 0; r < n.length; r++) {
      i = n[r];
      if (Array.isArray(i)) {
        l(i);
      } else if (i != null && typeof i !== "boolean") {
        if ((o = typeof e !== "function" && !isComplexType(i))) {
          i = String(i);
        }
        if (o && u) {
          f[f.length - 1].t += i;
        } else {
          f.push(o ? newVNode(null, i) : i);
        }
        u = o;
      }
    }
  };
  l(r);
  if (n) {
    if (n.key) {
      a = n.key;
    }
    {
      var s = n.className || n.class;
      if (s) {
        n.class =
          typeof s !== "object"
            ? s
            : Object.keys(s)
                .filter(function (e) {
                  return s[e];
                })
                .join(" ");
      }
    }
  }
  if (typeof e === "function") {
    return e(n === null ? {} : n, f, vdomFnUtils);
  }
  var c = newVNode(e, null);
  c.i = n;
  if (f.length > 0) {
    c.o = f;
  }
  {
    c.u = a;
  }
  return c;
};
var newVNode = function (e, n) {
  var r = { l: 0, v: e, t: n, p: null, o: null };
  {
    r.i = null;
  }
  {
    r.u = null;
  }
  return r;
};
var Host = {};
var isHost = function (e) {
  return e && e.v === Host;
};
var vdomFnUtils = {
  forEach: function (e, n) {
    return e.map(convertToPublic).forEach(n);
  },
  map: function (e, n) {
    return e.map(convertToPublic).map(n).map(convertToPrivate);
  },
};
var convertToPublic = function (e) {
  return {
    vattrs: e.i,
    vchildren: e.o,
    vkey: e.u,
    vname: e.h,
    vtag: e.v,
    vtext: e.t,
  };
};
var convertToPrivate = function (e) {
  if (typeof e.vtag === "function") {
    var n = Object.assign({}, e.vattrs);
    if (e.vkey) {
      n.key = e.vkey;
    }
    if (e.vname) {
      n.name = e.vname;
    }
    return h.apply(
      void 0,
      __spreadArray([e.vtag, n], e.vchildren || [], false)
    );
  }
  var r = newVNode(e.vtag, e.vtext);
  r.i = e.vattrs;
  r.o = e.vchildren;
  r.u = e.vkey;
  r.h = e.vname;
  return r;
};
var initializeClientHydrate = function (e, n, r, t) {
  var i = createTime("hydrateClient", n);
  var a = e.shadowRoot;
  var o = [];
  var u = [];
  var f = a ? [] : null;
  var l = (t.m = newVNode(n, null));
  if (!plt.S) {
    initializeDocumentHydrate(doc.body, (plt.S = new Map()));
  }
  e[HYDRATE_ID] = r;
  e.removeAttribute(HYDRATE_ID);
  clientHydrate(l, o, u, f, e, e, r);
  o.map(function (e) {
    var r = e._ + "." + e.T;
    var t = plt.S.get(r);
    var i = e.p;
    if (t && supportsShadow && t["s-en"] === "") {
      t.parentNode.insertBefore(i, t.nextSibling);
    }
    if (!a) {
      i["s-hn"] = n;
      if (t) {
        i["s-ol"] = t;
        i["s-ol"]["s-nr"] = i;
      }
    }
    plt.S.delete(r);
  });
  if (a) {
    f.map(function (e) {
      if (e) {
        a.appendChild(e);
      }
    });
  }
  i();
};
var clientHydrate = function (e, n, r, t, i, a, o) {
  var u;
  var f;
  var l;
  var s;
  if (a.nodeType === 1) {
    u = a.getAttribute(HYDRATE_CHILD_ID);
    if (u) {
      f = u.split(".");
      if (f[0] === o || f[0] === "0") {
        l = {
          l: 0,
          _: f[0],
          T: f[1],
          C: f[2],
          $: f[3],
          v: a.tagName.toLowerCase(),
          p: a,
          i: null,
          o: null,
          u: null,
          h: null,
          t: null,
        };
        n.push(l);
        a.removeAttribute(HYDRATE_CHILD_ID);
        if (!e.o) {
          e.o = [];
        }
        e.o[l.$] = l;
        e = l;
        if (t && l.C === "0") {
          t[l.$] = l.p;
        }
      }
    }
    for (s = a.childNodes.length - 1; s >= 0; s--) {
      clientHydrate(e, n, r, t, i, a.childNodes[s], o);
    }
    if (a.shadowRoot) {
      for (s = a.shadowRoot.childNodes.length - 1; s >= 0; s--) {
        clientHydrate(e, n, r, t, i, a.shadowRoot.childNodes[s], o);
      }
    }
  } else if (a.nodeType === 8) {
    f = a.nodeValue.split(".");
    if (f[1] === o || f[1] === "0") {
      u = f[0];
      l = {
        l: 0,
        _: f[1],
        T: f[2],
        C: f[3],
        $: f[4],
        p: a,
        i: null,
        o: null,
        u: null,
        h: null,
        v: null,
        t: null,
      };
      if (u === TEXT_NODE_ID) {
        l.p = a.nextSibling;
        if (l.p && l.p.nodeType === 3) {
          l.t = l.p.textContent;
          n.push(l);
          a.remove();
          if (!e.o) {
            e.o = [];
          }
          e.o[l.$] = l;
          if (t && l.C === "0") {
            t[l.$] = l.p;
          }
        }
      } else if (l._ === o) {
        if (u === SLOT_NODE_ID) {
          l.v = "slot";
          if (f[5]) {
            a["s-sn"] = l.h = f[5];
          } else {
            a["s-sn"] = "";
          }
          a["s-sr"] = true;
          if (t) {
            l.p = doc.createElement(l.v);
            if (l.h) {
              l.p.setAttribute("name", l.h);
            }
            a.parentNode.insertBefore(l.p, a);
            a.remove();
            if (l.C === "0") {
              t[l.$] = l.p;
            }
          }
          r.push(l);
          if (!e.o) {
            e.o = [];
          }
          e.o[l.$] = l;
        } else if (u === CONTENT_REF_ID) {
          if (t) {
            a.remove();
          }
        }
      }
    }
  } else if (e && e.v === "style") {
    var c = newVNode(null, a.textContent);
    c.p = a;
    c.$ = "0";
    e.o = [c];
  }
};
var initializeDocumentHydrate = function (e, n) {
  if (e.nodeType === 1) {
    var r = 0;
    for (; r < e.childNodes.length; r++) {
      initializeDocumentHydrate(e.childNodes[r], n);
    }
    if (e.shadowRoot) {
      for (r = 0; r < e.shadowRoot.childNodes.length; r++) {
        initializeDocumentHydrate(e.shadowRoot.childNodes[r], n);
      }
    }
  } else if (e.nodeType === 8) {
    var t = e.nodeValue.split(".");
    if (t[0] === ORG_LOCATION_ID) {
      n.set(t[1] + "." + t[2], e);
      e.nodeValue = "";
      e["s-en"] = t[3];
    }
  }
};
var parsePropertyValue = function (e, n) {
  if (e != null && !isComplexType(e)) {
    if (n & 4) {
      return e === "false" ? false : e === "" || !!e;
    }
    if (n & 2) {
      return parseFloat(e);
    }
    if (n & 1) {
      return String(e);
    }
    return e;
  }
  return e;
};
var getElement = function (e) {
  return getHostRef(e).$hostElement$;
};
var createEvent = function (e, n, r) {
  var t = getElement(e);
  return {
    emit: function (e) {
      return emitEvent(t, n, {
        bubbles: !!(r & 4),
        composed: !!(r & 2),
        cancelable: !!(r & 1),
        detail: e,
      });
    },
  };
};
var emitEvent = function (e, n, r) {
  var t = plt.ce(n, r);
  e.dispatchEvent(t);
  return t;
};
var rootAppliedStyles = new WeakMap();
var registerStyle = function (e, n, r) {
  var t = styles.get(e);
  if (supportsConstructableStylesheets && r) {
    t = t || new CSSStyleSheet();
    if (typeof t === "string") {
      t = n;
    } else {
      t.replaceSync(n);
    }
  } else {
    t = n;
  }
  styles.set(e, t);
};
var addStyle = function (e, n, r) {
  var t;
  var i = getScopeId(n);
  var a = styles.get(i);
  e = e.nodeType === 11 ? e : doc;
  if (a) {
    if (typeof a === "string") {
      e = e.head || e;
      var o = rootAppliedStyles.get(e);
      var u = void 0;
      if (!o) {
        rootAppliedStyles.set(e, (o = new Set()));
      }
      if (!o.has(i)) {
        if (
          e.host &&
          (u = e.querySelector(
            "[".concat(HYDRATED_STYLE_ID, '="').concat(i, '"]')
          ))
        ) {
          u.innerHTML = a;
        } else {
          u = doc.createElement("style");
          u.innerHTML = a;
          var f =
            (t = plt.H) !== null && t !== void 0
              ? t
              : queryNonceMetaTagContent(doc);
          if (f != null) {
            u.setAttribute("nonce", f);
          }
          e.insertBefore(u, e.querySelector("link"));
        }
        if (n.l & 4) {
          u.innerHTML += SLOT_FB_CSS;
        }
        if (o) {
          o.add(i);
        }
      }
    } else if (!e.adoptedStyleSheets.includes(a)) {
      e.adoptedStyleSheets = __spreadArray(
        __spreadArray([], e.adoptedStyleSheets, true),
        [a],
        false
      );
    }
  }
  return i;
};
var attachStyles = function (e) {
  var n = e.D;
  var r = e.$hostElement$;
  var t = n.l;
  var i = createTime("attachStyles", n.N);
  var a = addStyle(r.shadowRoot ? r.shadowRoot : r.getRootNode(), n);
  if (t & 10) {
    r["s-sc"] = a;
    r.classList.add(a + "-h");
  }
  i();
};
var getScopeId = function (e, n) {
  return "sc-" + e.N;
};
var convertScopedToShadow = function (e) {
  return e.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{");
};
var setAccessor = function (e, n, r, t, i, a) {
  if (r !== t) {
    var o = isMemberInElement(e, n);
    var u = n.toLowerCase();
    if (n === "class") {
      var f = e.classList;
      var l = parseClassList(r);
      var s = parseClassList(t);
      f.remove.apply(
        f,
        l.filter(function (e) {
          return e && !s.includes(e);
        })
      );
      f.add.apply(
        f,
        s.filter(function (e) {
          return e && !l.includes(e);
        })
      );
    } else if (n === "style") {
      {
        for (var c in r) {
          if (!t || t[c] == null) {
            if (c.includes("-")) {
              e.style.removeProperty(c);
            } else {
              e.style[c] = "";
            }
          }
        }
      }
      for (var c in t) {
        if (!r || t[c] !== r[c]) {
          if (c.includes("-")) {
            e.style.setProperty(c, t[c]);
          } else {
            e.style[c] = t[c];
          }
        }
      }
    } else if (n === "key");
    else if (n === "ref") {
      if (t) {
        t(e);
      }
    } else if (!o && n[0] === "o" && n[1] === "n") {
      if (n[2] === "-") {
        n = n.slice(3);
      } else if (isMemberInElement(win, u)) {
        n = u.slice(2);
      } else {
        n = u[2] + n.slice(3);
      }
      if (r || t) {
        var v = n.endsWith(CAPTURE_EVENT_SUFFIX);
        n = n.replace(CAPTURE_EVENT_REGEX, "");
        if (r) {
          plt.rel(e, n, r, v);
        }
        if (t) {
          plt.ael(e, n, t, v);
        }
      }
    } else {
      var d = isComplexType(t);
      if ((o || (d && t !== null)) && !i) {
        try {
          if (!e.tagName.includes("-")) {
            var p = t == null ? "" : t;
            if (n === "list") {
              o = false;
            } else if (r == null || e[n] != p) {
              e[n] = p;
            }
          } else {
            e[n] = t;
          }
        } catch (e) {}
      }
      var h = false;
      {
        if (u !== (u = u.replace(/^xlink\:?/, ""))) {
          n = u;
          h = true;
        }
      }
      if (t == null || t === false) {
        if (t !== false || e.getAttribute(n) === "") {
          if (h) {
            e.removeAttributeNS(XLINK_NS, n);
          } else {
            e.removeAttribute(n);
          }
        }
      } else if ((!o || a & 4 || i) && !d) {
        t = t === true ? "" : t;
        if (h) {
          e.setAttributeNS(XLINK_NS, n, t);
        } else {
          e.setAttribute(n, t);
        }
      }
    }
  }
};
var parseClassListRegex = /\s/;
var parseClassList = function (e) {
  return !e ? [] : e.split(parseClassListRegex);
};
var CAPTURE_EVENT_SUFFIX = "Capture";
var CAPTURE_EVENT_REGEX = new RegExp(CAPTURE_EVENT_SUFFIX + "$");
var updateElement = function (e, n, r, t) {
  var i = n.p.nodeType === 11 && n.p.host ? n.p.host : n.p;
  var a = (e && e.i) || EMPTY_OBJ;
  var o = n.i || EMPTY_OBJ;
  {
    for (t in a) {
      if (!(t in o)) {
        setAccessor(i, t, a[t], undefined, r, n.l);
      }
    }
  }
  for (t in o) {
    setAccessor(i, t, a[t], o[t], r, n.l);
  }
};
var createElm = function (e, n, r, t) {
  var i = n.o[r];
  var a = 0;
  var o;
  var u;
  if (i.t !== null) {
    o = i.p = doc.createTextNode(i.t);
  } else {
    if (!isSvgMode) {
      isSvgMode = i.v === "svg";
    }
    o = i.p = doc.createElementNS(isSvgMode ? SVG_NS : HTML_NS, i.v);
    if (isSvgMode && i.v === "foreignObject") {
      isSvgMode = false;
    }
    {
      updateElement(null, i, isSvgMode);
    }
    if (isDef(scopeId) && o["s-si"] !== scopeId) {
      o.classList.add((o["s-si"] = scopeId));
    }
    if (i.o) {
      for (a = 0; a < i.o.length; ++a) {
        u = createElm(e, i, a);
        if (u) {
          o.appendChild(u);
        }
      }
    }
    {
      if (i.v === "svg") {
        isSvgMode = false;
      } else if (o.tagName === "foreignObject") {
        isSvgMode = true;
      }
    }
  }
  return o;
};
var addVnodes = function (e, n, r, t, i, a) {
  var o = e;
  var u;
  if (o.shadowRoot && o.tagName === hostTagName) {
    o = o.shadowRoot;
  }
  for (; i <= a; ++i) {
    if (t[i]) {
      u = createElm(null, r, i);
      if (u) {
        t[i].p = u;
        o.insertBefore(u, n);
      }
    }
  }
};
var removeVnodes = function (e, n, r) {
  for (var t = n; t <= r; ++t) {
    var i = e[t];
    if (i) {
      var a = i.p;
      nullifyVNodeRefs(i);
      if (a) {
        a.remove();
      }
    }
  }
};
var updateChildren = function (e, n, r, t) {
  var i = 0;
  var a = 0;
  var o = 0;
  var u = 0;
  var f = n.length - 1;
  var l = n[0];
  var s = n[f];
  var c = t.length - 1;
  var v = t[0];
  var d = t[c];
  var p;
  var h;
  while (i <= f && a <= c) {
    if (l == null) {
      l = n[++i];
    } else if (s == null) {
      s = n[--f];
    } else if (v == null) {
      v = t[++a];
    } else if (d == null) {
      d = t[--c];
    } else if (isSameVnode(l, v)) {
      patch(l, v);
      l = n[++i];
      v = t[++a];
    } else if (isSameVnode(s, d)) {
      patch(s, d);
      s = n[--f];
      d = t[--c];
    } else if (isSameVnode(l, d)) {
      patch(l, d);
      e.insertBefore(l.p, s.p.nextSibling);
      l = n[++i];
      d = t[--c];
    } else if (isSameVnode(s, v)) {
      patch(s, v);
      e.insertBefore(s.p, l.p);
      s = n[--f];
      v = t[++a];
    } else {
      o = -1;
      {
        for (u = i; u <= f; ++u) {
          if (n[u] && n[u].u !== null && n[u].u === v.u) {
            o = u;
            break;
          }
        }
      }
      if (o >= 0) {
        h = n[o];
        if (h.v !== v.v) {
          p = createElm(n && n[a], r, o);
        } else {
          patch(h, v);
          n[o] = undefined;
          p = h.p;
        }
        v = t[++a];
      } else {
        p = createElm(n && n[a], r, a);
        v = t[++a];
      }
      if (p) {
        {
          l.p.parentNode.insertBefore(p, l.p);
        }
      }
    }
  }
  if (i > f) {
    addVnodes(e, t[c + 1] == null ? null : t[c + 1].p, r, t, a, c);
  } else if (a > c) {
    removeVnodes(n, i, f);
  }
};
var isSameVnode = function (e, n) {
  if (e.v === n.v) {
    {
      return e.u === n.u;
    }
  }
  return false;
};
var patch = function (e, n) {
  var r = (n.p = e.p);
  var t = e.o;
  var i = n.o;
  var a = n.v;
  var o = n.t;
  if (o === null) {
    {
      isSvgMode =
        a === "svg" ? true : a === "foreignObject" ? false : isSvgMode;
    }
    {
      if (a === "slot");
      else {
        updateElement(e, n, isSvgMode);
      }
    }
    if (t !== null && i !== null) {
      updateChildren(r, t, n, i);
    } else if (i !== null) {
      if (e.t !== null) {
        r.textContent = "";
      }
      addVnodes(r, null, n, i, 0, i.length - 1);
    } else if (t !== null) {
      removeVnodes(t, 0, t.length - 1);
    }
    if (isSvgMode && a === "svg") {
      isSvgMode = false;
    }
  } else if (e.t !== o) {
    r.data = o;
  }
};
var nullifyVNodeRefs = function (e) {
  {
    e.i && e.i.ref && e.i.ref(null);
    e.o && e.o.map(nullifyVNodeRefs);
  }
};
var renderVdom = function (e, n, r) {
  if (r === void 0) {
    r = false;
  }
  var t = e.$hostElement$;
  var i = e.D;
  var a = e.m || newVNode(null, null);
  var o = isHost(n) ? n : h(null, null, n);
  hostTagName = t.tagName;
  if (i.R) {
    o.i = o.i || {};
    i.R.map(function (e) {
      var n = e[0],
        r = e[1];
      return (o.i[r] = t[n]);
    });
  }
  if (r && o.i) {
    for (var u = 0, f = Object.keys(o.i); u < f.length; u++) {
      var l = f[u];
      if (t.hasAttribute(l) && !["key", "ref", "style", "class"].includes(l)) {
        o.i[l] = t[l];
      }
    }
  }
  o.v = null;
  o.l |= 4;
  e.m = o;
  o.p = a.p = t.shadowRoot || t;
  {
    scopeId = t["s-sc"];
  }
  patch(a, o);
};
var attachToAncestor = function (e, n) {
  if (n && !e.I && n["s-p"]) {
    n["s-p"].push(
      new Promise(function (n) {
        return (e.I = n);
      })
    );
  }
};
var scheduleUpdate = function (e, n) {
  {
    e.l |= 16;
  }
  if (e.l & 4) {
    e.l |= 512;
    return;
  }
  attachToAncestor(e, e.A);
  var r = function () {
    return dispatchHooks(e, n);
  };
  return writeTask(r);
};
var dispatchHooks = function (e, n) {
  var r = createTime("scheduleUpdate", e.D.N);
  var t = e.L;
  var i;
  if (n) {
    {
      e.l |= 256;
      if (e.M) {
        e.M.map(function (e) {
          var n = e[0],
            r = e[1];
          return safeCall(t, n, r);
        });
        e.M = undefined;
      }
    }
    {
      i = safeCall(t, "componentWillLoad");
    }
  } else {
    {
      i = safeCall(t, "componentWillUpdate");
    }
  }
  {
    i = enqueue(i, function () {
      return safeCall(t, "componentWillRender");
    });
  }
  r();
  return enqueue(i, function () {
    return updateComponent(e, t, n);
  });
};
var enqueue = function (e, n) {
  return isPromisey(e) ? e.then(n) : n();
};
var isPromisey = function (e) {
  return e instanceof Promise || (e && e.then && typeof e.then === "function");
};
var updateComponent = function (e, n, r) {
  return __awaiter(void 0, void 0, void 0, function () {
    var t, i, a, o, u, f, l;
    return __generator(this, function (s) {
      i = e.$hostElement$;
      a = createTime("update", e.D.N);
      o = i["s-rc"];
      if (r) {
        attachStyles(e);
      }
      u = createTime("render", e.D.N);
      {
        callRender(e, n, i, r);
      }
      if (o) {
        o.map(function (e) {
          return e();
        });
        i["s-rc"] = undefined;
      }
      u();
      a();
      {
        f = (t = i["s-p"]) !== null && t !== void 0 ? t : [];
        l = function () {
          return postUpdateComponent(e);
        };
        if (f.length === 0) {
          l();
        } else {
          Promise.all(f).then(l);
          e.l |= 4;
          f.length = 0;
        }
      }
      return [2];
    });
  });
};
var callRender = function (e, n, r, t) {
  try {
    n = n.render();
    {
      e.l &= ~16;
    }
    {
      e.l |= 2;
    }
    {
      {
        {
          renderVdom(e, n, t);
        }
      }
    }
  } catch (n) {
    consoleError(n, e.$hostElement$);
  }
  return null;
};
var postUpdateComponent = function (e) {
  var n = e.D.N;
  var r = e.$hostElement$;
  var t = createTime("postUpdate", n);
  var i = e.L;
  var a = e.A;
  {
    safeCall(i, "componentDidRender");
  }
  if (!(e.l & 64)) {
    e.l |= 64;
    {
      addHydratedFlag(r);
    }
    {
      safeCall(i, "componentDidLoad");
    }
    t();
    {
      e.O(r);
      if (!a) {
        appDidLoad();
      }
    }
  } else {
    {
      safeCall(i, "componentDidUpdate");
    }
    t();
  }
  {
    e.k(r);
  }
  {
    if (e.I) {
      e.I();
      e.I = undefined;
    }
    if (e.l & 512) {
      nextTick(function () {
        return scheduleUpdate(e, false);
      });
    }
    e.l &= ~(4 | 512);
  }
};
var forceUpdate = function (e) {
  {
    var n = getHostRef(e);
    var r = n.$hostElement$.isConnected;
    if (r && (n.l & (2 | 16)) === 2) {
      scheduleUpdate(n, false);
    }
    return r;
  }
};
var appDidLoad = function (e) {
  {
    addHydratedFlag(doc.documentElement);
  }
  nextTick(function () {
    return emitEvent(win, "appload", { detail: { namespace: NAMESPACE } });
  });
};
var safeCall = function (e, n, r) {
  if (e && e[n]) {
    try {
      return e[n](r);
    } catch (e) {
      consoleError(e);
    }
  }
  return undefined;
};
var addHydratedFlag = function (e) {
  return e.classList.add("hydrated");
};
var getValue = function (e, n) {
  return getHostRef(e).V.get(n);
};
var setValue = function (e, n, r, t) {
  var i = getHostRef(e);
  var a = i.$hostElement$;
  var o = i.V.get(n);
  var u = i.l;
  var f = i.L;
  r = parsePropertyValue(r, t.P[n][0]);
  var l = Number.isNaN(o) && Number.isNaN(r);
  var s = r !== o && !l;
  if ((!(u & 8) || o === undefined) && s) {
    i.V.set(n, r);
    if (f) {
      if (t.U && u & 128) {
        var c = t.U[n];
        if (c) {
          c.map(function (e) {
            try {
              f[e](r, o, n);
            } catch (e) {
              consoleError(e, a);
            }
          });
        }
      }
      if ((u & (2 | 16)) === 2) {
        scheduleUpdate(i, false);
      }
    }
  }
};
var proxyComponent = function (e, n, r) {
  var t;
  if (n.P) {
    if (e.watchers) {
      n.U = e.watchers;
    }
    var i = Object.entries(n.P);
    var a = e.prototype;
    i.map(function (e) {
      var t = e[0],
        i = e[1][0];
      if (i & 31 || (r & 2 && i & 32)) {
        Object.defineProperty(a, t, {
          get: function () {
            return getValue(this, t);
          },
          set: function (e) {
            setValue(this, t, e, n);
          },
          configurable: true,
          enumerable: true,
        });
      } else if (r & 1 && i & 64) {
        Object.defineProperty(a, t, {
          value: function () {
            var e = [];
            for (var n = 0; n < arguments.length; n++) {
              e[n] = arguments[n];
            }
            var r = getHostRef(this);
            return r.j.then(function () {
              var n;
              return (n = r.L)[t].apply(n, e);
            });
          },
        });
      }
    });
    if (r & 1) {
      var o = new Map();
      a.attributeChangedCallback = function (e, r, t) {
        var i = this;
        plt.jmp(function () {
          var u = o.get(e);
          if (i.hasOwnProperty(u)) {
            t = i[u];
            delete i[u];
          } else if (
            a.hasOwnProperty(u) &&
            typeof i[u] === "number" &&
            i[u] == t
          ) {
            return;
          } else if (u == null) {
            var f = getHostRef(i);
            var l = f === null || f === void 0 ? void 0 : f.l;
            if (!(l & 8) && l & 128 && t !== r) {
              var s = f.L;
              var c = n.U[e];
              c === null || c === void 0
                ? void 0
                : c.forEach(function (n) {
                    if (s[n] != null) {
                      s[n].call(s, t, r, e);
                    }
                  });
            }
            return;
          }
          i[u] = t === null && typeof i[u] === "boolean" ? false : t;
        });
      };
      e.observedAttributes = Array.from(
        new Set(
          __spreadArray(
            __spreadArray(
              [],
              Object.keys((t = n.U) !== null && t !== void 0 ? t : {}),
              true
            ),
            i
              .filter(function (e) {
                var n = e[0],
                  r = e[1];
                return r[0] & 15;
              })
              .map(function (e) {
                var r = e[0],
                  t = e[1];
                var i = t[1] || r;
                o.set(i, r);
                if (t[0] & 512) {
                  n.R.push([r, i]);
                }
                return i;
              }),
            true
          )
        )
      );
    }
  }
  return e;
};
var initializeComponent = function (e, n, r, t) {
  return __awaiter(void 0, void 0, void 0, function () {
    var e, t, i, a, o, u, f, l;
    return __generator(this, function (s) {
      switch (s.label) {
        case 0:
          if (!((n.l & 32) === 0)) return [3, 3];
          n.l |= 32;
          e = loadModule(r);
          if (!e.then) return [3, 2];
          t = uniqueTime();
          return [4, e];
        case 1:
          e = s.sent();
          t();
          s.label = 2;
        case 2:
          if (!e.isProxied) {
            {
              r.U = e.watchers;
            }
            proxyComponent(e, r, 2);
            e.isProxied = true;
          }
          i = createTime("createInstance", r.N);
          {
            n.l |= 8;
          }
          try {
            new e(n);
          } catch (e) {
            consoleError(e);
          }
          {
            n.l &= ~8;
          }
          {
            n.l |= 128;
          }
          i();
          fireConnectedCallback(n.L);
          if (e.style) {
            a = e.style;
            o = getScopeId(r);
            if (!styles.has(o)) {
              u = createTime("registerStyles", r.N);
              registerStyle(o, a, !!(r.l & 1));
              u();
            }
          }
          s.label = 3;
        case 3:
          f = n.A;
          l = function () {
            return scheduleUpdate(n, true);
          };
          if (f && f["s-rc"]) {
            f["s-rc"].push(l);
          } else {
            l();
          }
          return [2];
      }
    });
  });
};
var fireConnectedCallback = function (e) {
  {
    safeCall(e, "connectedCallback");
  }
};
var connectedCallback = function (e) {
  if ((plt.l & 1) === 0) {
    var n = getHostRef(e);
    var r = n.D;
    var t = createTime("connectedCallback", r.N);
    if (!(n.l & 1)) {
      n.l |= 1;
      var i = void 0;
      {
        i = e.getAttribute(HYDRATE_ID);
        if (i) {
          if (r.l & 1) {
            var a = addStyle(e.shadowRoot, r);
            e.classList.remove(a + "-h", a + "-s");
          }
          initializeClientHydrate(e, r.N, i, n);
        }
      }
      {
        var o = e;
        while ((o = o.parentNode || o.host)) {
          if (
            (o.nodeType === 1 && o.hasAttribute("s-id") && o["s-p"]) ||
            o["s-p"]
          ) {
            attachToAncestor(n, (n.A = o));
            break;
          }
        }
      }
      if (r.P) {
        Object.entries(r.P).map(function (n) {
          var r = n[0],
            t = n[1][0];
          if (t & 31 && e.hasOwnProperty(r)) {
            var i = e[r];
            delete e[r];
            e[r] = i;
          }
        });
      }
      {
        initializeComponent(e, n, r);
      }
    } else {
      addHostEventListeners(e, n, r.q);
      if (n === null || n === void 0 ? void 0 : n.L) {
        fireConnectedCallback(n.L);
      } else if (n === null || n === void 0 ? void 0 : n.F) {
        n.F.then(function () {
          return fireConnectedCallback(n.L);
        });
      }
    }
    t();
  }
};
var disconnectInstance = function (e) {
  {
    safeCall(e, "disconnectedCallback");
  }
};
var disconnectedCallback = function (e) {
  return __awaiter(void 0, void 0, void 0, function () {
    var n;
    return __generator(this, function (r) {
      if ((plt.l & 1) === 0) {
        n = getHostRef(e);
        {
          if (n.Y) {
            n.Y.map(function (e) {
              return e();
            });
            n.Y = undefined;
          }
        }
        if (n === null || n === void 0 ? void 0 : n.L) {
          disconnectInstance(n.L);
        } else if (n === null || n === void 0 ? void 0 : n.F) {
          n.F.then(function () {
            return disconnectInstance(n.L);
          });
        }
      }
      return [2];
    });
  });
};
var patchCloneNode = function (e) {
  var n = e.cloneNode;
  e.cloneNode = function (e) {
    var r = this;
    var t = r.shadowRoot && supportsShadow;
    var i = n.call(r, t ? e : false);
    if (!t && e) {
      var a = 0;
      var o = void 0,
        u = void 0;
      var f = [
        "s-id",
        "s-cr",
        "s-lr",
        "s-rc",
        "s-sc",
        "s-p",
        "s-cn",
        "s-sr",
        "s-sn",
        "s-hn",
        "s-ol",
        "s-nr",
        "s-si",
      ];
      for (; a < r.childNodes.length; a++) {
        o = r.childNodes[a]["s-nr"];
        u = f.every(function (e) {
          return !r.childNodes[a][e];
        });
        if (o) {
          if (i.__appendChild) {
            i.__appendChild(o.cloneNode(true));
          } else {
            i.appendChild(o.cloneNode(true));
          }
        }
        if (u) {
          i.appendChild(r.childNodes[a].cloneNode(true));
        }
      }
    }
    return i;
  };
};
var patchSlotAppendChild = function (e) {
  e.__appendChild = e.appendChild;
  e.appendChild = function (e) {
    var n = (e["s-sn"] = getSlotName(e));
    var r = getHostSlotNode(this.childNodes, n);
    if (r) {
      var t = getHostSlotChildNodes(r, n);
      var i = t[t.length - 1];
      return i.parentNode.insertBefore(e, i.nextSibling);
    }
    return this.__appendChild(e);
  };
};
var patchChildSlotNodes = function (e, n) {
  var r = (function (e) {
    __extends(n, e);
    function n() {
      return (e !== null && e.apply(this, arguments)) || this;
    }
    n.prototype.item = function (e) {
      return this[e];
    };
    return n;
  })(Array);
  if (n.l & 8) {
    var t = e.__lookupGetter__("childNodes");
    Object.defineProperty(e, "children", {
      get: function () {
        return this.childNodes.map(function (e) {
          return e.nodeType === 1;
        });
      },
    });
    Object.defineProperty(e, "childElementCount", {
      get: function () {
        return e.children.length;
      },
    });
    Object.defineProperty(e, "childNodes", {
      get: function () {
        var e = t.call(this);
        if ((plt.l & 1) === 0 && getHostRef(this).l & 2) {
          var n = new r();
          for (var i = 0; i < e.length; i++) {
            var a = e[i]["s-nr"];
            if (a) {
              n.push(a);
            }
          }
          return n;
        }
        return r.from(e);
      },
    });
  }
};
var getSlotName = function (e) {
  return e["s-sn"] || (e.nodeType === 1 && e.getAttribute("slot")) || "";
};
var getHostSlotNode = function (e, n) {
  var r = 0;
  var t;
  for (; r < e.length; r++) {
    t = e[r];
    if (t["s-sr"] && t["s-sn"] === n) {
      return t;
    }
    t = getHostSlotNode(t.childNodes, n);
    if (t) {
      return t;
    }
  }
  return null;
};
var getHostSlotChildNodes = function (e, n) {
  var r = [e];
  while ((e = e.nextSibling) && e["s-sn"] === n) {
    r.push(e);
  }
  return r;
};
var bootstrapLazy = function (e, n) {
  if (n === void 0) {
    n = {};
  }
  var r;
  var t = createTime();
  var i = [];
  var a = n.exclude || [];
  var o = win.customElements;
  var u = doc.head;
  var f = u.querySelector("meta[charset]");
  var l = doc.createElement("style");
  var s = [];
  var c = doc.querySelectorAll("[".concat(HYDRATED_STYLE_ID, "]"));
  var v;
  var d = true;
  var p = 0;
  Object.assign(plt, n);
  plt.X = new URL(n.resourcesUrl || "./", doc.baseURI).href;
  {
    plt.l |= 2;
  }
  {
    for (; p < c.length; p++) {
      registerStyle(
        c[p].getAttribute(HYDRATED_STYLE_ID),
        convertScopedToShadow(c[p].innerHTML),
        true
      );
    }
  }
  var h = false;
  e.map(function (e) {
    e[1].map(function (r) {
      var t;
      var u = { l: r[0], N: r[1], P: r[2], q: r[3] };
      if (u.l & 4) {
        h = true;
      }
      {
        u.P = r[2];
      }
      {
        u.q = r[3];
      }
      {
        u.R = [];
      }
      {
        u.U = (t = r[4]) !== null && t !== void 0 ? t : {};
      }
      var f = n.transformTagName ? n.transformTagName(u.N) : u.N;
      var l = (function (e) {
        __extends(n, e);
        function n(n) {
          var r = e.call(this, n) || this;
          n = r;
          registerHost(n, u);
          if (u.l & 1) {
            {
              {
                n.attachShadow({ mode: "open" });
              }
            }
          }
          return r;
        }
        n.prototype.connectedCallback = function () {
          var e = this;
          if (v) {
            clearTimeout(v);
            v = null;
          }
          if (d) {
            s.push(this);
          } else {
            plt.jmp(function () {
              return connectedCallback(e);
            });
          }
        };
        n.prototype.disconnectedCallback = function () {
          var e = this;
          plt.jmp(function () {
            return disconnectedCallback(e);
          });
        };
        n.prototype.componentOnReady = function () {
          return getHostRef(this).F;
        };
        return n;
      })(HTMLElement);
      {
        {
          patchChildSlotNodes(l.prototype, u);
        }
        {
          patchCloneNode(l.prototype);
        }
        {
          patchSlotAppendChild(l.prototype);
        }
      }
      u.W = e[0];
      if (!a.includes(f) && !o.get(f)) {
        i.push(f);
        o.define(f, proxyComponent(l, u, 1));
      }
    });
  });
  if (h) {
    l.innerHTML += SLOT_FB_CSS;
  }
  {
    l.innerHTML += i + HYDRATED_CSS;
  }
  if (l.innerHTML.length) {
    l.setAttribute("data-styles", "");
    u.insertBefore(l, f ? f.nextSibling : u.firstChild);
    var m =
      (r = plt.H) !== null && r !== void 0 ? r : queryNonceMetaTagContent(doc);
    if (m != null) {
      l.setAttribute("nonce", m);
    }
  }
  d = false;
  if (s.length) {
    s.map(function (e) {
      return e.connectedCallback();
    });
  } else {
    {
      plt.jmp(function () {
        return (v = setTimeout(appDidLoad, 30));
      });
    }
  }
  t();
};
var Fragment = function (e, n) {
  return n;
};
var addHostEventListeners = function (e, n, r, t) {
  if (r) {
    r.map(function (r) {
      var t = r[0],
        i = r[1],
        a = r[2];
      var o = getHostListenerTarget(e, t);
      var u = hostListenerProxy(n, a);
      var f = hostListenerOpts(t);
      plt.ael(o, i, u, f);
      (n.Y = n.Y || []).push(function () {
        return plt.rel(o, i, u, f);
      });
    });
  }
};
var hostListenerProxy = function (e, n) {
  return function (r) {
    try {
      {
        if (e.l & 256) {
          e.L[n](r);
        } else {
          (e.M = e.M || []).push([n, r]);
        }
      }
    } catch (e) {
      consoleError(e);
    }
  };
};
var getHostListenerTarget = function (e, n) {
  if (n & 4) return doc;
  if (n & 8) return win;
  return e;
};
var hostListenerOpts = function (e) {
  return (e & 2) !== 0;
};
var setNonce = function (e) {
  return (plt.H = e);
};
var hostRefs = new WeakMap();
var getHostRef = function (e) {
  return hostRefs.get(e);
};
var registerInstance = function (e, n) {
  return hostRefs.set((n.L = e), n);
};
var registerHost = function (e, n) {
  var r = { l: 0, $hostElement$: e, D: n, V: new Map() };
  {
    r.j = new Promise(function (e) {
      return (r.k = e);
    });
  }
  {
    r.F = new Promise(function (e) {
      return (r.O = e);
    });
    e["s-p"] = [];
    e["s-rc"] = [];
  }
  addHostEventListeners(e, r, n.q);
  return hostRefs.set(e, r);
};
var isMemberInElement = function (e, n) {
  return n in e;
};
var consoleError = function (e, n) {
  return (0, console.error)(e, n);
};
var cmpModules = new Map();
var loadModule = function (e, n, r) {
  var t = e.N.replace(/-/g, "_");
  var i = e.W;
  var a = cmpModules.get(i);
  if (a) {
    return a[t];
  }
  /*!__STENCIL_STATIC_IMPORT_SWITCH__*/ return import(
    "./".concat(i, ".entry.js").concat("")
  ).then(function (e) {
    {
      cmpModules.set(i, e);
    }
    return e[t];
  }, consoleError);
};
var styles = new Map();
var win = typeof window !== "undefined" ? window : {};
var doc = win.document || { head: {} };
var H =
  win.HTMLElement ||
  (function () {
    function e() {}
    return e;
  })();
var plt = {
  l: 0,
  X: "",
  jmp: function (e) {
    return e();
  },
  raf: function (e) {
    return requestAnimationFrame(e);
  },
  ael: function (e, n, r, t) {
    return e.addEventListener(n, r, t);
  },
  rel: function (e, n, r, t) {
    return e.removeEventListener(n, r, t);
  },
  ce: function (e, n) {
    return new CustomEvent(e, n);
  },
};
var supportsShadow = true;
var promiseResolve = function (e) {
  return Promise.resolve(e);
};
var supportsConstructableStylesheets = (function () {
  try {
    new CSSStyleSheet();
    return typeof new CSSStyleSheet().replaceSync === "function";
  } catch (e) {}
  return false;
})();
var queueDomReads = [];
var queueDomWrites = [];
var queueTask = function (e, n) {
  return function (r) {
    e.push(r);
    if (!queuePending) {
      queuePending = true;
      if (n && plt.l & 4) {
        nextTick(flush);
      } else {
        plt.raf(flush);
      }
    }
  };
};
var consume = function (e) {
  for (var n = 0; n < e.length; n++) {
    try {
      e[n](performance.now());
    } catch (e) {
      consoleError(e);
    }
  }
  e.length = 0;
};
var flush = function () {
  consume(queueDomReads);
  {
    consume(queueDomWrites);
    if ((queuePending = queueDomReads.length > 0)) {
      plt.raf(flush);
    }
  }
};
var nextTick = function (e) {
  return promiseResolve().then(e);
};
var writeTask = queueTask(queueDomWrites, true);
export {
  Fragment as F,
  H,
  Host as a,
  bootstrapLazy as b,
  createEvent as c,
  forceUpdate as f,
  getElement as g,
  h,
  promiseResolve as p,
  registerInstance as r,
  setNonce as s,
};
//# sourceMappingURL=index-5bae4795.js.map
