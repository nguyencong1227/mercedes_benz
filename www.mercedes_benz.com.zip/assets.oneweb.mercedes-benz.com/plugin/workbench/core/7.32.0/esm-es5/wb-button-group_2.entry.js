/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
import {
  r as registerInstance,
  h,
  a as Host,
  g as getElement,
} from "./index-5bae4795.js";
import { t as transformTagNames } from "./transform-tag-name-a73790cf.js";
import { D as DEFAULT_WORKBENCH_THEME } from "./themes-a8a87b7c.js";
import { q as querySelectorAllAsArray } from "./query-selector-all-as-array-1350920c.js";
import { i as isBaseCharsEqual } from "./is-base-chars-equal-c50e4e34.js";
var buttonGroupCss =
  ":host{--btn-group-color-focus:var(--wb-blue-50)}:host([theme=dark]){--btn-group-color-focus:var(--wb-blue-45)}:host{--focus-color:var(--btn-group-color-focus);-ms-flex-align:center;align-items:center;display:-ms-inline-flexbox;display:inline-flex}:host([direction=horizontal]){-ms-flex-direction:row;flex-direction:row}:host([direction=vertical]){-ms-flex-align:stretch;align-items:stretch;-ms-flex-direction:column;flex-direction:column}::slotted(.wb-popover){-webkit-margin-start:-.0625rem;margin-inline-start:-.0625rem}";
var ButtonGroupComponent$1 = (function () {
  function t(t) {
    var o = this;
    registerInstance(this, t);
    this.TagNames = transformTagNames(this, "wb-button-group", [
      "wb-button-group-item",
    ]);
    this.handleSlotChange = function () {
      o.updateButtonReferences();
      o.passPropsToButtons();
    };
    this.theme = DEFAULT_WORKBENCH_THEME;
    this.variant = "default";
    this.direction = "horizontal";
  }
  t.prototype.handleClick = function (t) {
    var o = this;
    if (this.variant !== "radio") {
      return;
    }
    var r = t.composedPath();
    var e = r.find(function (t) {
      return isBaseCharsEqual(
        t === null || t === void 0 ? void 0 : t.tagName,
        o.TagNames.WbButtonGroupItem
      );
    });
    if (!e || e.disabled) {
      return;
    }
    this.buttons.forEach(function (t) {
      t.selected = t === e;
    });
  };
  t.prototype.onDirectionChange = function () {
    this.passPropsToButtons();
  };
  t.prototype.passPropsToButtons = function () {
    var t = this;
    this.buttons.forEach(function (o) {
      o.theme = t.theme;
      o.direction = t.direction;
    });
  };
  t.prototype.updateButtonReferences = function () {
    this.buttons = querySelectorAllAsArray(
      this.el,
      this.TagNames.WbButtonGroupItem
    );
  };
  t.prototype.render = function () {
    return h(
      Host,
      { role: "group", class: "wb-button-group" },
      h("slot", { onSlotchange: this.handleSlotChange })
    );
  };
  Object.defineProperty(t.prototype, "el", {
    get: function () {
      return getElement(this);
    },
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(t, "watchers", {
    get: function () {
      return { direction: ["onDirectionChange"] };
    },
    enumerable: false,
    configurable: true,
  });
  return t;
})();
ButtonGroupComponent$1.style = buttonGroupCss;
var buttonGroupItemCss =
  ":host{--btn-group-item-bg-color-selected:var(--wb-black);--btn-group-item-border-color-selected:var(--wb-grey-20);--btn-group-item-text-color-selected:var(--wb-white)}:host([theme=dark]){--btn-group-item-bg-color-selected:var(--wb-white);--btn-group-item-border-color-selected:var(--wb-grey-70);--btn-group-item-text-color-selected:var(--wb-black)}:host([direction=horizontal]:not(:first-child)){-webkit-margin-start:-.0625rem;margin-inline-start:-.0625rem}:host([direction=vertical]:not(:first-child)){-webkit-margin-before:-.0625rem;margin-block-start:-.0625rem}:host([direction=horizontal]:not(:last-child)) .wb-button::part(button){border-end-end-radius:0;border-start-end-radius:0}:host([direction=horizontal]:not(:first-child)) .wb-button::part(button){border-end-start-radius:0;border-start-start-radius:0}:host([direction=vertical]:not(:last-child)) .wb-button::part(button){border-end-end-radius:0;border-end-start-radius:0}:host([direction=vertical]:not(:first-child)) .wb-button::part(button){border-start-end-radius:0;border-start-start-radius:0}:host([variant=primary][selected]:not([disabled])) .wb-button::part(button){-webkit-animation:initial;animation:initial;background-color:var(--btn-bg-color-active);cursor:default}:host([variant=primary][selected]:not([disabled])) .wb-button::part(button):active,:host([variant=primary][selected]:not([disabled])) .wb-button::part(button):focus{-webkit-box-shadow:var(--btn-box-shadow);box-shadow:var(--btn-box-shadow)}:host([variant=secondary][selected]:not([disabled])) .wb-button::part(button),:host([variant=secondary][selected]:not([disabled])) .wb-button::part(button):active,:host([variant=secondary][selected]:not([disabled])) .wb-button::part(button):focus,:host([variant=secondary][selected]:not([disabled])) .wb-button::part(button):hover{-webkit-animation:initial;animation:initial;background-color:var(--btn-group-item-bg-color-selected);border-color:var(--btn-group-item-border-color-selected);color:var(--btn-group-item-text-color-selected);cursor:default}:host([selected]) .wb-button::part(button):focus,:host([selected]) .wb-button::part(button):focus-within{-webkit-box-shadow:0 0 0 .0625rem var(--focus-color) inset;box-shadow:0 0 0 .0625rem var(--focus-color) inset}.wb-button{max-width:none;width:100%}.wb-button[icon-only]{min-width:3.5rem}.wb-button::part(button):focus,.wb-button::part(button):focus-within{z-index:1}:host([direction=horizontal][variant=primary]:not(:first-child)) .wb-button::part(button){border-inline-start-color:var(--wb-blue-35)}:host([direction=vertical][variant=primary]:not(:first-child)) .wb-button::part(button){border-block-start-color:var(--wb-blue-35)}";
var ButtonGroupComponent = (function () {
  function t(t) {
    registerInstance(this, t);
    this.TagNames = transformTagNames(this, "wb-button-group-item", [
      "wb-button",
    ]);
    this.direction = undefined;
    this.selected = false;
    this.loading = false;
    this.variant = undefined;
    this.size = "l";
    this.iconOnly = false;
    this.disabled = false;
    this.href = undefined;
    this.download = undefined;
    this.rel = undefined;
    this.target = undefined;
    this.theme = DEFAULT_WORKBENCH_THEME;
  }
  t.prototype.render = function () {
    var t = this.TagNames.WbButton;
    return h(
      Host,
      { role: "group", class: "wb-button-group-item" },
      h(
        t,
        {
          loading: this.loading,
          variant: this.variant,
          size: this.size,
          theme: this.theme,
          iconOnly: this.iconOnly,
          disabled: this.disabled,
          href: this.href,
          download: this.download,
          rel: this.rel,
          target: this.target,
        },
        h("slot", { name: "icon", slot: "icon" }),
        h("slot", null)
      )
    );
  };
  return t;
})();
ButtonGroupComponent.style = buttonGroupItemCss;
export {
  ButtonGroupComponent$1 as wb_button_group,
  ButtonGroupComponent as wb_button_group_item,
};
//# sourceMappingURL=wb-button-group_2.entry.js.map
