/**
 * @preserve
 * Licenses of bundled dependencies can be found in dependencies-licenses.txt
 */
var MERCEDES_BENZ_LIGHT = "light";
var MERCEDES_BENZ_DARK = "dark";
var DEFAULT_WORKBENCH_THEME = MERCEDES_BENZ_LIGHT;
export {
  DEFAULT_WORKBENCH_THEME as D,
  MERCEDES_BENZ_LIGHT as M,
  MERCEDES_BENZ_DARK as a,
};
//# sourceMappingURL=themes-a8a87b7c.js.map
